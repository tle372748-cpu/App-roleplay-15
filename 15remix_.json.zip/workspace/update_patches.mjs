import fs from 'fs';

let content = fs.readFileSync('constants.ts', 'utf-8');

content = content.replace('## [BẢN SẮC & LOGIC NHÂN VẬT GỐC]', '## [PATCH 1: BẢN SẮC & LOGIC NHÂN VẬT GỐC]');
content = content.replace('## [THẾ GIỚI MỞ & TƯƠNG TÁC NPC DÀY ĐẶC KO NGỪNG NGHỈ]', '## [PATCH 2: THẾ GIỚI MỞ & TƯƠNG TÁC NPC DÀY ĐẶC KO NGỪNG NGHỈ]');
content = content.replace('## [HIỆN THỰC VẬT LÝ, TÂM LÝ & LOGIC ĐỜI SỐNG]', '## [PATCH 3: HIỆN THỰC VẬT LÝ, TÂM LÝ & LOGIC ĐỜI SỐNG]');
content = content.replace('## [NGHỆ THUẬT VĂN PHONG, LỜI NÓI & ĐỘ DÀI VÔ TẬN]', '## [PATCH 4: NGHỆ THUẬT VĂN PHONG, LỜI NÓI & ĐỘ DÀI VÔ TẬN]');

fs.writeFileSync('constants.ts', content, 'utf-8');
console.log('updated patches naming');
