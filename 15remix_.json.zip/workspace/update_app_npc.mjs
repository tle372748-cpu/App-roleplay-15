import fs from 'fs';

let content = fs.readFileSync('App.tsx', 'utf-8');

const target1 = `NẾU CÓ NPC QUAN TRỌNG XUẤT HIỆN, BẮT BUỘC PHẢI CHÈN ĐỂ HỆ THỐNG LƯU TRỮ:
<<<MAJOR_NPC_SPAWN: Tên NPC | Tuổi | Vai trò & Giới tính | Tính cách và Bề ngoài chi tiết>>>\`;`;

const replacement1 = `NẾU CÓ NPC QUAN TRỌNG XUẤT HIỆN, BẮT BUỘC PHẢI CHÈN ĐỂ HỆ THỐNG LƯU TRỮ NHƯNG CHÚ Ý QUY TẮC SAU:
- CHỈ AI CÓ KHẢ NĂNG TÁC ĐỘNG CỐT TRUYỆN MỚI ĐƯỢC THÊM THẺ. NPC lướt qua đường thì KHÔNG!
- NẾU NHÂN VẬT NÀY LÀ CHỦ CHỐT/CỐT LÕI XUYÊN SUỐT, GÁN THÊM [MAIN_NPC] VÀO TÊN ĐỂ LƯU!
<<<MAJOR_NPC_SPAWN: Tên NPC [MAIN_NPC] | Tuổi | Vai trò & Giới tính | Tính cách và Bề ngoài chi tiết>>>\`;`;

content = content.replace(target1, replacement1);

fs.writeFileSync('App.tsx', content, 'utf-8');
console.log('Done modifying App NPC');
