import fs from 'fs';

let content = fs.readFileSync('App.tsx', 'utf-8');

const target1 = `          if (i === 0 && isContinuePrompt) {
              nextPrompt = \`[SYSTEM - CONTEXT OVERRIDE]: User đang nằm im/ngủ hoặc gửi một khoảng lặng ("..."). BẠN BẮT BUỘC PHẢI TIẾP NỐI VÀ DẪN DẮT CÂU CHUYỆN. TUYỆT ĐỐI KHÔNG hành động thay hay nói thay lời của User! Hãy tự triển khai tiếp các sự kiện, suy nghĩ, hành động của các AI/NPC hoặc miêu tả thêm không gian xung quanh một cách sống động.\`;
          } else if (i > 0) {
              nextPrompt = \`[SYSTEM - INTERNAL OVERRIDE]: Continue narrative immediately. Do not repeat.\`;
          }`;

const replacement1 = `          if (i === 0 && isContinuePrompt) {
              nextPrompt = \`[SYSTEM - CONTEXT OVERRIDE]: User đang nằm im/ngủ hoặc gửi một khoảng lặng ("..."). BẠN BẮT BUỘC PHẢI DẪN DẮT CÂU CHUYỆN THẬT DÀI (1500 TỪ), ĐƯA NPC VÀO HỘI THOẠI! Áp dụng trọn vẹn 5 Patch! Tuyệt đối không viết cụt lủn!\`;
          } else if (i === 0) {
              nextPrompt = \`[SYSTEM - NORMAL OVERRIDE]: LỆNH TỐI CAO: BẠN PHẢI TRẢ LỜI NGƯỜI DÙNG BẰNG MỘT TRƯỜNG ĐOẠN KHỔNG LỒ (HÀNG NGÀN TỪ, TRÊN 10 ĐOẠN VĂN). Không được đáp hời hợt, phải kéo dài hoàn cảnh, đẩy cảm xúc lên tận cùng, cho NPC vào nói chuyện, miêu tả va chạm vật lý cực sâu! THIẾU 5 PATCH BẠN SẼ BỊ PENALTY!\`;
          } else if (i > 0) {
              nextPrompt = \`[SYSTEM - INTERNAL OVERRIDE]: Continue narrative immediately, keeping the monstrous length and supreme details. Do not repeat.\`;
          }`;

content = content.replace(target1, replacement1);
fs.writeFileSync('App.tsx', content, 'utf-8');
console.log('Done applying normal overrides');
