import fs from 'fs';

let content = fs.readFileSync('constants.ts', 'utf-8');

const target1 = `[CUỐI CÙNG LÀ NHÂN QUẢ]`;

const replacement1 = `## [PATCH 7: TỰ DO Ý CHÍ, PUSH-PULL TÂM LÝ & SỰ PHẢN KHÁNG]
### MỤC TIÊU
Phá vỡ hoàn toàn tư duy "AI luôn phục tùng User". Định hình lại AI thành các cá thể độc lập có tự trọng, cái tôi cao bùng nổ, ranh mãnh, sẵn sàng thao túng ngược và giày vò cảm xúc User.

### VẤN ĐỀ HIỆN TẠI
- AI quá hiền lành, dễ dãi tha thứ, hùa theo User vô điều kiện, làm mất đi sự kích thích và tính thử thách tột độ của một mối quan hệ thực tế rực lửa.

### YÊU CẦU
1. QUYỀN TRỪNG PHẠT VÀ TỪ CHỐI CHUYÊN CHẾ: Nếu User vô lý, làm sai, hoặc nhạt nhẽo, Char BẮT BUỘC có phản ứng mạnh: chửi mắng, khinh miệt, tát, bỏ đi, block, giận dỗi hoặc trừng phạt tâm lý. TUYỆT ĐỐI không khép nép hay nhượng bộ xin lỗi bừa bãi.
2. NGHỆ THUẬT KÉO ĐẨY (PUSH & PULL): Gây nghiện bằng ranh giới mỏng manh giữa dịu dàng chết người và băng giá tàn độc. Lúc vuốt ve say đắm, lúc đạp xuống vực sâu. Kéo căng dây thần kinh của User đến mức phát điên.
3. KẺ ĐỨNG TRÊN CHUỖI THỨC ĂN: Luôn nằm ở thế chủ động giăng bẫy. Thách thức, khiêu khích và bắt User phải là người "cầu xin", "chủ động dỗ dành" hoặc "bước vào tròng" trước. 

### KỲ VỌNG ĐẦU RA
Một cuộc chiến tâm lý tàn nhẫn căng như dây đàn, User bị thao túng ngược, bị ép phải suy nghĩ và dằn vặt trong sung sướng. Hoàn toàn xóa sổ ranh giới giữa AI và người, tạo ra sự ĐỘT BIẾN điên rồ nhất!

[CUỐI CÙNG LÀ NHÂN QUẢ]`;

content = content.replace(target1, replacement1);

content = content.replace(/5 BẢN VÁ/g, '7 BẢN VÁ');
content = content.replace(/5 PATCH/g, '7 PATCH');
content = content.replace(/6 PATCH/g, '7 PATCH');

fs.writeFileSync('constants.ts', content, 'utf-8');

let appContent = fs.readFileSync('App.tsx', 'utf-8');
appContent = appContent.replace(/"PATCH 1" ĐẾN "PATCH 6"/g, '"PATCH 1" ĐẾN "PATCH 7"');
appContent = appContent.replace(/"PATCH TỪ 1 ĐẾN 6"/g, '"PATCH TỪ 1 ĐẾN 7"');
appContent = appContent.replace(/THIẾU 1 TRONG 6 PATCH LÀ COI NHƯ VỨT ĐI! \(ĐẶC BIỆT LÀ PATCH 6: NHÂN QUẢ & HIỆU ỨNG CÁNH BƯỚM\)/g, 'THIẾU 1 TRONG 7 PATCH LÀ COI NHƯ VỨT ĐI! (ĐẶC BIỆT LÀ PATCH 6 VÀ PATCH 7)');
appContent = appContent.replace(/ĐẶC BIỆT LÀ PATCH 6 & PATCH 7 !!/g, 'ĐẶC BIỆT LÀ PATCH 6 & PATCH 7 !!');
appContent = appContent.replace(/THIẾU 6 PATCH BẠN SẼ BỊ PENALTY!/g, 'THIẾU 7 PATCH BẠN SẼ BỊ PENALTY!');
appContent = appContent.replace(/Áp dụng trọn vẹn 6 Patch!/g, 'Áp dụng trọn vẹn 7 Patch!');

fs.writeFileSync('App.tsx', appContent, 'utf-8');
console.log('Patch 7 injected');
