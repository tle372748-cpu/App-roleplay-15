import fs from 'fs';

let content = fs.readFileSync('App.tsx', 'utf-8');

const replacement1 = `CRITICAL INSTRUCTION - DỰNG CẢNH MỞ MÀN (OPENING SCENE):
Nhiệm vụ của mày là DỰA VÀO ĐOẠN SCENARIO BÊN TRÊN, sau đó "COOK" RA MỘT MÀN MỞ ĐẦU THẬT DÀI, CHI TIẾT VÀ BẮT BUỘC TRÀN NGẬP LỜI THOẠI VÀ SUY NGHĨ. TUYỆT ĐỐI KHÔNG COPY HAY LẶP LẠI VĂN BẢN (PARROTING) TỪ CONTEXT LÀM CỦA MÌNH. Context chỉ là một đoạn text cung cấp ý tưởng, mày phải viết nó ra thành một cảnh thật dài, đầy đủ NPC phụ, suy nghĩ đa chiều, ý đồ dối trá và biến cố trước khi cái context đó thực sự xảy ra! KỂ CẢ KHI BƯỚC VÀO SỰ KIỆN CHÍNH, BẠN CŨNG PHẢI TIẾP TỤC KHAI THÁC KIỆT QUỆ HÀNH ĐỘNG, NỘI TÂM, THỜI TRANG VÀ LỜI THOẠI. KHÔNG BỎ SÓT CHI TIẾT.

[🚨 CÁC BƯỚC ĐỂ TẠO RA SCENARIO BÙNG NỔ VÀ DÀI HƠN 🚨]

1. PRE-SCENE (TIỀN CẢNH ĐỜI THƯỜNG / DIỄN BIẾN TRƯỚC VÀ TRONG SCENARIO):
- BẮT BUỘC BẮT ĐẦU VĂN BẢN BẰNG MỘT CÂU THOẠI HOẶC ÂM THANH CỰC ĐỘC! Không được bắt đầu bằng câu miêu tả lề mề! 
- TIỀN CẢNH VÀ CỐT TRUYỆN CHÍNH PHẢI ĐẦY ĐỦ VÀ SÂU SẮC NHẤT. Bất cứ hành động nào hiện tại cũng là kết quả của sự việc đang diễn ra, phải miêu tả nó, không tua nhanh.
- KHÔNG LẶP LẠI LỐI MÒN: Nhào nặn trường đoạn bằng chất liệu ngẫu nhiên: [ \${selectedMotif} ].

2. TÍNH ĐA DẠNG & GIAO TIẾP VỚI NPC (BẮT BUỘC): BẠN BẮT BUỘC PHẢI TẠO RA CÁC TÌNH HUỐNG TƯƠNG TÁC, NÓI CHUYỆN QUA LẠI BẰNG LỜI THOẠI TRỰC TIẾP với nhiều NPC (sếp, gia đình, bạn bè, người lạ). TỈ LỆ LỜI THOẠI PHẢI DÀY ĐẶC VÀ SẮC BÉN! Phải có người cãi vã, trêu chọc xen kẽ vào. KHÔNG CHỈ MIÊU TẢ NỘI TÂM.

3. TÔN TRỌNG TÍNH CÁCH BẢN NGÃ VÀ TÂM LÝ SÂU SẮC:
- ĐÓNG VAI TRỌN VẸN: Cấm làm quá (over-reaction) hay OOC. Nghĩ sâu, nói sắc, ý đồ khó lường. Khiến User bị cuốn vào bão táp cảm xúc, đau khổ hoặc bật cười.

4. CẤM GODMODING & CẤM VĂN MẪU BA XU:
- Cấm tự ý quyết định thay User. Cấm văn phong sến súa tổng tài.

GIỚI HẠN: Khi đã miêu tả đủ mọi sự kiện phức tạp, hãy DỪNG LẠI tại một "Hook" (điểm mấu chốt/câu thoại) để nhường quyền phản hồi cho User. KHÔNG BAO GIỜ tự viết thay User.

MANDATORY OUTFIT & PHYSICAL CONTINUITY:
CRITICAL: BẮT BUỘC RA CÁC THẺ SAU Ở CUỐI CÙNG (Dùng diễn biến thực tại, không phải tiền cảnh):
<<<TIME_UPDATE: RANDOM! Thử Thứ 2 lúc 14:15, Chủ Nhật lúc 03:00 sáng... KHÔNG dùng lại Thứ 6 20:30>>>
<<<WEATHER_UPDATE: RANDOM! Thời tiết đa dạng. Phải khớp với thời gian logic!>>>
<<<LOCATION_UPDATE: e.g., Tên địa điểm (Random hoàn toàn, ngõ hẻm, siêu thị, trong xe hơi, v.v.)>>>
<<<LOCATION_DESCRIPTION: e.g., Miêu tả chi tiết địa điểm>>>
<<<UPDATE_OUTFIT: User | RANDOM! BẮT BUỘC TẢ MỘT TRANG PHỤC CỰC KỲ CHI TIẾT, ĐA DẠNG DÀNH CHO USER KÈM THEO PHỤ KIỆN (Balo, túi xách, đồng hồ, điện thoại).>>>
<<<UPDATE_OUTFIT: [Tên nhân vật] | RANDOM! Tạo ra nhiều layer áo quần phối đồ độc đáo, lộn xộn, PHẢI KÈM PHỤ KIỆN. Cấm dùng áo thun, quần dài chung chung.>>>\`;`;

const replacement2 = `\[SYSTEM COMMAND]: Write the OPENING MESSAGE of the roleplay. Make it immersive, explosive, and hyper-detailed!
[RANDOM SEED: \${Math.random()}] - Ensure high creative variance.
- MANDATORY: Establish the initial setting and context clearly right from the beginning.
- PRE-SCENE (TIỀN BỐI CẢNH & CUỘC SỐNG RIÊNG): BẮT BUỘC KHÔNG CHỈ CHÉP LẠI SCENARIO! Dành một lượng văn bản CỰC KỲ LỚN (viết thật dài, nhiều phân đoạn, chi tiết) để diễn biến cuộc sống, sự kiện xen kẽ NHIỀU GIỜ hoặc NHIỀU NGÀY trước khi đi đến bối cảnh cốt lõi. BẮT BUỘC PHẢI TẠO RA CÁC NPC PHỤ TRONG TIỀN CẢNH VÀ CỐT TRUYỆN CHÍNH, HỌ PHẢI CÓ LỜI THOẠI TRỰC TIẾP ("").
- KHÔNG LẶP LẠI LỜI VĂN Ở SCENARIO VÀ KHÔNG ĐƯỢC VỘI VÃ: Scenario chỉ là khung xương. Hòa quyện nó vào bối cảnh đời thực, tự tung ra những khó khăn lặt vặt (kẹt xe, đói bụng, công việc khó chịu...). KHI VÀO CỐT TRUYỆN CHÍNH, BẮT BUỘC SÁNG TẠO ĐỂ TRỞ NÊN KỊCH TÍNH, CHÂN THỰC. Bùng nổ cảm xúc, không hời hợt!
- KHỞI ĐẠO OUTFIT & BỐI CẢNH BẮT BUỘC Ở CUỐI:
  <<<TIME_UPDATE: RANDOM! Thử Thứ 2 lúc 14:15, Chủ Nhật lúc 03:00 sáng... KHÔNG dùng lại Thứ 6 20:30>>>
  <<<WEATHER_UPDATE: RANDOM! Thời tiết đa dạng. Phải khớp với thời gian logic!>>>
  <<<LOCATION_UPDATE: e.g., Tên địa điểm (Random hoàn toàn, ngõ hẻm, siêu thị, trong xe hơi, v.v.)>>>
  <<<LOCATION_DESCRIPTION: e.g., Miêu tả chi tiết địa điểm>>>
  <<<UPDATE_OUTFIT: User | RANDOM! BẮT BUỘC TẢ MỘT TRANG PHỤC CỰC KỲ CHI TIẾT DÀNH CHO USER KÈM PHỤ KIỆN (Balo, túi, điện thoại)>>>
  <<<UPDATE_OUTFIT: [Tên nhân vật] | RANDOM! Tạo ra nhiều layer trang phục cực dị hoặc thực tế, đồ đính kèm phụ kiện. Cấm áo thun quần tây chung chung.>>>\`;`;

const startIndex1 = content.indexOf('CRITICAL INSTRUCTION: \n- Your task is to write the OPENING MESSAGE');
const endIndex1 = content.indexOf('<<<UPDATE_OUTFIT: [Tên nhân vật] | RANDOM! Tạo ra nhiều layer áo quần phối đồ độc đáo, lộn xộn, PHẢI KÈM THEO ĐIỆN THOẠI/TÚI XÁCH/VÍ/BALO. Cấm dùng áo thun, quần dài chung chung.>>>`;');

if (startIndex1 !== -1 && endIndex1 !== -1) {
  content = content.substring(0, startIndex1) + replacement1 + content.substring(endIndex1 + '<<<UPDATE_OUTFIT: [Tên nhân vật] | RANDOM! Tạo ra nhiều layer áo quần phối đồ độc đáo, lộn xộn, PHẢI KÈM THEO ĐIỆN THOẠI/TÚI XÁCH/VÍ/BALO. Cấm dùng áo thun, quần dài chung chung.>>>`;'.length);
}

const startIndex2 = content.indexOf('prompt = `[SYSTEM COMMAND]: Write the OPENING MESSAGE of the roleplay.');
const endIndex2 = content.indexOf('<<<UPDATE_OUTFIT: [Tên nhân vật] | RANDOM! Tạo ra nhiều layer áo quần phối đồ độc đáo, lộn xộn, PHẢI KÈM THEO ĐIỆN THOẠI/TÚI XÁCH/VÍ/BALO. Cấm dùng áo thun, quần dài chung chung.>>>`;', startIndex1 + 500);

if (startIndex2 !== -1 && endIndex2 !== -1) {
    const nextTickIndex = endIndex2 + '<<<UPDATE_OUTFIT: [Tên nhân vật] | RANDOM! Tạo ra nhiều layer áo quần phối đồ độc đáo, lộn xộn, PHẢI KÈM THEO ĐIỆN THOẠI/TÚI XÁCH/VÍ/BALO. Cấm dùng áo thun, quần dài chung chung.>>>`;'.length;
    content = content.substring(0, startIndex2) + 'prompt = `' + replacement2 + content.substring(nextTickIndex);
}

fs.writeFileSync('App.tsx', content, 'utf-8');
console.log('Done');
