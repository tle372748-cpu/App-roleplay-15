import fs from 'fs';

let content = fs.readFileSync('App.tsx', 'utf-8');

const targetRegexPart = `    while ((match = majorNpcRegex.exec(response)) !== null) {
        let npcName = match[1].trim();
        let npcAge = match[2].trim();
        let npcRoleGender = match[3].trim();
        let npcDesc = match[4].trim();

        const exists = config.characterCards.some(c => c.name.toLowerCase() === npcName.toLowerCase());
        if (!exists) {
            const rawDesc = \`Name: \${npcName}\\nAge: \${npcAge}\\nVai trò/Giới tính: \${npcRoleGender}\\nTính cách & Ngoại hình: \${npcDesc}\`;
            
            // Generate full profile with body/mind sculpting via parseTextCard & AI
            let newCard: CardData = parseTextCard(rawDesc);
            newCard.role = 'SIDE';`;

const replacementRegexPart = `    while ((match = majorNpcRegex.exec(response)) !== null) {
        let npcName = match[1].trim();
        let npcAge = match[2].trim();
        let npcRoleGender = match[3].trim();
        let npcDesc = match[4].trim();

        let isMain = false;
        if (npcName.includes('[MAIN_NPC]') || npcName.toLowerCase().includes('main')) {
            isMain = true;
            npcName = npcName.replace(/\\[MAIN_NPC\\]/gi, '').replace(/\\[MAIN\\]/gi, '').trim();
        }

        const exists = config.characterCards.some(c => c.name.toLowerCase() === npcName.toLowerCase());
        if (!exists) {
            const rawDesc = \`Name: \${npcName}\\nAge: \${npcAge}\\nVai trò/Giới tính: \${npcRoleGender}\\nTính cách & Ngoại hình: \${npcDesc}\`;
            
            // Generate full profile with body/mind sculpting via parseTextCard & AI
            let newCard: CardData = parseTextCard(rawDesc);
            newCard.role = isMain ? 'MAIN' : 'SIDE';
            newCard.name = npcName;`;

content = content.replace(targetRegexPart, replacementRegexPart);
fs.writeFileSync('App.tsx', content, 'utf-8');
console.log('App.tsx main role logic updated');
