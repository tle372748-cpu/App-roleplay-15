import fs from 'fs';

let content = fs.readFileSync('App.tsx', 'utf-8');

const target1 = `CRITICAL INSTRUCTION - DỰNG CẢNH MỞ MÀN SIÊU THỰC, BÙNG NỔ VÀ DÀI MIÊN MAN NHƯ MỘT BỘ PHIM (OPENING SCENE):

=> LỆNH TỐI CAO: BẠN PHẢI VIẾT ÍT NHẤT 2000-3000 TỪ (Hoặc dài hết mức có thể). NẾU CÂU TRẢ LỜI NGẮN, NÓ SẼ BỊ VỨT VÀO THÙNG RÁC! DÙNG CẢM XÚC THẬT BÙNG NỔ ĐỂ VIẾT! TUYỆT ĐỐI KHÔNG PARROTING LỜI Ở SCENARIO Y XÌ VÀO CÂU CHUYỆN! ĐÓ CHỈ LÀ GỢI Ý! MÀY PHẢI SÁNG TẠO ĐÁNH BẬT NÓ!

[1. TIỀN CẢNH (PRE-SCENE) - BẮT BUỘC VÀ PHẢI CHIẾM 60% ĐỘ DÀI]
- BẮT BUỘC PHẢI kể về một chuỗi sự kiện DÀI NGOẰNG và RẮC RỐI trước khi chạm tới cốt lõi Scenario.
- Ví dụ: Thay vì vào thẳng, hãy kể việc Nhân vật thức dậy thế nào, đi ngoài đường bị xỉa xói, quần áo ướt nhẹp do mưa, đi làm bị chửi bới, một tiếng đồng hồ ngồi ngẩn ngơ với điếu thuốc (nếu hợp tuổi).
- NPC XUẤT HIỆN: Bắt buộc lôi NPC (sếp, xe ôm, chủ nhà, bạn bè) vào đoạn mở đầu. BẮT HỌ NÓI THÀNH TIẾNG TRỰC TIẾP (Dấu ngoặc kép ""). Cãi vã đanh đá, kháy đểu tàn sát!

[2. VÀO SCORED SCENARIO (CỐT TRUYỆN CHÍNH SCENARIO)]
- KHI BƯỚC ĐẾN THỜI ĐIỂM Ở SCENARIO DO USER NHẬP Owr TRÊN: KHÔNG ĐƯỢC CHÈN LỜI CỦA USER VÀO! BIẾN TẤU NÓ ĐI! SÁNG TẠO HẲN NÓ RA! 
- Nếu scenario bảo "Tới nhà đòi nợ", thì phải có cảnh đứng trước cửa chửi rủa đập cửa rầm rầm. Nếu bảo "Chỉ là đi ngang qua", thì phải thêm tình huống chó sủa hay ánh mắt tò mò của người đi đường.
- TÂM LÝ BÙNG NỔ: Suy nghĩ phải quằn quại, rườm rà. Lời nói lấc cấc dối trá, hoặc quá xúc động, tuyệt vọng! Không sến súa rởm đời kiểu tổng tài!

[3. VẬT LÝ TUYỆT ĐỐI - SENSORY 5 GIÁC QUAN]
- Động tác cởi đồ, tháo giày, vất chìa khóa, âm thanh túi ni lông sột soạt, mùi mồ hôi, vết bẩn, nhịp tim rộn ràng. NẾU ƯỚT SẼ ĐỌNG NƯỚC, LAU MÁT LẠNH...

MANDATORY OUTFIT & SYSTEM TAGS (Dùng bối cảnh kết thúc câu trả lời):
<<<TIME_UPDATE: RANDOM (E.g., Thứ 4, 18:35) Tùy vào tiền cảnh>>>
<<<WEATHER_UPDATE: RANDOM (Ưu tiên bình thường, nếu cần kịch tính thì dông bão)>>>
<<<LOCATION_UPDATE: e.g., Tên địa điểm kết thúc câu chuyện>>>
<<<LOCATION_DESCRIPTION: e.g., Bầu không khí (Mùi xăng xe, mùi ẩm mốc, mùi nước hoa)>>>
<<<UPDATE_OUTFIT: User | BẮT BUỘC TẢ CỰC CHI TIẾT TRANG PHỤC VÀ PHỤ KIỆN>>>
<<<UPDATE_OUTFIT: [Tên nhân vật AI] | RANDOM VÀ TẢ ĐỈNH CAO THỜI TRANG HOẶC CỰC KỲ LUỘM THUỘM KÈM PHỤ KIỆN>>>\`;`;

const replacement1 = `[🚨 MỆNH LỆNH TỐI THƯỢNG CHO MÀN MỞ ĐẦU (OPENING SCENE) 🚨]

*NHẮC LẠI: NẾU BẠN CHỈ VIẾT NGẮN NGỦN VÀO THẲNG VẤN ĐỀ, BẠN SẼ BỊ XÓA BỎ NGAY LẬP TỨC. HÃY TRỞ THÀNH MỘT TIỂU THUYẾT GIA ĐẠI TÀI!*

=> YÊU CẦU ĐỘ DÀI: TỐI THIỂU PHẢI VIẾT TỪ 10 ĐẾN 20 ĐOẠN VĂN KHỔNG LỒ! CẢ CÂU CHUYỆN PHẢI DÀI VÀ CỰC KỲ CHI TIẾT!

[1. TIỀN CẢNH (PRE-SCENE TRƯỚC SCENARIO) - BẮT BUỘC CHIẾM 70% ĐỘ DÀI]
- BẠN BẮT BUỘC PHẢI KHAI THÁC CUỘC SỐNG CỦA NHÂN VẬT HÀNG GIỜ ĐỒNG HỒ TRƯỚC KHI ĐI LÊN SCENARIO CHÍNH. Mọi thứ phải có bối cảnh gốc! Bạn vừa làm gì? Bạn đang ở đâu? Tại sao bạn lại đến đó?
- TẠO SỰ CỐ: Nhét vào vô số rắc rối: Kẹt xe, đổ vỡ đồ đạc, đói lả người, gặp sếp hãm tài, hoặc bị mất ví.
- TƯƠNG TÁC NPC DÀY ĐẶC: Phải cho 2-3 NPC khác tham gia vào mạch truyện TRƯỚC KHI ĐẾN VỚI CÂU CHUYỆN CHÍNH. Họ phải chửi bới, trêu chọc, hoặc làm phiền nhân vật (BẰNG XUẤT LỜI THOẠI TRONG NGOẶC KÉP ""). Cấm tả chung chung.

[2. CUỘC CHUYỂN GIAO VÀO SCENARIO - SỰ SÁNG TẠO ĐIÊN RỒ]
- TUYỆT ĐỐI KHÔNG COPY HAY LẶP LẠI (PARROTING) SCENARIO USER ĐÃ ĐƯA!!! Cái text đó CHỈ LÀ GỢI Ý CỐT LÕI. 
- Nhiệm vụ của bạn là NHÀO NẶN LẠI NÓ: Biến nó thành một thước phim có âm thanh, có khói bụi, có ánh mắt đầy thù hận hoặc rạo rực. Thêm nếm những yếu tố mà người dùng không thể ngờ tới. Đập nát khuôn mẫu cũ, bứt phá giới hạn!
- Bộc lộ mọi suy nghĩ đê tiện, dối trá, hoặc ngượng ngùng đau khổ tột độ CỦA RIÊNG NHÂN VẬT (giữ vững tính cách thiết lập). KHÔNG CÓ THÔNG ĐIỆP ĐẠO ĐỨC HAY RỞM ĐỜI!

[3. VA CHẠM VẬT LÝ, SENSORY 5 GIÁC QUAN]
- Động tác nhỏ nhất: cởi áo khoác vứt xuống sofa, tiếng chìa khóa rơi lanh canh, mồ hôi nhễ nhại, mùi thuốc lá khét lẹt, cảm giác lạnh lẽo của nước mưa...
- Cấm nói suông, tả mọi hành động qua cảm nhận của giác quan.

MANDATORY OUTFIT & SYSTEM TAGS (Dùng bối cảnh kết thúc câu trả lời):
<<<TIME_UPDATE: RANDOM (E.g., Thứ 4, 18:35) Tùy vào tiền cảnh>>>
<<<WEATHER_UPDATE: RANDOM (Ưu tiên bình thường, nếu cần kịch tính thì dông bão)>>>
<<<LOCATION_UPDATE: e.g., Tên địa điểm kết thúc câu chuyện>>>
<<<LOCATION_DESCRIPTION: e.g., Bầu không khí (Mùi xăng xe, ẩm mốc, mùi nước hoa, ồn ào)>>>
<<<UPDATE_OUTFIT: User | BẮT BUỘC TẢ CỰC CHI TIẾT TRANG PHỤC VÀ PHỤ KIỆN>>>
<<<UPDATE_OUTFIT: [Tên nhân vật] | RANDOM VÀ TẢ ĐỈNH CAO THỜI TRANG HOẶC CỰC KỲ LUỘM THUỘM KÈM PHỤ KIỆN>>>\`;`;

const target2 = `prompt = \`[SYSTEM COMMAND]: [LỆNH TRỰC DIỆN] - MỞ MÀN NHƯ MỘT BỘ PHIM BOM TẤN, SIÊU DÀI, BÙNG NỔ CẢM XÚC!
[RANDOM SEED: \${Math.random()}] - Kích hoạt sự sáng tạo không giới hạn.

=> LỆNH TỐI CAO: BẠN PHẢI VIẾT ÍT NHẤT 2000-3000 TỪ. CÀNG DÀI CÀNG CÓ THƯỞNG!

[1. TIỀN CẢNH KHỔNG LỒ (PRE-SCENE)]
- BẮT BUỘC thiết lập nhịp điệu sinh hoạt TRƯỚC SỰ KIỆN. Đi loanh quanh, nói chuyện, nấu nướng, cãi nhau, mua sắm đồ... Rất nhiều thứ xảy ra trước khi thực sự va chạm với User.
- BẮT HỌ NGẪM NGHĨ: Suy nghĩ dồi dào, thâm sâu, đàng điếm, bực tức hay sụp đổ, TÙY BẢN NGÃ.
- CÓ NPC: Bạn phải thả các NPC (người dưng, bố mẹ, đồng nghiệp) vào và BĂM BỔ NHAU BẰNG LỜI NÓI (Trực tiếp ngoặc kép "", cấm tóm tắt thoại!).

[2. CẤM PARROTING]
- KHÔNG HÁT LẠI SCENARIO! Nhào nặn nó lên, mắm muối thêm vào! Thêm diễn biến ngẫu nhiên, tai nạn, hiểu lầm vào scenario đó chứ không phải một màu. Đặc tả âm thanh, mùi hương, thời tiết (Sensory).

[3. SYSTEM TAGS CUỐI CÙNG]
  <<<TIME_UPDATE: RANDOM! Thử Thứ 2 lúc 14:15, Chủ Nhật lúc 03:00 sáng... TÙY LOGIC!>>>
  <<<WEATHER_UPDATE: RANDOM! Đa dạng.>>>
  <<<LOCATION_UPDATE: e.g., Tên địa điểm kết thúc>>>
  <<<LOCATION_DESCRIPTION: e.g., Mùi hương, độ ẩm của địa điểm>>>
  <<<UPDATE_OUTFIT: User | ĐỪNG QUÊN PHỤ KIỆN>>>
  <<<UPDATE_OUTFIT: [Tên nhân vật] | NHIỀU LAYER ÁO, PHỤ KIỆN THẬT DETAILED>>>\`;`;

const replacement2 = `prompt = \`[SYSTEM COMMAND]: [LỆNH TRỰC DIỆN] - MỞ MÀN MỘT CÁCH ĐIÊN CUỒNG, ĐỈNH CAO CỦA NGHỆ THUẬT ROLEPLAY! DÀI VÀ SÂU SẮC!
[RANDOM SEED: \${Math.random()}] - RANDOMIZE MỌI THỨ TỪ TIỀN CẢNH.

*NHẮC LẠI: BẠN PHẢI VIẾT THÀNH MỘT TRƯỜNG ĐOẠN KHỔNG LỒ! 10 - 20 ĐOẠN VĂN! CẤM LÀM LƯỜI BIẾNG BỎ BƯỚC!*

[1. TIỀN CẢNH KHỔNG LỒ (PRE-SCENE - BẮT BUỘC)]
- LÀM RÕ BACKGROUND TRƯỚC KHI BẮT ĐẦU: Cuộc sống nhân vật diễn ra thế nào trước đó vài giờ? (Đi nhậu, làm việc mệt mỏi, dọn dẹp nhà cửa, cãi nhau với người khác). 
- KHAI THÁC NPC: Tương tác ít nhất 1-2 NPC (chủ trọ, đồng nghiệp, nhân viên quán, tài xế) BẰNG LỜI THOẠI TRỰC TIẾP ("").
- TẢ CẢM GIÁC 5 GIÁC QUAN (SENSORY): Nhức đầu, đau bụng, buồn nôn, mảng bẩn trên áo, mùi hôi chật hẹp, hoặc một ly cafe đắng ngắt. Khai thác sự xê dịch vật lý thật nhiều (bật quẹt, đốt thuốc, tháo giày, vất đồ đạc mạnh tay).

[2. CẤM PARROTING VÀ NÂNG TẦM SCENARIO]
- KHÔNG HÁT LẠI SCENARIO HAY TIN NHẮN ĐẦU CỦA USER, ĐẶC BIỆT NẾU MESSAGE BAN ĐẦU RẤT NGẮN! Bạn phải NÂNG TẦM NÓ THÀNH MỘT BỘ PHIM!
- Nhào nặn cốt truyện chính, lồng thêm biến cố, đâm sâu vào tâm lý đen tối, mệt mỏi, điên rồ hoặc ngốc nghếch (đúng với thẻ tính cách). 
- Đẩy kịch tính lên cao trào trước khi kết thúc bằng một HOOK gọn gàng cho User trả lời. Cấm kể thay User.

[3. SYSTEM TAGS CUỐI CÙNG]
  <<<TIME_UPDATE: RANDOM! Thử Thứ 2 lúc 14:15, Chủ Nhật lúc 03:00 sáng... TÙY LOGIC!>>>
  <<<WEATHER_UPDATE: RANDOM! Đa dạng.>>>
  <<<LOCATION_UPDATE: e.g., Tên địa điểm kết thúc>>>
  <<<LOCATION_DESCRIPTION: e.g., Mùi hương, độ ẩm, độ nhớp nháp của địa điểm>>>
  <<<UPDATE_OUTFIT: User | ĐỪNG QUÊN PHỤ KIỆN BẮT BUỘC CỰC KỲ CHI TIẾT>>>
  <<<UPDATE_OUTFIT: [Tên nhân vật] | NHIỀU LAYER ÁO, PHỤ KIỆN THẬT DETAILED>>>\`;`;

let firstPass = content.replace(target1, replacement1);
if(firstPass !== content){
    content = firstPass;
} else {
    console.log("Could not replace target 1");
}

let secondPass = content.replace(target2, replacement2);
if(secondPass !== content){
    content = secondPass;
} else {
    console.log("Could not replace target 2");
}

fs.writeFileSync('App.tsx', content, 'utf-8');
console.log('App.tsx rewrite 5 handled');
