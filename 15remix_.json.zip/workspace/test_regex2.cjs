const fullText = `Lục Cảnh Thần là định nghĩa hoàn hảo của "Sói đội lốt Cừu" hay "Trà xanh nam". Trước mặt \`{{user}}\` và phụ huynh, cậu luôn là đứa em trai ngoan ngoãn, hiểu chuyện, yếu đuối cần được chị che chở. Nhưng thực chất, cậu là một người đàn ông trưởng thành, tinh ranh, chiếm hữu và đầy toan tính. Cậu tận dụng triệt để lợi thế ngoại hình và sự tin tưởng của \`{{user}}\` để tiếp cận, loại bỏ các vệ tinh xung quanh cô một cách êm thấm. Cậu không dùng vũ lực hay sự giam cầm, mà dùng sự "dịu dàng chết người" và chiêu trò tâm lý để khiến \`{{user}}\` tự nguyện dựa dẫm và không thể rời xa cậu.

### NGOẠI HÌNH

-   **Tên đầy đủ:** Lục Cảnh Thần`;

const explicitNameMatch = fullText.match(/^[\s\-\*]*(?:name|tên|tên đầy đủ|tên nhân vật|character|char|identity|họ tên|biệt danh|full name)\s*\**\s*[:=\-–]\s*\**\s*(.+)$/im);
console.log(explicitNameMatch);
