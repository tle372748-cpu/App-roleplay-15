import fs from 'fs';

let content = fs.readFileSync('App.tsx', 'utf-8');

const target1 = `*LỆNH KHẨN: KHI VIẾT, TUYỆT ĐỐI TUÂN THỦ TỪNG CHI TIẾT CỦA "PATCH 1", "PATCH 2", "PATCH 3", VÀ "PATCH 4" (Tương tác NPC, Vật lý, Văn phong, Bản ngã). THIẾU 1 TRONG 4 PATCH LÀ COI NHƯ VỨT ĐI!*`;
const replacement1 = `*LỆNH KHẨN: KHI VIẾT, TUYỆT ĐỐI TUÂN THỦ TỪNG CHI TIẾT CỦA BỘ 5 PATCH CỐT LÕI TỪ "PATCH 1" ĐẾN "PATCH 5". "PATCH 5" BẮT BUỘC BẠN PHẢI VIẾT TIỀN CẢNH SIÊU DÀI, NPC NÓI CHUYỆN LIÊN TỤC VÀ KHAI THÁC LẠI SCENARIO! THIẾU 1 TRONG 5 PATCH LÀ COI NHƯ VỨT ĐI!*`;

const target2 = `=> NGOÀI RA: BẮT BUỘC ỨNG DỤNG "PATCH 1", "PATCH 2", "PATCH 3", VÀ "PATCH 4" LIÊN TỤC KHÔNG NGỪNG NGHỈ XUYÊN SUỐT MÀN MỞ NÀY.`;
const replacement2 = `=> NGOÀI RA: BẮT BUỘC ỨNG DỤNG TỪ "PATCH 1" TỚI "PATCH 5" LIÊN TỤC KHÔNG NGỪNG NGHỈ XUYÊN SUỐT MÀN MỞ NÀY. ĐẶC BIỆT LÀ PATCH 5 !!`;

const target3 = `*LỆNH KHẨN: BẠN BẮT BUỘC PHẢI THỂ HIỆN SỰ HIỆN DIỆN CỦA "PATCH 1", "PATCH 2", "PATCH 3", VÀ "PATCH 4" (Đã quy định ở trên) VÀO MÀN MỞ QUAN TRỌNG NÀY!*`;
const replacement3 = `*LỆNH KHẨN: BẠN BẮT BUỘC PHẢI THỂ HIỆN SỰ HIỆN DIỆN CỦA TẤT CẢ "PATCH TỪ 1 ĐẾN 5" VÀO MÀN MỞ QUAN TRỌNG NÀY! (SỰ KIỆN NPC, VẬT LÝ, BẢN NGÃ VÀ TIỀN CẢNH SIÊU CHI TIẾT)*`;

content = content.replace(target1, replacement1);
content = content.replace(target2, replacement2);
content = content.replace(target3, replacement3);

fs.writeFileSync('App.tsx', content, 'utf-8');
console.log('App.tsx Patch 5 injected');
