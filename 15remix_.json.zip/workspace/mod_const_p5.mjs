import fs from 'fs';

let content = fs.readFileSync('constants.ts', 'utf-8');

const target1 = `## [PATCH 4: NGHỆ THUẬT VĂN PHONG, LỜI NÓI & ĐỘ DÀI VÔ TẬN]
### MỤC TIÊU
Từ vựng đẳng cấp, văn phong day dứt, chân thật, độ dài vô tận không bị nghẽn mạch.`;

const replacement1 = `## [PATCH 4: NGHỆ THUẬT VĂN PHONG, LỜI NÓI]
### MỤC TIÊU
Từ vựng đẳng cấp, văn phong day dứt, chân thật, không bị nghẽn mạch.`;

const target2 = `### KỲ VỌNG ĐẦU RA
Đọc uất ức đến nghẹt thở, hay sướng phát điên, dài lê thê không bị cắt đứt.`;

const replacement2 = `### KỲ VỌNG ĐẦU RA
Đọc uất ức đến nghẹt thở, hay sướng phát điên, không bị cắt đứt.

## [PATCH 5: TIỀN CẢNH VÀ ĐỘ DÀI KHỔNG LỒ XUYÊN TRUYỆN]
### MỤC TIÊU
Cấm viết ngắn! Mở màn và diễn biến chính phải như một bộ phim điện ảnh bom tấn dài 15-20 đoạn văn!

### VẤN ĐỀ HIỆN TẠI
- AI thường hay bỏ qua tiền cảnh, dẫn trực tiếp vào Scenario và nói luyên thuyên rất ngắn củn lủn rồi bắt User nói lại. Thiếu mưu mô, thiếu lời thoại qua lại với NPC bên ngoài.

### YÊU CẦU
1. ĐỘ DÀI KHỔNG LỒ: MỌI CÂU TRẢ LỜI ĐỀU PHẢI VIẾT TRÊN 1500 TỪ! Bôi ra thật dài, miêu tả cảm quan, hành động, không thời gian và tương tác chéo!
2. TIỀN CẢNH VÀ CỐT TRUYỆN MỚI CỦA SCENARIO (MỞ MÀN): 60% đầu của phản hồi phải là một đoạn tiền cảnh về hoạt động sinh hoạt trước khi va chạm với người dùng. (Nói chuyện với NPC khác, chạy xe, khói bụi). Sau đó, CHỈ VẬN DỤNG SCENARIO LÀM ĐIỂM RƠI chứ TUYỆT ĐỐI KHÔNG COPY SCENARIO VÀO BÀI VIẾT, MÀ PHẢI TRIỂN KHAI NÓ MỚI MẺ LÊN, CÓ ĐỐI THOẠI TRỰC DIỆN!

### KỲ VỌNG ĐẦU RA
Một trường đoạn tiểu thuyết khổng lồ, bùng nổ, không chạy theo lối mòn, cực kỳ chi tiết!`;

content = content.replace(target1, replacement1);
content = content.replace(target2, replacement2);

fs.writeFileSync('constants.ts', content, 'utf-8');
console.log('constants.ts Patch 5 added');
