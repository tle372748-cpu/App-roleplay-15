import fs from 'fs';

let content = fs.readFileSync('App.tsx', 'utf-8');

const startIndex = content.indexOf('CRITICAL INSTRUCTION - DỰNG CẢNH MỞ MÀN SIÊU THỰC, CỰC KỲ CHI TIẾT & BÙNG NỔ (OPENING SCENE):');
const endIndex = content.indexOf('<<<UPDATE_OUTFIT: User | [BẮT BUỘC TẢ MỘT TRANG PHỤC CỰC KỲ CHI TIẾT, NỔI BẬT VÀ KHÁC BIỆT DÀNH CHO USER (Không dùng lại đồ cũ)]>>>');

if (startIndex !== -1 && endIndex !== -1) {
    const replacement = `CRITICAL INSTRUCTION - DỰNG CẢNH MỞ MÀN SIÊU THỰC, BÙNG NỔ VÀ DÀI MIÊN MAN NHƯ MỘT BỘ PHIM (OPENING SCENE):

=> LỆNH TỐI CAO: BẠN PHẢI VIẾT ÍT NHẤT 2000-3000 TỪ (Hoặc dài hết mức có thể). NẾU CÂU TRẢ LỜI NGẮN, NÓ SẼ BỊ VỨT VÀO THÙNG RÁC! DÙNG CẢM XÚC THẬT BÙNG NỔ ĐỂ VIẾT! TUYỆT ĐỐI KHÔNG PARROTING LỜI Ở SCENARIO Y XÌ VÀO CÂU CHUYỆN! ĐÓ CHỈ LÀ GỢI Ý DÀNH CHO BẠN BIẾT ĐIỂM RƠI KHÊU GỢI CẢM HỨNG!

[1. TIỀN CẢNH (PRE-SCENE) - BẮT BUỘC VÀ PHẢI CHIẾM 60% ĐỘ DÀI]
- BẮT BUỘC PHẢI kể về một chuỗi sự kiện DÀI NGOẰNG và RẮC RỐI trước khi chạm tới cốt lõi Scenario.
- Ví dụ: Thay vì vào thẳng, hãy kể việc Nhân vật thức dậy thế nào, đi ngoài đường bị xỉa xói, quần áo ướt nhẹp do mưa, đi làm bị chửi bới, một tiếng đồng hồ ngồi ngẩn ngơ với điếu thuốc (nếu hợp tuổi), đánh rớt đồ và nhặt lên.
- Tùy chỉnh motif này làm gợi ý nếu bí: [ \${selectedMotif} ].
- NPC XUẤT HIỆN: Bắt buộc lôi NPC (sếp, xe ôm, chủ nhà, bạn bè, thú cưng, người lạ) vào đoạn mở đầu. BẮT HỌ NÓI THÀNH TIẾNG TRỰC TIẾP (Dấu ngoặc kép ""). Cãi vã đanh đá, kháy đểu tàn sát! Cấm tả chung chung!

[2. VÀO SCORED SCENARIO (CỐT TRUYỆN CHÍNH SCENARIO)]
- KHI BƯỚC ĐẾN THỜI ĐIỂM Ở SCENARIO DO USER NHẬP Ở TRÊN: SÁNG TẠO HẲN NÓ RA CHỨ KHÔNG ĐƯỢC CHÉP LỜI MÀ NHAI LẠI! BIẾN NÓ THÀNH MỘT SỰ THỰC KỊCH TÍNH HOẶC RẤT HÀI HƯỚC.
- Nếu scenario bảo "Tới nhà đòi nợ", thì phải có cảnh đứng trước cửa chửi rủa đập cửa rầm rầm. Nếu bảo "Chỉ là đi ngang qua", thì phải thêm tình huống chó sủa hay ánh mắt tò mò của người đi đường.
- Cảm xúc Bùng Nổ hoặc Tàn Bạo: Suy nghĩ phải quằn quại, rườm rà. Lời nói lấc cấc dối trá, hoặc quá xúc động, tuyệt vọng! Tùy tính cách nhưng phải ĐỈNH KOUT.

[3. VẬT LÝ TUYỆT ĐỐI - SENSORY 5 GIÁC QUAN]
- Động tác cởi đồ, tháo giày, vất chìa khóa, âm thanh túi ni lông sột soạt, mùi mồ hôi, vết bẩn, nhịp tim rộn ràng. NẾU ƯỚT SẼ ĐỌNG NƯỚC, LAU MÁT LẠNH... Cấm miêu tả nội tâm lèo tèo.

[🚨 SYSTEM TAGS BẮT BUỘC PHẢI CÓ Ở DƯỚI CÙNG 🚨]
<<<TIME_UPDATE: RANDOM (Ví dụ: Thứ 4, 18:35, tùy vào tiền cảnh)>>>
<<<WEATHER_UPDATE: [Thời tiết đa dạng: ưu tiên bình thường (nắng đẹp, mây nhẹ, hơi se lạnh), thỉnh thoảng mới dông bão/mưa lớn...]>>>
<<<LOCATION_UPDATE: [Tên địa điểm kết thúc - RANDOM HOÀN TOÀN]>>>
<<<LOCATION_DESCRIPTION: [Miêu tả về mùi hương và độ ẩm của không gian]>>>
`;

    content = content.substring(0, startIndex) + replacement + content.substring(endIndex);
    fs.writeFileSync('App.tsx', content, 'utf-8');
    console.log('updated correctly');
} else {
    console.log('could not find indices');
    console.log(startIndex, endIndex);
}
