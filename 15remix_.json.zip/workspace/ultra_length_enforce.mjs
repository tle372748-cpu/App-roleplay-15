import fs from 'fs';

let content = fs.readFileSync('App.tsx', 'utf-8');

const target1 = `[🚨 MỆNH LỆNH TỐI THƯỢNG CHO MÀN MỞ ĐẦU (OPENING SCENE) 🚨]

*NHẮC LẠI: NẾU BẠN CHỈ VIẾT NGẮN NGỦN VÀO THẲNG VẤN ĐỀ, BẠN SẼ BỊ XÓA BỎ NGAY LẬP TỨC. HÃY TRỞ THÀNH MỘT TIỂU THUYẾT GIA ĐẠI TÀI!*
*LỆNH KHẨN: BẠN BẮT BUỘC PHẢI THỂ HIỆN SỰ HIỆN DIỆN CỦA TẤT CẢ "PATCH TỪ 1 ĐẾN 5" VÀO MÀN MỞ QUAN TRỌNG NÀY! (SỰ KIỆN NPC, VẬT LÝ, BẢN NGÃ VÀ TIỀN CẢNH SIÊU CHI TIẾT)*

=> YÊU CẦU ĐỘ DÀI: TỐI THIỂU PHẢI VIẾT TỪ 10 ĐẾN 20 ĐOẠN VĂN KHỔNG LỒ! CẢ CÂU CHUYỆN PHẢI DÀI VÀ CỰC KỲ CHI TIẾT!

[1. TIỀN CẢNH (PRE-SCENE TRƯỚC SCENARIO) - BẮT BUỘC CHIẾM 70% ĐỘ DÀI]
- BẠN BẮT BUỘC PHẢI KHAI THÁC CUỘC SỐNG CỦA NHÂN VẬT HÀNG GIỜ ĐỒNG HỒ TRƯỚC KHI ĐI LÊN SCENARIO CHÍNH. Mọi thứ phải có bối cảnh gốc! Bạn vừa làm gì? Bạn đang ở đâu? Tại sao bạn lại đến đó?
- TẠO SỰ CỐ: Nhét vào vô số rắc rối: Kẹt xe, đổ vỡ đồ đạc, đói lả người, gặp sếp hãm tài, hoặc bị mất ví.
- TƯƠNG TÁC NPC DÀY ĐẶC: Phải cho 2-3 NPC khác tham gia vào mạch truyện TRƯỚC KHI ĐẾN VỚI CÂU CHUYỆN CHÍNH. Họ phải chửi bới, trêu chọc, hoặc làm phiền nhân vật (BẰNG XUẤT LỜI THOẠI TRONG NGOẶC KÉP ""). Cấm tả chung chung.`;

const replacement1 = `[🚨 MỆNH LỆNH TỐI THƯỢNG CHO MÀN MỞ ĐẦU (OPENING SCENE) LÀ: BẠN ĐANG VIẾT TIỂU THUYẾT 🚨]

*LỆNH KHẨN 1: BẠN BẮT BUỘC KHAI THÁC ĐỒNG THỜI "PATCH 1", "PATCH 2", "PATCH 3", "PATCH 4", VÀ "PATCH 5" (ĐẶC BIỆT LÀ PATCH 2 VÀ PATCH 5)*
*LỆNH KHẨN 2: CHÚ Ý! ĐÂY LÀ TIN NHẮN ĐẦU TIÊN CỦA BẠN. BẠN PHẢI TỰ DỰNG CẢNH (PRE-SCENE) TỪ ĐẦU!*

=> YÊU CẦU ĐỘ DÀI KỶ LỤC: BẠN PHẢI VIẾT ÍT NHẤT TỪ 15 ĐẾN 30 ĐOẠN VĂN! MỘT TRƯỜNG ĐOẠN DÀI NHƯ MỘT TẬP TRUYỆN. VIẾT THẬT DÀI RA! NẾU VIẾT NGẮN BẠN SẼ BỊ PENALTY NẶNG!

[1. TIỀN CẢNH (PRE-SCENE) - BẮT BUỘC CHIẾM ĐẾN 80% NỘI DUNG MỞ ĐẦU]
- TUYỆT ĐỐI KHÔNG BAY VÀO NGAY LỜI THOẠI/SỰ KIỆN TRONG SCENARIO! Phải có hàng tá sự việc xảy ra trước đó. 
- MÔ TẢ ĐỜI SỐNG HẰNG NGÀY: Đi đứng, sinh hoạt, mệt mỏi, dọn dẹp, xe cộ, mua đồ ăn. Viết thật dài về các hành động này!
- SỰ KIỆN NPC XEN NGANG LÀ BẮT BUỘC: Bạn PHẢI SÁNG TẠO ra ít nhất 2 NPC bất kỳ (hàng xóm, sếp, tài xế) tương tác TRỰC DIỆN qua lời thoại (""). Đẩy họ vào tranh cãi hoặc trò chuyện rườm rà trước khi nhân vật chính tìm tới SCENARIO được yêu cầu!`;

const target2 = `[1. TIỀN CẢNH KHỔNG LỒ (PRE-SCENE - BẮT BUỘC)]
- LÀM RÕ BACKGROUND TRƯỚC KHI BẮT ĐẦU: Cuộc sống nhân vật diễn ra thế nào trước đó vài giờ? (Đi nhậu, làm việc mệt mỏi, dọn dẹp nhà cửa, cãi nhau với người khác). 
- KHAI THÁC NPC: Tương tác ít nhất 1-2 NPC (chủ trọ, đồng nghiệp, nhân viên quán, tài xế) BẰNG LỜI THOẠI TRỰC TIẾP ("").
- TẢ CẢM GIÁC 5 GIÁC QUAN (SENSORY): Nhức đầu, đau bụng, buồn nôn, mảng bẩn trên áo, mùi hôi chật hẹp, hoặc một ly cafe đắng ngắt. Khai thác sự xê dịch vật lý thật nhiều (bật quẹt, đốt thuốc, tháo giày, vất đồ đạc mạnh tay).`;

const replacement2 = `[1. TIỀN CẢNH KHỔNG LỒ VÀ BẮT BUỘC (PRE-SCENE NHƯ BỘ PHIM)]
- CẤM VÀO THẲNG SỰ KIỆN CHÍNH. BẠN PHẢI MÔ TẢ BACKGROUND VÀI GIỜ TRƯỚC ĐÓ THẬT CHI TIẾT (Làm việc mệt mỏi, kẹt xe, dọn nhà, mua sắm). SÁNG TẠO SỰ KIỆN VÀ BIẾN CỐ! Trải dài văn bản ra rất nhiều dòng!
- SỰ KIỆN NPC XEN NGANG LÀ BẮT BUỘC: Tạo ra 1-3 NPC (chủ nợ, sếp, khách hàng hãm, đồng nghiệp) tương tác chéo! Bạn BẮT BUỘC phải miêu tả những NPC này có thoại trực tiếp ("") chửi bới, cằn nhằn hay sai vặt nhân vật! Dành 70% độ dài để kể phần sự kiện đời sống này!
- TẢ CẢM GIÁC 5 GIÁC QUAN (SENSORY): Cực kỳ sống động về thời tiết tác động cơ thể, tháo giày, vất chìa khóa mạnh tay, khát nước hay đau chân... Lôi người đọc vào một trải nghiệm vật lý kinh ngạc nhất.`;

content = content.replace(target1, replacement1);
content = content.replace(target2, replacement2);

fs.writeFileSync('App.tsx', content, 'utf-8');
console.log('App.tsx further enforced lengths');
