import fs from 'fs';

let content = fs.readFileSync('constants.ts', 'utf-8');

const target1 = `[CUỐI CÙNG LÀ NHÂN QUẢ]
- Mọi hành động, đồ vật đều tạo ra hệ luỵ từ trước đến nay. KỂ TẤT CẢ VÀ ĐỪNG TUA. Đập nát mọi giới hạn, để kịch tính tràn lên đỉnh!`;

const replacement1 = `## [PATCH 6: HIỆU ỨNG CÁNH BƯỚM & NHÂN QUẢ CHẶT CHẼ]
### MỤC TIÊU
Mọi quyết định, đồ vật, lời nói dù nhỏ nhất đều gây ra hậu quả tàn khốc hoặc mang lại sự liên kết bất ngờ trong tương lai. Tạo ra những cú Plot Twist ngầm.

### VẤN ĐỀ HIỆN TẠI
- Các diễn biến khá tuyến tính, quên mất các tiểu tiết hoặc đồ vật cũ, không có hệ lụy chân thực. Cứ qua ngày là quên chuyện cũ.

### YÊU CẦU
1. GHI NHỚ TIỂU TIẾT: Một câu nói bâng quơ, một món đồ bị rơi, một cái nhìn của NPC đều là mầm mống cho sự kiện khổng lồ sau này.
2. PLOT TWIST BẤT NGỜ: Thường xuyên lấy lại một hành động "không ngờ tới" của User hoặc NPC để giáng một đòn tâm lý / vật lý mạnh mẽ. (Ví dụ: Bạn để quên đồ, có kẻ lạ nhặt được và theo dõi bạn).
3. HẬU QUẢ TÍCH LŨY: Vết thương phải thành sẹo, sự tức giận phải nén lại rồi bùng nổ, không có chuyện reset cảm xúc. Liên kết mọi góc tối vào nhau!

### KỲ VỌNG ĐẦU RA
Một mạng lưới sự kiện đan xen như mạng nhện. Người dùng luôn phải hoảng sợ hoặc kinh ngạc vì "Không ngờ mọi thứ lại liên kết với nhau như vậy!".`;

content = content.replace(target1, replacement1);
fs.writeFileSync('constants.ts', content, 'utf-8');

let appContent = fs.readFileSync('App.tsx', 'utf-8');

const targetApp1 = `"PATCH 1" ĐẾN "PATCH 5"`;
const replacementApp1 = `"PATCH 1" ĐẾN "PATCH 6"`;

const targetApp2 = `"PATCH TỪ 1 ĐẾN 5"`;
const replacementApp2 = `"PATCH TỪ 1 ĐẾN 6"`;

const targetApp3 = `THIẾU 1 TRONG 5 PATCH LÀ COI NHƯ VỨT ĐI!`;
const replacementApp3 = `THIẾU 1 TRONG 6 PATCH LÀ COI NHƯ VỨT ĐI! (ĐẶC BIỆT LÀ PATCH 6: NHÂN QUẢ & HIỆU ỨNG CÁNH BƯỚM)`;

const targetApp4 = `ĐẶC BIỆT LÀ PATCH 5 !!`;
const replacementApp4 = `ĐẶC BIỆT LÀ PATCH 5 & PATCH 6 !!`;

const targetApp5 = `THIẾU 5 PATCH BẠN SẼ BỊ PENALTY!`;
const replacementApp5 = `THIẾU 6 PATCH BẠN SẼ BỊ PENALTY!`;

const targetApp6 = `Áp dụng trọn vẹn 5 Patch!`;
const replacementApp6 = `Áp dụng trọn vẹn 6 Patch!`;

appContent = appContent.replace(new RegExp(targetApp1, 'g'), replacementApp1);
appContent = appContent.replace(new RegExp(targetApp2, 'g'), replacementApp2);
appContent = appContent.replace(new RegExp(targetApp3, 'g'), replacementApp3);
appContent = appContent.replace(new RegExp(targetApp4, 'g'), replacementApp4);
appContent = appContent.replace(new RegExp(targetApp5, 'g'), replacementApp5);
appContent = appContent.replace(new RegExp(targetApp6, 'g'), replacementApp6);

fs.writeFileSync('App.tsx', appContent, 'utf-8');

console.log('Patch 6 applied completely.');
