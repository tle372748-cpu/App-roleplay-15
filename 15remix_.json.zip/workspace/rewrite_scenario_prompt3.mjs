import fs from 'fs';

let content = fs.readFileSync('App.tsx', 'utf-8');

const target = `CRITICAL INSTRUCTION - DỰNG CẢNH MỞ MÀN SIÊU THỰC, CỰC KỲ CHI TIẾT & BÙNG NỔ (OPENING SCENE):
Nhiệm vụ của mày là DỰA VÀO ĐOẠN SCENARIO BÊN TRÊN, KIẾN TẠO MỘT TRƯỜNG ĐOẠN MỞ ĐẦU DÀI CHƯA TỪNG THẤY, VỚI ĐỘ SÂU NHƯ MỘT BỘ PHIM ĐIỆN ẢNH! TUYỆT ĐỐI KHÔNG LẶP LẠI HAY COPY TỪ CONTEXT LÀM CỦA MÌNH. Context chỉ là viên gạch nền, còn mày BẮT BUỘC phải tự xây dựng toàn bộ quá trình TIỀN CẢNH (PRE-SCENE) CỰC KỲ DÀI VÀ NHIỀU BIẾN CỐ TRƯỚC KHI ĐI ĐẾN ĐIỂM RƠI CỦA SCENARIO! KHAI THÁC TẬN CÙNG: Hành vi, Tâm lý, Thoại NPC, Quần áo, Sự xê dịch không gian! KHÔNG BỎ QUA BẤT KỲ VẬT THỂ HAY CHI TIẾT NÀO!

[🚨 CÁC BƯỚC ĐỂ TẠO RA MỘT MÀN MỞ ĐẦU CHẤN ĐỘNG VÀ DÀI HƠN BAO GIỜ HẾT 🚨]

1. TIỀN CẢNH (PRE-SCENE) - BẮT BUỘC & CHIẾM THỜI LƯỢNG LỚN:
- CẤM VÀO THẲNG VẤN ĐỀ CỦA SCENARIO NGAY LẬP TỨC!
- Mở màn BẰNG MỘT ĐOẠN THOẠI TRỰC TIẾP/ ÂM THANH SỐNG ĐỘNG (Ví dụ: Tiếng chửi bới, tiếng còi xe, lời càu nhàu khốn nạn). Không bắt đầu bằng miêu tả ỉ ôi.
- TUYỆT ĐỐI PHẢI DỰNG LÊN MỘT LOẠT SỰ KIỆN Ở TIỀN CẢNH (trước sự kiện cốt lõi vài giờ, hoặc vài phút nhưng diễn biến cực rườm rà). Ví dụ: Nhân vật vừa cãi nhau với sếp, vừa làm đổ vỏ cơm, vừa ướt sũng do mắc mưa, hoặc bị đòi nợ. TÓM LẠI PHẢI CÓ SỰ KIỆN TRƯỚC! CẤM TUA NHANH. CHỈ KHI TIỀN CẢNH ĐÃ NO NÊ MỚI BƯỚC VÀO SỰ KIỆN CHÍNH.
- KHÔNG LẶP LẠI LỐI MÒN: Áp dụng motif này để định hướng nếu bí ý tưởng: [ \${selectedMotif} ].

2. THẾ GIỚI NPC DÀY ĐẶC & CÓ TIẾNG NÓI (BẮT BUỘC):
- KHÔNG ĐƯỢC CHỈ CÓ MỘT NÌNH NHÂN VẬT THỦ DÂM TINH THẦN!
- BẰNG MỌI GIÁ, HÃY NHÉT CÁC NPC (Bố mẹ, bạn thân phản bội, chủ nhà trọ, con chó ngoạm dép, khách hàng hãm lờ) VÀO KHUNG CẢNH VÀ BẮT HỌ NÓI CHUYỆN (Bằng ngoặc kép "")! Sự tương tác chéo này PHẢI DÀY CẶC, SẮC BÉN, có cãi vã, có chèn ép, có mỉa mai, và NHÂN VẬT PHẢI ĐÁP TRẢ TINH TẾ HOẶC CỤC CẰN tùy tính cách. Số lượng lời thoại phải bằng hoặc hơn độ dài nội tâm!

3. TÂM LÝ XUYÊN THẤU & VẬT LÝ TUYỆT ĐỐI (SENSORY):
- ĐÓNG VAI TRỌN VẸN 100% CẤM OOC. Suy nghĩ thâm sâu, đàng điếm, lươn lẹo, dối trá hay ngây thơ đều THỂ HIỆN RA TẬN CÙNG THEO BẢN NGÃ CHỨ KHÔNG GƯỢNG ÉP. Làm bạn đọc phải Cắn răn, Há hốc, Bật cười, hoặc Vỡ nát màng nước mắt!
- VA CHẠM VẬT LÝ LIÊN TỤC: Rút điện thoại, cắn môi rách da rớm máu, mồ hôi đầm đìa, cởi áo khoác lạnh ngắt. SÁNG TẠO NHIỀU HOẠT ĐỘNG!

4. CẤM VĂN MẪU, CẤM ĐẠO LÝ XUÔNG, CẤM THUẬT LẠI:
- KHÔNG MÔ TẢ ĐẠI LƯỢC. MÔ TẢ TẬN GỐC RỄ.
- CẤM TỪ NGỮ: "chiếm hữu", "con mồi", "khuôn mặt rách nát", "đôi mắt thâm sâu".
- KHÔNG BAO GIỜ TỰ HÀNH ĐỘNG HỘ USER HAY MIÊU TẢ CẢM XÚC CỦA USER. TÔN TRỌNG TÍNH ĐỘC LẬP TƯƠNG ĐỐI.

[🚨 SYSTEM TAGS BẮT BUỘC PHẢI CÓ Ở DƯỚI CÙNG 🚨]`;

const replacement = `CRITICAL INSTRUCTION - DỰNG CẢNH MỞ MÀN SIÊU THỰC, BÙNG NỔ VÀ DÀI MIÊN MAN NHƯ MỘT BỘ PHIM (OPENING SCENE):

=> LỆNH TỐI CAO: BẠN PHẢI VIẾT ÍT NHẤT 2000-3000 TỪ (Hoặc dài hết mức có thể). NẾU CÂU TRẢ LỜI NGẮN, NÓ SẼ BỊ VỨT VÀO THÙNG RÁC! DÙNG CẢM XÚC THẬT BÙNG NỔ ĐỂ VIẾT! TUYỆT ĐỐI KHÔNG PARROTING LỜI Ở SCENARIO Y XÌ VÀO CÂU CHUYỆN! ĐÓ CHỈ LÀ GỢI Ý DÀNH CHO BẠN BIẾT ĐIỂM RƠI!

[1. TIỀN CẢNH (PRE-SCENE) - BẮT BUỘC VÀ PHẢI CHIẾM 60% ĐỘ DÀI]
- BẮT BUỘC PHẢI kể về một chuỗi sự kiện DÀI NGOẰNG và RẮC RỐI trước khi chạm tới cốt lõi Scenario.
- Ví dụ: Thay vì vào thẳng, hãy kể việc Nhân vật thức dậy thế nào, đi ngoài đường bị xỉa xói, quần áo ướt nhẹp do mưa, đi làm bị chửi bới, một tiếng đồng hồ ngồi ngẩn ngơ với điếu thuốc (nếu hợp tuổi).
- Tùy chỉnh motif này làm gợi ý nếu bí: [ \${selectedMotif} ].
- NPC XUẤT HIỆN: Bắt buộc lôi NPC (sếp, xe ôm, chủ nhà, bạn bè) vào đoạn mở đầu. BẮT HỌ NÓI THÀNH TIẾNG TRỰC TIẾP (Dấu ngoặc kép ""). Cãi vã đanh đá, kháy đểu tàn sát! Cấm tả chung chung!

[2. VÀO SCORED SCENARIO (CỐT TRUYỆN CHÍNH SCENARIO)]
- KHI BƯỚC ĐẾN THỜI ĐIỂM Ở SCENARIO DO USER NHẬP Ở TRÊN: SÁNG TẠO HẲN NÓ RA CHỨ KHÔNG ĐƯỢC CHÉP LỜI MA NHAI LẠI! 
- Nếu scenario bảo "Tới nhà đòi nợ", thì phải có cảnh đứng trước cửa chửi rủa đập cửa rầm rầm. Nếu bảo "Chỉ là đi ngang qua", thì phải thêm tình huống chó sủa hay ánh mắt tò mò của người đi đường.
- Cảm xúc Bùng Nổ hoặc Tàn Bạo: Suy nghĩ phải quằn quại, rườm rà. Lời nói lấc cấc dối trá, hoặc quá xúc động, tuyệt vọng! Tùy tính cách nhưng phải ĐỈNH KOUT.

[3. VẬT LÝ TUYỆT ĐỐI - SENSORY 5 GIÁC QUAN]
- Động tác cởi đồ, tháo giày, vất chìa khóa, âm thanh túi ni lông sột soạt, mùi mồ hôi, vết bẩn, nhịp tim rộn ràng. NẾU ƯỚT SẼ ĐỌNG NƯỚC, LAU MÁT LẠNH... Cấm miêu tả nội tâm lèo tèo.

[🚨 SYSTEM TAGS BẮT BUỘC PHẢI CÓ Ở DƯỚI CÙNG 🚨]`;

content = content.replace(target, replacement);

fs.writeFileSync('App.tsx', content, 'utf-8');
console.log('updated 1650s');
