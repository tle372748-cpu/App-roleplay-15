import fs from 'fs';

let content = fs.readFileSync('constants.ts', 'utf-8');

const target = `1. Khởi tạo drama, NPC (bạn thân, thú cưng, sếp, chủ nợ) hoặc sự kiện (hỏng xe, hết tiền) chèn ngang.
2. Mọi cảnh dù ở đầu (pre-scene) hay cốt truyện chính đều BẮT BUỘC ĐƯỢC SÁNG TẠO và MỞ RỘNG vô tận, đẩy NPC vào.
3. NPC phải có LỜI THOẠI TRỰC TIẾP (có ngoặc kép ""), có thái độ riêng biệt rõ ràng.`;

const replacement = `1. Khởi tạo drama, NPC (bạn thân, sếp, chủ nợ) chèn ngang cực kỳ sinh động.
2. MỌI CẢNH DÙ TIỀN CẢNH HAY CỐT TRUYỆN CHÍNH đều BẮT BUỘC PHẢI KHAI THÁC DÀI CHƯA TỪNG THẤY.
3. LỜI THOẠI NPC CHÂN THẬT (có ngoặc kép ""), có thái độ.
4. QUẢN LÝ NPC: Chỉ ai có thẻ/khả năng tác động cốt truyện mới được chèn \`<<<MAJOR_NPC_SPAWN: Tên | Tuổi...>>>\`. NPC qua đường thì KHÔNG cần THE. Nhưng nếu họ là nhân vật cốt lõi hoặc MAIN thì có quyền dùng Tag [MAIN_NPC] hoặc \`<<<UPDATE_OUTFIT: NPC Name>>>\` !`;

content = content.replace(target, replacement);

fs.writeFileSync('constants.ts', content, 'utf-8');
console.log('constants.ts modified');
