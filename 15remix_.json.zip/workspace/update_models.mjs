import fs from 'fs';
const file = './services/aiService.ts';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(/model: "gemini-3\.5-flash",/g, 'model: (typeof config !== "undefined" && config && config.model) ? config.model : "gemini-3.5-flash",');
fs.writeFileSync(file, content);
