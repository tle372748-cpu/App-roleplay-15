import fs from 'fs';

const constantsContent = fs.readFileSync('constants.ts', 'utf-8');
const newPromptContent = fs.readFileSync('workspace/new_prompt.txt', 'utf-8');

const prefix = constantsContent.substring(0, constantsContent.indexOf('export const NM_PLUS_1_6_PROMPT = `'));
const suffix = constantsContent.substring(constantsContent.indexOf('export const SM_PLUS_PROMPT = `'));

fs.writeFileSync('constants.ts', prefix + newPromptContent + suffix, 'utf-8');
console.log('Successfully updated constants.ts');
