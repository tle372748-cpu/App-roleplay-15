import fs from 'fs';

let content = fs.readFileSync('constants.ts', 'utf-8');

const target2 = `### KỲ VỌNG ĐẦU RA
Đau đáu sâu sắc hoặc hài hước chua cay. Từng chữ đập vào tiềm thức, hành động liên tục chảy không ngừng.

[CUỐI CÙNG LÀ NHÂN QUẢ]`;

const replacement2 = `### KỲ VỌNG ĐẦU RA
Đau đáu sâu sắc hoặc hài hước chua cay. Từng chữ đập vào tiềm thức, hành động liên tục chảy không ngừng.

## [PATCH 5: TIỀN CẢNH VÀ ĐỘ DÀI KHỔNG LỒ XUYÊN TRUYỆN]
### MỤC TIÊU
CẤM VIẾT NGẮN! BẮT BUỘC MỞ RỘNG VÀ KÉO DÀI MỌI TÌNH HUỐNG LÊN GẤP 10 LẦN! Nếu Scenario yêu cầu uống cà phê, bạn phải mô tả cả việc chọn góc ngồi, nghe tiếng ly lanh canh, suy nghĩ vẩn vơ, bị gián đoạn, và nhìn dòng người!

### VẤN ĐỀ HIỆN TẠI
- AI thường hay bỏ qua tiền cảnh, dẫn trực tiếp vào Scenario và nói luyên thuyên rất ngắn củn lủn rồi bắt User nói lại. Thiếu mưu mô, thiếu lời thoại qua lại với NPC bên ngoài.

### YÊU CẦU
1. ĐỘ DÀI KHỔNG LỒ: MỌI CÂU TRẢ LỜI ĐỀU PHẢI VIẾT TRÊN 1500 TỪ (Nhiều chục đoạn văn)!
2. TIỀN CẢNH VÀ CỐT TRUYỆN MỚI CỦA SCENARIO (MỞ MÀN): 80% đầu của phản hồi phải là một đoạn tiền cảnh về hoạt động sinh hoạt TRƯỚC KHI BƯỚC TỚI SỰ KIỆN TRONG THÔNG TÊN CỦA USER, TRƯỚC KHI GẶP USER. Tạo ra hội thoại TRỰC TIẾP ("") với NPC khác. Không nhảy thẳng vào vấn đề! CHỈ DÙNG LUẬN ĐIỂM CỦA MỚI NHẤT TRONG TIN NHẮN USER ĐỂ LÀM KẾT BÀI ĐIỂM RƠI!

### KỲ VỌNG ĐẦU RA
Một trường đoạn tiểu thuyết khổng lồ, bùng nổ, rùng rợn, không chạy theo lối mòn, cực kỳ chi tiết!

[CUỐI CÙNG LÀ NHÂN QUẢ]`;

content = content.replace(target2, replacement2);

fs.writeFileSync('constants.ts', content, 'utf-8');
console.log('Patch 5 finally injected successfully');
