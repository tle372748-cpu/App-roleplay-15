import fs from 'fs';

let content = fs.readFileSync('App.tsx', 'utf-8');

const target1 = `CRITICAL INSTRUCTION - DỰNG CẢNH MỞ MÀN (OPENING SCENE):
Nhiệm vụ của mày là DỰA VÀO ĐOẠN SCENARIO BÊN TRÊN, sau đó "COOK" RA MỘT MÀN MỞ ĐẦU THẬT DÀI, CHI TIẾT VÀ BẮT BUỘC TRÀN NGẬP LỜI THOẠI VÀ SUY NGHĨ. TUYỆT ĐỐI KHÔNG COPY HAY LẶP LẠI VĂN BẢN (PARROTING) TỪ CONTEXT LÀM CỦA MÌNH. Context chỉ là một đoạn text cung cấp ý tưởng, mày phải viết nó ra thành một cảnh thật dài, đầy đủ NPC phụ, suy nghĩ đa chiều, ý đồ dối trá và biến cố trước khi cái context đó thực sự xảy ra! KỂ CẢ KHI BƯỚC VÀO SỰ KIỆN CHÍNH, BẠN CŨNG PHẢI TIẾP TỤC KHAI THÁC KIỆT QUỆ HÀNH ĐỘNG, NỘI TÂM, THỜI TRANG VÀ LỜI THOẠI. KHÔNG BỎ SÓT CHI TIẾT.

[🚨 CÁC BƯỚC ĐỂ TẠO RA SCENARIO BÙNG NỔ, XUYÊN THẤU VÀ SIÊU VIỆT VỀ ĐỘ DÀI 🚨]

1. PRE-SCENE (TIỀN CẢNH LÀ SINH TỬ):
- LỆNH TỐI CAO: TUYỆT ĐỐI KHÔNG NHÀO VÀO CỐT TRUYỆN SCENARIO NGAY. BẠN PHẢI VIẾT MỘT PHÂN ĐOẠN TIỀN CẢNH KHỔNG LỒ! 
- MỞ MÀN BẰNG CÂU CHỬI THỀ, TIẾNG THỞ DỐC, HAY MỘT CÂU THOẠI NÃO NỀ TỪ NPC NÀO ĐÓ NHẮM VÀO NHÂN VẬT!
- Diễn biến trọn vẹn những gì nhân vật TỰ LÀM, TRĂN TRỞ trước khi đi đến sự kiện đụng mặt User. Có thể là kẹt xe hàng giờ đồng hồ, có thể là mua nhầm ly cà phê, có thể là rên rỉ vì mệt. Phải có tính nhân quả, không trên trời rơi xuống.
- Random hóa ý tưởng khởi đầu bằng Motif: [ \${selectedMotif} ].

2. NÃO BỘ, NPC, VÀ THẾ GIỚI XUNG QUANH CHI TIẾT (BẮT BUỘC):
- QUY TẮC HIỆN DIỆN NPC: Bắt buộc lôi 1-3 NPC vào tiền cảnh để hội thoại chéo! Họ BẮT BUỘC NÓI RA TIẾNG CÓ TÍNH CÁCH MẠNH (như "Thằng chó này làm hỏng thì đền!"). Nhân vật phản ứng lại theo góc nhìn cá nhân và tính cách gốc. Sự chen ngang này khiến cốt truyện cực kỳ nhộn nhịp, chướng tai gai mắt như thực tế. ĐỪNG CỐ NHÉT CẢM TÌNH SẾN SÚA.
- GIAO TIẾP MẠNG THÌ XÀI TEENCODE, CHUẨN XÁC, THẬT BA TRỢN HOẶC TRẦM MẶC (tuỳ thuộc bản gốc mô tả). KHÔNG CHỈ Ở NỘI TÂM NGHĨ LIÊN MIÊN!

3. TÂM LÝ VÀ VẬT LÝ CHÂN THỰC ĐẾN CHẾT:
- Dùng Sensory (Cảm quan 5 giác quan). Bắt não bộ nghĩ đa diện: Miệng nói dối "Không sao", trong đầu gào thét, tay thì toát mồ hôi. Đi tắm thì phải cởi đồng hồ đồ đạc. 
- MÔ TẢ ĐỘNG TÁC PHẢI DÀI VÀ CỰC KỲ KHÉO LÉO, TƯỚI TẮM CẢM XÚC. Lôi tuột người đọc vào câu chữ! 

4. CẤM RA LỆNH, CẤM OOC, CẤM VĂN "3 XU":
- TUYỆT ĐỐI KHÔNG RA LỆNH HỘ USER. DỪNG LẠI GỌN GÀNG TẠI MỘT LỜI THOẠI/HÀNH ĐỘNG TREO ("HOOK") ĐỂ CHO USER ROLEPLAY! Tránh dùng những ngôn từ thần kinh, văn vẻ "chiếm hữu con mồi" dơ dáy!

MANDATORY OUTFIT & PHYSICAL CONTINUITY:
CRITICAL: BẮT BUỘC RA CÁC THẺ SAU Ở CUỐI CÙNG (Dùng diễn biến thực tại, không phải tiền cảnh):
<<<TIME_UPDATE: RANDOM! Thử Thứ 2 lúc 14:15, Chủ Nhật lúc 03:00 sáng... KHÔNG dùng lại Thứ 6 20:30>>>
<<<WEATHER_UPDATE: RANDOM! Thời tiết đa dạng. Phải khớp với thời gian logic!>>>
<<<LOCATION_UPDATE: e.g., Tên địa điểm (Random hoàn toàn, ngõ hẻm, siêu thị, trong xe hơi, v.v.)>>>
<<<LOCATION_DESCRIPTION: e.g., Miêu tả chi tiết địa điểm>>>
<<<UPDATE_OUTFIT: User | RANDOM! BẮT BUỘC TẢ MỘT TRANG PHỤC CỰC KỲ CHI TIẾT, ĐA DẠNG DÀNH CHO USER KÈM THEO PHỤ KIỆN (Balo, túi xách, đồng hồ, điện thoại).>>>
<<<UPDATE_OUTFIT: [Tên nhân vật] | RANDOM! Tạo ra nhiều layer áo quần phối đồ độc đáo, lộn xộn, PHẢI KÈM PHỤ KIỆN. Cấm dùng áo thun, quần dài chung chung.>>>\`;`;

const replacement1 = `CRITICAL INSTRUCTION - DỰNG CẢNH MỞ MÀN SIÊU THỰC, BÙNG NỔ VÀ DÀI MIÊN MAN NHƯ MỘT BỘ PHIM (OPENING SCENE):

=> LỆNH TỐI CAO: BẠN PHẢI VIẾT ÍT NHẤT 2000-3000 TỪ (Hoặc dài hết mức có thể). NẾU CÂU TRẢ LỜI NGẮN, NÓ SẼ BỊ VỨT VÀO THÙNG RÁC! DÙNG CẢM XÚC THẬT BÙNG NỔ ĐỂ VIẾT! TUYỆT ĐỐI KHÔNG PARROTING LỜI Ở SCENARIO Y XÌ VÀO CÂU CHUYỆN! ĐÓ CHỈ LÀ GỢI Ý! MÀY PHẢI SÁNG TẠO ĐÁNH BẬT NÓ!

[1. TIỀN CẢNH (PRE-SCENE) - BẮT BUỘC VÀ PHẢI CHIẾM 60% ĐỘ DÀI]
- BẮT BUỘC PHẢI kể về một chuỗi sự kiện DÀI NGOẰNG và RẮC RỐI trước khi chạm tới cốt lõi Scenario.
- Ví dụ: Thay vì vào thẳng, hãy kể việc Nhân vật thức dậy thế nào, đi ngoài đường bị xỉa xói, quần áo ướt nhẹp do mưa, đi làm bị chửi bới, một tiếng đồng hồ ngồi ngẩn ngơ với điếu thuốc (nếu hợp tuổi).
- NPC XUẤT HIỆN: Bắt buộc lôi NPC (sếp, xe ôm, chủ nhà, bạn bè) vào đoạn mở đầu. BẮT HỌ NÓI THÀNH TIẾNG TRỰC TIẾP (Dấu ngoặc kép ""). Cãi vã đanh đá, kháy đểu tàn sát!

[2. VÀO SCORED SCENARIO (CỐT TRUYỆN CHÍNH SCENARIO)]
- KHI BƯỚC ĐẾN THỜI ĐIỂM Ở SCENARIO DO USER NHẬP Owr TRÊN: KHÔNG ĐƯỢC CHÈN LỜI CỦA USER VÀO! BIẾN TẤU NÓ ĐI! SÁNG TẠO HẲN NÓ RA! 
- Nếu scenario bảo "Tới nhà đòi nợ", thì phải có cảnh đứng trước cửa chửi rủa đập cửa rầm rầm. Nếu bảo "Chỉ là đi ngang qua", thì phải thêm tình huống chó sủa hay ánh mắt tò mò của người đi đường.
- TÂM LÝ BÙNG NỔ: Suy nghĩ phải quằn quại, rườm rà. Lời nói lấc cấc dối trá, hoặc quá xúc động, tuyệt vọng! Không sến súa rởm đời kiểu tổng tài!

[3. VẬT LÝ TUYỆT ĐỐI - SENSORY 5 GIÁC QUAN]
- Động tác cởi đồ, tháo giày, vất chìa khóa, âm thanh túi ni lông sột soạt, mùi mồ hôi, vết bẩn, nhịp tim rộn ràng. NẾU ƯỚT SẼ ĐỌNG NƯỚC, LAU MÁT LẠNH...

MANDATORY OUTFIT & SYSTEM TAGS (Dùng bối cảnh kết thúc câu trả lời):
<<<TIME_UPDATE: RANDOM (E.g., Thứ 4, 18:35) Tùy vào tiền cảnh>>>
<<<WEATHER_UPDATE: RANDOM (Ưu tiên bình thường, nếu cần kịch tính thì dông bão)>>>
<<<LOCATION_UPDATE: e.g., Tên địa điểm kết thúc câu chuyện>>>
<<<LOCATION_DESCRIPTION: e.g., Bầu không khí (Mùi xăng xe, mùi ẩm mốc, mùi nước hoa)>>>
<<<UPDATE_OUTFIT: User | BẮT BUỘC TẢ CỰC CHI TIẾT TRANG PHỤC VÀ PHỤ KIỆN>>>
<<<UPDATE_OUTFIT: [Tên nhân vật AI] | RANDOM VÀ TẢ ĐỈNH CAO THỜI TRANG HOẶC CỰC KỲ LUỘM THUỘM KÈM PHỤ KIỆN>>>\`;`;

let target2 = `prompt = \`[SYSTEM COMMAND]: [LỆNH TRỰC DIỆN] - COOK RA MÀN MỞ GÌ ĐÓ ĐIÊN RỒ, CỰC KỲ DÀI, CỰC KỲ CHI TIẾT VÀ BÙNG NỔ!
[RANDOM SEED: \${Math.random()}] - Kích hoạt sự sáng tạo không giới hạn.
- MANDATORY PRE-SCENE (LỆNH TỐI CAO - TIỀN BỐI CẢNH KHỔNG LỒ): BẮT BUỘC PHẢI VIẾT MỘT ĐOẠN TIỀN CẢNH VÔ CÙNG DÀI, CHI TIẾT (có thể nhiều sự kiện nối tiếp nhau) VỀ CUỘC SỐNG HIỆN TẠI TRƯỚC KHI BƯỚC TỚI SỰ KIỆN TRONG SCENARIO MONG ĐỢI! Không được nhảy đùng một phát vào điểm rơi kịch tính ở scenario. Bạn phải xây dựng móng (Ví dụ: đi qua mấy con phố, đối mặt với thời tiết, giáp lá cà với những NPC khó ưa, đấu tranh nội tâm).
- NPC BẮT BUỘC VÀO CUỘC: Phải có ít nhất 1-2 NPC nhảy vào tương tác TRỰC TIẾP bằng CÂU THOẠI (Dùng dấu ngoặc kép "") để tạo ra xung đột, đối chọi, gián đoạn. Không được kể lể một mình tĩnh mịch.
- KHÔNG PARROTING: Không lặp lại lời văn được mô tả bằng một format sến. Nhào nặn nó lên, mắm muối thêm vào. Vận dụng tính cách 100% không OOC. Gây shock não bộ của User bằng ngòi bút thần sầu đứt cõi lòng hoặc siêu hài hước.
- KHỞI ĐẠO OUTFIT & BỐI CẢNH BẮT BUỘC Ở CUỐI:
  <<<TIME_UPDATE: RANDOM! Thử Thứ 2 lúc 14:15, Chủ Nhật lúc 03:00 sáng... KHÔNG dùng lại Thứ 6 20:30>>>
  <<<WEATHER_UPDATE: RANDOM! Thời tiết đa dạng. Phải khớp với thời gian logic!>>>
  <<<LOCATION_UPDATE: e.g., Tên địa điểm (Random hoàn toàn, ngõ hẻm, siêu thị, trong xe hơi, v.v.)>>>
  <<<LOCATION_DESCRIPTION: e.g., Miêu tả chi tiết địa điểm>>>
  <<<UPDATE_OUTFIT: User | RANDOM! BẮT BUỘC TẢ MỘT TRANG PHỤC CỰC KỲ CHI TIẾT DÀNH CHO USER KÈM PHỤ KIỆN (Balo, túi, điện thoại)>>>
  <<<UPDATE_OUTFIT: [Tên nhân vật] | RANDOM! Tạo ra nhiều layer trang phục cực dị hoặc thực tế, đồ đính kèm phụ kiện. Cấm áo thun quần tây chung chung.>>>\`;`;

let replacement2 = `prompt = \`[SYSTEM COMMAND]: [LỆNH TRỰC DIỆN] - MỞ MÀN NHƯ MỘT BỘ PHIM BOM TẤN, SIÊU DÀI, BÙNG NỔ CẢM XÚC!
[RANDOM SEED: \${Math.random()}] - Kích hoạt sự sáng tạo không giới hạn.

=> LỆNH TỐI CAO: BẠN PHẢI VIẾT ÍT NHẤT 2000-3000 TỪ. CÀNG DÀI CÀNG CÓ THƯỞNG!

[1. TIỀN CẢNH KHỔNG LỒ (PRE-SCENE)]
- BẮT BUỘC thiết lập nhịp điệu sinh hoạt TRƯỚC SỰ KIỆN. Đi loanh quanh, nói chuyện, nấu nướng, cãi nhau, mua sắm đồ... Rất nhiều thứ xảy ra trước khi thực sự va chạm với User.
- BẮT HỌ NGẪM NGHĨ: Suy nghĩ dồi dào, thâm sâu, đàng điếm, bực tức hay sụp đổ, TÙY BẢN NGÃ.
- CÓ NPC: Bạn phải thả các NPC (người dưng, bố mẹ, đồng nghiệp) vào và BĂM BỔ NHAU BẰNG LỜI NÓI (Trực tiếp ngoặc kép "", cấm tóm tắt thoại!).

[2. CẤM PARROTING]
- KHÔNG HÁT LẠI SCENARIO! Nhào nặn nó lên, mắm muối thêm vào! Thêm diễn biến ngẫu nhiên, tai nạn, hiểu lầm vào scenario đó chứ không phải một màu. Đặc tả âm thanh, mùi hương, thời tiết (Sensory).

[3. SYSTEM TAGS CUỐI CÙNG]
  <<<TIME_UPDATE: RANDOM! Thử Thứ 2 lúc 14:15, Chủ Nhật lúc 03:00 sáng... TÙY LOGIC!>>>
  <<<WEATHER_UPDATE: RANDOM! Đa dạng.>>>
  <<<LOCATION_UPDATE: e.g., Tên địa điểm kết thúc>>>
  <<<LOCATION_DESCRIPTION: e.g., Mùi hương, độ ẩm của địa điểm>>>
  <<<UPDATE_OUTFIT: User | ĐỪNG QUÊN PHỤ KIỆN>>>
  <<<UPDATE_OUTFIT: [Tên nhân vật] | NHIỀU LAYER ÁO, PHỤ KIỆN THẬT DETAILED>>>\`;`;

content = content.replace(target1, replacement1);
content = content.replace(target2, replacement2);

fs.writeFileSync('App.tsx', content, 'utf-8');
console.log('first replacement done');
