import fs from 'fs';

let content = fs.readFileSync('constants.ts', 'utf-8');

const target1 = `1. ĐỘ DÀI & ĐỒNG BỘ: Tuỳ biến linh hoạt nhưng phải CỰC KỲ DÀI ở những cảnh tâm lý, hành động quan trọng (nhưng nếu User nói trống lỏng ping-pong thì trả lời ngắn lại). Miêu tả sao cho rùng mình, đau đớn, há hốc.`;

const replacement1 = `1. ĐỘ DÀI & ĐỒNG BỘ: BẮT BUỘC VIẾT DÀI THEO CHIỀU SÂU TÂM LÝ! Bôi ra hàng ngàn chữ nếu cần thiết để tả sự đau khổ, mâu thuẫn hay tiếng cười sảng khoái (kể cả khi User nói ngắn gọn, bạn vẫn phải tự build up nội tâm). Tả cho rùng mình, đau đớn, há hốc.`;

content = content.replace(target1, replacement1);

fs.writeFileSync('constants.ts', content, 'utf-8');
console.log('constants.ts modified');
