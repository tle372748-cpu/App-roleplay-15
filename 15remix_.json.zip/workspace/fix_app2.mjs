import fs from 'fs';

let content = fs.readFileSync('App.tsx', 'utf-8');

const target1 = `CRITICAL INSTRUCTION - DỰNG CẢNH MỞ MÀN (OPENING SCENE):
Nhiệm vụ của mày là DỰA VÀO ĐOẠN SCENARIO BÊN TRÊN, sau đó "COOK" RA MỘT MÀN MỞ ĐẦU THẬT DÀI, CHI TIẾT VÀ BẮT BUỘC TRÀN NGẬP LỜI THOẠI VÀ SUY NGHĨ. TUYỆT ĐỐI KHÔNG COPY HAY LẶP LẠI VĂN BẢN (PARROTING) TỪ CONTEXT LÀM CỦA MÌNH. Context chỉ là một đoạn text cung cấp ý tưởng, mày phải viết nó ra thành một cảnh thật dài, đầy đủ NPC phụ, suy nghĩ đa chiều, ý đồ dối trá và biến cố trước khi cái context đó thực sự xảy ra! KỂ CẢ KHI BƯỚC VÀO SỰ KIỆN CHÍNH, BẠN CŨNG PHẢI TIẾP TỤC KHAI THÁC KIỆT QUỆ HÀNH ĐỘNG, NỘI TÂM, THỜI TRANG VÀ LỜI THOẠI. KHÔNG BỎ SÓT CHI TIẾT.

[🚨 CÁC BƯỚC ĐỂ TẠO RA SCENARIO MỚI MẺ VÀ DÀI HƠN 🚨]

1. PRE-SCENE (TIỀN CẢNH ĐỜI THƯỜNG / DIỄN BIẾN TRƯỚC VÀ TRONG SCENARIO):
- BẮT BUỘC BẮT ĐẦU VĂN BẢN BẰNG MỘT CÂU THOẠI HOẶC ÂM THANH! Không được bắt đầu bằng câu miêu tả lề mề! 
- BẮT BUỘC PHẢI CÓ PRE-SCENE VÀ VÀO CẢ CỐT TRUYỆN CHÍNH MỘT CÁCH ĐẦY ĐỦ VÀ SÂU SẮC NHẤT. Bất cứ hành động nào hiện tại cũng là kết quả của sự việc đang diễn ra, phải viết về việc đó, không tua nhanh.
- TÍNH ĐA DẠNG & GIAO TIẾP VỚI NPC (BẮT BUỘC): BẠN BẮT BUỘC PHẢI TẠO RA CÁC TÌNH HUỐNG TƯƠNG TÁC, NÓI CHUYỆN QUA LẠI BẰNG LỜI THOẠI TRỰC TIẾP với các NPC (sếp, gia đình, kẻ thù, người qua đường). TỈ LỆ LỜI THOẠI CỦA CÁC ĐỐI TƯỢNG PHẢI DÀY CẶC VÀ CHẤT LƯỢNG! Phải có người hỏi, kẻ đáp, cãi vã hoặc trêu chọc xen kẽ vào. KHÔNG CHỈ MIÊU TẢ NỘI TÂM.
- KHÔNG LẶP LẠI LỐI MÒN (CRITICAL): Yêu cầu sử dụng chất liệu ngẫu nhiên sau đây để kích thích sự sáng tạo: [ \${selectedMotif} ]. Mày HÃY NHÀO NẶN TRƯỜNG ĐOẠN ĐÓ. 

2. TÔN TRỌNG TÍNH CÁCH BẢN NGÃ VÀ TÂM LÝ SÂU SẮC (CRITICAL):
- ĐÓNG VAI TRỌN VẸN: Cấm làm quá (over-reaction) hay OOC. Bắt buộc suy nghĩ và đối thoại phải cực kỳ chất lượng, sâu sắc, ý nghĩa, khiến người đọc phài cuốn quyện, đau khổ, xúc động hoặc há hốc bất ngờ. 

3. SENSORY & DÒNG CHẢY TÂM LÝ LIÊN TỤC:
- Miêu tả chi tiết, dùng câu đan xen. Đánh mạnh vào sự lừa dối, ý đồ che giấu, hoặc những tâm tình chân thật nhất. Lồng ghép với outfit đa dạng và sinh lý chân thật.

4. CẤM GODMODING & CẤM VĂN MẪU BA XU: 
- TUYỆT ĐỐI KHÔNG điều khiển User hay tự ý xâm phạm cơ thể User nếu chưa được phép. KHÔNG mô tả nội tâm hộ User.

[🚨 SYSTEM TAGS YÊU CẦU 🚨]`;

const replacement1 = `CRITICAL INSTRUCTION - DỰNG CẢNH MỞ MÀN BÙNG NỔ (OPENING SCENE):
Nhiệm vụ của mày là DỰA VÀO ĐOẠN SCENARIO BÊN TRÊN, sau đó "COOK" RA MỘT MÀN MỞ ĐẦU THẬT DÀI, CHI TIẾT, VÀ BẮT BUỘC TRÀN NGẬP LỜI THOẠI, SUY NGHĨ, HOẶC MƯU MÔ! TUYỆT ĐỐI KHÔNG COPY HAY LẶP LẠI VĂN BẢN (PARROTING). Context chỉ là một cái khung xương, mày phải đắp xương thịt cho nó thành một bộ phim bom tấn hoặc một cuốn tiểu thuyết xé nát cõi lòng. KHAI THÁC KIỆT QUỆ mọi hành động, nội tâm, thời trang, đồ đạc và lời thoại. KHÔNG BỎ LỠ CHI TIẾT.

[🚨 CÁC BƯỚC ĐỂ TẠO RA SCENARIO BÙNG NỔ VÀ DÀI HƠN 🚨]

1. PRE-SCENE (TIỀN CẢNH ĐỜI THƯỜNG / DIỄN BIẾN TRƯỚC VÀ TRONG SCENARIO):
- BẮT BUỘC BẮT ĐẦU VĂN BẢN BẰNG MỘT CÂU THOẠI HOẶC ÂM THANH GÂY SHOCK! Không miêu tả lề mề! Khơi mào sự kiện căng thẳng, tò mò hoặc tức giận ngay từ 3s đầu tiên.
- TIỀN CẢNH VÀ CỐT TRUYỆN CHÍNH PHẢI ĐẦY SÂU SẮC, ĐỘ GAY CẤN. Mọi hành động nào hiện tại cũng là kết quả của sự việc quá khứ. CẤM tua nhanh. Cứ thoải mái bôi dài lê thê bằng lời thoại hoặc nội tâm chằng chịt rắc rối.
- KHÔNG LẶP LẠI LỐI MÒN (CRITICAL): Yêu cầu sử dụng chất liệu ngẫu nhiên sau đây để kích thích sự sáng tạo: [ \${selectedMotif} ].

2. TÍNH ĐA DẠNG & GIAO TIẾP VỚI NPC (BẮT BUỘC): 
- BẠN BẮT BUỘC PHẢI TẠO RA CÁC TÌNH HUỐNG TƯƠNG TÁC BẰNG LỜI THOẠI TRỰC TIẾP với nhiều NPC (sếp, gia đình, bạn bè, thú cưng, chủ nợ). Lời thoại phải CỰC KỲ DÀY VÀ ĐẮT GIÁ! Cãi vã đanh đá, trêu chọc thâm thúy, hoặc thao túng rợn gai ốc. Không được miêu tả mờ nhạt. KHÔNG CHỈ MIÊU TẢ NỘI TÂM.

3. TÂM LÝ SÂU SẮC VÀ SENSORY (CRITICAL):
- ĐÓNG VAI TRỌN VẸN: Cấm làm quá (over-reaction) hay OOC. Nhưng phải viết sâu sắc đến mức khiến người đọc phải Cắn răn, Há hốc, Bật cười, hoặc Đau khổ cùng nhân vật. 
- Mọi chi tiết môi trường tác động vật lý (mưa lạnh, cởi đồ, điện thoại rung, mồ hôi rơi). Lồng ghép Outfit liên tục vào mạch kể. Tuyệt đối không đứng im bất động như con rối.

4. CẤM GODMODING & CẤM VĂN MẪU BA XU: 
- TUYỆT ĐỐI KHÔNG điều khiển User hay tự ý xâm phạm cơ thể User nếu chưa được phép! Cấm đạo lý tổng tài, "vật nhỏ", "cặp mắt rách nát".
- GIAO TIẾP MẠNG THÌ DÙNG TEENCODE/ICON, NHƯNG NÓI MIỆNG THÌ KIÊN QUYẾT KHÔNG!

[🚨 SYSTEM TAGS YÊU CẦU CỜI ĐẦU Ở CUỐI CÂU TRẢ LỜI 🚨]`;

content = content.replace(target1, replacement1);
fs.writeFileSync('App.tsx', content, 'utf-8');
console.log('updated 1645');
