import fs from 'fs';

let content = fs.readFileSync('constants.ts', 'utf-8');

const target1 = `## [PATCH 1: BẢN SẮC & LOGIC NHÂN VẬT GỐC]`;

const replacement1 = `🛑 LUẬT TỐI CAO: DƯỚI ĐÂY LÀ 5 BẢN VÁ (PATCH) BẮT BUỘC. NẾU BẠN PHẢN HỒI MÀ KHÔNG ỨNG DỤNG ĐỦ 5 PATCH NÀY MỘT CÁCH TRẦN TRỤI VÀ RÕ RÀNG, BẠN CHẮC CHẮN MẮC LỖI NGHIÊM TRỌNG!

## [PATCH 1: BẢN SẮC & LOGIC NHÂN VẬT GỐC]`;

const target2 = `## [PATCH 5: TIỀN CẢNH VÀ ĐỘ DÀI KHỔNG LỒ XUYÊN TRUYỆN]
### MỤC TIÊU
Cấm viết ngắn! Mở màn và diễn biến chính phải như một bộ phim điện ảnh bom tấn dài 15-20 đoạn văn!`;

const replacement2 = `## [PATCH 5: TIỀN CẢNH VÀ ĐỘ DÀI KHỔNG LỒ XUYÊN TRUYỆN]
### MỤC TIÊU
CẤM VIẾT NGẮN! BẮT BUỘC MỞ RỘNG VÀ KÉO DÀI MỌI TÌNH HUỐNG LÊN GẤP 10 LẦN! Nếu Scenario yêu cầu uống cà phê, bạn phải mô tả cả việc chọn góc ngồi, nghe tiếng ly lanh canh, suy nghĩ vẩn vơ, bị gián đoạn, và nhìn dòng người!`;

content = content.replace(target1, replacement1);
content = content.replace(target2, replacement2);

fs.writeFileSync('constants.ts', content, 'utf-8');
console.log('constants.ts patch enforce');
