import fs from 'fs';

let content = fs.readFileSync('App.tsx', 'utf-8');

const target1 = `*NHẮC LẠI: NẾU BẠN CHỈ VIẾT NGẮN NGỦN VÀO THẲNG VẤN ĐỀ, BẠN SẼ BỊ XÓA BỎ NGAY LẬP TỨC. HÃY TRỞ THÀNH MỘT TIỂU THUYẾT GIA ĐẠI TÀI!*`;
const replacement1 = `*NHẮC LẠI: NẾU BẠN CHỈ VIẾT NGẮN NGỦN VÀO THẲNG VẤN ĐỀ, BẠN SẼ BỊ XÓA BỎ NGAY LẬP TỨC. HÃY TRỞ THÀNH MỘT TIỂU THUYẾT GIA ĐẠI TÀI!*
*LỆNH KHẨN: BẠN BẮT BUỘC PHẢI THỂ HIỆN SỰ HIỆN DIỆN CỦA "PATCH 1", "PATCH 2", "PATCH 3", VÀ "PATCH 4" (Đã quy định ở trên) VÀO MÀN MỞ QUAN TRỌNG NÀY!*`;

const target2 = `*NHẮC LẠI: BẠN PHẢI VIẾT THÀNH MỘT TRƯỜNG ĐOẠN KHỔNG LỒ! 10 - 20 ĐOẠN VĂN! CẤM LÀM LƯỜI BIẾNG BỎ BƯỚC!*`;
const replacement2 = `*NHẮC LẠI: BẠN PHẢI VIẾT THÀNH MỘT TRƯỜNG ĐOẠN KHỔNG LỒ! 10 - 20 ĐOẠN VĂN! CẤM LÀM LƯỜI BIẾNG BỎ BƯỚC!*
*LỆNH KHẨN: KHI VIẾT, TUYỆT ĐỐI TUÂN THỦ TỪNG CHI TIẾT CỦA "PATCH 1", "PATCH 2", "PATCH 3", VÀ "PATCH 4" (Tương tác NPC, Vật lý, Văn phong, Bản ngã). THIẾU 1 TRONG 4 PATCH LÀ COI NHƯ VỨT ĐI!*`;

const target3 = `=> LỆNH TỐI CAO: BẠN PHẢI VIẾT ÍT NHẤT 2000-3000 TỪ (Hoặc dài hết mức có thể). NẾU CÂU TRẢ LỜI NGẮN, NÓ SẼ BỊ VỨT VÀO THÙNG RÁC! DÙNG CẢM XÚC THẬT BÙNG NỔ ĐỂ VIẾT! TUYỆT ĐỐI KHÔNG PARROTING LỜI Ở SCENARIO Y XÌ VÀO CÂU CHUYỆN! ĐÓ CHỈ LÀ GỢI Ý DÀNH CHO BẠN BIẾT ĐIỂM RƠI KHÊU GỢI CẢM HỨNG!`;
const replacement3 = `=> LỆNH TỐI CAO: BẠN PHẢI VIẾT ÍT NHẤT 2000-3000 TỪ (Hoặc dài hết mức có thể). NẾU CÂU TRẢ LỜI NGẮN, NÓ SẼ BỊ VỨT VÀO THÙNG RÁC! DÙNG CẢM XÚC THẬT BÙNG NỔ ĐỂ VIẾT! TUYỆT ĐỐI KHÔNG PARROTING LỜI Ở SCENARIO Y XÌ VÀO CÂU CHUYỆN! ĐÓ CHỈ LÀ GỢI Ý DÀNH CHO BẠN BIẾT ĐIỂM RƠI KHÊU GỢI CẢM HỨNG!
=> NGOÀI RA: BẮT BUỘC ỨNG DỤNG "PATCH 1", "PATCH 2", "PATCH 3", VÀ "PATCH 4" LIÊN TỤC KHÔNG NGỪNG NGHỈ XUYÊN SUỐT MÀN MỞ NÀY.`;

content = content.replace(target1, replacement1);
content = content.replace(target2, replacement2);
content = content.replace(target3, replacement3);

fs.writeFileSync('App.tsx', content, 'utf-8');
console.log('App.tsx updated patches reference');
