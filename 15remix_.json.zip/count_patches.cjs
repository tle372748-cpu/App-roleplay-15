const fs = require('fs');
const content = fs.readFileSync('constants.ts', 'utf8');
const lines = content.split('\n');
const patchLines = lines.filter(line => line.includes("Patch "));
let patchNumbers = [];
patchLines.forEach(line => {
   const match = line.match(/Patch\s+([\d/]+)/);
   if (match) {
       const nums = match[1].split('/');
       patchNumbers.push(...nums.map(n => parseInt(n)));
   }
});
const uniquePatches = [...new Set(patchNumbers)];
console.log("Unique patches total:", uniquePatches.length);
uniquePatches.sort((a,b)=>a-b);
console.log("Patches:", uniquePatches.join(', '));
