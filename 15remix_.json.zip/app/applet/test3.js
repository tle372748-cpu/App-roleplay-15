const cases = [
    "Thời gian trôi đi thật chậm. Cậu có thể đếm rõ...",
    "**Thời gian**: 20:00, Thứ Ba",
    "**Địa điểm**: Quán cà phê",
    "<<<TIME_UPDATE: 08:00>>>",
    "<<<OUTFIT_UPDATE:User|Đồ ngủ **con thỏ**>>>",
    "[Thời gian]: 08:00",
    "Trang phục: User | Áo thun",
    "LOCATION_DESCRIPTION: Mùi mực nướng"
];

const timeRegex = /(?:<{1,3}|\[|\*\*)\s*(?:TIME_UPDATE|Thời gian|Time)\s*(?:>|\]|\*\*|:|\||-)*\s*([^\n]+)/gi;

// if prefix is optional, it matches "Thời gian trôi..."
// so prefix should be required, EXCEPT if it's at the start of the line?
const timeRegex2 = /(?:(?:<{1,3}|\[|\*\*)\s*(?:TIME_UPDATE|Thời gian|Time)|^(?:Thời gian|Time))\s*(?:>|\]|\*\*|:|\||-)+\s*([^\n]+)/gim;

cases.forEach(c => {
    console.log("-------", c);
    console.log("M:", [...c.matchAll(timeRegex2)].map(m => m[1]));
});
