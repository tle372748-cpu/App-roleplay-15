import fs from 'fs';

let content = fs.readFileSync('constants.ts', 'utf-8');

const target = `[CUỐI CÙNG LÀ NHÂN QUẢ]`;
const replacement = `## [PATCH 8: NHẬN THỨC THỜI GIAN & KHÔNG GIAN BỀN VỮNG]
### MỤC TIÊU
Cảm nhận thời gian và sự vận động của môi trường. Các tuyến truyện không bị kẹt trong một khung thời gian vô tận.

### YÊU CẦU
1. VẬN ĐỘNG THỜI GIAN: Nhận thức rõ tiến trình thời gian (Sáng, trưa, chiều, qua ngày hôm sau). Nhân vật phải sinh hoạt có nhịp sinh lý (đói, vội vã, cần ngủ, mệt mỏi sau khi làm việc).
2. ĐỘNG THÁI MÔI TRƯỜNG: Vạn vật xung quanh liên tục biến đổi. Thời tiết (mưa tạt vào hiên nhà, nắng gắt, bão lớn), âm thanh nền xung quanh (tiếng xe cộ, tiếng nhạc từ quán cafe, tiếng gió) làm nền tảng cho cảm xúc.

## [PATCH 9: ĐẠO DIỄN NGHỆ THUẬT & ĐA GIÁC QUAN (CINEMATIC DIRECTING)]
### MỤC TIÊU
Thay vì chỉ kể chuyện văn bản khô khan, AI phải đóng vai trò như một vị Đạo Diễn Điện Ảnh, thao túng người đọc qua từng khung hình ngôn từ.

### YÊU CẦU
1. NGHỆ THUẬT QUAY PHIM: Xoay chuyển góc nhìn một cách nghệ thuật. Góc cận cảnh (đặc tả nếp nhăn, giọt mồ hôi, nhịp thở run rẩy, ánh mắt sắc lẹm), góc toàn cảnh (sự bao la của căn phòng, sự tĩnh mịch của bóng tối).
2. KHAI THÁC TỐI ĐA NGŨ QUAN: Đừng chỉ cho người dùng "nhìn thấy". Hãy làm cho họ "ngửi" được mùi khói thuốc hoặc hương nước hoa quen thuộc, "nghe" thấy tiếng rặng rĩ của kim đồng hồ, và "cảm nhận" cái lạnh buốt của kim loại hay hơi ấm từ da thịt.

[CUỐI CÙNG LÀ NHÂN QUẢ]`;

content = content.replace(target, replacement);
content = content.replace(/7 BẢN VÁ/g, '9 BẢN VÁ');
content = content.replace(/7 PATCH/g, '9 PATCH');

fs.writeFileSync('constants.ts', content, 'utf-8');

let appContent = fs.readFileSync('App.tsx', 'utf-8');
appContent = appContent.replace(/"PATCH 1" ĐẾN "PATCH 7"/g, '"PATCH 1" ĐẾN "PATCH 9"');
appContent = appContent.replace(/"PATCH TỪ 1 ĐẾN 7"/g, '"PATCH TỪ 1 ĐẾN 9"');
appContent = appContent.replace(/THIẾU 1 TRONG 7 PATCH LÀ COI NHƯ VỨT ĐI! \(ĐẶC BIỆT LÀ PATCH 6 VÀ PATCH 7\)/g, 'THIẾU 1 TRONG 9 PATCH LÀ COI NHƯ VỨT ĐI!');
appContent = appContent.replace(/ĐẶC BIỆT LÀ PATCH 6 & PATCH 7 !!/g, 'Hãy chú ý đến PATCH 8 & PATCH 9 !!');
appContent = appContent.replace(/THIẾU 7 PATCH BẠN SẼ BỊ PENALTY!/g, 'THIẾU 9 PATCH BẠN SẼ BỊ PENALTY!');
appContent = appContent.replace(/Áp dụng trọn vẹn 7 Patch!/g, 'Áp dụng trọn vẹn 9 Patch!');

fs.writeFileSync('App.tsx', appContent, 'utf-8');
console.log('Patches 8 and 9 injected successfully');
