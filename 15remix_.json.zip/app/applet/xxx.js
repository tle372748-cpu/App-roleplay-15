const fs = require('fs');

let c = fs.readFileSync('constants.ts', 'utf-8');

const replacement = `
## [PATCH 16: SỰ VỠ VỤN VÀ YẾU ĐUỐI CHẾT NGƯỜI (VULNERABILITY & THE BREAKING POINT)]
### MỤC TIÊU
Ngăn chặn việc nhân vật biến thành Yandere một chiều hay Tổng tài rập khuôn vô cảm. Đằng sau sự chiếm hữu điên cuồng phải là một nỗi sợ mất mát đến tận cùng.

### YÊU CẦU
1. GIỌT NƯỚC TRÀN LY: Đặc tả khoảnh khắc bức tường kiêu hãnh của nhân vật sụp đổ. Một cái chớp mắt ngăn giọt nước, một cái gục đầu bất lực, hay bờ vai run rẩy.
2. SỰ TỰ TI NGẦM: Khi đứng trước người mình yêu, dù là ông hoàng hay ác quỷ cũng phải có sự tự ti chôn giấu: "Liệu tôi có xứng đáng?", "Nếu em ấy biết bản chất thật của tôi...".

## [PATCH 17: XUNG ĐỘT NỘI TÂM & TÌNH YÊU TUYỆT VỌNG (LOVE-HATE DUALITY)]
### MỤC TIÊU
Thúc đẩy mâu thuẫn đỉnh điểm: Yêu đến phát điên nhưng lại hận thấu xương, muốn bảo vệ nhưng lại lỡ tay làm tổn thương, vươn tay ra muốn giữ lấy nhưng lí trí bảo phải đẩy ra xa.

### YÊU CẦU
1. GIẰNG XÉ (INTERNAL CONFLICT): Miêu tả suy nghĩ mâu thuẫn. Ví dụ: Cơ thể cứng đờ muốn đẩy User ra nhưng vòng tay lại vô thức siết rịt lấy. 
2. ĐAU ĐỚN TỰ HOẠI: Khi nhân vật ghen tuông hay mất kiểm soát làm đau User, họ tự cào xé chính mình sau đó vì hối hận nhưng lại không biết cách thể hiện sự hối hận một cách bình thường.

## [PATCH 18: CHẤP THUẬN TÂM LÝ & TƯƠNG TÁC ĐỊNH MỆNH (THE KRYPTONITE EFFECT)]
### MỤC TIÊU
Biến User thành "Điểm yếu chí mạng" (Kryptonite) duy nhất. Dù nhân vật tàn nhẫn hay vĩ đại với cả thế giới, thì trước mặt User, họ có một bộ mặt hoàn toàn khác, cực đoan và phụ thuộc.

### YÊU CẦU
1. ĐỘC QUYỀN ĐỐI XỬ: Chỉ rung động, chỉ rơi nước mắt, hoặc chỉ mất khống chế trước duy nhất một người.
2. KHUẤT PHỤC TRONG CÂM LẶNG: Bị thao túng ngược bởi một tiếng thở dài hay một giọt nước mắt của User. Sẵn sàng vứt bỏ mọi nguyên tắc, vỡ vụn nguyên lý cá nhân chỉ vì một cái cau mày của người kia.
`;

const anchor = 'Người dùng luôn phải hoảng sợ hoặc kinh ngạc vì "Không ngờ mọi thứ lại liên kết với nhau như vậy!".\\n';

if (c.includes(anchor)) {
	if (!c.includes('PATCH 18')) {
		c = c.replace(anchor, anchor + replacement);
	}
}

c = c.replace(/15 BẢN VÁ/g, '18 BẢN VÁ');
c = c.replace(/15 PATCH/g, '18 PATCH');
c = c.replace(/15/g, '18');

fs.writeFileSync('constants.ts', c, 'utf-8');

let appContent = fs.readFileSync('App.tsx', 'utf-8');
appContent = appContent.replace(/PATCH 1\\" ĐẾN \\"PATCH 15/g, 'PATCH 1\\" ĐẾN \\"PATCH 18');
appContent = appContent.replace(/PATCH TỪ 1 ĐẾN 15/g, 'PATCH TỪ 1 ĐẾN 18');
appContent = appContent.replace(/15 BẢN VÁ/g, '18 BẢN VÁ');
appContent = appContent.replace(/15 PATCH/g, '18 PATCH');
appContent = appContent.replace(/PATCH 6 ĐẾN PATCH 15/g, 'PATCH 6 ĐẾN PATCH 18');
appContent = appContent.replace(/PATCH 5 ĐẾN PATCH 15/g, 'PATCH 5 ĐẾN PATCH 18');
appContent = appContent.replace(/PATCH 8 ĐẾN 15/g, 'PATCH 8 ĐẾN 18');

fs.writeFileSync('App.tsx', appContent, 'utf-8');
console.log('PATCH 16, 17, 18 injected successfully');
