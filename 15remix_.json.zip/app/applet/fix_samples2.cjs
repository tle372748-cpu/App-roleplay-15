const fs = require('fs');

let content = fs.readFileSync('/app/applet/constants.ts', 'utf8');

content = content.replace(/Nhưng sự chiếm hữu điên cuồng trong lồng ngực Minh không quan tâm đến lý trí\./g, '');
content = content.replace(/Lưng Trúc Linh bị ép sát vào bức tường bê tông xù xì\. Hai lòng bàn tay to lớn của cậu đập mạnh hai bên tai cô, khóa chặt cô trong vòng tay\. Cậu cúi xuống, khối cơ thể nóng hầm hập ép sát, hơi thở dồn dập phả vào da mặt cô\. Nụ cười mặt trời nhỏ đã biến mất hoàn toàn\./g, "Cậu dừng bước, bàn tay vô tình siết nhẹ lấy mép áo khoác. Cảm giác bồn chồn khó tả xẹt qua lồng ngực. Thay vì sải bước lên như mọi khi, cậu chỉ đứng yên dưới những bậc thang, đôi mắt hổ phách lấp lánh nết phức tạp nhìn về phía cô. Nụ cười rạng rỡ thường ngày nhường chỗ cho một vẻ thâm trầm ít thấy.");
content = content.replace(/Cậu quay đầu, ánh mắt tối sầm khiến thằng bạn khựng lại, bàn tay vô thức rụt về\. Không nói thêm lời nào, Minh ném khăn xuống ghế, vứt chai nước vào thùng rác loảng xoảng, rồi sải bước lên bậc thang\./g, "Cậu lắc đầu, khẽ nở nụ cười trừ. 'Không, tao có việc rồi.' Minh ném khăn xuống ghế, sải bước ra cửa, cố gắng tống khứ cái cảm giác nghèn nghẹn vô cớ trong cổ họng.");
content = content.replace(/ép gã phải lùi lại/g, "khiến gã giật mình lùi lại");

fs.writeFileSync('/app/applet/constants.ts', content);
console.log("Fixed constants.ts");
