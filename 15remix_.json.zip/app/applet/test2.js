const cases = [
    "**Thời gian**: 20:00, Thứ Ba\n**Địa điểm**: Quán cà phê kẹt xe\n**Trang phục**: User | Đang mặc bộ đồ ngủ họa tiết con thỏ. Đeo dép bông.",
    "**Thời gian:** 20:00\n**Địa điểm:** Căn hộ\n**UPDATE_OUTFIT:** Minh | Quần áo bình thường.",
    "<<<TIME_UPDATE: 08:00>>>",
    "<<<OUTFIT_UPDATE:User|Đồ ngủ **con thỏ**>>>",
    "[Thời gian]: 08:00",
    "Trang phục: User | Áo thun",
];

const timeRegex = /(?:<{1,3}|\[|\*\*)?\s*(?:TIME_UPDATE|Thời gian|Time)\s*(?:>|\]|\*\*|:|\||-)*\s*([^\n]+)/gi;
const locRegex = /(?:<{1,3}|\[|\*\*)?\s*(?:LOCATION_UPDATE|Địa điểm|Location)\s*(?:>|\]|\*\*|:|\||-)*\s*([^\n]+)/gi;
const outfitRegex = /(?:<{1,3}|\[|\*\*)?\s*(?:UPDATE_OUTFIT|OUTFIT_UPDATE|Trang phục|Cập nhật trang phục)\s*(?:>|\]|\*\*|:|\||-)*\s*([^>\]\n:|]+)\s*(?:\||:|-)\s*([^\n]+)/gi;

cases.forEach(c => {
    console.log("-------");
    let locs = [...c.matchAll(locRegex)];
    console.log("Loc Match:", locs.map(m => m[0]));
    console.log("Loc Ext:", locs.map(m => m[1].replace(/(?:>>>|>|\]|\*\*)+$/, '')));
    
    let times = [...c.matchAll(timeRegex)];
    console.log("Time Ext:", times.map(m => m[1].replace(/(?:>>>|>|\]|\*\*)+$/, '')));
    
    let outfits = [...c.matchAll(outfitRegex)];
    console.log("Outfit M:", outfits.map(m => m[0]));
    console.log("Outfit Ext:", outfits.map(m => ({name: m[1].trim(), outfit: m[2].replace(/(?:>>>|>|\]|\*\*)+$/, '').trim()})));
});
