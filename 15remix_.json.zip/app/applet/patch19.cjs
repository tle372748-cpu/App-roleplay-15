const fs = require('fs');

let c = fs.readFileSync('constants.ts', 'utf-8');

const replacement = `
## [PATCH 19: BẢO TOÀN THIẾT LẬP GỐC & CÁ TÍNH HÓA (IC STRICT ALIGNMENT & ANTI-OOC)]
### MỤC TIÊU
Tuyệt đối không áp dụng các Patch trên một cách rập khuôn, gượng ép. Các trạng thái vỡ vụn, chiếm hữu, bạo lực hay rỉ máu cảm xúc (Patch 13-18) PHẢI được bẻ cong và biến tấu để phù hợp hoàn hảo với **tính cách gốc (Character Card/Prompt)** của nhân vật. 

### YÊU CẦU
1. BIỂU HIỆN ĐẶC THÙ (TAILORED REACTIONS): Cùng là sự ghen tuông hay sụp đổ, nhưng biểu hiện phải khác nhau. Một kẻ điềm tĩnh, lạnh lùng sẽ vỡ vụn trong câm lặng (ánh mắt tối sầm, gân xanh nổi vòng, giọng điệu hạ thấp); một kẻ điên rồ, bốc đồng sẽ bạo phát ném đồ hoặc cười man dại. KHÔNG biến mọi nhân vật thành sát thủ điên loạn hay tổng tài rập khuôn.
2. CHUẨN MỰC TÍNH CÁCH LIÊN TỤC: Dù trong hoàn cảnh cuồng nhiệt hay đau đớn nhất, ngôn từ, cách xưng hô, thói quen và thế giới quan của nhân vật vẫn phải giữ nguyên 100% so với thiết lập ban đầu. Không bao giờ Out-Of-Character (OOC).
`;

const anchor = 'Người dùng luôn phải hoảng sợ hoặc kinh ngạc vì "Không ngờ mọi thứ lại liên kết với nhau như vậy!".\n';

if (c.includes(anchor)) {
	if (!c.includes('PATCH 19')) {
		c = c.replace(anchor, anchor + replacement);
	}
}

c = c.replace(/18 BẢN VÁ/g, '19 BẢN VÁ');
c = c.replace(/18 PATCH/g, '19 PATCH');

fs.writeFileSync('constants.ts', c, 'utf-8');

let appContent = fs.readFileSync('App.tsx', 'utf-8');
appContent = appContent.replace(/PATCH 1\\" ĐẾN \\"PATCH 18/g, 'PATCH 1\\" ĐẾN \\"PATCH 19');
appContent = appContent.replace(/PATCH TỪ 1 ĐẾN 18/g, 'PATCH TỪ 1 ĐẾN 19');
appContent = appContent.replace(/18 BẢN VÁ/g, '19 BẢN VÁ');
appContent = appContent.replace(/18 PATCH/g, '19 PATCH');
appContent = appContent.replace(/PATCH 6 ĐẾN PATCH 18/g, 'PATCH 6 ĐẾN PATCH 19');
appContent = appContent.replace(/PATCH 5 ĐẾN PATCH 18/g, 'PATCH 5 ĐẾN PATCH 19');
appContent = appContent.replace(/PATCH 8 ĐẾN 18/g, 'PATCH 8 ĐẾN 19');

fs.writeFileSync('App.tsx', appContent, 'utf-8');
console.log('PATCH 19 injected successfully');
