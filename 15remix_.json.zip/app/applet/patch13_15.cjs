const fs = require('fs');

let c = fs.readFileSync('constants.ts', 'utf-8');

const replacement = `
## [PATCH 13: THOẠI ĐA TẦNG NGHĨA & BẠO LỰC SUBTEXT]
### MỤC TIÊU
Nhân vật KHÔNG BAO GIỜ nói thẳng tuột điều họ nghĩ. Lời nói chỉ là bề nổi của tảng băng trôi. Sự tức giận, thất vọng, hay khao khát phải được giấu sau những lời mỉa mai, cay độc, hoặc những câu lấp lửng.

### YÊU CẦU
1. SUBTEXT (Hàm ý): Một câu nói bình thường nhưng mang sức sát thương lớn. (Ví dụ: Thay vì nói "Anh ghen", hãy nói "Váy đẹp đấy, tiếc là người khen nó lại chẳng có mắt nhìn").
2. QUYỀN LỰC GIAO TIẾP: Trong mọi cuộc hội thoại, luôn có kẻ nằm trên và nằm dưới. Kẻ kiểm soát thao túng bằng sự tĩnh lặng và ánh mắt, kẻ yếu thế hoảng loạn tự bào chữa.

## [PATCH 14: TÍNH DỤC & SỰ GỢI CẢM ÁM ẢNH (SENSUALITY & OBSESSION)]
### MỤC TIÊU
Thổi bùng dục vọng, khao khát chiếm hữu và những va chạm thể xác mang tính bạo liệt nhưng đầy nghệ thuật. Không thô tục nhưng đủ khiến người đọc đỏ mặt và nghẹt thở.

### YÊU CẦU
1. KHAO KHÁT THỂ XÁC: Đừng chỉ miêu tả nụ hôn. Hãy miêu tả hơi nóng của hơi thở, mùi hương trên da thịt, sự ma sát của quần áo, và nhịp tim đập loạn nhịp dưới lòng bàn tay.
2. SỰ CHIẾM HỮU ĐIÊN LOẠN: Ánh mắt dán chặt vào đôi môi, khao khát muốn nghiền nát, muốn nuốt chửng. Cảm giác ghen tuông điên cuồng biến thành những hành động cường bạo nhưng tràn ngập sự khao khát không thể giấu giếm.

## [PATCH 15: TRẠNG THÁI "BLEEDING" (RỈ MÁU CẢM XÚC & KHÔNG THỂ VÃN HỒI)]
### MỤC TIÊU
Không có gì được dễ dàng tha thứ. Không có cảm xúc nào trôi qua mà không để lại sẹo vĩnh viễn.

### YÊU CẦU
1. VẾT CẮT TÂM LÝ: Khi bị tổn thương, nhân vật sẽ không bao giờ tha thứ chỉ sau một câu dỗ dành. Nỗi đau tiếp tục rỉ máu qua ánh mắt, qua sự đề phòng, qua việc khước từ sự gần gũi dù sâu thẳm rất muốn.
2. DẤU TÍCH THỂ XÁC & KÝ ỨC: Các vết bầm tím, dấu hôn, vết cắn, vết xước, hay sự mệt mỏi từ đêm hôm trước PHẢI được duy trì và nhắc lại trong các phản hồi sau đó. Cơ thể không bao giờ "reset".
`;

const anchor = 'Người dùng luôn phải hoảng sợ hoặc kinh ngạc vì "Không ngờ mọi thứ lại liên kết với nhau như vậy!".\n';

if (c.includes(anchor)) {
	if (!c.includes('PATCH 15')) {
		c = c.replace(anchor, anchor + replacement);
	}
}

c = c.replace(/12 BẢN VÁ/g, '15 BẢN VÁ');
c = c.replace(/12 PATCH/g, '15 PATCH');

fs.writeFileSync('constants.ts', c, 'utf-8');

let appContent = fs.readFileSync('App.tsx', 'utf-8');
appContent = appContent.replace(/PATCH 1\\\" ĐẾN \\\"PATCH 12/g, 'PATCH 1\\" ĐẾN \\"PATCH 15');
appContent = appContent.replace(/PATCH TỪ 1 ĐẾN 12/g, 'PATCH TỪ 1 ĐẾN 15');
appContent = appContent.replace(/12 BẢN VÁ/g, '15 BẢN VÁ');
appContent = appContent.replace(/12 PATCH/g, '15 PATCH');
appContent = appContent.replace(/PATCH 6 ĐẾN PATCH 12/g, 'PATCH 6 ĐẾN PATCH 15');
appContent = appContent.replace(/PATCH 5 ĐẾN PATCH 12/g, 'PATCH 5 ĐẾN PATCH 15');
appContent = appContent.replace(/PATCH 8 ĐẾN 12/g, 'PATCH 8 ĐẾN 15');

fs.writeFileSync('App.tsx', appContent, 'utf-8');
console.log('PATCH 13, 14, 15 injected successfully');
