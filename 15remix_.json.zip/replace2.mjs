import fs from 'fs';
['./types.ts', './components/VectorMemoryModal.tsx'].forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/"gemini-3-flash-preview"/g, '"gemini-3.5-flash"');
  fs.writeFileSync(file, content);
});
