import express from "express";
import path from "path";
import cors from "cors";
import { GoogleGenAI } from "@google/genai";
import { CUSTOM_USER_DIRECTIVES } from "./utils/custom_directives.js";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json({ limit: "50mb" }));

  // Initialize Gemini
  let ai: GoogleGenAI | null = null;
  
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      ai = new GoogleGenAI({ apiKey });
    }
  } catch (err) {
    console.error("Failed to initialize Gemini:", err);
  }

  const SYSTEM_INSTRUCTION = CUSTOM_USER_DIRECTIVES;

  app.post("/api/chat", async (req, res) => {
    if (!ai) {
      return res.status(500).json({ error: "GEMINI_API_KEY is not configured on the server." });
    }

    try {
      const { messages, diceRollRequested } = req.body;
      
      let chatMessages = messages;
      
      // If the UI sends a flag to start the dice roll, we simulate the prompt context
      if (diceRollRequested && messages.length === 0) {
         chatMessages = [{ role: 'user', content: "[SYSTEM CMD: Kích hoạt OMNI-DICE ROLL cho {{user}}. Hãy thực hiện PHASE 1: Bốc thăm mù quáng bảng 1 (Tone Vibe 10 lựa chọn) và tạo ra khung cảnh khởi đầu hoàn toàn ngẫu nhiên mà chưa đưa {{user}} vào. Đảm bảo nhịp chậm rãi.]" }];
      }

      // Convert format for latest @google/genai SDK
      const formattedHistory = chatMessages.map((msg: any) => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.content }],
      }));

      // In genai SDK, system instructions and safety settings are passed in the config
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: formattedHistory,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          safetySettings: [
             { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
             { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" },
             { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
             { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" }
          ] as any,
          temperature: 0.9,
          // Instructing for long length but giving a reasonable max tokens
          maxOutputTokens: 3000,
        }
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Chat Error:", error);
      res.status(500).json({ error: error.message || "An error occurred fetching response" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
