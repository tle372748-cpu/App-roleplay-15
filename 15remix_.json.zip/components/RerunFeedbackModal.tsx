
import React, { useState } from 'react';
import { X, Star, AlertTriangle, MessageSquare, Zap, Check } from 'lucide-react';

interface RerunFeedbackModalProps {
  onClose: () => void;
  onConfirm: (instruction: string) => void;
  themeColors: any;
}

const ERROR_TAGS = [
    "OOC (Sai Tính Cách)",
    "Văn Phong Chán/Lặp",
    "Logic Ngu (Mất Não)",
    "Quên Ký Ức/Lore",
    "Quá Ngắn/Cụt Lủn",
    "Thiếu Cảm Xúc",
    "Sai Bối Cảnh",
    "Quá 'AI' (Máy Móc)"
];

const RerunFeedbackModal: React.FC<RerunFeedbackModalProps> = ({ onClose, onConfirm, themeColors }) => {
  const [rating, setRating] = useState(0);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [guidance, setGuidance] = useState('');

  const toggleTag = (tag: string) => {
      setSelectedTags(prev => 
          prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
      );
  };

  const handleSubmit = () => {
      // If no feedback provided, send empty string to trigger default "Strong Rerun" mode in ChatInterface
      if (rating === 0 && selectedTags.length === 0 && !guidance.trim()) {
          onConfirm("");
          return;
      }

      let instruction = `[SYSTEM - REGENERATION ORDER]\n`;
      
      if (rating > 0) {
          instruction += `- PREVIOUS RATING: ${rating}/5 Stars (User Feedback).\n`;
      }
      
      if (selectedTags.length > 0) {
          instruction += `- DETECTED FLAWS: ${selectedTags.join(', ')}.\n`;
          instruction += `- DIRECTIVE: Avoid these flaws absolutely in the new generation.\n`;
      }

      if (guidance.trim()) {
          instruction += `- USER COMMAND: "${guidance}"\n`;
          instruction += `- INSTRUCTION: Rewrite the response following the User Command strictly.\n`;
      } else {
          instruction += `- INSTRUCTION: Rewrite with better quality and creativity.\n`;
      }

      onConfirm(instruction);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in zoom-in-95 duration-200">
      <div className="w-full max-w-md bg-zinc-950 border border-yellow-500/30 rounded-xl shadow-2xl flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="p-4 border-b border-yellow-500/20 bg-yellow-950/10 flex justify-between items-center">
            <div className="flex items-center gap-2 text-yellow-500">
                <Zap size={20} className="fill-current" />
                <h3 className="font-mono font-bold uppercase tracking-widest text-sm">CẢI TẠO NỘI DUNG</h3>
            </div>
            <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors"><X size={20}/></button>
        </div>

        <div className="p-6 flex flex-col gap-6">
            
            {/* 1. Rating */}
            <div className="flex flex-col gap-2 items-center">
                <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Đánh Giá Tin Nhắn Cũ</span>
                <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                        <button 
                            key={star}
                            onClick={() => setRating(star)}
                            className={`transition-all hover:scale-110 ${rating >= star ? 'text-yellow-400 fill-yellow-400' : 'text-zinc-700'}`}
                        >
                            <Star size={24} />
                        </button>
                    ))}
                </div>
            </div>

            {/* 2. Error Tags */}
            <div className="space-y-2">
                <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                    <AlertTriangle size={12}/> Vạch Lá Tìm Sâu (Chọn Lỗi)
                </span>
                <div className="grid grid-cols-2 gap-2">
                    {ERROR_TAGS.map(tag => (
                        <button
                            key={tag}
                            onClick={() => toggleTag(tag)}
                            className={`px-3 py-2 rounded-lg text-[10px] font-bold border text-left transition-all
                                ${selectedTags.includes(tag) 
                                    ? 'bg-red-900/30 border-red-500 text-red-300' 
                                    : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:border-zinc-600'}
                            `}
                        >
                            {tag}
                        </button>
                    ))}
                </div>
            </div>

            {/* 3. Guidance */}
            <div className="space-y-2">
                <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                    <MessageSquare size={12}/> Chỉ Đạo Sửa Đổi
                </span>
                <textarea 
                    value={guidance}
                    onChange={(e) => setGuidance(e.target.value)}
                    placeholder="VD: Viết dâm hơn, Char phải ngại ngùng hơn, Đừng nói đạo lý nữa..."
                    className="w-full h-24 bg-black/40 border border-zinc-700 rounded-xl p-3 text-xs text-white placeholder-zinc-600 outline-none focus:border-yellow-500 transition-colors resize-none font-mono"
                />
            </div>

            {/* Actions */}
            <button 
                onClick={handleSubmit}
                className="w-full py-3 bg-yellow-600 hover:bg-yellow-500 text-black font-black uppercase tracking-widest rounded-xl shadow-lg shadow-yellow-900/20 transition-all active:scale-95 flex items-center justify-center gap-2"
            >
                <Check size={16} /> Thực Thi Sửa Đổi
            </button>
            
            <p className="text-[9px] text-center text-zinc-600 italic">
                (Để trống và ấn nút trên để Rerun tự động với thiết lập "Chống Tua Nhanh / Tăng Độ Dài")
            </p>

        </div>
      </div>
    </div>
  );
};

export default RerunFeedbackModal;