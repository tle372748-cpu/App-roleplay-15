import React, { useState, useRef, useEffect } from 'react';
import { X, Upload, Layers, Trash2, Move, Image as ImageIcon, Plus, Check, Monitor, Smartphone, RotateCw, Scissors } from 'lucide-react';
import { AppConfig, ThemeOverlay } from '../types';

interface ThemeOverlayManagerProps {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  onClose: () => void;
}

const ThemeOverlayManager: React.FC<ThemeOverlayManagerProps> = ({ config, setConfig, onClose }) => {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'LAYERS' | 'PREVIEW'>('LAYERS');
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const previewRef = useRef<HTMLDivElement>(null);

  const overlays = config.overlays || [];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const src = event.target?.result as string;
      const newOverlay: ThemeOverlay = {
        id: Date.now().toString(),
        src,
        x: 50,
        y: 50,
        scale: 1,
        rotation: 0,
        layer: 'background'
      };
      setConfig(prev => ({ ...prev, overlays: [...(prev.overlays || []), newOverlay] }));
      setSelectedId(newOverlay.id);
      setActiveTab('PREVIEW'); // Switch to preview to position it
    };
    reader.readAsDataURL(file);
  };

  const updateOverlay = (id: string, updates: Partial<ThemeOverlay>) => {
    setConfig(prev => ({
      ...prev,
      overlays: (prev.overlays || []).map(o => o.id === id ? { ...o, ...updates } : o)
    }));
  };

  const deleteOverlay = (id: string) => {
    setConfig(prev => ({
      ...prev,
      overlays: (prev.overlays || []).filter(o => o.id !== id)
    }));
    if (selectedId === id) setSelectedId(null);
  };

  const handleChromaKey = async (id: string, color: 'GREEN' | 'WHITE') => {
    const overlay = overlays.find(o => o.id === id);
    if (!overlay) return;

    setIsProcessing(true);
    try {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.src = overlay.src;
      await new Promise((resolve) => { img.onload = resolve; });

      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.drawImage(img, 0, 0);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;

      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];

        if (color === 'GREEN') {
             // Simple Green Screen Removal (Target: Bright Green)
             // Heuristic: G is dominant and significantly brighter than R and B
            if (g > 100 && g > r + 40 && g > b + 40) {
                data[i + 3] = 0; // Set Alpha to 0
            }
        } else if (color === 'WHITE') {
            // Simple White Background Removal
            // Heuristic: All channels are very bright
            if (r > 240 && g > 240 && b > 240) {
                data[i + 3] = 0;
            }
        }
      }

      ctx.putImageData(imageData, 0, 0);
      const newSrc = canvas.toDataURL('image/png');
      updateOverlay(id, { src: newSrc });
    } catch (e) {
      console.error("Chroma Key Failed", e);
      alert("Failed to process image. Ensure it's a valid image file.");
    } finally {
      setIsProcessing(false);
    }
  };

  // Drag Logic
  const handleDragStart = (e: React.MouseEvent | React.TouchEvent, id: string) => {
    e.stopPropagation();
    setSelectedId(id);
    
    const startX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const startY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    
    const overlay = overlays.find(o => o.id === id);
    if (!overlay) return;
    
    const startOverlayX = overlay.x;
    const startOverlayY = overlay.y;

    const handleMove = (moveEvent: MouseEvent | TouchEvent) => {
      if (!previewRef.current) return;
      
      const currentX = 'touches' in moveEvent ? moveEvent.touches[0].clientX : (moveEvent as MouseEvent).clientX;
      const currentY = 'touches' in moveEvent ? moveEvent.touches[0].clientY : (moveEvent as MouseEvent).clientY;
      
      const deltaX = currentX - startX;
      const deltaY = currentY - startY;
      
      const rect = previewRef.current.getBoundingClientRect();
      const percentX = (deltaX / rect.width) * 100;
      const percentY = (deltaY / rect.height) * 100;
      
      updateOverlay(id, {
        x: Math.min(100, Math.max(0, startOverlayX + percentX)),
        y: Math.min(100, Math.max(0, startOverlayY + percentY))
      });
    };

    const handleEnd = () => {
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('mouseup', handleEnd);
      window.removeEventListener('touchmove', handleMove);
      window.removeEventListener('touchend', handleEnd);
    };

    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleEnd);
    window.addEventListener('touchmove', handleMove);
    window.addEventListener('touchend', handleEnd);
  };

  const selectedOverlay = overlays.find(o => o.id === selectedId);

  // Determine background style for preview
  const bgStyle = config.customBackground 
    ? (config.customBackground.startsWith('video|') ? {} : { backgroundImage: `url(${config.customBackground})` })
    : { backgroundColor: '#000' }; // Fallback

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/90 backdrop-blur-md p-0 md:p-4">
      <div className="w-full h-full md:max-w-4xl md:h-[90vh] bg-zinc-900 border-0 md:border md:border-white/10 md:rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-white/10 bg-zinc-900 z-10">
          <h2 className="text-lg font-serif text-amber-100 flex items-center gap-2">
            <Layers size={18} className="text-amber-500"/>
            Theme Overlays
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <X size={20} className="text-white/70" />
          </button>
        </div>

        {/* Mobile Tabs */}
        <div className="flex md:hidden border-b border-white/10">
          <button 
            onClick={() => setActiveTab('LAYERS')}
            className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider ${activeTab === 'LAYERS' ? 'text-amber-400 border-b-2 border-amber-400 bg-white/5' : 'text-zinc-500'}`}
          >
            Layers & Settings
          </button>
          <button 
            onClick={() => setActiveTab('PREVIEW')}
            className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider ${activeTab === 'PREVIEW' ? 'text-amber-400 border-b-2 border-amber-400 bg-white/5' : 'text-zinc-500'}`}
          >
            Preview & Edit
          </button>
        </div>

        <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
          
          {/* Left: Controls (Visible on Desktop or LAYERS tab) */}
          <div className={`w-full md:w-1/3 p-4 border-r border-white/10 overflow-y-auto custom-scrollbar bg-zinc-900 ${activeTab === 'LAYERS' ? 'block' : 'hidden md:block'}`}>
            <div className="space-y-6 pb-20 md:pb-0">
              {/* Upload Button */}
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-3 px-4 bg-white/5 hover:bg-white/10 border border-dashed border-white/20 rounded-xl flex items-center justify-center gap-2 transition-all group"
              >
                <div className="p-2 bg-amber-500/20 rounded-lg group-hover:bg-amber-500/30 transition-colors">
                  <Upload size={18} className="text-amber-400" />
                </div>
                <span className="text-sm font-medium text-zinc-300">Upload New Overlay</span>
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*" 
                onChange={handleFileUpload} 
              />

              {/* Selected Item Controls */}
              {selectedOverlay ? (
                <div className="bg-black/40 rounded-xl p-4 border border-white/5 space-y-4 animate-in fade-in slide-in-from-left-4">
                  <div className="flex items-center gap-3 mb-2 pb-2 border-b border-white/5">
                    <img src={selectedOverlay.src} className="w-10 h-10 rounded object-cover border border-white/10" />
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] text-zinc-500 uppercase tracking-wider">Editing</p>
                      <p className="text-sm font-medium text-white truncate">Overlay #{selectedOverlay.id.slice(-4)}</p>
                    </div>
                    <button 
                      onClick={() => deleteOverlay(selectedOverlay.id)}
                      className="p-2 hover:bg-red-500/20 text-zinc-400 hover:text-red-400 rounded-lg transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>

                  {/* Scale Slider */}
                  <div>
                    <div className="flex justify-between text-xs text-zinc-400 mb-1">
                      <span>Scale</span>
                      <span>{(selectedOverlay.scale * 100).toFixed(0)}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="0.1" 
                      max="3" 
                      step="0.1" 
                      value={selectedOverlay.scale}
                      onChange={(e) => updateOverlay(selectedOverlay.id, { scale: parseFloat(e.target.value) })}
                      className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-amber-500"
                    />
                  </div>

                  {/* Rotation Slider */}
                  <div>
                    <div className="flex justify-between text-xs text-zinc-400 mb-1">
                      <span className="flex items-center gap-1"><RotateCw size={10}/> Rotation</span>
                      <span>{Math.round(selectedOverlay.rotation || 0)}°</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="360" 
                      step="1" 
                      value={selectedOverlay.rotation || 0}
                      onChange={(e) => updateOverlay(selectedOverlay.id, { rotation: parseInt(e.target.value) })}
                      className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-amber-500"
                    />
                  </div>

                  {/* Chroma Key Buttons */}
                  <div className="flex gap-2">
                      <button 
                        onClick={() => handleChromaKey(selectedOverlay.id, 'GREEN')}
                        disabled={isProcessing}
                        className="flex-1 py-2 px-3 bg-green-900/30 hover:bg-green-900/50 border border-green-500/30 rounded-lg flex items-center justify-center gap-2 text-green-400 text-[10px] font-bold uppercase transition-all"
                      >
                        {isProcessing ? (
                          <span className="animate-pulse">Processing...</span>
                        ) : (
                          <>
                            <Scissors size={12} /> Remove Green
                          </>
                        )}
                      </button>
                      <button 
                        onClick={() => handleChromaKey(selectedOverlay.id, 'WHITE')}
                        disabled={isProcessing}
                        className="flex-1 py-2 px-3 bg-zinc-800 hover:bg-zinc-700 border border-zinc-600 rounded-lg flex items-center justify-center gap-2 text-white text-[10px] font-bold uppercase transition-all"
                      >
                        {isProcessing ? (
                          <span className="animate-pulse">Processing...</span>
                        ) : (
                          <>
                            <Scissors size={12} /> Remove White
                          </>
                        )}
                      </button>
                  </div>

                  {/* Layer Toggle */}
                  <div className="flex gap-2">
                    <button 
                      onClick={() => updateOverlay(selectedOverlay.id, { layer: 'background' })}
                      className={`flex-1 py-2 px-3 rounded-lg text-xs font-medium border transition-all flex items-center justify-center gap-2 ${
                        selectedOverlay.layer === 'background' 
                          ? 'bg-amber-500/20 border-amber-500/50 text-amber-300' 
                          : 'bg-white/5 border-transparent text-zinc-400 hover:bg-white/10'
                      }`}
                    >
                      <ImageIcon size={14} />
                      Background
                    </button>
                    <button 
                      onClick={() => updateOverlay(selectedOverlay.id, { layer: 'foreground' })}
                      className={`flex-1 py-2 px-3 rounded-lg text-xs font-medium border transition-all flex items-center justify-center gap-2 ${
                        selectedOverlay.layer === 'foreground' 
                          ? 'bg-purple-500/20 border-purple-500/50 text-purple-300' 
                          : 'bg-white/5 border-transparent text-zinc-400 hover:bg-white/10'
                      }`}
                    >
                      <Layers size={14} />
                      Foreground
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-4 px-4 bg-white/5 rounded-xl border border-dashed border-white/10 text-zinc-500 text-xs">
                  Select an overlay below to edit properties
                </div>
              )}

              {/* List of Overlays */}
              <div className="space-y-2">
                <h3 className="text-xs font-mono text-zinc-500 uppercase tracking-widest mb-2 flex justify-between">
                  <span>Layers ({overlays.length})</span>
                  <span className="text-[10px]">Top = Front</span>
                </h3>
                {overlays.length === 0 && (
                  <div className="text-center py-8 text-zinc-600 text-xs italic">
                    No overlays added yet.
                  </div>
                )}
                {overlays.map((overlay, idx) => (
                  <div 
                    key={overlay.id}
                    onClick={() => setSelectedId(overlay.id)}
                    className={`flex items-center gap-3 p-2 rounded-lg cursor-pointer border transition-all ${
                      selectedId === overlay.id 
                        ? 'bg-white/10 border-white/20' 
                        : 'hover:bg-white/5 border-transparent'
                    }`}
                  >
                    <span className="text-[10px] text-zinc-600 font-mono w-4">{idx + 1}</span>
                    <div className="w-8 h-8 rounded bg-black/50 flex items-center justify-center overflow-hidden border border-white/5">
                      <img src={overlay.src} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-zinc-300 truncate">Overlay #{overlay.id.slice(-4)}</p>
                      <p className="text-[10px] text-zinc-500 capitalize">{overlay.layer}</p>
                    </div>
                    {selectedId === overlay.id && <Check size={14} className="text-amber-400" />}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Preview (Visible on Desktop or PREVIEW tab) */}
          <div className={`w-full md:w-2/3 bg-black/95 relative flex items-center justify-center p-0 md:p-8 overflow-hidden ${activeTab === 'PREVIEW' ? 'block h-full' : 'hidden md:flex'}`}>
            <div className="absolute inset-0 texture-dots opacity-20 pointer-events-none" />
            
            {/* Phone Frame Preview */}
            <div 
              ref={previewRef}
              className="relative w-full h-full md:w-[320px] md:h-[640px] bg-zinc-900 md:border-4 md:border-zinc-800 md:rounded-[3rem] md:shadow-2xl overflow-hidden flex-shrink-0"
            >
              {/* Wallpaper Placeholder */}
              <div className="absolute inset-0 bg-cover bg-center opacity-50 transition-all duration-500" style={bgStyle} />
              {config.customBackground?.startsWith('video|') && (
                 <video src={config.customBackground.replace('video|', '')} autoPlay loop muted playsInline className="absolute inset-0 w-full h-full object-cover opacity-50" />
              )}
              
              {/* Content Placeholder (Simulated UI) */}
              <div className="absolute inset-0 flex flex-col p-6 pointer-events-none z-10">
                <div className="mt-8 md:mt-12 w-1/2 h-4 bg-white/10 rounded mb-4 backdrop-blur-sm" />
                <div className="w-3/4 h-20 bg-white/5 rounded-xl mb-4 backdrop-blur-sm border border-white/5" />
                <div className="self-end w-3/4 h-16 bg-amber-500/10 rounded-xl mb-4 border border-amber-500/20 backdrop-blur-sm" />
                <div className="w-2/3 h-12 bg-white/5 rounded-xl backdrop-blur-sm" />
                
                <div className="mt-auto w-full h-12 bg-white/5 rounded-full backdrop-blur-md border border-white/10 flex items-center px-4 gap-2">
                    <div className="w-6 h-6 rounded-full bg-white/20"></div>
                    <div className="flex-1 h-2 bg-white/10 rounded"></div>
                </div>
              </div>

              {/* Overlays Rendering */}
              {overlays.map(overlay => (
                <div
                  key={overlay.id}
                  onMouseDown={(e) => handleDragStart(e, overlay.id)}
                  onTouchStart={(e) => handleDragStart(e, overlay.id)}
                  className={`absolute cursor-move transition-transform touch-none ${selectedId === overlay.id ? 'z-50 ring-2 ring-amber-400 ring-offset-2 ring-offset-black' : 'z-20'}`}
                  style={{
                    left: `${overlay.x}%`,
                    top: `${overlay.y}%`,
                    transform: `translate(-50%, -50%) scale(${overlay.scale}) rotate(${overlay.rotation || 0}deg)`,
                    zIndex: overlay.layer === 'foreground' ? 30 : 5, // Visual z-index in preview
                    opacity: overlay.layer === 'foreground' ? 1 : 0.8 // Visual distinction
                  }}
                >
                  <img 
                    src={overlay.src} 
                    className="max-w-[150px] max-h-[150px] object-contain pointer-events-none select-none" 
                    alt="overlay"
                  />
                </div>
              ))}
            </div>
            
            <div className="absolute bottom-4 left-0 right-0 text-zinc-500 text-[10px] text-center pointer-events-none bg-black/50 py-1 backdrop-blur-sm">
              Drag to move • Pinch/Slider to scale • Select to edit
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ThemeOverlayManager;
