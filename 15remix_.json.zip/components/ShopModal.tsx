
import React, { useState } from 'react';
import { ShoppingCart, X, Loader2, Coins, Heart, RefreshCw, Search, Ghost, CheckCircle } from 'lucide-react';
import { ShopItem, ChatMessage } from '../types';
import { formatVND } from '../utils/mockDataGenerator';
import { searchShopItems } from '../services/aiService';

interface ShopModalProps {
  onClose: () => void;
  shopItems: ShopItem[];
  isLoading: boolean;
  onBuy: (item: ShopItem) => void;
  userBalance: number;
  themeColors: any;
  onRefresh?: () => void;
  messages?: ChatMessage[]; // Pass history for context-aware search
}

const ShopModal: React.FC<ShopModalProps> = ({ onClose, shopItems: initialItems, isLoading: initialLoading, onBuy, userBalance, themeColors, onRefresh, messages = [] }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isBlackMarket, setIsBlackMarket] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<ShopItem[] | null>(null);
  const [purchaseFeedback, setPurchaseFeedback] = useState<{ item: string, price: number } | null>(null);

  const displayedItems = searchResults || initialItems;
  const loading = isSearching || initialLoading;

  // Visual Theme overrides for Black Market
  const modalBg = isBlackMarket ? 'bg-zinc-950' : themeColors.bgMain;
  const borderColor = isBlackMarket ? 'border-red-900/50' : themeColors.border;
  const headerBg = isBlackMarket ? 'bg-red-950/30' : themeColors.bgPanel;
  const accentText = isBlackMarket ? 'text-red-500' : 'text-yellow-500';
  const iconBg = isBlackMarket ? 'bg-red-900/20 border-red-500/50 text-red-500' : 'bg-yellow-500/10 text-yellow-500 border-yellow-500/30';

  const handleSearch = async () => {
      if (!searchQuery.trim()) {
          setSearchResults(null);
          return;
      }
      setIsSearching(true);
      try {
          const results = await searchShopItems(searchQuery, isBlackMarket, userBalance, messages);
          setSearchResults(results);
      } catch (e) {
          console.error(e);
      } finally {
          setIsSearching(false);
      }
  };

  const toggleBlackMarket = () => {
      setIsBlackMarket(!isBlackMarket);
      setSearchResults(null); // Reset results when switching modes
      setSearchQuery('');
  };

  const handleBuyClick = (item: ShopItem) => {
      onBuy(item);
      setPurchaseFeedback({ item: item.name, price: item.price });
      setTimeout(() => setPurchaseFeedback(null), 1500);
  };

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200 ${isBlackMarket ? 'bg-black/90' : 'bg-black/80'}`}>
      <div className={`w-full max-w-2xl border rounded-xl shadow-2xl flex flex-col h-[80vh] transition-colors duration-500 ${modalBg} ${borderColor} relative overflow-hidden`}>
        
        {/* Background Effect for Black Market */}
        {isBlackMarket && (
            <div className="absolute inset-0 pointer-events-none z-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-red-900/10 via-transparent to-transparent opacity-50"></div>
        )}

        {/* Purchase Feedback Overlay */}
        {purchaseFeedback && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
                <div className={`p-8 rounded-2xl shadow-[0_0_50px_rgba(0,0,0,0.5)] flex flex-col items-center gap-4 transform animate-in zoom-in-95 slide-in-from-bottom-2 duration-300 border ${isBlackMarket ? 'bg-red-950 border-red-500' : 'bg-zinc-900 border-green-500'}`}>
                    <div className={`p-4 rounded-full ${isBlackMarket ? 'bg-red-500/20 text-red-400 shadow-[0_0_20px_rgba(220,38,38,0.4)]' : 'bg-green-500/20 text-green-400 shadow-[0_0_20px_rgba(34,197,94,0.4)]'}`}>
                        <CheckCircle size={48} className="animate-in zoom-in duration-300" />
                    </div>
                    <div className="text-center">
                        <h3 className={`font-bold text-xl font-mono uppercase tracking-wider ${isBlackMarket ? 'text-red-200' : 'text-green-200'}`}>
                            {isBlackMarket ? 'GIAO DỊCH THÀNH CÔNG' : 'CẢM ƠN QUÝ KHÁCH!'}
                        </h3>
                        <p className={`text-sm font-mono mt-1 ${isBlackMarket ? 'text-red-400' : 'text-green-400'}`}>
                            {purchaseFeedback.item}
                        </p>
                        <div className="mt-3 px-3 py-1 bg-black/40 rounded border border-white/10 inline-block">
                            <p className="text-xs opacity-70 font-mono text-white">
                                - {formatVND(purchaseFeedback.price)}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* Header */}
        <div className={`flex items-center justify-between p-4 border-b ${borderColor} ${headerBg} rounded-t-xl shrink-0 z-10 transition-colors duration-300`}>
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-full border transition-colors duration-300 ${iconBg}`}>
                {isBlackMarket ? <Ghost size={20} className="animate-pulse" /> : <ShoppingCart size={20} />}
            </div>
            <div>
                <h2 className={`font-mono font-bold tracking-widest text-lg ${accentText} transition-colors duration-300`}>
                    {isBlackMarket ? 'CHỢ ĐEN' : 'CỬA HÀNG NGỮ CẢNH'}
                </h2>
                <div className="flex items-center gap-1 text-[10px] font-mono opacity-70">
                    <Coins size={10} className={accentText}/>
                    <span>Số dư: {formatVND(userBalance)}</span>
                </div>
            </div>
          </div>
          <div className="flex gap-2 items-center">
              {/* Black Market Toggle */}
              <button 
                onClick={toggleBlackMarket}
                className={`p-2 rounded-full border transition-all duration-500 group relative ${isBlackMarket ? 'bg-red-600 border-red-400 text-white shadow-[0_0_15px_rgba(220,38,38,0.5)]' : 'bg-zinc-800 border-zinc-700 text-zinc-500 hover:text-zinc-300'}`}
                title={isBlackMarket ? "Quay về an toàn" : "Vào Chợ Đen"}
              >
                  <Ghost size={18} />
                  {/* Tooltip hint for normal mode */}
                  {!isBlackMarket && <span className="absolute -bottom-8 right-0 text-[9px] w-max bg-black text-white px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">Web Ngầm?</span>}
              </button>

              {onRefresh && !isBlackMarket && (
                  <button 
                    onClick={onRefresh} 
                    disabled={loading}
                    className="p-2 rounded-full hover:bg-white/5 text-yellow-500/80 hover:text-yellow-400 transition-colors disabled:opacity-50 disabled:animate-spin"
                    title="Làm mới hàng"
                  >
                      <RefreshCw size={18} />
                  </button>
              )}
              <button onClick={onClose} className={`${themeColors.textDim} hover:${themeColors.textMain} transition-colors p-2 rounded-full hover:bg-white/5`}>
                <X size={20} />
              </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className={`p-3 border-b ${borderColor} ${isBlackMarket ? 'bg-red-950/20' : ''} flex gap-2 z-10`}>
            <div className="relative flex-1">
                <input 
                    type="text" 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                    placeholder={isBlackMarket ? "Tìm hàng cấm..." : "Tìm vật phẩm..."}
                    className={`w-full bg-black/40 border ${borderColor} rounded-lg pl-9 pr-3 py-2 text-xs font-mono outline-none focus:border-current transition-colors ${themeColors.textMain} placeholder:text-white/20`}
                />
                <Search size={14} className={`absolute left-3 top-2.5 ${themeColors.textDim}`} />
            </div>
            <button 
                onClick={handleSearch}
                disabled={loading}
                className={`px-4 py-2 rounded-lg font-mono text-xs font-bold uppercase transition-all ${isBlackMarket ? 'bg-red-800 hover:bg-red-700 text-white' : 'bg-blue-600 hover:bg-blue-500 text-white'}`}
            >
                {loading ? <Loader2 size={14} className="animate-spin"/> : 'TÌM'}
            </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar relative z-10">
            {loading ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                    <Loader2 size={32} className={`animate-spin ${accentText}`} />
                    <span className={`font-mono text-xs ${accentText} opacity-70 animate-pulse`}>
                        {isBlackMarket ? "Đang kết nối web ngầm... Tìm nguồn hàng..." : "Đang kiểm tra kho... Tìm hàng..."}
                    </span>
                </div>
            ) : displayedItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center opacity-50 gap-2">
                    {isBlackMarket ? <Ghost size={32} className="text-red-500" /> : <ShoppingCart size={32} />}
                    <span className="text-xs font-mono">
                        {isBlackMarket ? "Bóng tối đang trống rỗng... lúc này." : "Cửa hàng trống trơn. Thử tìm kiếm xem!"}
                    </span>
                </div>
            ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {displayedItems.map((item) => {
                        const price = isNaN(item.price) ? 0 : item.price;
                        const canAfford = userBalance >= price;
                        return (
                            <div key={item.id} className={`p-4 rounded-xl border transition-all relative group flex flex-col gap-3 ${
                                isBlackMarket 
                                    ? (canAfford ? 'border-red-900/30 bg-red-950/10 hover:bg-red-900/20 hover:border-red-500/50' : 'border-red-900/10 bg-black/40 opacity-60')
                                    : (canAfford ? 'border-white/10 hover:border-yellow-500/50 bg-white/5 hover:bg-white/10' : 'border-red-500/20 bg-red-900/5 opacity-70 grayscale')
                            }`}>
                                <div className="flex justify-between items-start">
                                    <div className="flex items-center gap-3">
                                        <span className="text-3xl filter drop-shadow-md">{item.icon || '📦'}</span>
                                        <div className="flex flex-col">
                                            <span className={`font-bold text-sm ${isBlackMarket ? 'text-red-200' : themeColors.textMain}`}>{item.name}</span>
                                            <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded w-fit border mt-1 ${
                                                isBlackMarket 
                                                ? 'text-red-400 bg-red-900/20 border-red-900/50' 
                                                : 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20'
                                            }`}>{item.type || 'ITEM'}</span>
                                        </div>
                                    </div>
                                    <button className="text-white/20 hover:text-pink-500 transition-colors p-1" title="Thêm vào Yêu thích">
                                        <Heart size={14} />
                                    </button>
                                </div>
                                
                                <p className={`text-[11px] ${isBlackMarket ? 'text-red-200/60' : themeColors.textDim} leading-relaxed min-h-[2.5em]`}>{item.description}</p>
                                
                                {item.usageType && item.usageType !== 'CONSUMABLE' && (
                                    <div className={`text-[9px] font-mono uppercase px-2 py-1 rounded w-fit ${item.usageType === 'EQUIP' ? 'bg-blue-900/30 text-blue-300' : 'bg-purple-900/30 text-purple-300'}`}>
                                        {item.usageType === 'EQUIP' ? '🛡️ Mặc/Đeo' : '♾️ Vĩnh Viễn'}
                                    </div>
                                )}
                                
                                <div className="mt-auto flex justify-between items-center pt-2 border-t border-white/5">
                                    <span className={`font-mono text-xs font-bold ${canAfford ? (isBlackMarket ? 'text-red-400' : 'text-green-400') : 'text-gray-500'}`}>
                                        {formatVND(price)}
                                    </span>
                                    <button 
                                        onClick={() => canAfford && handleBuyClick(item)}
                                        disabled={!canAfford}
                                        className={`px-4 py-1.5 rounded text-[10px] font-bold uppercase tracking-wide transition-all ${
                                            canAfford 
                                            ? (isBlackMarket 
                                                ? 'bg-red-700 hover:bg-red-600 text-white shadow-lg shadow-red-900/40' 
                                                : 'bg-yellow-600 hover:bg-yellow-500 text-white shadow-lg shadow-yellow-900/20')
                                            : 'bg-white/10 text-white/30 cursor-not-allowed'
                                        }`}
                                    >
                                        {canAfford ? 'MUA NGAY' : 'THIẾU TIỀN'}
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
        
        <div className={`p-3 border-t ${borderColor} ${headerBg} text-center z-10 transition-colors`}>
            <span className="text-[9px] font-mono text-white/30">
                {isBlackMarket 
                    ? "⚠️ CẢNH BÁO: Giao dịch ẩn danh. Không hoàn tiền. Miễn hỏi." 
                    : "Hàng hóa phụ thuộc vào túi tiền & bối cảnh của bạn."}
            </span>
        </div>

      </div>
    </div>
  );
};

export default ShopModal;
