
import React, { useEffect, useState } from 'react';

interface SplashScreenProps {
  onComplete: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [opacity, setOpacity] = useState(1);

  useEffect(() => {
    // Start fade out at 0.5s
    const fadeTimer = setTimeout(() => {
      setOpacity(0);
    }, 500); 

    // Complete exactly at 1.0s
    const completeTimer = setTimeout(() => {
      onComplete();
    }, 1000); 

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(completeTimer);
    };
  }, [onComplete]);

  return (
    <div 
      className="fixed inset-0 z-[100] bg-black flex items-center justify-center transition-opacity duration-500 ease-out cursor-default select-none"
      style={{ opacity: opacity }}
    >
      <div className="relative animate-in zoom-in-50 duration-[500ms] fade-in">
        {/* Ink splatter effect background */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.15)_0%,transparent_70%)] blur-2xl transform scale-150"></div>
        
        <h1 
          className="text-7xl md:text-9xl text-white font-water relative z-10 tracking-widest"
          style={{ 
            textShadow: '0 0 20px rgba(255,255,255,0.8), 0 0 40px rgba(255,255,255,0.4)',
            filter: 'contrast(1.2) brightness(1.2)'
          }}
        >
          Reborn
        </h1>
        
        {/* Ink drippings visual effect */}
        <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-1/2 h-1 bg-white/20 blur-sm rounded-full animate-pulse"></div>
      </div>
    </div>
  );
};

export default SplashScreen;
