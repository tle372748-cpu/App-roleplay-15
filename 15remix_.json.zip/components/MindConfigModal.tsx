
import React, { useState, useEffect } from 'react';
import { AppConfig, CardData } from '../types';
import { X, User, Brain, Zap, Lock, List, Save, Plus, Trash2, Sparkles, Activity, AlertTriangle, Scale, Heart, Skull, Mic, Flame } from 'lucide-react';

interface MindConfigModalProps {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  onClose: () => void;
  themeColors: any;
  initialTarget?: 'USER' | number;
}

const DEFAULT_STATUS = {
    stress: "0",
    arousal: "0",
    secret: "",
    hp: "100"
};

// ALIGNMENT GRID
const ALIGNMENTS = [
    ["Lawful Good", "Neutral Good", "Chaotic Good"],
    ["Lawful Neutral", "True Neutral", "Chaotic Neutral"],
    ["Lawful Evil", "Neutral Evil", "Chaotic Evil"]
];

// SPEECH STYLES
const SPEECH_STYLES = [
    "Normal", "Formal (Polite)", "Casual (Slang)", "Stuttering (Shy)", "Broken (Robot)", 
    "Poetic", "Vulgar (Rude)", "Cryptic", "Childish", "Old English"
];

// Helper Control for Numeric Stats with Improved Input Handling
const StatInputControl = ({ label, value, max = 100, onChange, colorClass = "text-cyan-400" }: any) => {
    const [localVal, setLocalVal] = useState(value.toString());

    useEffect(() => {
        setLocalVal(value.toString());
    }, [value]);

    const handleBlur = () => {
        let num = parseInt(localVal);
        if (isNaN(num)) num = 0;
        if (num > max) num = max;
        if (num < 0) num = 0;
        onChange(num);
        setLocalVal(num.toString());
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter') {
            handleBlur();
            (e.target as HTMLElement).blur();
        }
    };

    return (
      <div className={`flex flex-col gap-2 p-3 rounded-xl border border-white/5 bg-zinc-900/50 hover:bg-zinc-900 transition-all group`}>
          <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider group-hover:text-zinc-300 transition-colors">{label}</span>
              <div className="flex items-center gap-2">
                  <input 
                      type="number"
                      min="0" max={max}
                      value={localVal}
                      onChange={(e) => setLocalVal(e.target.value)}
                      onBlur={handleBlur}
                      onKeyDown={handleKeyDown}
                      className={`w-12 bg-black/40 border border-white/10 rounded text-right px-1 text-xs font-mono font-bold outline-none focus:border-current ${colorClass}`}
                  />
                  <span className="text-[10px] text-zinc-600 font-mono">/{max}</span>
              </div>
          </div>
          <input 
              type="range"
              min="0" max={max}
              value={isNaN(parseInt(localVal)) ? 0 : parseInt(localVal)}
              onChange={(e) => {
                  setLocalVal(e.target.value);
                  onChange(parseInt(e.target.value));
              }}
              className={`w-full h-2 bg-zinc-800 rounded-lg cursor-pointer accent-current ${colorClass.replace('text-', 'accent-')}`}
          />
      </div>
    );
};

// --- NEW MILESTONE COMPONENTS ---

const MilestoneTrack = ({ value, min, max, step, onChange, labels, colorFunc }: { value: number, min: number, max: number, step: number, onChange: (v: number) => void, labels: Record<number, string>, colorFunc: (v: number) => string }) => {
    const stops = [];
    for (let i = min; i <= max; i += step) stops.push(i);
    const percentage = Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100));
    const activeColor = colorFunc(value);

    return (
        <div className="relative py-8 select-none h-16 flex items-center">
            {/* INVISIBLE RANGE INPUT FOR DRAGGING/SWIPING */}
            <input 
                type="range" 
                min={min} max={max} step={step} 
                value={value} 
                onChange={(e) => onChange(parseInt(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20 m-0 p-0"
                style={{ touchAction: 'none' }}
            />

            {/* Track Line */}
            <div className="absolute left-2 right-2 h-1.5 bg-zinc-800 rounded-full z-0"></div>
            
            {/* Fill Line */}
            <div 
                className="absolute left-2 h-1.5 rounded-full transition-all duration-200 z-0"
                style={{ width: `calc(${percentage}% - 0px)`, backgroundColor: activeColor }}
            ></div>

            {/* Stops */}
            <div className="absolute left-2 right-2 h-full pointer-events-none z-10 top-0">
                {stops.map((stopVal) => {
                    const stopPercent = ((stopVal - min) / (max - min)) * 100;
                    const isActive = stopVal === value;
                    const isPassed = stopVal <= value;
                    const label = labels[stopVal];

                    return (
                        <div key={stopVal} style={{ left: `${stopPercent}%` }} className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center">
                            <div
                                className={`w-4 h-4 rounded-full border-2 transition-all duration-200 
                                    ${isActive ? 'scale-125 bg-black' : isPassed ? 'bg-zinc-900' : 'bg-zinc-900'}
                                `}
                                style={{ 
                                    borderColor: isPassed ? activeColor : '#3f3f46',
                                    backgroundColor: isActive ? activeColor : undefined
                                }}
                            />
                            <span 
                                className={`absolute top-6 text-[8px] font-bold uppercase whitespace-nowrap transition-all
                                    ${isActive ? 'text-white scale-110 opacity-100' : 'text-zinc-600 opacity-70'}
                                `}
                            >
                                {label}
                            </span>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

// Personality Milestone Component
const PersonalityMilestone = ({ leftLabel, rightLabel, value, onChange }: { leftLabel: string, rightLabel: string, value: number, onChange: (val: number) => void }) => {
    // Range: -50 to 50, Step 25 (-50, -25, 0, 25, 50)
    const labels: Record<number, string> = {
        [-50]: "Extreme",
        [-25]: "Leaning",
        0: "Balanced",
        25: "Leaning",
        50: "Extreme"
    };

    const getColor = (v: number) => {
        if (v === 0) return '#a1a1aa'; // Zinc-400
        if (v < 0) return '#22d3ee'; // Cyan-400 (Left)
        return '#c084fc'; // Purple-400 (Right)
    };

    return (
        <div className="flex flex-col gap-1 p-3 bg-zinc-900/40 rounded-xl border border-white/5">
            <div className="flex justify-between text-[10px] font-bold uppercase">
                <span className={value < 0 ? "text-cyan-400" : "text-zinc-600"}>{leftLabel}</span>
                <span className={value > 0 ? "text-purple-400" : "text-zinc-600"}>{rightLabel}</span>
            </div>
            <MilestoneTrack 
                value={value} 
                min={-50} 
                max={50} 
                step={25} 
                onChange={onChange} 
                labels={labels}
                colorFunc={getColor}
            />
        </div>
    );
};

// Jealousy Milestone Component
const JealousyMilestone = ({ value, onChange }: { value: number, onChange: (val: number) => void }) => {
    // 0, 25, 50, 75, 100
    const labels: Record<number, string> = {
        0: "NTR/Cuck",
        25: "Open",
        50: "Normal",
        75: "Clingy",
        100: "YANDERE"
    };

    const getColor = (v: number) => {
        if (v <= 10) return '#4ade80'; // Green (NTR)
        if (v <= 40) return '#60a5fa'; // Blue (Tolerant)
        if (v <= 60) return '#a1a1aa'; // Grey (Normal)
        if (v <= 80) return '#fb923c'; // Orange (Possessive)
        return '#ef4444'; // Red (Yandere)
    };

    let activeLabel = "Normal";
    if (value <= 10) activeLabel = "NTR / Cuckquean (Enjoy Sharing)";
    else if (value <= 40) activeLabel = "Tolerant / Open (Thoáng)";
    else if (value <= 60) activeLabel = "Normal (Bình Thường)";
    else if (value <= 80) activeLabel = "Possessive (Chiếm Hữu)";
    else activeLabel = "YANDERE (Điên Tình / Murderous)";

    return (
        <div className="flex flex-col gap-2 p-4 rounded-xl border border-red-900/30 bg-red-950/10">
            <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2"><Flame size={12} className={value >= 80 ? "animate-pulse text-red-500" : ""}/> Jealousy Engine</span>
                <span className="text-[10px] font-mono font-bold uppercase transition-colors" style={{ color: getColor(value) }}>{activeLabel}</span>
            </div>
            <MilestoneTrack 
                value={value} 
                min={0} 
                max={100} 
                step={25} 
                onChange={onChange} 
                labels={labels}
                colorFunc={getColor}
            />
        </div>
    );
};

const MindConfigModal: React.FC<MindConfigModalProps> = ({ config, setConfig, onClose, themeColors, initialTarget }) => {
  const [selectedTarget, setSelectedTarget] = useState<'USER' | number>(initialTarget !== undefined ? initialTarget : 'USER');
  const [activeTab, setActiveTab] = useState<'PSYCHE' | 'TRAITS' | 'DEEP'>('PSYCHE');
  
  const [newTraitInput, setNewTraitInput] = useState('');
  const [newMemoryInput, setNewMemoryInput] = useState('');
  const [newObsessionInput, setNewObsessionInput] = useState('');

  // --- DATA HELPERS ---
  const getTargetCard = (target: 'USER' | number): CardData => {
      const card = target === 'USER' ? config.userCard : config.characterCards[target as number];
      return card || { name: "Unknown", traits: [], status: DEFAULT_STATUS, hiddenMemories: [] } as any;
  };

  const currentCard = getTargetCard(selectedTarget);

  // --- UPDATE LOGIC ---
  const updateCard = (updates: Partial<CardData>) => {
      setConfig(prev => {
          if (selectedTarget === 'USER') {
              return prev.userCard ? { 
                  ...prev, 
                  userCard: { ...prev.userCard, ...updates } 
              } : prev;
          } else {
              const idx = selectedTarget as number;
              const newChars = [...prev.characterCards];
              if (newChars[idx]) {
                  newChars[idx] = { ...newChars[idx], ...updates };
              }
              return { ...prev, characterCards: newChars };
          }
      });
  };

  const updateStatus = (key: string, val: string | number) => {
      const currentStatus = currentCard.status || {};
      updateCard({ status: { ...currentStatus, [key]: String(val) } });
  };

  const parseStat = (val: string | undefined): number => {
      if (!val) return 0;
      const num = parseInt(val.replace(/[^0-9-]/g, '')); // Allow negative for personality stats if stored there
      const safeNum = isNaN(num) ? 0 : num;
      return safeNum; 
  };

  const setPersonalityStat = (key: string, val: number) => {
      updateStatus(key, val);
  };

  // --- TRAIT HANDLERS ---
  const addTrait = () => {
      if (!newTraitInput.trim()) return;
      const currentTraits = currentCard.traits || [];
      if (!currentTraits.includes(newTraitInput.trim())) {
          updateCard({ traits: [...currentTraits, newTraitInput.trim()] });
      }
      setNewTraitInput('');
  };

  const removeTrait = (trait: string) => {
      const currentTraits = currentCard.traits || [];
      updateCard({ traits: currentTraits.filter(t => t !== trait) });
  };

  // --- OBSESSION HANDLERS (Stored in status.obsessions as comma list) ---
  const getObsessions = () => {
      return (currentCard.status?.obsessions || "").split(',').filter(s => s.trim());
  };
  
  const addObsession = () => {
      if (!newObsessionInput.trim()) return;
      const current = getObsessions();
      if (!current.includes(newObsessionInput.trim())) {
          updateStatus('obsessions', [...current, newObsessionInput.trim()].join(','));
      }
      setNewObsessionInput('');
  };

  const removeObsession = (item: string) => {
      const current = getObsessions();
      updateStatus('obsessions', current.filter(i => i !== item).join(','));
  };

  // --- MEMORY HANDLERS ---
  const addMemory = () => {
      if (!newMemoryInput.trim()) return;
      const currentMems = currentCard.hiddenMemories || [];
      updateCard({ hiddenMemories: [...currentMems, newMemoryInput.trim()] });
      setNewMemoryInput('');
  };

  const removeMemory = (idx: number) => {
      const currentMems = currentCard.hiddenMemories || [];
      updateCard({ hiddenMemories: currentMems.filter((_, i) => i !== idx) });
  };

  const currentCardName = currentCard.name || "User";
  const stressVal = Math.min(100, Math.max(0, parseStat(currentCard.status?.stress)));
  const arousalVal = Math.min(100, Math.max(0, parseStat(currentCard.status?.arousal)));
  const hpVal = Math.min(100, Math.max(0, parseStat(currentCard.status?.hp)));
  
  // Personality Stats (-50 to 50)
  const logicEmotion = parseStat(currentCard.status?.logicEmotion); 
  const introExtro = parseStat(currentCard.status?.introExtro); 
  const subDom = parseStat(currentCard.status?.subDom); 

  // Jealousy (0-100, default 50)
  const jealousyVal = currentCard.status?.jealousy ? parseStat(currentCard.status.jealousy) : 50;

  // Alignment
  const alignment = currentCard.status?.alignment || "True Neutral";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
      <div className="w-full max-w-2xl bg-[#09090b] border border-cyan-500/20 rounded-xl shadow-2xl flex flex-col h-[85vh] overflow-hidden">
        
        {/* HEADER */}
        <div className="p-4 border-b border-cyan-500/20 bg-cyan-950/10 flex justify-between items-center shrink-0">
            <div className="flex items-center gap-3 text-cyan-400">
                <Brain size={24} />
                <div>
                    <h2 className="font-mono font-bold uppercase tracking-widest text-lg text-white">Mind Sculpting</h2>
                    <p className="text-[10px] font-mono text-cyan-400/60 uppercase">Psychology • Traits • Memories</p>
                </div>
            </div>
            <div className="flex gap-2">
                <button 
                    onClick={onClose} 
                    className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold uppercase flex items-center gap-2 transition-all shadow-lg shadow-cyan-900/20"
                >
                    <Save size={14} /> Close
                </button>
            </div>
        </div>

        {/* CHARACTER SELECTOR */}
        <div className="flex gap-2 p-3 bg-black/40 border-b border-white/5 overflow-x-auto custom-scrollbar shrink-0">
            {config.userCard && (
                <button 
                    onClick={() => setSelectedTarget('USER')}
                    className={`px-4 py-2 rounded-lg border text-xs font-bold uppercase whitespace-nowrap transition-all flex items-center gap-2
                        ${selectedTarget === 'USER' ? 'bg-cyan-600 text-white border-cyan-500' : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:border-cyan-500/50'}
                    `}
                >
                    <User size={14} /> User (You)
                </button>
            )}
            {config.characterCards.map((char, idx) => (
                <button 
                    key={idx}
                    onClick={() => setSelectedTarget(idx)}
                    className={`px-4 py-2 rounded-lg border text-xs font-bold uppercase whitespace-nowrap transition-all flex items-center gap-2
                        ${selectedTarget === idx ? 'bg-cyan-600 text-white border-cyan-500' : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:border-cyan-500/50'}
                    `}
                >
                    {char.name}
                </button>
            ))}
        </div>

        {/* TABS */}
        <div className="flex border-b border-white/10 shrink-0 bg-zinc-900/50">
            <button onClick={() => setActiveTab('PSYCHE')} className={`flex-1 py-3 text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'PSYCHE' ? 'text-cyan-400 border-b-2 border-cyan-500 bg-cyan-500/5' : 'text-zinc-500 hover:text-zinc-300'}`}>Psyche (Tâm Lý)</button>
            <button onClick={() => setActiveTab('TRAITS')} className={`flex-1 py-3 text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'TRAITS' ? 'text-violet-400 border-b-2 border-violet-500 bg-violet-500/5' : 'text-zinc-500 hover:text-zinc-300'}`}>Traits (Tính Cách)</button>
            <button onClick={() => setActiveTab('DEEP')} className={`flex-1 py-3 text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'DEEP' ? 'text-indigo-400 border-b-2 border-indigo-500 bg-indigo-500/5' : 'text-zinc-500 hover:text-zinc-300'}`}>Deep (Tiềm Thức)</button>
        </div>

        {/* CONTENT */}
        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar bg-zinc-950">
            <div className="space-y-8 max-w-lg mx-auto">
                <div className="flex justify-between items-center pb-4 border-b border-white/5">
                    <span className="text-xs font-mono text-zinc-500 uppercase">Sculpting: <span className="text-white font-bold">{currentCardName}</span></span>
                </div>
                
                {/* --- TAB: PSYCHE --- */}
                {activeTab === 'PSYCHE' && (
                    <div className="space-y-8 animate-in fade-in slide-in-from-right-4">
                        {/* Vital Stats */}
                        <div className="grid grid-cols-1 gap-4">
                            <StatInputControl 
                                label="Mức Độ Stress / Áp Lực" 
                                value={stressVal} 
                                onChange={(v: number) => updateStatus('stress', v)} 
                                colorClass="text-red-400"
                            />
                            <StatInputControl 
                                label="Ham Muốn (Arousal / Libido)" 
                                value={arousalVal} 
                                onChange={(v: number) => updateStatus('arousal', v)} 
                                colorClass="text-pink-400"
                            />
                            <StatInputControl 
                                label="Sức Bền Tinh Thần (Mental HP)" 
                                value={hpVal} 
                                onChange={(v: number) => updateStatus('hp', v)} 
                                colorClass="text-green-400"
                            />
                        </div>

                        {/* Jealousy Engine (Milestone Version) */}
                        <JealousyMilestone value={jealousyVal} onChange={(v) => updateStatus('jealousy', v)} />

                        {/* Personality Spectrum (Milestone Version) */}
                        <div className="space-y-4">
                            <h4 className="text-cyan-400 font-bold text-xs uppercase flex items-center gap-2"><Scale size={14}/> Phổ Tính Cách (Spectrum)</h4>
                            <PersonalityMilestone leftLabel="Logic (Lý Trí)" rightLabel="Emotion (Cảm Xúc)" value={logicEmotion} onChange={(v) => setPersonalityStat('logicEmotion', v)} />
                            <PersonalityMilestone leftLabel="Introvert (Hướng Nội)" rightLabel="Extrovert (Hướng Ngoại)" value={introExtro} onChange={(v) => setPersonalityStat('introExtro', v)} />
                            <PersonalityMilestone leftLabel="Submissive (Nhu Nhược)" rightLabel="Dominant (Áp Đặt)" value={subDom} onChange={(v) => setPersonalityStat('subDom', v)} />
                        </div>

                        {/* Alignment Grid */}
                        <div className="space-y-2">
                            <h4 className="text-cyan-400 font-bold text-xs uppercase flex items-center gap-2"><Activity size={14}/> Xu Hướng Đạo Đức (Alignment)</h4>
                            <div className="grid grid-cols-3 gap-1">
                                {ALIGNMENTS.flat().map(align => (
                                    <button
                                        key={align}
                                        onClick={() => updateStatus('alignment', align)}
                                        className={`p-2 text-[9px] font-bold uppercase rounded border transition-all ${alignment === align ? 'bg-cyan-600 text-white border-cyan-400 shadow-lg' : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:bg-zinc-800 hover:text-zinc-300'}`}
                                    >
                                        {align}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                )}

                {/* --- TAB: TRAITS --- */}
                {activeTab === 'TRAITS' && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                        {/* Traits Input */}
                        <div className="space-y-2">
                            <h4 className="text-violet-400 font-bold text-xs uppercase flex items-center gap-2"><Sparkles size={14}/> Đặc Điểm Nổi Bật (Tags)</h4>
                            <div className="flex gap-2">
                                <input 
                                    type="text" 
                                    value={newTraitInput}
                                    onChange={(e) => setNewTraitInput(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && addTrait()}
                                    placeholder="Add trait (e.g. Tsundere)..."
                                    className="flex-1 bg-black/40 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-violet-500 transition-colors"
                                />
                                <button onClick={addTrait} className="px-3 bg-violet-600 hover:bg-violet-500 text-white rounded-lg"><Plus size={18}/></button>
                            </div>
                            <div className="flex flex-wrap gap-2">
                                {(currentCard.traits || []).map((trait, i) => (
                                    <span key={i} className="px-3 py-1 bg-violet-900/30 border border-violet-500/30 rounded-full text-xs text-violet-200 flex items-center gap-2 group">
                                        {trait}
                                        <button onClick={() => removeTrait(trait)} className="text-violet-400 hover:text-white"><X size={12}/></button>
                                    </span>
                                ))}
                            </div>
                        </div>

                        {/* Obsessions & Phobias */}
                        <div className="space-y-2">
                            <h4 className="text-violet-400 font-bold text-xs uppercase flex items-center gap-2"><Heart size={14}/> Sở Thích & Ám Ảnh (Obsessions)</h4>
                            <div className="flex gap-2">
                                <input 
                                    type="text" 
                                    value={newObsessionInput}
                                    onChange={(e) => setNewObsessionInput(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && addObsession()}
                                    placeholder="Add obsession/fear..."
                                    className="flex-1 bg-black/40 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-violet-500 transition-colors"
                                />
                                <button onClick={addObsession} className="px-3 bg-violet-600 hover:bg-violet-500 text-white rounded-lg"><Plus size={18}/></button>
                            </div>
                            <div className="flex flex-wrap gap-2">
                                {getObsessions().map((item, i) => (
                                    <span key={i} className="px-3 py-1 bg-pink-900/20 border border-pink-500/30 rounded text-xs text-pink-200 flex items-center gap-2">
                                        {item}
                                        <button onClick={() => removeObsession(item)} className="text-pink-400 hover:text-white"><X size={12}/></button>
                                    </span>
                                ))}
                                {getObsessions().length === 0 && <span className="text-zinc-600 text-xs italic">Chưa có dữ liệu.</span>}
                            </div>
                        </div>

                        <div className="pt-4 border-t border-white/5">
                            <span className="text-[10px] font-bold text-zinc-500 uppercase mb-2 block">Quick Presets</span>
                            <div className="flex flex-wrap gap-2">
                                {["Yandere", "Tsundere", "Kuudere", "Deredere", "Himbo", "Genius", "Shy", "Dominant", "Submissive"].map(p => (
                                    <button 
                                        key={p} 
                                        onClick={() => {
                                            const current = currentCard.traits || [];
                                            if (!current.includes(p)) updateCard({ traits: [...current, p] });
                                        }}
                                        className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 rounded text-[10px] text-zinc-300 border border-zinc-700"
                                    >
                                        + {p}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                )}

                {/* --- TAB: DEEP --- */}
                {activeTab === 'DEEP' && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                        
                        {/* Speech Style */}
                        <div className="space-y-2">
                            <h4 className="text-indigo-400 font-bold text-xs uppercase flex items-center gap-2"><Mic size={14}/> Phong Cách Nói Chuyện (Speech)</h4>
                            <div className="grid grid-cols-2 gap-2">
                                {SPEECH_STYLES.map(style => (
                                    <button
                                        key={style}
                                        onClick={() => updateStatus('speechStyle', style)}
                                        className={`p-2 text-[10px] font-bold uppercase rounded border text-left transition-all ${currentCard.status?.speechStyle === style ? 'bg-indigo-600 text-white border-indigo-400' : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:bg-zinc-800 hover:text-zinc-300'}`}
                                    >
                                        {style}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Secret */}
                        <div className="space-y-2">
                            <h4 className="text-indigo-400 font-bold text-xs uppercase flex items-center gap-2"><Lock size={14}/> Bí Mật Thầm Kín (Secret)</h4>
                            <textarea 
                                value={currentCard.status?.secret || ''}
                                onChange={(e) => updateStatus('secret', e.target.value)}
                                className="w-full h-24 bg-black/40 border border-indigo-500/30 rounded-xl p-3 text-xs text-indigo-100 placeholder-indigo-500/30 outline-none focus:border-indigo-500 transition-colors resize-none font-mono"
                                placeholder="Điều mà nhân vật này che giấu..."
                            />
                        </div>

                        {/* Hidden Memories */}
                        <div className="space-y-2">
                            <h4 className="text-indigo-400 font-bold text-xs uppercase flex items-center gap-2"><List size={14}/> Ký Ức Ẩn / Trauma</h4>
                            
                            <div className="flex gap-2 mb-2">
                                <input 
                                    type="text" 
                                    value={newMemoryInput}
                                    onChange={(e) => setNewMemoryInput(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && addMemory()}
                                    placeholder="Add hidden memory..."
                                    className="flex-1 bg-black/40 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-indigo-500 transition-colors"
                                />
                                <button onClick={addMemory} className="px-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg"><Plus size={18}/></button>
                            </div>

                            <div className="flex flex-col gap-2 max-h-[200px] overflow-y-auto custom-scrollbar">
                                {(currentCard.hiddenMemories || []).map((mem, i) => (
                                    <div key={i} className="p-3 bg-zinc-900/50 border border-white/5 rounded-lg flex justify-between items-start gap-3 group hover:border-indigo-500/30 transition-colors">
                                        <p className="text-xs text-zinc-300 font-mono leading-relaxed">{mem}</p>
                                        <button onClick={() => removeMemory(i)} className="text-zinc-600 hover:text-red-400 transition-colors shrink-0 pt-0.5"><Trash2 size={12}/></button>
                                    </div>
                                ))}
                                {(currentCard.hiddenMemories || []).length === 0 && (
                                    <div className="text-center text-zinc-600 text-xs italic py-4">No hidden memories recorded.</div>
                                )}
                            </div>
                        </div>

                    </div>
                )}

            </div>
        </div>

      </div>
    </div>
  );
};

export default MindConfigModal;
