
import React, { useState } from 'react';
import { X, User, Coins } from 'lucide-react';
import { CardData } from '../types';
import { formatVND } from '../utils/mockDataGenerator';

interface BankModalProps {
  onClose: () => void;
  characters: CardData[];
  userBalance: number;
  onTransfer: (targetName: string, amount: number, note: string) => void;
  themeColors: any;
}

const BankModal: React.FC<BankModalProps> = ({ onClose, userBalance, themeColors }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className={`w-full max-w-sm border rounded-xl shadow-2xl flex flex-col bg-zinc-900 border-zinc-700 overflow-hidden`}>
        
        <div className="p-4 border-b border-zinc-700 bg-zinc-800 flex justify-between items-center">
            <div className="flex items-center gap-2 text-yellow-400">
                <Coins size={18} />
                <h3 className="font-mono font-bold uppercase tracking-widest text-sm">Q-Bank</h3>
            </div>
            <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors"><X size={18} /></button>
        </div>

        <div className="p-6 flex flex-col gap-5 items-center justify-center">
            
            <div className="text-center space-y-2">
                <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Total Balance</span>
                <div className="text-4xl font-bold text-white font-mono">{formatVND(userBalance)}</div>
            </div>

            <div className="flex items-center gap-2 bg-black/30 px-4 py-2 rounded-full border border-white/5">
                <User size={14} className="text-zinc-500" />
                <span className="text-xs text-zinc-400 font-mono">Personal Account</span>
            </div>

        </div>

      </div>
    </div>
  );
};

export default BankModal;
