
import React, { useRef, useState, useEffect } from 'react';
import { Play, Pause, SkipForward, SkipBack, Repeat, Mic2, Upload, Volume2, X, Minimize2, Radio, Music, List, Search, Loader2, Plus, ExternalLink, Maximize2, GripHorizontal, GripVertical, FileVideo } from 'lucide-react';
import { AppConfig, MusicTrack } from '../types';
import { findMusicTrack } from '../services/aiService';

interface MusicPlayerWidgetProps {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  themeColors: any;
}

interface ExtendedMusicTrack extends MusicTrack {
    isVideo?: boolean;
}

const PRESET_CHANNELS = [
    { id: 'lofi', title: 'Lofi Girl - Relax/Study', url: 'https://stream.zeno.fm/0r0xa75z7tzuv' },
    { id: 'rain', title: 'Rain Sounds (Loop)', url: 'https://cdn.pixabay.com/audio/2022/07/04/audio_307e229f37.mp3' },
    { id: 'cyber', title: 'Cyberpunk City Ambience', url: 'https://cdn.pixabay.com/audio/2023/02/28/audio_550d815533.mp3' },
    { id: 'piano', title: 'Sad Piano', url: 'https://cdn.pixabay.com/audio/2021/11/01/audio_00fa5593f3.mp3' },
    { id: 'dark', title: 'Dark Synthwave', url: 'https://cdn.pixabay.com/audio/2021/09/06/audio_9c0379659b.mp3' },
];

const MusicPlayerWidget: React.FC<MusicPlayerWidgetProps> = ({ config, setConfig, themeColors }) => {
  const audioRef = useRef<HTMLAudioElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [showPlaylist, setShowPlaylist] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchUrl, setSearchUrl] = useState('');
  const [isMinimized, setIsMinimized] = useState(config.musicPlayer?.isMinimized || false);
  const [isSearching, setIsSearching] = useState(false);

  const [position, setPosition] = useState<{x: number, y: number} | null>(null);
  const isDragging = useRef(false);
  const dragOffset = useRef({ x: 0, y: 0 });

  const { bgPanel, textMain, textDim, border, accent, activeItem, hover } = themeColors;

  useEffect(() => {
      if (!config.musicPlayer) {
          setConfig(prev => ({
              ...prev,
              musicPlayer: {
                  playlist: [],
                  currentIndex: 0,
                  isPlaying: false,
                  isLooping: false,
                  volume: 0.5,
                  isMinimized: false
              }
          }));
      } else {
          if (audioRef.current && config.musicPlayer.volume !== undefined) {
              audioRef.current.volume = config.musicPlayer.volume;
          }
          if (videoRef.current && config.musicPlayer.volume !== undefined) {
              videoRef.current.volume = config.musicPlayer.volume;
          }
          if (config.musicPlayer.isMinimized !== undefined) {
              setIsMinimized(config.musicPlayer.isMinimized);
          }
      }
  }, []);

  const musicState = config.musicPlayer || { playlist: [], currentIndex: 0, isPlaying: false, isLooping: false, volume: 0.5 };
  const currentTrack = musicState.playlist[musicState.currentIndex] as ExtendedMusicTrack;

  useEffect(() => {
      const vol = musicState.volume;
      const loop = musicState.isLooping && musicState.playlist.length === 1;

      if (currentTrack?.isVideo) {
          if (audioRef.current) audioRef.current.pause();
          if (videoRef.current) {
              videoRef.current.volume = vol;
              videoRef.current.loop = loop;
              if (isPlaying) {
                  videoRef.current.play().catch(e => {
                      console.warn("Video autoplay blocked:", e);
                      setIsPlaying(false);
                  });
              } else {
                  videoRef.current.pause();
              }
          }
      } else {
          if (videoRef.current) videoRef.current.pause();
          if (audioRef.current) {
              audioRef.current.volume = vol;
              audioRef.current.loop = loop;
              if (isPlaying) {
                  audioRef.current.play().catch(e => {
                      console.warn("Audio autoplay blocked:", e);
                      setIsPlaying(false);
                  });
              } else {
                  audioRef.current.pause();
              }
          }
      }
  }, [isPlaying, musicState.currentIndex, musicState.volume, musicState.isLooping, currentTrack?.isVideo]);

  // UNIFIED DRAG LOGIC
  const handleStart = (clientX: number, clientY: number) => {
      if (!containerRef.current) return;
      isDragging.current = true;
      const rect = containerRef.current.getBoundingClientRect();
      dragOffset.current = {
          x: clientX - rect.left,
          y: clientY - rect.top
      };
      if (!position) {
          setPosition({ x: rect.left, y: rect.top });
      }
  };

  const onMouseDown = (e: React.MouseEvent) => handleStart(e.clientX, e.clientY);
  const onTouchStart = (e: React.TouchEvent) => handleStart(e.touches[0].clientX, e.touches[0].clientY);

  useEffect(() => {
      const handleMove = (clientX: number, clientY: number) => {
          if (isDragging.current) {
              const newX = clientX - dragOffset.current.x;
              const newY = clientY - dragOffset.current.y;
              setPosition({ x: newX, y: newY });
          }
      };

      const onMouseMove = (e: MouseEvent) => handleMove(e.clientX, e.clientY);
      const onTouchMove = (e: TouchEvent) => {
          if (isDragging.current) {
              // Prevent scrolling while dragging
              if (e.cancelable) e.preventDefault();
              handleMove(e.touches[0].clientX, e.touches[0].clientY);
          }
      };

      const handleEnd = () => {
          isDragging.current = false;
      };

      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', handleEnd);
      window.addEventListener('touchmove', onTouchMove, { passive: false });
      window.addEventListener('touchend', handleEnd);

      return () => {
          window.removeEventListener('mousemove', onMouseMove);
          window.removeEventListener('mouseup', handleEnd);
          window.removeEventListener('touchmove', onTouchMove);
          window.removeEventListener('touchend', handleEnd);
      };
  }, []);

  const updateState = (updates: Partial<typeof musicState>) => {
      setConfig(prev => ({
          ...prev,
          musicPlayer: { ...prev.musicPlayer!, ...updates }
      }));
  };

  const handlePlayPause = () => {
      setIsPlaying(!isPlaying);
      updateState({ isPlaying: !isPlaying });
  };

  const handleNext = () => {
      if (musicState.playlist.length === 0) return;
      let nextIndex = musicState.currentIndex + 1;
      if (nextIndex >= musicState.playlist.length) {
          nextIndex = 0;
      }
      updateState({ currentIndex: nextIndex });
      setIsPlaying(true);
  };

  const handlePrev = () => {
      if (musicState.playlist.length === 0) return;
      let prevIndex = musicState.currentIndex - 1;
      if (prevIndex < 0) {
          prevIndex = musicState.playlist.length - 1;
      }
      updateState({ currentIndex: prevIndex });
      setIsPlaying(true);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const vol = parseFloat(e.target.value);
      if (audioRef.current) audioRef.current.volume = vol;
      if (videoRef.current) videoRef.current.volume = vol;
      updateState({ volume: vol });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files;
      if (!files || files.length === 0) return;

      const newTracks: ExtendedMusicTrack[] = Array.from(files).map((file: File) => ({
          id: `local-${Date.now()}-${Math.random()}`,
          title: file.name.replace(/\.[^/.]+$/, ""),
          url: URL.createObjectURL(file),
          isLocal: true,
          isVideo: file.type.startsWith('video/')
      }));

      const updatedPlaylist = [...musicState.playlist, ...newTracks];
      updateState({ playlist: updatedPlaylist });
      
      if (musicState.playlist.length === 0 || !isPlaying) {
          updateState({ currentIndex: musicState.playlist.length });
          setIsPlaying(true);
      }
      
      e.target.value = '';
  };

  const addPresetChannel = (preset: typeof PRESET_CHANNELS[0]) => {
      const newTrack: ExtendedMusicTrack = {
          id: `preset-${preset.id}-${Date.now()}`,
          title: preset.title,
          url: preset.url,
          isLocal: false,
          isVideo: false
      };
      const updatedPlaylist = [...musicState.playlist, newTrack];
      updateState({ playlist: updatedPlaylist });
      setShowSearch(false);
      
      if (updatedPlaylist.length === 1) {
          updateState({ currentIndex: 0 });
          setIsPlaying(true);
      }
  };

  const handleSearchSubmit = async () => {
      if (!searchUrl.trim()) return;
      
      setIsSearching(true);
      try {
          const track = await findMusicTrack(searchUrl);
          
          const newTrack: ExtendedMusicTrack = {
              id: `search-${Date.now()}`,
              title: track.title,
              url: track.url,
              isLocal: false,
              isVideo: false
          };
          
          const updatedPlaylist = [...musicState.playlist, newTrack];
          updateState({ playlist: updatedPlaylist });
          setSearchUrl('');
          setShowSearch(false);
          
          if (updatedPlaylist.length === 1) {
              updateState({ currentIndex: 0 });
              setIsPlaying(true);
          }
      } catch (e) {
          console.error("Search failed", e);
      } finally {
          setIsSearching(false);
      }
  };

  const removeTrack = (index: number) => {
      const newPlaylist = musicState.playlist.filter((_, i) => i !== index);
      let newIndex = musicState.currentIndex;
      if (index < newIndex) newIndex--;
      if (newIndex >= newPlaylist.length) newIndex = 0;
      
      updateState({ playlist: newPlaylist, currentIndex: newIndex });
      if (newPlaylist.length === 0) setIsPlaying(false);
  };

  const handleMediaError = () => {
      if (isPlaying) { 
          setIsPlaying(false);
          updateState({ isPlaying: false });
      }
  };

  const containerStyle: React.CSSProperties = position 
      ? { left: `${position.x}px`, top: `${position.y}px`, bottom: 'auto', right: 'auto' }
      : {}; 

  return (
    <>
      <div 
        ref={containerRef}
        className={`fixed z-50 animate-in fade-in transition-shadow duration-300 ${!position ? 'bottom-4 right-4 slide-in-from-bottom-5' : ''}`}
        style={containerStyle}
      >
        {/* --- MINIMIZED UI --- */}
        <div className={`${isMinimized ? 'flex' : 'hidden'} items-center gap-2 pl-1 pr-2 py-2 rounded-full border shadow-[0_0_20px_rgba(0,0,0,0.3)] backdrop-blur-md ${bgPanel} ${border} ${textMain}`}>
            
            <div 
                className="cursor-move touch-none p-1 text-gray-500 hover:text-white transition-colors"
                onMouseDown={onMouseDown}
                onTouchStart={onTouchStart}
            >
                <GripVertical size={14} />
            </div>

            <button 
                onClick={() => { setIsMinimized(false); updateState({ isMinimized: false }); }}
                className={`p-2 rounded-full hover:bg-white/10 transition-colors ${accent}`}
                title="Expand"
            >
                <Maximize2 size={16} />
            </button>

            <button 
                onClick={handlePlayPause}
                className={`p-2 rounded-full hover:bg-white/10 transition-colors ${isPlaying ? 'text-green-400' : textDim}`}
            >
                {isPlaying ? <Pause size={16} /> : <Play size={16} />}
            </button>

            {currentTrack && (
                <div className="w-24 overflow-hidden relative mx-1">
                    <div className={`whitespace-nowrap font-mono text-[10px] ${textDim} ${isPlaying ? 'animate-marquee' : ''}`}>
                        {currentTrack.title}
                    </div>
                </div>
            )}

            <div className="flex items-center gap-1.5 pl-2 border-l border-white/10 group relative">
                <Volume2 size={14} className={textDim} />
                <div className="w-0 group-hover:w-16 overflow-hidden transition-all duration-300">
                    <input 
                        type="range" 
                        min="0" max="1" step="0.05" 
                        value={musicState.volume} 
                        onChange={handleVolumeChange}
                        className={`w-16 h-1 rounded-lg appearance-none cursor-pointer ${accent}`}
                        style={{ backgroundColor: 'currentColor', opacity: 0.3 }}
                    />
                </div>
            </div>
        </div>

        {/* --- FULL WIDGET MODE --- */}
        <div className={`${!isMinimized ? 'flex' : 'hidden'} w-80 border rounded-xl shadow-2xl backdrop-blur-md flex-col overflow-hidden font-mono ${bgPanel} ${border} ${textMain}`}>
            <div 
                className={`flex items-center justify-between p-2 border-b bg-black/20 ${border} cursor-move touch-none`}
                onMouseDown={onMouseDown}
                onTouchStart={onTouchStart}
            >
                <div className={`flex items-center gap-2 ${accent}`}>
                    <GripHorizontal size={14} className="opacity-50" />
                    {currentTrack?.isVideo ? <FileVideo size={14} className={isPlaying ? "animate-pulse" : ""} /> : <Radio size={14} className={isPlaying ? "animate-pulse" : ""} />}
                    <span className="text-[10px] font-bold tracking-widest">NANO_PLAYER</span>
                </div>
                <div className="flex items-center gap-1" onMouseDown={(e) => e.stopPropagation()} onTouchStart={(e) => e.stopPropagation()}>
                    <button onClick={() => { setIsMinimized(true); updateState({ isMinimized: true }); }} className={`p-1 rounded hover:bg-white/10 ${textDim} hover:${themeColors.textMain}`}><Minimize2 size={12} /></button>
                    <button onClick={() => setConfig(prev => ({ ...prev, activeModules: prev.activeModules.filter(m => m !== "Music_Player") }))} className={`p-1 rounded hover:bg-red-500/20 ${textDim} hover:text-red-400`}><X size={12} /></button>
                </div>
            </div>

            {showSearch && (
                <div className={`absolute inset-0 z-20 flex flex-col p-4 gap-3 animate-in fade-in ${bgPanel}`}>
                    <div className={`flex justify-between items-center border-b pb-2 ${border} ${accent}`}>
                        <span className="text-xs font-bold">FREQUENCY SCANNER</span>
                        <button onClick={() => setShowSearch(false)}><X size={14}/></button>
                    </div>
                    <div className="space-y-2 max-h-40 overflow-y-auto custom-scrollbar">
                        <span className={`text-[9px] uppercase ${textDim}`}>Presets (Royalty Free)</span>
                        {PRESET_CHANNELS.map(ch => (
                            <button 
                                key={ch.id} 
                                onClick={() => addPresetChannel(ch)}
                                className={`w-full text-left p-2 rounded border border-transparent text-xs transition-all flex items-center gap-2 ${hover} ${textDim} hover:${themeColors.textMain}`}
                            >
                                <Radio size={12} /> {ch.title}
                            </button>
                        ))}
                    </div>
                    <div className="mt-auto">
                        <span className={`text-[9px] uppercase ${textDim}`}>Search Song / Direct Link</span>
                        <div className="flex gap-1 mt-1">
                            <input 
                                type="text" 
                                value={searchUrl}
                                onChange={(e) => setSearchUrl(e.target.value)}
                                onKeyDown={(e) => e.key === 'Enter' && handleSearchSubmit()}
                                placeholder="e.g. 'Lofi', URL"
                                className={`flex-1 bg-black/40 border rounded px-2 py-1 text-xs outline-none focus:border-current ${border} ${textMain}`}
                            />
                            <button 
                                onClick={handleSearchSubmit} 
                                disabled={isSearching}
                                className={`px-2 rounded text-white disabled:opacity-50 flex items-center justify-center ${activeItem || 'bg-blue-600'}`}
                                style={{ backgroundColor: 'currentColor' }} 
                            >
                                {isSearching ? <Loader2 size={14} className="animate-spin text-white"/> : <Search size={14} className="text-white"/>}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {showPlaylist && !showSearch && (
                <div className={`absolute inset-0 z-10 flex flex-col p-2 animate-in slide-in-from-bottom-10 ${bgPanel}`}>
                    <div className={`flex justify-between items-center p-2 border-b mb-1 ${border}`}>
                        <span className={`text-[10px] font-bold ${textDim}`}>PLAYLIST QUEUE</span>
                        <button onClick={() => setShowPlaylist(false)} className={`${textDim} hover:${themeColors.textMain}`}><X size={12}/></button>
                    </div>
                    <div className="flex-1 overflow-y-auto custom-scrollbar space-y-1">
                        {musicState.playlist.map((track, idx) => (
                            <div key={track.id} className={`flex items-center justify-between p-2 rounded group transition-colors ${idx === musicState.currentIndex ? `${activeItem} ${accent}` : `${hover} ${textDim}`}`}>
                                <button 
                                    onClick={() => { updateState({ currentIndex: idx }); setIsPlaying(true); }}
                                    className="text-xs truncate max-w-[180px] text-left"
                                >
                                    {idx + 1}. {track.title}
                                </button>
                                <button onClick={() => removeTrack(idx)} className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-400"><X size={10}/></button>
                            </div>
                        ))}
                        {musicState.playlist.length === 0 && <div className={`text-center text-[10px] py-4 ${textDim}`}>Queue Empty</div>}
                    </div>
                </div>
            )}

            <div className="p-4 flex flex-col gap-4 relative">
                <div className={`rounded-lg border relative overflow-hidden group ${border} ${currentTrack?.isVideo ? 'aspect-video bg-black' : 'h-16 bg-black/40 flex items-center justify-center'}`}>
                    {currentTrack ? (
                        currentTrack.isVideo ? (
                            <div className="w-full h-full relative">
                                <video 
                                    ref={videoRef}
                                    src={currentTrack.url}
                                    className="w-full h-full object-contain bg-black"
                                    playsInline
                                    onClick={handlePlayPause}
                                    onEnded={handleNext}
                                    onError={handleMediaError}
                                />
                                <div className={`absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none`}>
                                    <div className="text-white bg-black/50 p-2 rounded-full backdrop-blur-sm">
                                        {isPlaying ? <Pause size={24} /> : <Play size={24} />}
                                    </div>
                                </div>
                                <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                    <span className="text-[10px] text-white font-bold truncate block">{currentTrack.title}</span>
                                </div>
                            </div>
                        ) : (
                            <>
                                <div className={`absolute inset-0 flex items-end justify-center gap-1 opacity-30 ${accent}`}>
                                    {[...Array(12)].map((_, i) => (
                                        <div 
                                            key={i} 
                                            className={`w-1 transition-all duration-300 ${isPlaying ? 'animate-music-bar' : 'h-1'}`} 
                                            style={{ 
                                                backgroundColor: 'currentColor',
                                                animationDelay: `${i * 0.1}s`, 
                                                height: isPlaying ? '100%' : '10%' 
                                            }}
                                        ></div>
                                    ))}
                                </div>
                                <div className="z-10 text-center px-4">
                                    <div className={`text-xs font-bold truncate max-w-[200px] ${textMain}`}>{currentTrack.title}</div>
                                    <div className={`text-[9px] font-mono mt-0.5 ${accent}`}>{isPlaying ? 'NOW PLAYING' : 'PAUSED'}</div>
                                </div>
                            </>
                        )
                    ) : (
                        <span className={`text-xs font-mono ${textDim}`}>NO SIGNAL</span>
                    )}
                </div>

                <div className="flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                        <button onClick={() => updateState({ isLooping: !musicState.isLooping })} className={`p-1.5 rounded transition-colors ${musicState.isLooping ? `${activeItem} ${accent}` : `${textDim} hover:${themeColors.textMain}`}`} title="Loop"><Repeat size={14}/></button>
                        
                        <div className="flex items-center gap-3">
                            <button onClick={handlePrev} className={`${textDim} hover:${themeColors.textMain} transition-colors`}><SkipBack size={18}/></button>
                            <button 
                                onClick={handlePlayPause}
                                className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-all active:scale-95 text-white ${accent} bg-current opacity-90 hover:opacity-100`}
                            >
                                {isPlaying ? <Pause size={18} className="text-black fill-current" /> : <Play size={18} className="text-black fill-current ml-0.5" />}
                            </button>
                            <button onClick={handleNext} className={`${textDim} hover:${themeColors.textMain} transition-colors`}><SkipForward size={18}/></button>
                        </div>

                        <button onClick={() => setShowPlaylist(!showPlaylist)} className={`p-1.5 rounded transition-colors ${showPlaylist ? `${activeItem} ${accent}` : `${textDim} hover:${themeColors.textMain}`}`} title="Queue"><List size={14}/></button>
                    </div>

                    <div className={`flex items-center gap-2 ${accent}`}>
                        <Volume2 size={12} className={textDim} />
                        <input 
                            type="range" 
                            min="0" max="1" step="0.05" 
                            value={musicState.volume} 
                            onChange={handleVolumeChange}
                            className="w-full h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                            style={{ accentColor: 'currentColor' }}
                        />
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-2 mt-1">
                    <button onClick={() => fileInputRef.current?.click()} className={`flex items-center justify-center gap-1.5 py-1.5 rounded text-[9px] transition-colors border ${border} ${hover} ${textDim} hover:${themeColors.textMain}`}>
                        <Upload size={10} /> Upload File
                    </button>
                    <button onClick={() => setShowSearch(true)} className={`flex items-center justify-center gap-1.5 py-1.5 rounded text-[9px] transition-colors border ${border} ${hover} ${textDim} hover:${themeColors.textMain}`}>
                        <Search size={10} /> Search
                    </button>
                </div>
            </div>
        </div>
      </div>

      <input type="file" ref={fileInputRef} accept="audio/*,video/*" className="hidden" onChange={handleFileUpload} multiple />
      <audio 
        ref={audioRef} 
        src={!currentTrack?.isVideo ? currentTrack?.url : undefined} 
        onEnded={handleNext} 
        loop={musicState.isLooping && musicState.playlist.length === 1} 
        onError={handleMediaError}
      />
      
      <style>{`
        @keyframes music-bar { 0% { height: 10%; } 50% { height: 100%; } 100% { height: 10%; } }
        .animate-music-bar { animation: music-bar 0.8s ease-in-out infinite; }
      `}</style>
    </>
  );
};

export default MusicPlayerWidget;
