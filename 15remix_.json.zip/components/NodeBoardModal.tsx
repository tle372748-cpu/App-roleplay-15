
import React, { useState, useRef, useEffect } from 'react';
import { AppConfig, TimelineNode } from '../types';
import { X, Plus, ZoomIn, ZoomOut, Edit2, Link, Trash2, Calendar, Users, Map as MapIcon, Crosshair, Lock, MessageSquare, Sparkles, Loader2 } from 'lucide-react';
import { generateBoardDataFromHistory } from '../services/aiService';

interface NodeBoardModalProps {
  mode: 'TIMELINE' | 'RELATION';
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  onClose: () => void;
}

const NodeBoardModal: React.FC<NodeBoardModalProps> = ({ mode, config, setConfig, onClose }) => {
  // State
  const [transform, setTransform] = useState({ x: 0, y: 0, scale: 1 });
  const [isDraggingBoard, setIsDraggingBoard] = useState(false);
  const [lastPointerPos, setLastPointerPos] = useState({ x: 0, y: 0 });

  const [activeNodeId, setActiveNodeId] = useState<string | null>(null);
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const [nodeDragStart, setNodeDragStart] = useState({ x: 0, y: 0 }); // Mouse pos at start of node drag
  const [nodeOriginalPos, setNodeOriginalPos] = useState({ x: 0, y: 0 }); // Node pos at start
  
  // Connection Mode
  const [isConnectMode, setIsConnectMode] = useState(false);
  const [connectSourceId, setConnectSourceId] = useState<string | null>(null);

  // Edit Modals State
  const [showEditModal, setShowEditModal] = useState(false);
  const [editForm, setEditForm] = useState({ id: '', date: '', title: '', content: '' });

  // Connection Edit Modal State
  const [editingConnection, setEditingConnection] = useState<{ sourceId: string, targetId: string, label: string } | null>(null);
  const [connLabelInput, setConnLabelInput] = useState('');

  // Generation State
  const [isGenerating, setIsGenerating] = useState(false);

  // Viewport Size for MiniMap
  const [containerSize, setContainerSize] = useState({ w: 0, h: 0 });

  const containerRef = useRef<HTMLDivElement>(null);

  // Load Data
  const nodes: TimelineNode[] = mode === 'TIMELINE' 
    ? (config.timelineData || []) 
    : (config.relationData || []);

  const updateNodes = (newNodes: TimelineNode[]) => {
    setConfig(prev => ({
        ...prev,
        [mode === 'TIMELINE' ? 'timelineData' : 'relationData']: newNodes
    }));
  };

  useEffect(() => {
      const updateSize = () => {
          if (containerRef.current) {
              setContainerSize({ w: containerRef.current.clientWidth, h: containerRef.current.clientHeight });
          }
      };
      updateSize();
      window.addEventListener('resize', updateSize);
      return () => window.removeEventListener('resize', updateSize);
  }, []);

  // --- SYNC CORE NODES (RELATION MODE) ---
  useEffect(() => {
      if (mode === 'RELATION') {
          setConfig(prev => {
              let hasChanges = false;
              let currentNodes = (prev.relationData || []).map(n => ({
                  ...n, 
                  connections: [...(n.connections || [])], 
                  connectionLabels: {...(n.connectionLabels || {})}
              }));

              const ensureCoreNode = (targetId: string, title: string, content: string, defaultPos: {x: number, y: number}) => {
                  let existingCore = currentNodes.find(n => n.id === targetId);
                  if (existingCore) {
                      if (existingCore.title !== title || existingCore.content !== content) {
                          existingCore.title = title;
                          existingCore.content = content;
                          hasChanges = true;
                      }
                      return;
                  }

                  const duplicateIndex = currentNodes.findIndex(n => (n.title || '').trim().toLowerCase() === (title || '').trim().toLowerCase() && !n.id.startsWith('core-'));
                  if (duplicateIndex !== -1) {
                      const duplicateNode = currentNodes[duplicateIndex];
                      const oldId = duplicateNode.id;
                      duplicateNode.id = targetId;
                      duplicateNode.title = title;
                      duplicateNode.content = content;
                      currentNodes.forEach(n => {
                          if ((n.connections || []).includes(oldId)) {
                              n.connections = (n.connections || []).map(c => c === oldId ? targetId : c);
                              if (n.connectionLabels && n.connectionLabels[oldId]) {
                                  n.connectionLabels[targetId] = n.connectionLabels[oldId];
                                  delete n.connectionLabels[oldId];
                              }
                          }
                      });
                      hasChanges = true;
                  } else {
                      currentNodes.push({
                          id: targetId,
                          title: title,
                          content: content,
                          date: 'RELATION',
                          position: defaultPos,
                          connections: [],
                          connectionLabels: {},
                          type: 'RELATION'
                      });
                      hasChanges = true;
                  }
              };

              if (prev.userCard) {
                  const userTraits = prev.userCard.traits?.length ? prev.userCard.traits.join(', ') : 'N/A';
                  const userDescShort = prev.userCard.description 
                      ? (prev.userCard.description.length > 150 ? prev.userCard.description.substring(0, 150) + '...' : prev.userCard.description)
                      : 'No description.';
                  const userContent = `[Role: ${prev.userCard.role || 'Protagonist'}]\nTraits: ${userTraits}\nBio: ${userDescShort}`;
                  ensureCoreNode('core-user', prev.userCard.name, userContent, { x: 0, y: 0 });
              }

              (prev.characterCards || []).forEach((char, idx) => {
                  const charId = `core-char-${idx}`;
                  const charTraits = char.traits?.length ? char.traits.join(', ') : 'N/A';
                  const charDescShort = char.description 
                      ? (char.description.length > 150 ? char.description.substring(0, 150) + '...' : char.description)
                      : 'No description.';
                  const charContent = `[Role: ${char.role || 'Side'}]\nTraits: ${charTraits}\nBio: ${charDescShort}`;
                  ensureCoreNode(charId, char.name, charContent, { x: 300 + (idx * 50), y: 100 + (idx * 50) });
              });

              if (hasChanges) {
                  return { ...prev, relationData: currentNodes };
              }
              return prev;
          });
      }
  }, [mode, config.userCard, config.characterCards, setConfig]);

  // --- AUTO GENERATION LOGIC ---
  const handleAutoGenerate = async () => {
      // Get chat history from localStorage
      const savedMsgs = localStorage.getItem('NMGX_MESSAGES');
      if (!savedMsgs) {
          alert("No chat history found to analyze.");
          return;
      }
      const history = JSON.parse(savedMsgs);
      if (history.length === 0) {
          alert("Chat history is empty.");
          return;
      }

      setIsGenerating(true);
      try {
          const { timeline, relations } = await generateBoardDataFromHistory(history);
          
          if (mode === 'TIMELINE') {
              // Process Timeline Data
              const newNodes: TimelineNode[] = timeline.map((item: any, index: number) => ({
                  id: `gen-time-${Date.now()}-${index}`,
                  date: item.date,
                  title: item.title,
                  content: item.content,
                  position: { x: index * 350, y: 0 + (index % 2 === 0 ? 0 : 200) }, // Staggered Y
                  connections: index < timeline.length - 1 ? [`gen-time-${Date.now()}-${index+1}`] : [], // Connect sequentially
                  type: 'TIMELINE'
              }));
              
              // Fix connection IDs
              for (let i = 0; i < newNodes.length - 1; i++) {
                  newNodes[i].connections = [newNodes[i+1].id];
              }

              updateNodes(newNodes);
          } else {
              // Process Relation Data
              const newNodes: TimelineNode[] = [];
              const center = { x: 0, y: 0 };
              const radius = 300;
              const angleStep = (2 * Math.PI) / Math.max(1, relations.length);

              // 1. Create Nodes
              relations.forEach((item: any, index: number) => {
                  const angle = index * angleStep;
                  newNodes.push({
                      id: `gen-rel-${index}`,
                      title: item.title,
                      content: item.content,
                      date: 'RELATION',
                      position: {
                          x: center.x + radius * Math.cos(angle),
                          y: center.y + radius * Math.sin(angle)
                      },
                      connections: [],
                      connectionLabels: {},
                      type: 'RELATION'
                  });
              });

              // 2. Create Connections
              const nameToIdMap: Record<string, string> = {};
              newNodes.forEach(n => { nameToIdMap[n.title] = n.id; });

              relations.forEach((item: any, index: number) => {
                  const sourceId = newNodes[index].id;
                  const sourceNode = newNodes[index];
                  
                  if (item.connections && Array.isArray(item.connections)) {
                      item.connections.forEach((targetName: string, connIdx: number) => {
                          // Fuzzy match name
                          const targetId = Object.keys(nameToIdMap).find(name => (name || '').toLowerCase().includes((targetName || '').toLowerCase()) || (targetName || '').toLowerCase().includes((name || '').toLowerCase()));
                          
                          if (targetId && nameToIdMap[targetId] !== sourceId) {
                              const realTargetId = nameToIdMap[targetId];
                              if (!sourceNode.connections.includes(realTargetId)) {
                                  sourceNode.connections.push(realTargetId);
                                  // Add Label if available
                                  if (item.labels && item.labels[connIdx]) {
                                      if (!sourceNode.connectionLabels) sourceNode.connectionLabels = {};
                                      sourceNode.connectionLabels[realTargetId] = item.labels[connIdx];
                                  }
                              }
                          }
                      });
                  }
              });

              updateNodes(newNodes);
          }
      } catch (e) {
          console.error(e);
          alert("Generation failed. Check API Key or Console.");
      } finally {
          setIsGenerating(false);
      }
  };

  // --- BOARD NAVIGATION ---
  
  const handleWheel = (e: React.WheelEvent) => {
    if (e.ctrlKey || e.metaKey) {
        // ZOOM (Pivot based)
        const zoomIntensity = 0.1;
        const delta = -Math.sign(e.deltaY) * zoomIntensity;
        const newScale = Math.min(5, Math.max(0.1, transform.scale * (1 + delta)));
        
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;

        const worldX = (mouseX - transform.x) / transform.scale;
        const worldY = (mouseY - transform.y) / transform.scale;

        const newX = mouseX - worldX * newScale;
        const newY = mouseY - worldY * newScale;

        setTransform({ x: newX, y: newY, scale: newScale });
    } else {
        // PAN
        setTransform(prev => ({ ...prev, x: prev.x - e.deltaX, y: prev.y - e.deltaY }));
    }
  };

  // Unified Pointer Down (Mouse & Touch)
  const handleBoardPointerDown = (e: React.PointerEvent) => {
    if ((e.pointerType === 'mouse' && e.button !== 0) || draggingNodeId) return;
    setIsDraggingBoard(true);
    setLastPointerPos({ x: e.clientX, y: e.clientY });
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handleBoardPointerMove = (e: React.PointerEvent) => {
      if (isDraggingBoard) {
          const dx = e.clientX - lastPointerPos.x;
          const dy = e.clientY - lastPointerPos.y;
          setTransform(prev => ({ ...prev, x: prev.x + dx, y: prev.y + dy }));
          setLastPointerPos({ x: e.clientX, y: e.clientY });
      }
  };

  const handleBoardPointerUp = (e: React.PointerEvent) => {
      if (isDraggingBoard) {
          setIsDraggingBoard(false);
          e.currentTarget.releasePointerCapture(e.pointerId);
      }
  };

  // Node Dragging Logic
  useEffect(() => {
    const handleGlobalMove = (e: MouseEvent | TouchEvent) => {
        if (draggingNodeId) {
            let clientX, clientY;
            if ('touches' in e) {
                clientX = e.touches[0].clientX;
                clientY = e.touches[0].clientY;
            } else {
                clientX = (e as MouseEvent).clientX;
                clientY = (e as MouseEvent).clientY;
            }

            const dx = (clientX - nodeDragStart.x) / transform.scale;
            const dy = (clientY - nodeDragStart.y) / transform.scale;
            
            updateNodes(nodes.map(n => 
                n.id === draggingNodeId 
                ? { ...n, position: { x: nodeOriginalPos.x + dx, y: nodeOriginalPos.y + dy } } 
                : n
            ));
        }
    };

    const handleGlobalUp = () => {
        setDraggingNodeId(null);
    };

    window.addEventListener('mousemove', handleGlobalMove);
    window.addEventListener('mouseup', handleGlobalUp);
    window.addEventListener('touchmove', handleGlobalMove);
    window.addEventListener('touchend', handleGlobalUp);
    return () => {
        window.removeEventListener('mousemove', handleGlobalMove);
        window.removeEventListener('mouseup', handleGlobalUp);
        window.removeEventListener('touchmove', handleGlobalMove);
        window.removeEventListener('touchend', handleGlobalUp);
    };
  }, [draggingNodeId, nodeDragStart, nodeOriginalPos, transform.scale, nodes]);

  // --- ACTIONS ---

  const handleCreateNode = () => {
      if (!containerRef.current) return;
      const centerX = (containerSize.w / 2 - transform.x) / transform.scale;
      const centerY = (containerSize.h / 2 - transform.y) / transform.scale;

      const newNode: TimelineNode = {
          id: `${mode.toLowerCase()}-${Date.now()}`,
          date: mode === 'TIMELINE' ? new Date().toLocaleDateString('en-GB') : '',
          title: mode === 'TIMELINE' ? 'New Event' : 'New Entity',
          content: 'Details here...',
          position: { x: centerX - 100, y: centerY - 50 },
          connections: [],
          type: mode
      };

      updateNodes([...nodes, newNode]);
  };

  const handleNodeClick = (e: React.MouseEvent | React.TouchEvent, id: string) => {
      e.stopPropagation();
      
      if (isConnectMode) {
          if (!connectSourceId) {
              setConnectSourceId(id);
          } else {
              if (connectSourceId === id) {
                  setConnectSourceId(null);
              } else {
                  // Toggle Logic
                  const sourceNode = nodes.find(n => n.id === connectSourceId);
                  const targetNode = nodes.find(n => n.id === id);

                  if (sourceNode && targetNode) {
                      const hasLinkForward = (sourceNode.connections || []).includes(id);
                      const hasLinkBackward = (targetNode.connections || []).includes(connectSourceId);

                      if (hasLinkForward || hasLinkBackward) {
                          // REMOVE connection
                          updateNodes(nodes.map(n => {
                              if (n.id === connectSourceId) return { ...n, connections: (n.connections || []).filter(cid => cid !== id) };
                              if (n.id === id) return { ...n, connections: (n.connections || []).filter(cid => cid !== connectSourceId) };
                              return n;
                          }));
                      } else {
                          // ADD connection
                          updateNodes(nodes.map(n => {
                              if (n.id === connectSourceId) return { ...n, connections: [...(n.connections || []), id] };
                              return n;
                          }));
                      }
                  }
                  setConnectSourceId(null);
                  setIsConnectMode(false);
              }
          }
      } else {
          setActiveNodeId(id);
      }
  };

  const startDragNode = (e: React.MouseEvent | React.TouchEvent, id: string) => {
      e.stopPropagation();
      if (isConnectMode) return;
      
      const node = nodes.find(n => n.id === id);
      if (!node) return;

      let clientX, clientY;
      if ('touches' in e) {
          clientX = e.touches[0].clientX;
          clientY = e.touches[0].clientY;
      } else {
          clientX = (e as React.MouseEvent).clientX;
          clientY = (e as React.MouseEvent).clientY;
      }

      setDraggingNodeId(id);
      setNodeDragStart({ x: clientX, y: clientY });
      setNodeOriginalPos({ x: node.position.x, y: node.position.y });
      setActiveNodeId(id);
  };

  const deleteNode = (id: string) => {
      // Prevent deleting core nodes
      if (id.startsWith('core-')) return;

      const newNodes = nodes.filter(n => n.id !== id);
      const cleanedNodes = newNodes.map(n => ({
          ...n,
          connections: (n.connections || []).filter(cid => cid !== id)
      }));
      updateNodes(cleanedNodes);
      setActiveNodeId(null);
      setShowEditModal(false);
  };

  const openEditor = (node: TimelineNode) => {
      setEditForm({
          id: node.id,
          date: node.date,
          title: node.title,
          content: node.content
      });
      setShowEditModal(true);
  };

  const saveEditor = () => {
      updateNodes(nodes.map(n => 
          n.id === editForm.id 
          ? { ...n, date: editForm.date, title: editForm.title, content: editForm.content } 
          : n
      ));
      setShowEditModal(false);
  };

  // --- CONNECTION EDITING ---
  const handleLineClick = (sourceId: string, targetId: string, label: string) => {
      setEditingConnection({ sourceId, targetId, label });
      setConnLabelInput(label);
  };

  const saveConnectionLabel = () => {
      if (!editingConnection) return;
      
      updateNodes(nodes.map(n => {
          if (n.id === editingConnection.sourceId) {
              const newLabels = { ...(n.connectionLabels || {}) };
              if (connLabelInput.trim()) {
                  newLabels[editingConnection.targetId] = connLabelInput.trim();
              } else {
                  delete newLabels[editingConnection.targetId];
              }
              return { ...n, connectionLabels: newLabels };
          }
          return n;
      }));
      
      setEditingConnection(null);
  };

  const deleteConnection = () => {
      if (!editingConnection) return;
      
      // Remove the connection string from source node
      updateNodes(nodes.map(n => {
          if (n.id === editingConnection.sourceId) {
              // Remove ID from connections
              const newConns = (n.connections || []).filter(cid => cid !== editingConnection.targetId);
              // Clean up label
              const newLabels = { ...(n.connectionLabels || {}) };
              delete newLabels[editingConnection.targetId];
              
              return { ...n, connections: newConns, connectionLabels: newLabels };
          }
          return n;
      }));
      
      setEditingConnection(null);
  };

  const renderLines = () => {
      const elements: React.ReactNode[] = [];
      
      nodes.forEach(source => {
          (source.connections || []).forEach(targetId => {
              const target = nodes.find(n => n.id === targetId);
              if (target) {
                  const w = 200;
                  const h = 80;
                  const x1 = source.position.x + w/2;
                  const y1 = source.position.y + h/2;
                  const x2 = target.position.x + w/2;
                  const y2 = target.position.y + h/2;

                  const midX = (x1 + x2) / 2;
                  const midY = (y1 + y2) / 2;
                  
                  const label = source.connectionLabels?.[targetId] || '';

                  elements.push(
                      <g key={`${source.id}-${target.id}`}>
                          {/* Invisible Thick Line for easier clicking (HIT AREA) */}
                          <line 
                              x1={x1} y1={y1} x2={x2} y2={y2}
                              stroke="transparent" 
                              strokeWidth="30"
                              cursor="pointer"
                              style={{ pointerEvents: 'all' }}
                              onPointerDown={(e) => e.stopPropagation()}
                              onClick={(e) => {
                                  e.stopPropagation();
                                  handleLineClick(source.id, targetId, label);
                              }}
                              className="hover:stroke-blue-500/20 transition-colors"
                          />
                          {/* Visible Line */}
                          <line 
                              x1={x1} y1={y1} x2={x2} y2={y2}
                              stroke="white" 
                              strokeWidth="2" 
                              opacity="0.3"
                              pointerEvents="none" 
                          />
                          {/* Label Text */}
                          {label && (
                              <foreignObject x={midX - 50} y={midY - 12} width="100" height="24" style={{ pointerEvents: 'none' }}>
                                  <div className="flex items-center justify-center w-full h-full">
                                      <span className="text-[10px] font-bold bg-black/80 px-2 py-0.5 rounded-full border border-white/20 text-white truncate max-w-full text-center">
                                          {label}
                                      </span>
                                  </div>
                              </foreignObject>
                          )}
                      </g>
                  );
              }
          });
      });
      return elements;
  };

  // --- MINIMAP RENDERER ---
  const renderMiniMap = () => {
      if (nodes.length === 0) return null;
      
      let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
      nodes.forEach(n => {
          if (n.position.x < minX) minX = n.position.x;
          if (n.position.x > maxX) maxX = n.position.x;
          if (n.position.y < minY) minY = n.position.y;
          if (n.position.y > maxY) maxY = n.position.y;
      });

      const vpX = -transform.x / transform.scale;
      const vpY = -transform.y / transform.scale;
      const vpW = containerSize.w / transform.scale;
      const vpH = containerSize.h / transform.scale;

      minX = Math.min(minX, vpX);
      maxX = Math.max(maxX, vpX + vpW);
      minY = Math.min(minY, vpY);
      maxY = Math.max(maxY, vpY + vpH);

      const pad = 1000;
      minX -= pad; maxX += pad; minY -= pad; maxY += pad;

      const worldW = maxX - minX;
      const worldH = maxY - minY;

      const mapSize = 100;
      const scaleX = mapSize / worldW;
      const scaleY = mapSize / worldH;
      const scale = Math.min(scaleX, scaleY);

      const mapW = worldW * scale;
      const mapH = worldH * scale;

      return (
          <div className="absolute bottom-4 right-4 bg-black/80 border border-white/20 rounded-lg shadow-xl overflow-hidden z-50 pointer-events-none" style={{ width: mapW, height: mapH }}>
              {nodes.map(n => (
                  <div 
                      key={n.id}
                      className={`absolute w-1 h-1 rounded-full ${n.id.startsWith('core-') ? 'bg-yellow-400' : 'bg-cyan-400'}`}
                      style={{
                          left: (n.position.x - minX) * scale,
                          top: (n.position.y - minY) * scale
                      }}
                  />
              ))}
              <div 
                  className="absolute border border-white/30 bg-white/5"
                  style={{
                      left: (vpX - minX) * scale,
                      top: (vpY - minY) * scale,
                      width: vpW * scale,
                      height: vpH * scale
                  }}
              />
          </div>
      );
  };

  const gridSize = 40 * transform.scale;
  
  return (
    <div className="fixed inset-0 z-[100] bg-[#09090b] overflow-hidden text-white flex flex-col font-sans select-none touch-none">
        
        {/* HEADER TOOLBAR */}
        <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center z-50 pointer-events-none">
            <div className="flex items-center gap-2 md:gap-4 pointer-events-auto bg-[#1a1a1a]/90 backdrop-blur-md p-2 rounded-xl border border-white/10 shadow-xl">
                <div className="flex items-center gap-2 px-2 hidden md:flex">
                    {mode === 'TIMELINE' ? <Calendar size={20} className="text-cyan-400"/> : <Users size={20} className="text-pink-400"/>}
                    <h2 className="font-bold text-sm tracking-wider uppercase">{mode === 'TIMELINE' ? 'Chronology' : 'Relationship Map'}</h2>
                </div>
                <div className="h-6 w-px bg-white/10 mx-1 hidden md:block"></div>
                <button onClick={handleCreateNode} className="p-2 hover:bg-white/10 rounded-lg transition-colors flex items-center gap-2 text-xs font-bold uppercase"><Plus size={16}/> <span className="hidden md:inline">Add Node</span></button>
                <button 
                    onClick={() => { setIsConnectMode(!isConnectMode); setConnectSourceId(null); }} 
                    className={`p-2 rounded-lg transition-colors flex items-center gap-2 text-xs font-bold uppercase ${isConnectMode ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30' : 'hover:bg-white/10 text-zinc-400'}`}
                >
                    <Link size={16}/> <span className="hidden md:inline">{isConnectMode ? 'Linking...' : 'Connect'}</span>
                </button>
                
                <div className="h-6 w-px bg-white/10 mx-1 hidden md:block"></div>
                
                <button 
                    onClick={handleAutoGenerate}
                    disabled={isGenerating}
                    className={`p-2 rounded-lg transition-colors flex items-center gap-2 text-xs font-bold uppercase ${isGenerating ? 'bg-purple-600/50 cursor-wait' : 'bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-500/20'}`}
                >
                    {isGenerating ? <Loader2 size={16} className="animate-spin"/> : <Sparkles size={16}/>} 
                    <span className="hidden md:inline">{isGenerating ? 'Generating...' : 'Auto-Generate'}</span>
                </button>
            </div>

            <div className="flex items-center gap-2 pointer-events-auto bg-[#1a1a1a]/90 backdrop-blur-md p-2 rounded-xl border border-white/10 shadow-xl">
                <button onClick={() => setTransform(t => ({...t, scale: Math.min(5, t.scale + 0.1)}))} className="p-2 hover:bg-white/10 rounded-lg"><ZoomIn size={18}/></button>
                <button onClick={() => setTransform(t => ({...t, scale: Math.max(0.1, t.scale - 0.1)}))} className="p-2 hover:bg-white/10 rounded-lg"><ZoomOut size={18}/></button>
                <button onClick={() => setTransform({x:0, y:0, scale: 1})} className="p-2 hover:bg-white/10 rounded-lg text-xs font-mono hidden md:block">100%</button>
                <div className="h-6 w-px bg-white/10 mx-1"></div>
                <button onClick={onClose} className="p-2 hover:bg-red-500/20 rounded-lg text-zinc-400 hover:text-red-400"><X size={18}/></button>
            </div>
        </div>

        {/* MINI MAP */}
        {renderMiniMap()}

        {/* CENTER HIGHLIGHT HUD */}
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-40 opacity-30">
            <Crosshair size={24} className="text-white" />
        </div>

        {/* MAIN CANVAS */}
        <div 
            ref={containerRef}
            className="flex-1 w-full h-full cursor-grab active:cursor-grabbing overflow-hidden relative touch-none"
            onPointerDown={handleBoardPointerDown}
            onPointerMove={handleBoardPointerMove}
            onPointerUp={handleBoardPointerUp}
            onPointerLeave={handleBoardPointerUp}
            onWheel={handleWheel}
            style={{
                backgroundImage: `radial-gradient(#52525b ${Math.max(1, 1 * transform.scale)}px, transparent 1px)`,
                backgroundSize: `${gridSize}px ${gridSize}px`,
                backgroundPosition: `${transform.x}px ${transform.y}px`,
                backgroundColor: '#09090b',
            }}
        >
            <div 
                className="absolute inset-0 origin-top-left will-change-transform"
                style={{
                    transform: `translate(${transform.x}px, ${transform.y}px) scale(${transform.scale})`
                }}
            >
                <svg className="absolute top-0 left-0 w-[50000px] h-[50000px] pointer-events-none" style={{ transform: 'translate(-25000px, -25000px)' }}> 
                    <g transform="translate(25000, 25000)"> 
                       {renderLines()}
                    </g>
                </svg>

                {nodes.map(node => {
                    const isCore = node.id.startsWith('core-');
                    return (
                    <div
                        key={node.id}
                        className={`absolute w-[200px] bg-[#111] rounded-lg border shadow-2xl flex flex-col group touch-auto
                            ${activeNodeId === node.id ? 'border-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.3)] z-20' : 'border-zinc-800 hover:border-zinc-600 z-10'}
                            ${connectSourceId === node.id ? 'ring-2 ring-blue-400 border-blue-400' : ''}
                            ${isCore ? 'ring-1 ring-yellow-500/20' : ''}
                        `}
                        style={{
                            left: node.position.x,
                            top: node.position.y
                        }}
                        onClick={(e) => handleNodeClick(e, node.id)}
                        onPointerDown={(e) => startDragNode(e, node.id)}
                    >
                        <div className={`p-2 rounded-t-lg border-b border-zinc-800 flex justify-between items-start cursor-grab active:cursor-grabbing ${isCore ? 'bg-yellow-900/10' : 'bg-[#1a1a1a]'}`}>
                            {mode === 'TIMELINE' ? (
                                <span className="text-[10px] font-mono text-cyan-400 font-bold bg-cyan-950/30 px-1.5 py-0.5 rounded border border-cyan-500/20 pointer-events-none">{node.date || 'No Date'}</span>
                            ) : (
                                <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded border pointer-events-none ${isCore ? 'text-yellow-400 bg-yellow-950/30 border-yellow-500/20' : 'text-pink-400 bg-pink-950/30 border-pink-500/20'}`}>{isCore ? 'CORE' : 'ENTITY'}</span>
                            )}
                            
                            <div className="flex gap-1 md:opacity-0 md:group-hover:opacity-100 transition-opacity">
                                <button onClick={(e) => { e.stopPropagation(); openEditor(node); }} className="p-1 hover:bg-white/10 rounded text-zinc-400 hover:text-white"><Edit2 size={10}/></button>
                                {isCore ? (
                                    <div className="p-1 text-zinc-600 cursor-not-allowed" title="Core Node - Cannot Delete"><Lock size={10}/></div>
                                ) : (
                                    <button onClick={(e) => { e.stopPropagation(); deleteNode(node.id); }} className="p-1 hover:bg-red-900/30 rounded text-zinc-400 hover:text-red-400"><Trash2 size={10}/></button>
                                )}
                            </div>
                        </div>
                        
                        <div className="p-3 pointer-events-none">
                            <h4 className="font-bold text-sm text-zinc-100 mb-1 leading-tight">{node.title}</h4>
                            <p className="text-[10px] text-zinc-500 line-clamp-3 font-mono leading-relaxed whitespace-pre-wrap">{node.content}</p>
                        </div>

                        {isConnectMode && (
                            <div className="absolute inset-0 bg-blue-500/10 border-2 border-blue-500 rounded-lg flex items-center justify-center animate-pulse pointer-events-none">
                                <Link className="text-blue-400" />
                            </div>
                        )}
                    </div>
                )})}
            </div>
        </div>

        {/* NODE EDITOR MODAL OVERLAY */}
        {showEditModal && (
            <div className="absolute inset-0 z-[60] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="w-full max-w-md bg-[#1a1a1a] border border-zinc-700 rounded-xl shadow-2xl p-6 flex flex-col gap-4 animate-in zoom-in-95 duration-200">
                    <div className="flex justify-between items-center border-b border-zinc-700 pb-2">
                        <h3 className="font-bold text-white uppercase tracking-widest flex items-center gap-2">
                            <Edit2 size={16} /> Edit {mode === 'TIMELINE' ? 'Event' : 'Entity'}
                        </h3>
                        <button onClick={() => setShowEditModal(false)}><X size={20} className="text-zinc-500 hover:text-white"/></button>
                    </div>

                    <div className="flex flex-col gap-3">
                        {mode === 'TIMELINE' && (
                            <div>
                                <label className="text-[10px] uppercase font-bold text-zinc-500 block mb-1">Date (DD/MM/YY)</label>
                                <input 
                                    type="text" 
                                    value={editForm.date} 
                                    onChange={e => setEditForm({...editForm, date: e.target.value})}
                                    className="w-full bg-black border border-zinc-700 rounded p-2 text-sm text-cyan-400 font-mono focus:border-cyan-500 outline-none"
                                />
                            </div>
                        )}
                        
                        <div>
                            <label className="text-[10px] uppercase font-bold text-zinc-500 block mb-1">{mode === 'TIMELINE' ? 'Title / Event Name' : 'Character Name'}</label>
                            <input 
                                type="text" 
                                value={editForm.title} 
                                onChange={e => setEditForm({...editForm, title: e.target.value})}
                                className="w-full bg-black border border-zinc-700 rounded p-2 text-sm text-white focus:border-white outline-none font-bold"
                            />
                        </div>

                        <div>
                            <label className="text-[10px] uppercase font-bold text-zinc-500 block mb-1">Description / Details</label>
                            <textarea 
                                value={editForm.content} 
                                onChange={e => setEditForm({...editForm, content: e.target.value})}
                                className="w-full h-32 bg-black border border-zinc-700 rounded p-2 text-xs text-zinc-300 focus:border-white outline-none resize-none font-mono leading-relaxed"
                            />
                        </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                        <button onClick={() => setShowEditModal(false)} className="px-4 py-2 rounded text-xs font-bold text-zinc-400 hover:text-white">Cancel</button>
                        <button onClick={saveEditor} className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold uppercase shadow-lg">Save Changes</button>
                    </div>
                </div>
            </div>
        )}

        {/* CONNECTION EDITOR MODAL */}
        {editingConnection && (
            <div className="absolute inset-0 z-[70] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="w-full max-w-sm bg-[#1a1a1a] border border-blue-500/50 rounded-xl shadow-2xl p-5 flex flex-col gap-4 animate-in zoom-in-95 duration-200">
                    <div className="flex justify-between items-center border-b border-zinc-700 pb-2">
                        <h3 className="font-bold text-blue-400 uppercase tracking-widest flex items-center gap-2">
                            <Link size={16} /> Edit Relationship
                        </h3>
                        <button onClick={() => setEditingConnection(null)}><X size={20} className="text-zinc-500 hover:text-white"/></button>
                    </div>

                    <div>
                        <label className="text-[10px] uppercase font-bold text-zinc-500 block mb-1">Label (e.g. Friends, Enemies)</label>
                        <input 
                            type="text" 
                            value={connLabelInput} 
                            onChange={e => setConnLabelInput(e.target.value)}
                            className="w-full bg-black border border-blue-500/30 rounded p-2 text-sm text-white focus:border-blue-500 outline-none font-bold placeholder:text-zinc-700"
                            placeholder="Type relationship..."
                            autoFocus
                        />
                        <p className="text-[10px] text-zinc-600 mt-1 italic">Leave empty to remove label only.</p>
                    </div>

                    <div className="flex gap-2 pt-2">
                        <button 
                            onClick={deleteConnection}
                            className="flex-1 py-2 bg-red-900/20 text-red-500 border border-red-900/50 hover:bg-red-900/40 rounded text-xs font-bold uppercase flex items-center justify-center gap-2"
                        >
                            <Trash2 size={12}/> Disconnect
                        </button>
                        <button 
                            onClick={saveConnectionLabel}
                            className="flex-1 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold uppercase shadow-lg"
                        >
                            Save Label
                        </button>
                    </div>
                </div>
            </div>
        )}

    </div>
  );
};

export default NodeBoardModal;
