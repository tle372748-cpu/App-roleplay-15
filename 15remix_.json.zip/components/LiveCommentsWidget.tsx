
import React, { useState, useEffect, useRef } from 'react';
import { AppConfig, ChatMessage, LiveState, LiveComment } from '../types';
import { generateLiveComments } from '../services/aiService';
import { MessageSquare, X, Minimize2, Coins, Gift, TrendingUp, GripHorizontal, GripVertical, Users, Settings, Smile, Skull, Heart } from 'lucide-react';
import { formatVND, parseBalance } from '../utils/mockDataGenerator';

interface LiveCommentsWidgetProps {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  themeColors: any;
  messages: ChatMessage[];
}

const LiveCommentsWidget: React.FC<LiveCommentsWidgetProps> = ({ config, setConfig, themeColors, messages }) => {
  const comments = config.liveState?.comments || [];
  const sessionEarnings = config.liveState?.earnings || 0;
  const viewerPersona = config.liveState?.persona || 'Casual';

  const [isMinimized, setIsMinimized] = useState(false);
  const [viewers, setViewers] = useState(124); 
  const [position, setPosition] = useState<{x: number, y: number} | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  
  const personaRef = useRef(viewerPersona);
  useEffect(() => { personaRef.current = viewerPersona; }, [viewerPersona]);

  const isDragging = useRef(false);
  const dragOffset = useRef({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  
  const lastProcessedMsgId = useRef<string | null>(null);
  const startTimeRef = useRef<number>(Date.now());
  const inactivityTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const startDelayRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const trickleIntervalRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  
  const commentQueueRef = useRef<any[]>([]);
  const isFetchingRef = useRef(false);
  const lastDonationTimeRef = useRef<number>(0);

  const { bgPanel, textMain, textDim, border, accent } = themeColors;

  const updateLiveState = (updates: Partial<LiveState>, gameStatsUpdate?: any) => {
      setConfig(prev => ({
          ...prev,
          gameStats: gameStatsUpdate ? { ...prev.gameStats!, ...gameStatsUpdate } : prev.gameStats,
          liveState: {
              comments: [],
              earnings: 0,
              persona: 'Casual',
              ...prev.liveState,
              ...updates
          }
      }));
  };

  useEffect(() => {
      const interval = setInterval(() => {
          const now = Date.now();
          const elapsedMinutes = (now - startTimeRef.current) / 60000;
          
          let baseViewers = 150;
          if (elapsedMinutes > 5) {
              const spikes = Math.floor((elapsedMinutes - 5) / 3);
              baseViewers += spikes * 1000 + 500;
          }

          const fluctuation = baseViewers * 0.05 * (Math.random() - 0.5);
          setViewers(Math.floor(baseViewers + fluctuation));

      }, 3000);
      return () => clearInterval(interval);
  }, []);

  useEffect(() => {
      if (listRef.current) {
          listRef.current.scrollTop = listRef.current.scrollHeight;
      }
  }, [comments]);

  useEffect(() => {
      const lastMsg = messages[messages.length - 1];
      if (!lastMsg) return;

      if (lastMsg.role === 'user') {
          if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
          if (startDelayRef.current) clearTimeout(startDelayRef.current);
          return;
      }

      if (lastMsg.role === 'assistant' && lastMsg.id !== lastProcessedMsgId.current) {
          const isIgnored = 
            lastMsg.content.includes('[ ROLEPLAY START: SCENARIO ]') || 
            lastMsg.content.startsWith('[SYSTEM') ||
            lastMsg.content.startsWith('»') ||
            lastMsg.content.trim() === '...';

          if (isIgnored) {
              lastProcessedMsgId.current = lastMsg.id;
              return;
          }

          lastProcessedMsgId.current = lastMsg.id;
          
          if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
          if (startDelayRef.current) clearTimeout(startDelayRef.current);
          if (trickleIntervalRef.current) clearInterval(trickleIntervalRef.current);
          
          commentQueueRef.current = [];

          startDelayRef.current = setTimeout(() => {
              fetchNewBatch(lastMsg.content);
          }, 3000);

          inactivityTimerRef.current = setTimeout(() => {
              triggerInactivityRage();
          }, 120000); 
      }
  }, [messages]);

  const triggerInactivityRage = async () => {
      if (trickleIntervalRef.current) clearInterval(trickleIntervalRef.current); 
      const elapsedMinutes = (Date.now() - startTimeRef.current) / 60000;
      const rageComments = await generateLiveComments(messages, elapsedMinutes, true, personaRef.current);
      addCommentsToState(rageComments);
  };

  const fetchNewBatch = async (aiContent: string) => {
      if (isFetchingRef.current) return;
      isFetchingRef.current = true;

      const elapsedMinutes = (Date.now() - startTimeRef.current) / 60000;
      const rawComments = await generateLiveComments(messages, elapsedMinutes, false, personaRef.current);
      
      isFetchingRef.current = false;

      if (rawComments.length > 0) {
          const burstSet = rawComments.slice(0, 5);
          const trickleSet = rawComments.slice(5);
          
          commentQueueRef.current = [...commentQueueRef.current, ...trickleSet];

          burstSet.forEach((c: any, idx: number) => {
              setTimeout(() => {
                  addSingleComment(c);
              }, idx * 600);
          });

          if (trickleIntervalRef.current) clearInterval(trickleIntervalRef.current);
          trickleIntervalRef.current = setInterval(processTrickleTick, 5000);
      }
  };

  const processTrickleTick = async () => {
      if (commentQueueRef.current.length > 0) {
          const nextComment = commentQueueRef.current.shift();
          addSingleComment(nextComment);
      }

      if (commentQueueRef.current.length <= 1 && !isFetchingRef.current) {
          isFetchingRef.current = true;
          const elapsedMinutes = (Date.now() - startTimeRef.current) / 60000;
          const moreComments = await generateLiveComments(messages, elapsedMinutes, false, personaRef.current);
          commentQueueRef.current = [...commentQueueRef.current, ...moreComments];
          isFetchingRef.current = false;
      }
  };

  const addSingleComment = (c: any) => {
      const newComment: LiveComment = {
          id: `cmt-${Date.now()}-${Math.random()}`,
          user: c.user,
          content: c.content,
          type: c.type,
          value: c.value
      };

      setConfig(prev => {
          const currentLive = prev.liveState || { comments: [], earnings: 0, persona: 'Casual' };
          const updatedComments = [...currentLive.comments, newComment];
          if (updatedComments.length > 60) updatedComments.shift();

          let newEarnings = currentLive.earnings;
          let gameStatsUpdate = undefined;

          // ANTI-INFLATION DONATE LOGIC
          if (c.type === 'DONATE') {
              const now = Date.now();
              const timeSinceLastDonation = now - lastDonationTimeRef.current;
              const sessionCap = 5000000; // 5M Ⓠ max per session

              // 1. Rate Limit: Max 1 donation per 10 seconds
              const isRateLimited = timeSinceLastDonation < 10000;
              // 2. Probability Gate: 40% chance to actually award the gold (visual only otherwise)
              const luckyAward = Math.random() < 0.4;
              // 3. Session Cap
              const isCapped = currentLive.earnings >= sessionCap;

              if (!isRateLimited && luckyAward && !isCapped) {
                  const amount = parseBalance(String(c.value)) || 0;
                  if (amount > 0) {
                      newEarnings += amount;
                      gameStatsUpdate = {
                          gold: (prev.gameStats?.gold || 0) + amount
                      };
                      lastDonationTimeRef.current = now;
                  }
              }
          }

          return {
              ...prev,
              gameStats: gameStatsUpdate ? { ...prev.gameStats!, ...gameStatsUpdate } : prev.gameStats,
              liveState: {
                  ...currentLive,
                  comments: updatedComments,
                  earnings: newEarnings
              }
          };
      });
  };

  const addCommentsToState = (list: any[]) => {
      list.forEach((c, idx) => {
          setTimeout(() => addSingleComment(c), idx * 800);
      });
  };

  const handleStart = (clientX: number, clientY: number) => {
      if (!containerRef.current) return;
      isDragging.current = true;
      const rect = containerRef.current.getBoundingClientRect();
      dragOffset.current = { x: clientX - rect.left, y: clientY - rect.top };
      if (!position) setPosition({ x: rect.left, y: rect.top });
  };

  const onMouseDown = (e: React.MouseEvent) => handleStart(e.clientX, e.clientY);
  const onTouchStart = (e: React.TouchEvent) => handleStart(e.touches[0].clientX, e.touches[0].clientY);

  useEffect(() => {
      const handleMove = (clientX: number, clientY: number) => {
          if (isDragging.current) {
              setPosition({ x: clientX - dragOffset.current.x, y: clientY - dragOffset.current.y });
          }
      };
      const handleEnd = () => isDragging.current = false;

      const onMouseMove = (e: MouseEvent) => { if(isDragging.current) { handleMove(e.clientX, e.clientY); } };
      const onTouchMove = (e: TouchEvent) => { 
          if(isDragging.current) { 
              if (e.cancelable) e.preventDefault();
              handleMove(e.touches[0].clientX, e.touches[0].clientY); 
          } 
      };

      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', handleEnd);
      window.addEventListener('touchmove', onTouchMove, { passive: false });
      window.addEventListener('touchend', handleEnd);
      return () => {
          window.removeEventListener('mousemove', onMouseMove);
          window.removeEventListener('mouseup', handleEnd);
          window.removeEventListener('touchmove', onTouchMove);
          window.removeEventListener('touchend', handleEnd);
      };
  }, []);

  const containerStyle: React.CSSProperties = position 
      ? { left: `${position.x}px`, top: `${position.y}px`, bottom: 'auto', right: 'auto' }
      : {}; 

  return (
    <div 
        ref={containerRef}
        className={`fixed z-40 animate-in fade-in transition-shadow duration-300 ${!position ? 'top-20 right-4 slide-in-from-right-5' : ''}`}
        style={containerStyle}
    >
        {isMinimized ? (
            <div 
                className={`flex items-center gap-2 px-3 py-2 rounded-full border shadow-xl backdrop-blur-md bg-black/80 border-red-500/30 text-white cursor-move touch-none`} 
                onMouseDown={onMouseDown}
                onTouchStart={onTouchStart}
            >
                <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                <span className="text-[10px] font-bold font-mono">LIVE</span>
                <span className="text-[10px] opacity-70 border-l border-white/20 pl-2 ml-1">{formatVND(sessionEarnings)}</span>
                <button onClick={() => setIsMinimized(false)} className="ml-2 hover:text-red-400 p-1" onTouchStart={(e) => e.stopPropagation()} onMouseDown={(e) => e.stopPropagation()}><Minimize2 size={14}/></button>
            </div>
        ) : (
            <div className={`w-[85vw] max-w-[320px] md:w-80 flex flex-col rounded-xl border shadow-2xl backdrop-blur-md overflow-hidden bg-black/80 border-white/10`}>
                <div 
                    className="flex items-center justify-between p-2 border-b border-white/10 bg-white/5 cursor-move touch-none relative" 
                    onMouseDown={onMouseDown}
                    onTouchStart={onTouchStart}
                >
                    <div className="flex items-center gap-2">
                        <GripHorizontal size={14} className="text-white/30" />
                        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-red-600/20 border border-red-500/50">
                            <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></div>
                            <span className="text-[9px] font-bold text-red-400 tracking-wider">LIVE</span>
                        </div>
                        <div className="flex items-center gap-1 text-[10px] text-white/50 font-mono">
                            <Users size={10} /> {viewers.toLocaleString()}
                        </div>
                    </div>
                    <div className="flex items-center gap-1" onMouseDown={e => e.stopPropagation()} onTouchStart={e => e.stopPropagation()}>
                        <button onClick={() => setShowSettings(!showSettings)} className="p-1.5 text-white/50 hover:text-white transition-colors" title="Settings"><Settings size={14}/></button>
                        <button onClick={() => setIsMinimized(true)} className="p-1.5 text-white/50 hover:text-white"><Minimize2 size={14}/></button>
                        <button onClick={() => setConfig(prev => ({ ...prev, activeModules: prev.activeModules.filter(m => m !== "Live_Comments") }))} className="p-1.5 text-white/50 hover:text-red-400"><X size={14}/></button>
                    </div>

                    {showSettings && (
                        <div className="absolute top-full right-2 mt-1 w-40 bg-zinc-900 border border-zinc-700 rounded-lg shadow-xl z-50 flex flex-col p-1 animate-in zoom-in-95 duration-100" onMouseDown={e => e.stopPropagation()} onTouchStart={e => e.stopPropagation()}>
                            <div className="px-2 py-1.5 text-[9px] font-mono text-zinc-500 uppercase font-bold border-b border-zinc-800 mb-1">Viewer Persona</div>
                            <button onClick={() => { updateLiveState({ persona: 'Casual' }); setShowSettings(false); }} className={`flex items-center gap-2 px-2 py-2.5 rounded text-xs font-mono transition-colors text-left ${viewerPersona === 'Casual' ? 'bg-blue-500/20 text-blue-400' : 'text-zinc-400 hover:bg-white/5'}`}>
                                <Smile size={12} /> Casual
                            </button>
                            <button onClick={() => { updateLiveState({ persona: 'Cruel' }); setShowSettings(false); }} className={`flex items-center gap-2 px-2 py-2.5 rounded text-xs font-mono transition-colors text-left ${viewerPersona === 'Cruel' ? 'bg-red-500/20 text-red-400' : 'text-zinc-400 hover:bg-white/5'}`}>
                                <Skull size={12} /> Cruel
                            </button>
                            <button onClick={() => { updateLiveState({ persona: 'Lewd' }); setShowSettings(false); }} className={`flex items-center gap-2 px-2 py-2.5 rounded text-xs font-mono transition-colors text-left ${viewerPersona === 'Lewd' ? 'bg-pink-500/20 text-pink-400' : 'text-zinc-400 hover:bg-white/5'}`}>
                                <Heart size={12} /> Lewd
                            </button>
                        </div>
                    )}
                </div>

                <div ref={listRef} className="h-64 md:h-80 overflow-y-auto custom-scrollbar p-3 flex flex-col gap-2 relative">
                    <div className="absolute inset-x-0 top-0 h-8 bg-gradient-to-b from-black/80 to-transparent pointer-events-none z-10"></div>
                    
                    {comments.map((comment) => (
                        <div key={comment.id} className={`text-xs animate-in slide-in-from-left-2 fade-in duration-300 break-words leading-tight ${comment.type === 'DONATE' ? 'bg-yellow-500/10 border-l-2 border-yellow-500 p-1.5 rounded-r' : comment.type === 'GIFT' ? 'bg-pink-500/10 border-l-2 border-pink-500 p-1.5 rounded-r' : ''}`}>
                            <span className={`font-bold mr-1.5 ${comment.type === 'DONATE' ? 'text-yellow-400' : comment.type === 'GIFT' ? 'text-pink-400' : 'text-gray-400'}`}>{comment.user}:</span>
                            
                            {comment.type === 'DONATE' && (
                                <span className="font-bold text-yellow-200 bg-yellow-500/20 px-1 rounded text-[10px] mr-1">
                                    {formatVND(parseBalance(String(comment.value)) || 0)}
                                </span>
                            )}
                            
                            {comment.type === 'GIFT' && (
                                <span className="font-bold text-pink-200 bg-pink-500/20 px-1 rounded text-[10px] mr-1 flex inline-flex items-center gap-1">
                                    <Gift size={8} /> {comment.value}
                                </span>
                            )}

                            <span className="text-gray-200/90">{comment.content}</span>
                        </div>
                    ))}
                    
                    {comments.length === 0 && (
                        <div className="text-center text-gray-600 text-xs italic mt-auto">Waiting for stream activity...</div>
                    )}
                </div>

                <div className="p-2 border-t border-white/10 bg-white/5 flex justify-between items-center text-[10px] font-mono text-gray-400">
                    <div className="flex items-center gap-1">
                        <TrendingUp size={12} className="text-green-400"/>
                        <span>Session: <span className="text-white font-bold">{formatVND(sessionEarnings)}</span></span>
                    </div>
                    <span>{(Date.now() - startTimeRef.current) / 60000 < 1 ? "< 1m" : `${Math.floor((Date.now() - startTimeRef.current) / 60000)}m`}</span>
                </div>
            </div>
        )}
    </div>
  );
};

export default LiveCommentsWidget;
