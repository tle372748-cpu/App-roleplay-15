
import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { formatVND } from '../utils/mockDataGenerator';

interface BegCardProps {
  itemName: string;
  price: number;
  icon?: string;
  onBuy: () => void;
  canAfford: boolean;
  themeColors: any;
}

const BegCard: React.FC<BegCardProps> = ({ itemName, price, icon, onBuy, canAfford, themeColors }) => {
  return (
    <div className={`p-4 rounded-xl border border-yellow-500/30 bg-yellow-900/10 flex flex-col gap-3 animate-in zoom-in duration-300`}>
        <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
                <div className="text-3xl filter drop-shadow-md">{icon || '🎁'}</div>
                <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-yellow-500 uppercase tracking-wider">Requested Item</span>
                    <span className="text-sm font-bold text-white">{itemName}</span>
                </div>
            </div>
            <span className="text-xs font-mono text-yellow-400 font-bold bg-black/40 px-2 py-1 rounded border border-yellow-500/20">
                {formatVND(price)}
            </span>
        </div>
        
        <button 
            onClick={onBuy}
            disabled={!canAfford}
            className={`w-full py-2 rounded-lg font-bold text-xs uppercase flex items-center justify-center gap-2 transition-all
                ${canAfford 
                    ? 'bg-yellow-600 hover:bg-yellow-500 text-white shadow-lg shadow-yellow-900/20 active:scale-95' 
                    : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'}
            `}
        >
            <ShoppingCart size={14} />
            {canAfford ? 'Buy for Character' : 'Insufficient Funds'}
        </button>
    </div>
  );
};

export default BegCard;
