
import React, { useState, useEffect } from 'react';
import { X, Plus, Minus, Hand, Coins, Wallet, CreditCard, RefreshCw, Clock, AlertTriangle, Ghost, Terminal, Building2, Briefcase, Car, FileText, Scroll, Package, Gift, ArrowRight, User } from 'lucide-react';
import { AppConfig, InventoryItem, HeavyAsset, CardData } from '../types';
import { parseBalance, formatVND } from '../utils/mockDataGenerator';

interface EconomyModalProps {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  onClose: () => void;
  onLogMessage: (msg: string) => void;
  onSendMessage: (msg: string) => void;
  themeColors: any;
}

const TRAGEDY_LOOT = [
    { name: "Tờ Giấy Nhàu Nát", desc: '"Tiền phẫu thuật cho mẹ - Đừng tiêu!" (Nét chữ run rẩy)', icon: '📄', thought: "Tiền... tiền viện phí của mẹ đâu rồi?! Mình vừa để đây mà..." },
    { name: "Nhẫn Cỏ Khô", desc: '"Quà cầu hôn... hy vọng cô ấy không chê nghèo."', icon: '💍', thought: "Chiếc nhẫn... Không, làm ơn, đừng là chiếc nhẫn. Đó là tất cả những gì mình có để cầu hôn cô ấy." },
    { name: "Ảnh Siêu Âm", desc: '"Con của bố... bố sẽ làm việc chăm chỉ vì con."', icon: '👶', thought: "Bức ảnh của con... Đừng ai lấy nó đi, làm ơn..." },
    { name: "Thư Đòi Nợ", desc: '"Hạn cuối ngày mai. Không trả thì cụt tay."', icon: '🔪', thought: "Mất hết tiền rồi... Bọn chúng sẽ giết mình mất. Chết chắc rồi." },
    { name: "Kỷ Vật Cuối Cùng", desc: 'Sợi dây chuyền rẻ tiền, di vật duy nhất của người bà quá cố.', icon: '📿', thought: "Bà ơi... cháu xin lỗi... cháu đã đánh mất kỷ vật duy nhất của bà rồi..." }
];

const ASSET_TYPES = [
    { id: 'REAL_ESTATE', label: 'Bất Động Sản', icon: <Building2 size={16}/> },
    { id: 'BUSINESS', label: 'Doanh Nghiệp', icon: <Briefcase size={16}/> },
    { id: 'VEHICLE', label: 'Phương Tiện', icon: <Car size={16}/> },
    { id: 'CONTRACT', label: 'Hợp Đồng', icon: <FileText size={16}/> },
    { id: 'TITLE', label: 'Danh Hiệu/Quyền Lực', icon: <Scroll size={16}/> },
    { id: 'OTHER', label: 'Khác (Other)', icon: <Package size={16}/> },
];

const EconomyModal: React.FC<EconomyModalProps> = ({ config, setConfig, onClose, onLogMessage, onSendMessage, themeColors }) => {
  const userBalance = config.gameStats?.gold || 0;
  const [now, setNow] = useState(Date.now());
  const [userCustomInput, setUserCustomInput] = useState('');
  const [charCustomInputs, setCharCustomInputs] = useState<Record<number, string>>({});
  
  // Asset Management State
  const [viewingAssetsFor, setViewingAssetsFor] = useState<'USER' | number | null>(null);
  const [isCreatingAsset, setIsCreatingAsset] = useState(false);
  const [newAssetForm, setNewAssetForm] = useState({ name: '', desc: '', val: '', type: 'REAL_ESTATE', icon: '🏠' });

  // User-to-Char Gifting State
  const [transferAsset, setTransferAsset] = useState<HeavyAsset | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const getCooldown = (charName: string): number => {
    const cooldowns = config.gameStats?.pickpocketCooldowns || {};
    const expiry = cooldowns[charName] || 0;
    const remaining = Math.max(0, expiry - now);
    return remaining;
  };

  const getStats = (charName: string) => {
    return config.gameStats?.pickpocketStats?.[charName] || { attempts: 0, penalties: 0 };
  };

  const calculateRisk = (charName: string) => {
    const stats = getStats(charName);
    return Math.min(0.70, 0.0 + (stats.penalties * 0.10));
  };

  const formatTime = (ms: number) => {
    const s = Math.ceil(ms / 1000);
    const m = Math.floor(s / 60);
    const rs = s % 60;
    return `${m}:${rs.toString().padStart(2, '0')}`;
  };

  const parseCustomAmount = (input: string): number => {
    if (!input) return 0;
    let clean = input.trim().toLowerCase();
    let multiplier = 1;
    
    if (clean.startsWith('-')) {
        multiplier = -1;
        clean = clean.substring(1);
    } else if (clean.startsWith('+')) {
        clean = clean.substring(1);
    }

    if (clean.includes('e')) {
        const val = Number(clean);
        if (!isNaN(val)) return val * multiplier;
    }

    const val = parseBalance(clean);
    return val * multiplier;
  };

  const handleUserCustomApply = () => {
    const amount = parseCustomAmount(userCustomInput);
    if (amount !== 0) {
        modifyUserBalance(amount, "Custom");
        setUserCustomInput('');
    }
  };

  const handleCharCustomApply = (idx: number) => {
    const input = charCustomInputs[idx];
    if (!input) return;
    const amount = parseCustomAmount(input);
    if (amount !== 0) {
        modifyCharBalance(idx, amount);
        setCharCustomInputs(prev => ({...prev, [idx]: ''}));
    }
  };

  const modifyUserBalance = (amount: number, reason: string) => {
    const newBal = userBalance + amount;
    setConfig(prev => {
        const next = { ...prev };
        if (next.gameStats) next.gameStats.gold = newBal;
        if (next.userCard && next.userCard.phone) {
            next.userCard.phone.bankBalance = formatVND(newBal);
        }
        return next;
    });
    const actionText = amount > 0 ? "ADDED" : "REMOVED";
    onLogMessage(`» ECONOMY UPDATE: User Balance ${actionText} ${formatVND(Math.abs(amount))}. New Balance: ${formatVND(newBal)}.`);
  };

  const modifyCharBalance = (index: number, amount: number) => {
    const char = config.characterCards[index];
    const current = parseBalance(char.phone?.bankBalance || "0");
    const newBal = current + amount;
    
    setConfig(prev => {
        const next = { ...prev };
        const newChars = [...next.characterCards];
        newChars[index] = {
            ...char,
            phone: { ...char.phone, bankBalance: formatVND(newBal) }
        };
        next.characterCards = newChars;
        return next;
    });
    const actionText = amount > 0 ? "INJECTED" : "DEDUCTED";
    onLogMessage(`» ECONOMY UPDATE: [${char.name}] ${actionText} ${formatVND(Math.abs(amount))}.`);
  };

  const robCharacter = (index: number) => {
    const char = config.characterCards[index];
    if (getCooldown(char.name) > 0) return;

    const current = parseBalance(char.phone?.bankBalance || "0");
    const stats = getStats(char.name);
    const catchChance = calculateRisk(char.name);
    const isCaught = Math.random() < catchChance;

    if (isCaught) {
        const expiry = Date.now() + (5 * 60 * 1000);
        setConfig(prev => ({
            ...prev,
            gameStats: {
                ...prev.gameStats!,
                pickpocketCooldowns: { ...(prev.gameStats!.pickpocketCooldowns || {}), [char.name]: expiry },
                pickpocketStats: { ...(prev.gameStats!.pickpocketStats || {}), [char.name]: { ...stats, penalties: stats.penalties + 1 } }
            }
        }));
        onSendMessage(`[ACTION]: *User lén đưa tay vào túi của ${char.name} định móc ví, nhưng vụng về nên bị ${char.name} phát hiện và nắm chặt cổ tay.* "Định làm gì đấy hả?!"`);
        onClose();
        return;
    }

    const basePercent = (Math.random() * 0.05) + 0.05;
    const reductionFactor = Math.pow(0.85, stats.attempts);
    const finalPercent = basePercent * reductionFactor;
    
    const robAmount = Math.max(10000, Math.floor(current * finalPercent));
    const finalRobAmount = Math.min(robAmount, current);
    
    if (finalRobAmount <= 0) {
        onLogMessage(`» KẾT QUẢ: [${char.name}] chẳng còn xu nào để móc.`);
        return;
    }

    const isTragedy = Math.random() < 0.20; 
    let tragedyItem: InventoryItem | null = null;
    let tragedyThought = "";

    if (isTragedy) {
        const tragedy = TRAGEDY_LOOT[Math.floor(Math.random() * TRAGEDY_LOOT.length)];
        tragedyItem = {
            id: `curse-${Date.now()}`,
            name: tragedy.name,
            description: tragedy.desc,
            icon: tragedy.icon,
            type: 'CURSED',
            usageType: 'CONSUMABLE',
            price: 0,
            quantity: 1,
            source: 'THEFT'
        };
        tragedyThought = tragedy.thought;
    }

    setConfig(prev => {
        const next = { ...prev };
        const newChars = [...next.characterCards];
        
        const memoryLeak = tragedyThought || `Someone stole my money (${formatVND(finalRobAmount)})... I feel unsafe.`;
        const currentMemories = char.hiddenMemories || [];
        const newMemories = [...currentMemories, `TRAUMA_EVENT: ${memoryLeak}`];

        newChars[index] = {
            ...char,
            phone: { ...char.phone, bankBalance: formatVND(current - finalRobAmount) },
            hiddenMemories: newMemories
        };
        next.characterCards = newChars;

        const newUserBal = (next.gameStats?.gold || 0) + finalRobAmount;
        const newInventory = tragedyItem ? [...(next.inventory || []), tragedyItem] : next.inventory;

        if (next.gameStats) {
            next.gameStats.gold = newUserBal;
            next.gameStats.pickpocketStats = {
                ...(next.gameStats.pickpocketStats || {}),
                [char.name]: { ...stats, attempts: stats.attempts + 1 }
            };
        }
        if (next.userCard && next.userCard.phone) {
            next.userCard.phone.bankBalance = formatVND(newUserBal);
        }
        if (newInventory) next.inventory = newInventory;

        return next;
    });

    if (isTragedy && tragedyItem) {
        onSendMessage(`[NARRATIVE EVENT]: *User đã âm thầm lấy mất [${tragedyItem.name}] của ${char.name}. Một lát sau, ${char.name} sờ vào túi và hoảng hốt nhận ra vật quan trọng nhất đời mình đã biến mất. Cảm giác tuyệt vọng ập đến.* (Suy nghĩ: "${tragedyThought}")`);
    } else {
        onSendMessage(`[NARRATIVE EVENT]: *User nhanh tay "mượn tạm" ${formatVND(finalRobAmount)} từ túi của ${char.name} mà không bị phát hiện. Tuy nhiên, ${char.name} cảm giác túi nhẹ đi và bắt đầu nghi ngờ, nhìn quanh dáo dác.*`);
    }
    
    onClose();
  };

  // --- ASSET MANAGEMENT LOGIC ---
  const getCurrentAssets = () => {
      if (viewingAssetsFor === 'USER') {
          return config.gameStats?.assets || [];
      } else if (typeof viewingAssetsFor === 'number') {
          return config.characterCards[viewingAssetsFor]?.assets || [];
      }
      return [];
  };

  const getTargetName = () => {
      if (viewingAssetsFor === 'USER') return config.userCard?.name || "User";
      if (typeof viewingAssetsFor === 'number') return config.characterCards[viewingAssetsFor]?.name || "Unknown";
      return "";
  };

  const handleCreateAsset = () => {
      if (!newAssetForm.name.trim()) return;
      
      const newAsset: HeavyAsset = {
          id: `asset-${Date.now()}`,
          name: newAssetForm.name,
          description: newAssetForm.desc || "No description.",
          value: parseBalance(newAssetForm.val),
          type: newAssetForm.type as any,
          icon: newAssetForm.icon || '📦'
      };

      setConfig(prev => {
          if (viewingAssetsFor === 'USER') {
              const currentAssets = prev.gameStats?.assets || [];
              return { ...prev, gameStats: { ...prev.gameStats!, assets: [...currentAssets, newAsset] } };
          } else if (typeof viewingAssetsFor === 'number') {
              const newChars = [...prev.characterCards];
              const char = newChars[viewingAssetsFor];
              const currentAssets = char.assets || [];
              newChars[viewingAssetsFor] = { ...char, assets: [...currentAssets, newAsset] };
              return { ...prev, characterCards: newChars };
          }
          return prev;
      });

      setIsCreatingAsset(false);
      setNewAssetForm({ name: '', desc: '', val: '', type: 'REAL_ESTATE', icon: '🏠' });
  };

  const handleDeleteAsset = (id: string) => {
      if (!window.confirm("Delete this asset permanently?")) return;
      
      setConfig(prev => {
          if (viewingAssetsFor === 'USER') {
              const currentAssets = prev.gameStats?.assets || [];
              return { ...prev, gameStats: { ...prev.gameStats!, assets: currentAssets.filter(a => a.id !== id) } };
          } else if (typeof viewingAssetsFor === 'number') {
              const newChars = [...prev.characterCards];
              const char = newChars[viewingAssetsFor];
              const currentAssets = char.assets || [];
              newChars[viewingAssetsFor] = { ...char, assets: currentAssets.filter(a => a.id !== id) };
              return { ...prev, characterCards: newChars };
          }
          return prev;
      });
  };

  // CHAR -> USER
  const handleTransferAssetToUser = (asset: HeavyAsset) => {
      if (typeof viewingAssetsFor !== 'number') return;
      const charName = config.characterCards[viewingAssetsFor].name;

      if (!window.confirm(`Request transfer of "${asset.name}" from ${charName} to User?`)) return;

      // Update state
      setConfig(prev => {
          const charIndex = viewingAssetsFor; // Should be in closure, but checking type again
          if (typeof charIndex !== 'number') return prev;

          // 1. Remove from Char
          const newChars = [...prev.characterCards];
          const char = newChars[charIndex];
          const charAssets = char.assets || [];
          newChars[charIndex] = { ...char, assets: charAssets.filter(a => a.id !== asset.id) };

          // 2. Add to User
          const userAssets = prev.gameStats?.assets || [];
          const transferredAsset = { ...asset, id: `asset-xfer-${Date.now()}` }; 
          const newGameStats = { ...prev.gameStats!, assets: [transferredAsset, ...userAssets] };

          return { ...prev, characterCards: newChars, gameStats: newGameStats };
      });

      // Roleplay Command
      onSendMessage(`[ACTION]: ${charName} signs the transfer deed for [${asset.name}] and hands it to User.`);
  };

  // USER -> CHAR
  const handleTransferAssetToChar = (targetIndex: number) => {
      if (!transferAsset) return;
      
      const targetChar = config.characterCards[targetIndex];
      const targetName = targetChar.name;

      setConfig(prev => {
           // 1. Remove from User
           const userAssets = prev.gameStats?.assets || [];
           const newGameStats = { 
               ...prev.gameStats!, 
               assets: userAssets.filter(a => a.id !== transferAsset.id) 
           };

           // 2. Add to Char
           const newChars = [...prev.characterCards];
           const char = newChars[targetIndex];
           const charAssets = char.assets || [];
           const transferredAsset = { ...transferAsset, id: `asset-xfer-${Date.now()}` };
           
           newChars[targetIndex] = { ...char, assets: [...charAssets, transferredAsset] };

           return { ...prev, gameStats: newGameStats, characterCards: newChars };
      });

      // Roleplay Command
      onSendMessage(`[ACTION]: User gifts the heavy asset [${transferAsset.name}] to ${targetName}. (Documents Transferred)`);
      
      // Cleanup
      setTransferAsset(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className={`w-full max-w-lg border rounded-xl shadow-2xl flex flex-col bg-zinc-900 border-yellow-600/50 overflow-hidden max-h-[85vh]`}>
        
        {/* HEADER */}
        <div className="p-4 border-b border-yellow-600/30 bg-yellow-900/10 flex justify-between items-center">
            <div className="flex items-center gap-2 text-yellow-500">
                <Coins size={20} />
                <h3 className="font-mono font-bold uppercase tracking-widest text-sm">Economy Control</h3>
            </div>
            <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors"><X size={18} /></button>
        </div>

        <div className="p-4 overflow-y-auto custom-scrollbar flex flex-col gap-6 relative">
            
            {/* ASSET MODAL OVERLAY */}
            {viewingAssetsFor !== null && (
                <div className="absolute inset-0 bg-zinc-900 z-20 flex flex-col animate-in slide-in-from-right-full duration-300">
                    <div className="p-4 bg-gradient-to-r from-yellow-900/20 to-black border-b border-yellow-500/20 flex justify-between items-center">
                        <div className="flex items-center gap-2 text-yellow-400">
                            <Building2 size={18} />
                            <div>
                                <h3 className="font-bold text-sm uppercase">{getTargetName()}'s Assets</h3>
                                <p className="text-[10px] text-zinc-500 font-mono">High Value Properties</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            <button onClick={() => setIsCreatingAsset(!isCreatingAsset)} className={`p-2 rounded hover:bg-yellow-500/20 transition-colors ${isCreatingAsset ? 'text-white bg-yellow-500/20' : 'text-yellow-500'}`}><Plus size={18}/></button>
                            <button onClick={() => { setViewingAssetsFor(null); setIsCreatingAsset(false); setTransferAsset(null); }} className="p-2 text-zinc-500 hover:text-white"><X size={18}/></button>
                        </div>
                    </div>

                    <div className="flex-1 overflow-y-auto p-4 custom-scrollbar relative">
                        {/* USER -> CHAR RECIPIENT SELECTOR OVERLAY */}
                        {transferAsset && (
                            <div className="absolute inset-0 bg-zinc-900/95 z-30 flex flex-col p-4 animate-in fade-in">
                                <div className="flex justify-between items-center mb-4">
                                    <h4 className="text-sm font-bold text-white uppercase flex items-center gap-2">
                                        <Gift size={16} className="text-pink-400"/> Gift {transferAsset.name} to:
                                    </h4>
                                    <button onClick={() => setTransferAsset(null)} className="text-zinc-500 hover:text-white"><X size={16}/></button>
                                </div>
                                <div className="grid grid-cols-2 gap-3 overflow-y-auto">
                                    {config.characterCards.map((char, idx) => (
                                        <button 
                                            key={idx}
                                            onClick={() => handleTransferAssetToChar(idx)}
                                            className="p-3 rounded-xl border border-white/10 bg-white/5 hover:bg-pink-900/20 hover:border-pink-500/50 transition-all flex flex-col items-center gap-2 group"
                                        >
                                            <div className="w-10 h-10 rounded-full bg-black flex items-center justify-center overflow-hidden border border-white/10 group-hover:border-pink-500">
                                                {char.avatar ? <img src={char.avatar} className="w-full h-full object-cover"/> : <User size={18} className="text-zinc-500"/>}
                                            </div>
                                            <span className="text-xs font-bold text-white truncate w-full text-center">{char.name}</span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}

                        {isCreatingAsset && (
                            <div className="mb-4 p-4 rounded-xl border border-yellow-500/30 bg-yellow-900/10 flex flex-col gap-3 animate-in fade-in">
                                <h4 className="text-xs font-bold text-yellow-500 uppercase">New Asset Registration</h4>
                                <input type="text" placeholder="Name (e.g. Royal Palace)" value={newAssetForm.name} onChange={e => setNewAssetForm({...newAssetForm, name: e.target.value})} className="bg-black/40 border border-white/10 rounded p-2 text-xs text-white outline-none focus:border-yellow-500"/>
                                <div className="flex gap-2">
                                    <select value={newAssetForm.type} onChange={e => setNewAssetForm({...newAssetForm, type: e.target.value})} className="bg-black/40 border border-white/10 rounded p-2 text-xs text-white outline-none">
                                        {ASSET_TYPES.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
                                    </select>
                                    <input type="text" placeholder="Icon (Emoji)" value={newAssetForm.icon} onChange={e => setNewAssetForm({...newAssetForm, icon: e.target.value})} className="w-16 bg-black/40 border border-white/10 rounded p-2 text-center text-xs text-white outline-none"/>
                                </div>
                                <input type="text" placeholder="Estimated Value (e.g. 50B)" value={newAssetForm.val} onChange={e => setNewAssetForm({...newAssetForm, val: e.target.value})} className="bg-black/40 border border-white/10 rounded p-2 text-xs text-white outline-none font-mono"/>
                                <textarea placeholder="Description..." value={newAssetForm.desc} onChange={e => setNewAssetForm({...newAssetForm, desc: e.target.value})} className="bg-black/40 border border-white/10 rounded p-2 text-xs text-white outline-none resize-none h-16"/>
                                <button onClick={handleCreateAsset} className="w-full py-2 bg-yellow-600 hover:bg-yellow-500 text-white font-bold text-xs uppercase rounded">Register Asset</button>
                            </div>
                        )}

                        <div className="flex flex-col gap-3">
                            {getCurrentAssets().length === 0 ? (
                                <div className="text-center text-zinc-500 text-xs italic py-10">No significant assets recorded.</div>
                            ) : (
                                getCurrentAssets().map((asset, idx) => (
                                    <div key={asset.id || idx} className="p-3 rounded-xl border border-yellow-500/20 bg-gradient-to-br from-black to-zinc-900 relative group">
                                        <div className="flex justify-between items-start">
                                            <div className="flex items-center gap-3">
                                                <div className="w-10 h-10 rounded-lg bg-yellow-900/20 border border-yellow-500/30 flex items-center justify-center text-xl shadow-inner">
                                                    {asset.icon}
                                                </div>
                                                <div>
                                                    <h4 className="font-bold text-sm text-yellow-100">{asset.name}</h4>
                                                    <span className="text-[10px] font-mono text-yellow-500/60 uppercase">{asset.type}</span>
                                                </div>
                                            </div>
                                            <div className="flex flex-col items-end">
                                                <span className="font-mono text-xs font-bold text-yellow-400">{formatVND(asset.value)}</span>
                                                
                                                {/* TRANSFER BUTTONS */}
                                                {typeof viewingAssetsFor === 'number' ? (
                                                    // Char -> User
                                                    <button 
                                                        onClick={() => handleTransferAssetToUser(asset)}
                                                        className="mt-1 px-2 py-0.5 bg-green-900/30 hover:bg-green-600 border border-green-500/50 rounded text-[9px] text-green-400 hover:text-white font-bold uppercase flex items-center gap-1 transition-all"
                                                        title="Transfer to User"
                                                    >
                                                        <Gift size={10} /> Gift User
                                                    </button>
                                                ) : (
                                                    // User -> Char
                                                    <button 
                                                        onClick={() => setTransferAsset(asset)}
                                                        className="mt-1 px-2 py-0.5 bg-pink-900/30 hover:bg-pink-600 border border-pink-500/50 rounded text-[9px] text-pink-400 hover:text-white font-bold uppercase flex items-center gap-1 transition-all"
                                                        title="Gift to Character"
                                                    >
                                                        <Gift size={10} /> Gift Char
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                        <p className="text-[10px] text-zinc-400 mt-2 line-clamp-2 pl-1 border-l-2 border-yellow-500/20">{asset.description}</p>
                                        
                                        <button 
                                            onClick={() => handleDeleteAsset(asset.id)}
                                            className="absolute top-2 right-2 p-1.5 text-zinc-600 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all bg-black/50 rounded"
                                            style={{ right: 'auto', left: '0.5rem', top: '0.5rem' }} 
                                        >
                                            <X size={12}/>
                                        </button>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            )}

            <div className="bg-black/40 border border-white/10 rounded-xl p-4">
                <div className="flex justify-between items-center mb-3">
                    <div className="flex items-center gap-2 text-green-400"><Wallet size={18} /><span className="font-bold text-sm">USER WALLET</span></div>
                    <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-lg text-white">{formatVND(userBalance)}</span>
                        {/* ASSET BUTTON FOR USER */}
                        <button 
                            onClick={() => setViewingAssetsFor('USER')}
                            className="p-1.5 bg-yellow-900/30 hover:bg-yellow-500/20 text-yellow-500 border border-yellow-500/30 rounded transition-colors"
                            title="View Heavy Assets"
                        >
                            <Building2 size={14}/>
                        </button>
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-2 mb-3">
                    <div className="flex flex-col gap-1">
                        <button onClick={() => modifyUserBalance(100000, "Small")} className="px-3 py-2 bg-green-900/30 hover:bg-green-800/50 border border-green-700/50 rounded text-green-400 text-xs font-mono flex items-center justify-between group"><span>Add Small</span> <span>+100k</span></button>
                        <button onClick={() => modifyUserBalance(5000000, "Medium")} className="px-3 py-2 bg-green-900/30 hover:bg-green-800/50 border border-green-700/50 rounded text-green-400 text-xs font-mono flex items-center justify-between group"><span>Add Med</span> <span>+5M</span></button>
                        <button onClick={() => modifyUserBalance(100000000, "Large")} className="px-3 py-2 bg-green-900/30 hover:bg-green-800/50 border border-green-700/50 rounded text-green-400 text-xs font-mono flex items-center justify-between group"><span>Add Huge</span> <span>+100M</span></button>
                    </div>
                    <div className="flex flex-col gap-1">
                        <button onClick={() => modifyUserBalance(-100000, "Small")} className="px-3 py-2 bg-red-900/30 hover:bg-red-800/50 border border-red-700/50 rounded text-red-400 text-xs font-mono flex items-center justify-between"><span>Sub Small</span> <span>-100k</span></button>
                        <button onClick={() => modifyUserBalance(-5000000, "Medium")} className="px-3 py-2 bg-red-900/30 hover:bg-red-800/50 border border-red-700/50 rounded text-red-400 text-xs font-mono flex items-center justify-between"><span>Sub Med</span> <span>-5M</span></button>
                        <button onClick={() => modifyUserBalance(-userBalance, "Reset")} className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-600 rounded text-zinc-300 text-xs font-mono flex items-center justify-center gap-2 mt-auto"><RefreshCw size={12}/> RESET TO ZERO</button>
                    </div>
                </div>
                {/* User Custom Input */}
                <div className="flex gap-2 pt-2 border-t border-white/5">
                    <div className="relative flex-1">
                        <Terminal size={12} className="absolute left-2 top-2 text-zinc-500" />
                        <input 
                            type="text" 
                            value={userCustomInput}
                            onChange={(e) => setUserCustomInput(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleUserCustomApply()}
                            placeholder="Custom (e.g. -500k, 1.5b, 1e9)"
                            className="w-full bg-black/50 border border-zinc-700 rounded px-2 pl-6 py-1.5 text-xs font-mono text-white outline-none focus:border-green-500 transition-colors"
                        />
                    </div>
                    <button 
                        onClick={handleUserCustomApply}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold font-mono rounded shadow-lg active:scale-95 transition-all"
                    >
                        EXEC
                    </button>
                </div>
            </div>
            <div className="flex flex-col gap-3">
                <h4 className="text-xs font-mono font-bold text-zinc-500 uppercase ml-1">Characters Assets</h4>
                {config.characterCards.map((char, idx) => {
                    const cooldown = getCooldown(char.name);
                    const isLocked = cooldown > 0;
                    const stats = getStats(char.name);
                    const risk = calculateRisk(char.name);
                    return (
                        <div key={idx} className="bg-black/40 border border-white/10 rounded-xl p-3 flex flex-col gap-2 relative overflow-hidden group">
                            <div className="flex justify-between items-center">
                                <div className="flex items-center gap-2"><CreditCard size={16} className="text-purple-400"/><span className="font-bold text-sm text-zinc-200">{char.name}</span></div>
                                <div className="flex flex-col items-end">
                                    <div className="flex items-center gap-2">
                                        <span className="font-mono text-sm text-yellow-500">{char.phone?.bankBalance || "0 Ⓠ"}</span>
                                        {/* ASSET BUTTON FOR CHAR */}
                                        <button 
                                            onClick={() => setViewingAssetsFor(idx)}
                                            className="p-1 bg-yellow-900/30 hover:bg-yellow-500/20 text-yellow-500 border border-yellow-500/30 rounded transition-colors"
                                            title="View Assets"
                                        >
                                            <Building2 size={12}/>
                                        </button>
                                    </div>
                                    <span className={`text-[8px] font-mono font-bold uppercase ${risk > 0.5 ? 'text-red-500' : 'text-zinc-500'}`}>Risk: {Math.round(risk * 100)}%</span>
                                </div>
                            </div>
                            <div className="flex gap-2 mt-1">
                                <button onClick={() => modifyCharBalance(idx, 1000000)} className="flex-1 py-1.5 bg-green-900/20 hover:bg-green-900/40 border border-green-800/50 rounded text-green-500 text-[10px] font-mono font-bold flex items-center justify-center gap-1"><Plus size={10}/> 1M</button>
                                <button onClick={() => modifyCharBalance(idx, 50000000)} className="flex-1 py-1.5 bg-green-900/20 hover:bg-green-900/40 border border-green-800/50 rounded text-green-500 text-[10px] font-mono font-bold flex items-center justify-center gap-1"><Plus size={10}/> 50M</button>
                                <button onClick={() => modifyCharBalance(idx, -1000000)} className="px-3 py-1.5 bg-red-900/20 hover:bg-red-900/40 border border-red-800/50 rounded text-red-500 text-[10px] font-mono font-bold"><Minus size={10}/></button>
                                <button onClick={() => robCharacter(idx)} disabled={isLocked} className={`px-3 py-1.5 rounded text-[10px] font-mono font-bold flex flex-col items-center gap-0.5 transition-all min-w-[60px]
                                        ${isLocked ? 'bg-zinc-800 border-zinc-700 text-zinc-500 cursor-not-allowed' : risk > 0.5 ? 'bg-red-900/20 hover:bg-red-900/40 border border-red-800/50 text-red-500' : 'bg-orange-900/20 hover:bg-orange-900/40 border border-orange-800/50 text-orange-500'}
                                    `}>
                                    <div className="flex items-center gap-1">{isLocked ? <Clock size={10}/> : <Hand size={10}/>}{isLocked ? formatTime(cooldown) : 'ROB'}</div>
                                </button>
                            </div>
                            
                            {/* Char Custom Input */}
                            <div className="flex gap-2 mt-1">
                                <input 
                                    type="text" 
                                    value={charCustomInputs[idx] || ''}
                                    onChange={(e) => setCharCustomInputs(prev => ({...prev, [idx]: e.target.value}))}
                                    onKeyDown={(e) => e.key === 'Enter' && handleCharCustomApply(idx)}
                                    placeholder="Custom (+/-)"
                                    className="flex-1 bg-black/50 border border-zinc-700 rounded px-2 py-1.5 text-[10px] font-mono text-white outline-none focus:border-purple-500 transition-colors"
                                />
                                <button 
                                    onClick={() => handleCharCustomApply(idx)}
                                    className="px-2 py-1.5 bg-blue-900/30 hover:bg-blue-800/50 border border-blue-700/50 text-blue-300 text-[10px] font-bold font-mono rounded transition-all"
                                >
                                    EXEC
                                </button>
                            </div>

                            {stats.attempts > 0 && <div className="text-[8px] font-mono text-zinc-600 flex justify-between px-1 mt-1"><span>Success: {stats.attempts}x</span><span>Penalties: {stats.penalties}x</span></div>}
                        </div>
                    );
                })}
            </div>
        </div>
      </div>
    </div>
  );
};

export default EconomyModal;
