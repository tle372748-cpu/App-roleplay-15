
// FILE DEPRECATED - MERGED INTO ADVANCED SETTINGS
import React from 'react';
export default () => null;
