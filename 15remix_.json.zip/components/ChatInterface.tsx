
import React, { useState, useEffect, useRef, useLayoutEffect, useMemo, useCallback } from 'react';
import { Send, Terminal, Eraser, Mic, Smartphone, Book, Eye, X, User, Users, MapPin, Cpu, Settings, Settings2, Download, Upload, Store, Check, Briefcase, Image, Wine, Award, Copy, Edit2, Trash2, RefreshCw, RotateCcw, Maximize, MessageSquare, Sparkles, FileText, Smile, Sticker, Video, HelpCircle, LayoutGrid, Backpack, Activity, Heart, Swords, CloudRain, FastForward, Dices, Shirt, Spade, Asterisk, Sparkle, ZapOff, Circle, Lightbulb, Loader2, AlertCircle, BarChart3, Flame, PowerOff, Palette, Gift, ShoppingCart, Package, Coins, BadgeDollarSign, CheckCircle, EyeOff, Bold, Italic, Code as CodeIcon, Monitor, TrendingUp, Brain, Trophy, BookOpen, Ticket, FileX, Globe, Ghost, ChevronDown, ChevronRight, CreditCard, Wand2, MonitorPlay, Grid, Fish, Utensils, Volume2, Zap, Clock, GitCommit, Map, HardDrive, Anchor, ChefHat, Ruler, AlignLeft, BatteryLow, MessageCircle, Undo2, ChevronLeft, ThumbsUp, ThumbsDown, Keyboard, Thermometer, Mic2, Disc, Gavel, Moon, FileSignature, Sun, Home, Layers, Scissors } from 'lucide-react';
import { ChatMessage, Kernel, AppConfig, Theme, GameStats, InventoryItem, ShopItem, CardData, CharacterSkillProfile, NarrativeLength, SaveSlotData } from '../types';
import { THEMES, EMOJI_LIST, STICKER_COLLECTIONS } from '../constants';
import AdvancedSettingsModal from './AdvancedSettingsModal';
import GardenMiniGame from './GardenMiniGame';
import FlipCard from './FlipCard';
import BegCard from './BegCard';
import ShopModal from './ShopModal';
import InventoryModal from './InventoryModal';
import BankModal from './BankModal';
import EconomyModal from './EconomyModal';
import WhatIfModal from './WhatIfModal';
import NodeBoardModal from './NodeBoardModal';
import SaveSlotsModal from './SaveSlotsModal';
import AchievementModal from './AchievementModal';
import MerchantModal from './MerchantModal';
import SmartPhone from './SmartPhone';
import CharacterConfigModal from './CharacterConfigModal'; 
import MindConfigModal from './MindConfigModal'; 
import DiaryModal from './DiaryModal';
import RerunFeedbackModal from './RerunFeedbackModal'; 
import VectorMemoryModal from './VectorMemoryModal'; 
import DirectorModeModal from './DirectorModeModal';
import { generatePhoneDisplay, generateHelpDisplay, generatePartialPhoneDisplay, generateBankDisplay, parseBalance, formatVND } from '../utils/mockDataGenerator';
import { generateShopItems, parseTextForTTS, playTTS, cleanThinking } from '../services/aiService';
import { ThemeStoreModal } from './ConfigPanel';

// ... (Existing Interfaces and Helpers) ...
interface ChatInterfaceProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  onSendSticker: (url: string) => void; 
  onReset: () => void;
  onResetChat: () => void;
  onClearChatLog: () => void;
  kernel: Kernel;
  onOpenSettings: () => void;
  config: AppConfig; 
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  onImportData: (file: File, type: 'FULL' | 'RESOURCE' | 'CHAT_CONFIG' | 'BOARD_DATA') => void;
  onExportData: (type: 'FULL' | 'RESOURCE' | 'CHAT_CONFIG' | 'BOARD_DATA') => void;
  onDeleteMessage: (id: string) => void;
  onDeleteFromHere: (id: string) => void;
  onEditMessage: (id: string, newContent: string) => void;
  onRerunMessage: (id: string, role: string, content: string, instruction?: string) => void; 
  onFastReload: () => void;
  isTyping: boolean;
  setIsTyping: (isTyping: boolean) => void;
  setMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
  onVersionChange?: (id: string, direction: 'PREV' | 'NEXT') => void;
  onFeedback?: (id: string, type: 'LIKE' | 'DISLIKE') => void;
  regeneratingId?: string | null; 
  onSystemSync: () => void;
}

// ... hexToRgba, HeaderMetaButton, ASCIIPopup, AttachedFileCard, MessageRenderer ...
const hexToRgba = (hex: string, alpha: number) => {
    if (!hex) return undefined;
    const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
    hex = hex.replace(shorthandRegex, (m, r, g, b) => r + r + g + g + b + b);
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? `rgba(${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}, ${alpha})` : hex;
};

const HeaderMetaButton: React.FC<{ icon: React.ReactNode; label: string; themeColors: any; onClick: () => void }> = ({ icon, label, themeColors, onClick }) => (
    <button 
        onClick={onClick} 
        className={`flex items-center gap-1.5 px-2 py-1.5 md:px-3 md:py-1.5 rounded-lg border transition-all hover:bg-white/5 active:scale-95 group ${themeColors.border}`}
    >
        <div className={`text-zinc-400 group-hover:${themeColors.textMain} transition-colors [&>svg]:w-4 [&>svg]:h-4 md:[&>svg]:w-5 md:[&>svg]:h-5`}>{icon}</div>
        <span className="hidden md:block text-[10px] font-bold font-mono tracking-wide uppercase opacity-70 group-hover:opacity-100">{label}</span>
    </button>
);

const ASCIIPopup: React.FC<{ title: string; content: string; color: string; onClose: () => void; themeColors: any }> = ({ title, content, color, onClose, themeColors }) => (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
        <div className={`relative max-w-2xl w-full p-4 rounded-xl border shadow-2xl ${themeColors.bgPanel} ${themeColors.border}`}>
            <div className={`flex justify-between items-center mb-2 pb-2 border-b ${themeColors.border}`}>
                <h3 className={`font-mono font-bold text-${color}-400 uppercase tracking-widest`}>{title}</h3>
                <button onClick={onClose} className={`${themeColors.textDim} hover:${themeColors.textMain}`}><X size={18}/></button>
            </div>
            <pre className={`font-mono text-[10px] md:text-xs leading-tight whitespace-pre-wrap overflow-auto max-h-[70vh] p-4 rounded bg-black/50 border border-white/5 text-${color}-300 shadow-inner`}>
                {content}
            </pre>
        </div>
    </div>
);

const AttachedFileCard: React.FC<{ data: any, themeColors: any, onClick?: () => void }> = ({ data, themeColors, onClick }) => {
    const Component = onClick ? 'button' : 'div';
    const interactionClasses = onClick ? 'hover:bg-white/5 cursor-pointer' : '';
    return (
        <Component onClick={onClick} className={`flex items-center gap-2 p-2 rounded border bg-black/20 ${themeColors.border} max-w-full overflow-hidden transition-colors group text-left ${interactionClasses}`}>
            <div className={`p-1.5 rounded text-yellow-400 ${onClick ? 'group-hover:scale-110' : ''} transition-transform ${data.type === 'IDENTITY' ? 'bg-blue-500/20 text-blue-400' : 'bg-white/5'}`}>{data.type === 'IDENTITY' ? <User size={16} /> : <FileText size={16} />}</div>
            <div className="flex flex-col min-w-0"><span className="text-[10px] font-bold font-mono truncate">{data.name}</span><span className="text-[9px] opacity-60 truncate">{data.type} FILE</span></div>
        </Component>
    );
};

const MessageRenderer: React.FC<{ content: string, role: string, themeColors: any, states: any, isSilenced?: boolean, isRefused?: boolean, silenceThreshold?: number, isNoLeds: boolean, textColor?: string }> = ({ content, role, themeColors, states, isSilenced, isRefused, silenceThreshold, isNoLeds, textColor }) => {
    const formatText = (text: string) => {
        let html = text
            .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/^### (.*$)/gim, '<h3 class="font-bold text-sm uppercase tracking-wider border-b border-current pb-1 mb-1 mt-2">$1</h3>')
            .replace(/^## (.*$)/gim, '<h2 class="font-bold text-base border-b border-current pb-1 mb-2 mt-3">$1</h2>')
            .replace(/^# (.*$)/gim, '<h1 class="font-bold text-lg border-b border-current pb-2 mb-2 mt-4">$1</h1>')
            .replace(/"([^"]+)"/g, '<span class="font-bold">"$1"</span>')
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold">$1</strong>')
            .replace(/\*([^\*]+)\*/g, '<em class="italic">$1</em>') 
            .replace(/`([^`]+)`/g, '<code class="bg-black/30 px-1.5 py-0.5 rounded font-mono text-[0.9em] border border-white/10">$1</code>');
        return { __html: html };
    };
    return (<div className={`whitespace-pre-wrap text-left`} style={{ color: textColor }} dangerouslySetInnerHTML={formatText(content)} />);
};

// ... ChatInputBar ...
const ChatInputBar = React.memo(({
    onSendMessage,
    onSendSticker,
    attachedAction,
    setAttachedAction,
    config,
    setConfig,
    isTyping,
    themeColors,
    isDiceEnabled,
    rollDice,
    isFocusMode,
    setIsFocusMode,
    isScenarioStarted,
    isNoLeds,
    isLowPerf,
    messages,
    onOpenDirectorMode
}: any) => {
    const [inputText, setInputText] = useState('');
    const isDirectorMode = config.directorPreferences?.enabled || false;
    const [showStickerMenu, setShowStickerMenu] = useState(false);
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const stickerInputRef = useRef<HTMLInputElement>(null);
    const videoInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            const scrollHeight = textareaRef.current.scrollHeight;
            textareaRef.current.style.height = `${Math.max(120, Math.min(scrollHeight, 200))}px`;
        }
    }, [inputText]);

    const isMessengerMode = config.messengerConfig?.enabled || false;
    const isMessengerPending = isMessengerMode && !isTyping && messages.length > 0 && messages[messages.length - 1].role === 'user' && !inputText.trim();

    const insertFormat = (fmt: string) => {
        if (textareaRef.current) {
            const start = textareaRef.current.selectionStart;
            const end = textareaRef.current.selectionEnd;
            const text = inputText;
            const newText = text.substring(0, start) + fmt + text.substring(start, end) + fmt + text.substring(end);
            setInputText(newText);
        }
    };

    const handleSend = () => {
        if (isMessengerPending) { onSendMessage("/trigger_messenger"); return; }
        if (!inputText.trim() && !attachedAction) { if (!isMessengerMode) setInputText("..."); else return; }
        let finalMsg = inputText;
        if (attachedAction) {
             if (attachedAction.type === 'EAT') {
                finalMsg += `\n[ACTION]: User eats ${attachedAction.items.map((i: any) => i.name).join(', ')}.`;
                setConfig((prev: any) => {
                    const newInv = [...(prev.inventory || [])];
                    attachedAction.items.forEach((item: any) => {
                        const idx = newInv.findIndex(i => i.id === item.id);
                        if (idx > -1) { if (newInv[idx].quantity > 1) newInv[idx].quantity--; else newInv.splice(idx, 1); }
                    });
                    return { ...prev, inventory: newInv };
                });
            } else if (attachedAction.type === 'GIFT') {
                const itemDetails = attachedAction.items.map((i: any) => `[${i.name}] (Type: ${i.type || 'Item'}, Value: ${formatVND(i.price)}, Desc: "${i.description || 'Unknown'}")`).join(', ');
                const front = `Sending to ${attachedAction.targetName || 'Someone'}...`;
                const cleanBack = attachedAction.items.map((i: any) => i.name).join(', ').replace(/[|>]/g, '');
                finalMsg += `\n<<<FLIP_CARD:${front}|${cleanBack}|GIFT>>>`;
                finalMsg += `\n[ACTION]: User gifts the following items to ${attachedAction.targetName}:\n${itemDetails}.\nContext: ${attachedAction.message || "A gift for you."}`;
                setConfig((prev: any) => ({ ...prev, inventory: prev.inventory?.filter((i: any) => !attachedAction.items.find((ai: any) => ai.id === i.id)) }));
            } else {
                const itemNames = attachedAction.items.map((i: any) => i.name).join(', ');
                finalMsg += `\n[ACTION]: User uses ${itemNames}`;
                setConfig((prev: any) => ({ ...prev, inventory: prev.inventory?.filter((i: any) => !attachedAction.items.find((ai: any) => ai.id === i.id)) }));
            }
            setAttachedAction(null);
        }
        onSendMessage(finalMsg);
        setInputText('');
    };

    const handleUploadSticker = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => {
            const base64 = ev.target?.result as string;
            if (base64) {
                setConfig((prev: any) => ({ ...prev, stickers: [...(prev.stickers || []), { id: `stk-${Date.now()}`, url: base64 }] }));
            }
        };
        reader.readAsDataURL(file);
        e.target.value = '';
    };

    const handleUploadVideo = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        
        if (file.size > 25 * 1024 * 1024) {
            alert("Video quá lớn! Vui lòng chọn file dưới 25MB để tránh lag trình duyệt.");
            return;
        }

        const reader = new FileReader();
        reader.onload = (ev) => {
            const base64 = ev.target?.result as string;
            if (base64) {
                // Send immediately as a sticker message
                onSendSticker(base64);
            }
        };
        reader.readAsDataURL(file);
        e.target.value = '';
    };

    const handleSendSticker = (url: string) => { onSendSticker(url); setShowStickerMenu(false); };
    
    const inputStyle = { 
        fontFamily: config.fontFamily,
        color: config.userTextColor 
    };
    
    const blurClass = isLowPerf ? '' : 'backdrop-blur-md bg-opacity-80';
    const inputBgClass = config.customBackground ? 'bg-black/30 border-t border-white/5' : `${themeColors.bgMain} ${themeColors.border}`;
    let sendButtonClass = `p-2.5 rounded-xl transition-all flex items-center justify-center ${config.customBackground ? 'bg-black/20' : themeColors.bgPanel} border ${themeColors.border} ${themeColors.textDim}`;
    let sendIcon = <Sparkles size={18} className="opacity-50" />;
    if (isTyping) { sendButtonClass += ' opacity-50 cursor-not-allowed'; sendIcon = <Loader2 size={18} className="animate-spin" />; }
    else if (isMessengerPending) { sendButtonClass = `p-2.5 rounded-xl transition-all flex items-center justify-center bg-blue-600 text-white shadow-[0_0_15px_#2563eb] animate-pulse`; sendIcon = <div className="flex items-center gap-1"><MessageCircle size={18} className="fill-current"/> <span className="text-[10px] font-bold">SEND</span></div>; }
    else if (inputText.trim() || attachedAction) { sendButtonClass = `p-2.5 rounded-xl transition-all flex items-center justify-center ${isDirectorMode ? `bg-yellow-600 text-white ${!isNoLeds ? 'shadow-[0_0_15px_#eab308]' : ''}` : `bg-nano-600 text-white ${!isNoLeds ? 'shadow-[0_0_15px_#0ea5e9]' : ''}`}`; sendIcon = <Send size={18} />; }

    return (
        <div className={`border-t shrink-0 relative z-20 pb-safe ${inputBgClass} ${blurClass}`}>
            {showStickerMenu && (
                <div className={`absolute bottom-full left-0 mb-2 ml-4 p-3 rounded-xl border shadow-xl flex flex-col gap-2 w-64 max-h-60 overflow-hidden animate-in slide-in-from-bottom-2 ${themeColors.bgPanel} ${themeColors.border}`}>
                    <div className="flex justify-between items-center pb-2 border-b border-white/10">
                        <span className="text-[10px] font-bold uppercase text-white/50">Sticker Library</span>
                        <button onClick={() => setShowStickerMenu(false)} className="hover:text-white text-zinc-500"><X size={14}/></button>
                    </div>
                    <div className="flex-1 overflow-y-auto grid grid-cols-3 gap-2 custom-scrollbar">
                        <button onClick={() => stickerInputRef.current?.click()} className="aspect-square border border-dashed border-white/20 rounded-lg flex flex-col items-center justify-center gap-1 hover:bg-white/5 transition-colors text-white/50 hover:text-white"><Upload size={16} /><span className="text-[8px] uppercase font-bold">Upload IMG</span></button>
                        {(config.stickers || []).map((s: any) => ( <button key={s.id} onClick={() => handleSendSticker(s.url)} className="aspect-square rounded-lg overflow-hidden border border-white/10 hover:border-white/50 transition-all active:scale-95 bg-black/20"><img src={s.url} className="w-full h-full object-cover" /></button> ))}
                    </div>
                    <input type="file" ref={stickerInputRef} className="hidden" accept="image/*" onChange={handleUploadSticker} />
                </div>
            )}
            {attachedAction && (
                <div className="px-4 py-2 bg-gradient-to-r from-pink-900/40 to-black border-b border-pink-500/30 flex justify-between items-center animate-in slide-in-from-bottom-2">
                    <div className="flex items-center gap-3 text-xs">
                        <div className="p-1.5 rounded-lg bg-pink-500/20 text-pink-400 border border-pink-500/30 animate-pulse">{attachedAction.type === 'GIFT' ? <Gift size={16} /> : attachedAction.type === 'EAT' ? <Utensils size={16}/> : <Sparkles size={16} />}</div>
                        <div className="flex flex-col"><span className="font-bold text-pink-200 uppercase tracking-wide text-[10px]">{attachedAction.type === 'GIFT' ? 'PENDING GIFT' : 'USING ITEM'}</span><span className="font-mono text-white/80">{attachedAction.items.length > 1 ? `${attachedAction.items.length} Items` : attachedAction.items[0].name} {attachedAction.targetName && <span className="text-zinc-400"> ➔ {attachedAction.targetName}</span>}</span></div>
                    </div>
                    <button onClick={() => setAttachedAction(null)} className="p-1.5 hover:bg-white/10 rounded-full text-zinc-400 hover:text-white transition-colors"><X size={14}/></button>
                </div>
            )}
            <div className="flex items-center gap-1 px-4 py-1.5 border-b border-white/5 bg-black/10">
                <button onClick={() => insertFormat('**')} className={`p-1.5 rounded ${themeColors.textDim}`}><Bold size={14}/></button>
                <button onClick={() => insertFormat('*')} className={`p-1.5 rounded ${themeColors.textDim}`}><Italic size={14}/></button>
                <button onClick={() => insertFormat('`')} className={`p-1.5 rounded ${themeColors.textDim}`}><CodeIcon size={14}/></button>
                <div className="w-px h-4 bg-white/10 mx-1"></div>
                <button onClick={onOpenDirectorMode} className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${isDirectorMode ? `bg-yellow-500/20 text-yellow-400 border-yellow-500/50 ${!isNoLeds ? 'shadow-[0_0_10px_rgba(234,179,8,0.2)]' : ''}` : themeColors.textDim}`}>{isDirectorMode ? <Monitor size={12}/> : <MessageSquare size={12}/>} Director</button>
                {!isScenarioStarted && <button onClick={() => onSendMessage('/scenario start')} className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono border border-purple-500/50 bg-purple-500/20 text-purple-300 hover:bg-purple-600 hover:text-white transition-all ${!isNoLeds ? 'shadow-[0_0_12px_rgba(168,85,247,0.3)] animate-pulse' : ''}`} title="Start Scenario"><Asterisk size={12} /> Start Scenario</button>}
                <div className="flex-1"></div>
                {isMessengerMode && <div className="flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono bg-blue-900/30 text-blue-400 border border-blue-500/30"><MessageCircle size={10} className="fill-current"/> Messenger Mode</div>}
                <button onClick={() => setIsFocusMode(!isFocusMode)} className={`p-1.5 rounded ${isFocusMode ? themeColors.textMain : themeColors.textDim}`} title="Toggle Focus Mode"><Maximize size={14}/></button>
            </div>
            <div className="p-3 md:p-4">
              <div className="text-center text-[9px] text-zinc-500/40 font-mono mb-1 select-none pointer-events-none">
                 I wontt read your chat, trust - Quasar
              </div>
              <div className={`max-w-5xl mx-auto flex items-end gap-3 p-3 rounded-2xl border-2 transition-all duration-300 ${config.customBackground ? 'bg-black/20 border-white/5 backdrop-blur-md' : themeColors.bgPanel}`}>
                {isDiceEnabled ? <button onClick={rollDice} disabled={isTyping} className={`p-2.5 rounded-xl hover:bg-white/5 transition-all ${themeColors.textDim} hover:${themeColors.textMain} ${isTyping ? 'opacity-50 cursor-not-allowed' : ''}`} title="Roll Dice (D20)"><Dices size={18} /></button> : <button className={`p-2.5 hidden md:flex rounded-xl ${themeColors.textDim}`}><Cpu size={18} /></button>}
                <textarea 
                    ref={textareaRef} 
                    value={inputText} 
                    onChange={(e) => setInputText(e.target.value)} 
                    onKeyDown={(e) => { if(e.key === 'Enter' && e.ctrlKey && !isTyping) handleSend(); }} 
                    disabled={isTyping} 
                    placeholder={isTyping ? "AI is replying..." : (isDirectorMode ? "Enter director/OOC instructions..." : (isMessengerMode ? "Message..." : "Write your narrative action..."))} 
                    className={`flex-1 bg-transparent border-none outline-none text-sm md:text-base font-medium resize-none py-3 px-2 leading-relaxed min-h-[120px] max-h-[200px] overflow-y-auto ${config.userTextColor ? '' : themeColors.textMain} placeholder:${themeColors.textDim} ${isTyping ? 'opacity-50 cursor-not-allowed' : ''}`} 
                    style={inputStyle} 
                />
                <button onClick={() => videoInputRef.current?.click()} disabled={isTyping} className={`p-2.5 rounded-xl transition-all ${config.customBackground ? 'bg-black/20' : themeColors.bgPanel} border ${themeColors.border} ${themeColors.textDim} hover:${themeColors.textMain} hover:text-red-400`} title="Upload Video Sticker"><Video size={18} /></button>
                <input type="file" ref={videoInputRef} className="hidden" accept="video/mp4,video/webm" onChange={handleUploadVideo} />
                
                <button onClick={() => setShowStickerMenu(!showStickerMenu)} disabled={isTyping} className={`p-2.5 rounded-xl transition-all ${showStickerMenu ? 'bg-pink-600 text-white' : `${config.customBackground ? 'bg-black/20' : themeColors.bgPanel} border ${themeColors.border} ${themeColors.textDim} hover:${themeColors.textMain}`}`} title="Stickers"><Sticker size={18} /></button>
                <button onClick={handleSend} disabled={isTyping} className={sendButtonClass}>{sendIcon}</button>
              </div>
            </div>
        </div>
    );
});

// ... MessageItem ...
const MessageItem = React.memo(({
    msg,
    index,
    themeColors,
    config,
    sysStates,
    isNoLeds,
    isLowPerf,
    isFlappingEnabled,
    editingMessageId,
    editContent,
    setEditContent,
    startEditing,
    cancelEditing,
    submitEdit,
    onRerunMessage,
    onDeleteMessage,
    onDeleteFromHere,
    handleViewCard,
    handleBuyBegItem,
    onUnsend,
    onVersionChange,
    onFeedback,
    regeneratingId
}: any) => {
    const isRegenerating = regeneratingId === msg.id;
    const [isPlayingAudio, setIsPlayingAudio] = useState(false);
    
    const handleTTS = async () => {
        setIsPlayingAudio(true);
        try {
            const script = await parseTextForTTS(config, msg.content);
            await playTTS(config, script);
        } catch (e) {
            console.error("TTS Error", e);
        } finally {
            setIsPlayingAudio(false);
        }
    };

    const flipCardMatch = msg.content.match(/<<<FLIP_CARD:(.+?)\|(.+?)\|(.+?)>>>/);
    const flipCardData = flipCardMatch ? { front: flipCardMatch[1], back: flipCardMatch[2], type: flipCardMatch[3] } : null;
    const begCardMatch = msg.content.match(/<<<BEG_CARD:(.+?)\|(.+?)\|(.+?)>>>/);
    const begCardData = begCardMatch ? { name: begCardMatch[1], price: parseInt(begCardMatch[2]), icon: begCardMatch[3] } : null;
    let displayContent = msg.content
        .replace(/<thought>[\s\S]*?<\/thought>/gi, '')
        .replace(/<<<FLIP_CARD:(.+?)\|(.+?)\|(.+?)>>>/g, '')
        .replace(/<<<BEG_CARD:(.+?)\|(.+?)\|(.+?)>>>/g, '')
        .replace(/<<<GIFT_REFUSED:(.+?)>>>/g, '')
        .trim();
    const defaultUserStyle = `${themeColors.msgUser} rounded-tr-none`;
    const defaultBotStyle = `bg-zinc-950 border-2 border-yellow-500/40 text-yellow-500 font-mono text-[11px] md:text-xs leading-tight`; 
    const defaultAssistantStyle = `${themeColors.msgBot} rounded-tl-none`;
    let bubbleClass = "";
    let customStyle: any = {};
    const userOpacity = config.userBubbleOpacity ?? 0.9;
    const charOpacity = config.charBubbleOpacity ?? 0.9;
    if (msg.role === 'user') {
        if (config.userBubbleTheme) { bubbleClass = config.userBubbleTheme + " rounded-tr-none"; customStyle = { ...customStyle, '--tw-bg-opacity': userOpacity }; } 
        else if (config.userBubbleColor) { bubbleClass = "text-white rounded-tr-none"; customStyle = { ...customStyle, backgroundColor: hexToRgba(config.userBubbleColor, userOpacity) }; } 
        else { bubbleClass = defaultUserStyle; customStyle = { ...customStyle, '--tw-bg-opacity': userOpacity }; }
    } else if (msg.role === 'assistant') {
        if (config.charBubbleTheme) { bubbleClass = config.charBubbleTheme + " rounded-tl-none"; customStyle = { ...customStyle, '--tw-bg-opacity': charOpacity }; } 
        else if (config.charBubbleColor) { bubbleClass = "text-white rounded-tl-none"; customStyle = { ...customStyle, backgroundColor: hexToRgba(config.charBubbleColor, charOpacity) }; } 
        else { bubbleClass = defaultAssistantStyle; customStyle = { ...customStyle, '--tw-bg-opacity': charOpacity }; }
    } else { bubbleClass = defaultBotStyle; }
    if (msg.role === 'user' && config.userTextColor) customStyle = { ...customStyle, color: config.userTextColor };
    if (msg.role === 'assistant' && config.charTextColor) customStyle = { ...customStyle, color: config.charTextColor };
    
    let forcedTextColor = undefined;
    if (msg.role === 'user' && config.userTextColor) forcedTextColor = config.userTextColor;
    if (msg.role === 'assistant' && config.charTextColor) forcedTextColor = config.charTextColor;

    const isSystem = msg.role === 'nano_quasar' || msg.role === 'system';
    const isEditing = editingMessageId === msg.id;
    const bubbleWrapperClass = config.customBackground ? 'backdrop-blur-sm' : '';

    // Video Detection Logic
    const isVideoSticker = msg.sticker && (msg.sticker.url.startsWith('data:video') || msg.sticker.url.includes('.mp4') || msg.sticker.url.includes('.webm'));

    return (
        <div className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'} ${isLowPerf ? '' : 'animate-in fade-in slide-in-from-bottom-2 duration-300'} group relative mb-2`}>
            <div className={`relative max-w-[95%] md:max-w-[85%] p-3 md:p-4 rounded-2xl shadow-sm ${bubbleClass} ${bubbleWrapperClass} ${!isNoLeds && !isLowPerf && msg.role !== 'nano_quasar' ? 'shadow-md' : ''}`} style={customStyle}>
                {(!isEditing && !isRegenerating && (msg.role !== 'system')) && (
                    <div className={`absolute -top-10 ${msg.role === 'user' ? 'right-0' : 'left-0'} opacity-0 group-hover:opacity-100 transition-all duration-200 flex items-center gap-2 bg-zinc-900 border border-zinc-700/80 rounded-full px-3 py-1.5 shadow-xl z-20 ${isLowPerf ? '' : 'backdrop-blur-md'}`}>
                        <button onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(msg.content); }} className="p-1 hover:text-white text-zinc-400 transition-colors" title="Copy"><Copy size={14}/></button>
                        <button onClick={(e) => { e.stopPropagation(); startEditing(msg); }} className="p-1 hover:text-blue-400 text-zinc-400 transition-colors" title="Edit"><Edit2 size={14}/></button>
                        
                        {(msg.role === 'assistant' || msg.role === 'user') && (
                            <button onClick={(e) => { e.stopPropagation(); handleTTS(); }} disabled={isPlayingAudio} className={`p-1 hover:text-pink-400 transition-colors ${isPlayingAudio ? 'text-pink-400 animate-pulse' : 'text-zinc-400'}`} title="Play Audio">
                                {isPlayingAudio ? <Loader2 size={14} className="animate-spin" /> : <Volume2 size={14}/>}
                            </button>
                        )}

                        {msg.role === 'assistant' && ( <> <button onClick={(e) => { e.stopPropagation(); onRerunMessage(msg.id, msg.role, msg.content); }} className="p-1 hover:text-green-400 text-zinc-400 transition-colors" title="Regenerate"><RotateCcw size={14}/></button> <div className="h-4 w-px bg-white/10 mx-1"></div> <button onClick={(e) => { e.stopPropagation(); onFeedback && onFeedback(msg.id, 'LIKE'); }} className={`p-1 hover:text-yellow-400 transition-colors ${msg.feedback === 'LIKE' ? 'text-yellow-400' : 'text-zinc-400'}`} title="Good"><ThumbsUp size={14}/></button> <button onClick={(e) => { e.stopPropagation(); onFeedback && onFeedback(msg.id, 'DISLIKE'); }} className={`p-1 hover:text-red-400 transition-colors ${msg.feedback === 'DISLIKE' ? 'text-red-400' : 'text-zinc-400'}`} title="Bad"><ThumbsDown size={14}/></button> </> )}
                        {config.messengerConfig?.enabled && msg.role === 'user' && ( <button onClick={(e) => { e.stopPropagation(); onUnsend(msg.id); }} className="p-1 hover:text-zinc-300 text-zinc-500 transition-colors" title="Thu hồi tin nhắn"><Undo2 size={14}/></button> )}
                        <button onClick={(e) => { e.stopPropagation(); onDeleteFromHere(msg.id); }} className="p-1 hover:text-orange-400 text-zinc-400 transition-colors" title="Rewind (Delete from here down)"><Scissors size={14}/></button>
                        <button onClick={(e) => { e.stopPropagation(); onDeleteMessage(msg.id); }} className="p-1 hover:text-red-400 text-zinc-400 transition-colors" title="Delete"><Trash2 size={14}/></button>
                    </div>
                )}
                {isRegenerating ? ( <div className="flex items-center gap-2 py-4 px-2 opacity-70"><Loader2 size={16} className="animate-spin text-white/50" /><span className="text-xs font-mono animate-pulse">Đang viết lại...</span></div> ) : isEditing ? ( <div className="flex flex-col gap-2 min-w-[300px]"><textarea value={editContent} onChange={(e) => setEditContent(e.target.value)} className="w-full bg-black/20 text-white p-2 rounded text-sm outline-none border border-white/20 resize-none h-24" /><div className="flex justify-end gap-2"><button onClick={cancelEditing} className="text-xs px-3 py-1 rounded bg-white/10 hover:bg-white/20">Cancel</button><button onClick={submitEdit} className="text-xs px-3 py-1 rounded bg-green-600 hover:bg-green-500 text-white font-bold">Save</button></div></div> ) : ( 
                    <> 
                        {msg.sticker && (
                            isVideoSticker ? (
                                <div className="mb-2 rounded-xl overflow-hidden border border-white/10 bg-black max-w-sm">
                                    <video 
                                        src={msg.sticker.url} 
                                        controls 
                                        className="w-full h-auto max-h-[300px] object-contain"
                                        playsInline
                                    />
                                </div>
                            ) : (
                                <div className="mb-2"><img src={msg.sticker.url} alt="Sticker" className="w-24 h-24 object-contain rounded-lg" /></div>
                            )
                        )} 
                        {msg.metadata?.attachedCards && ( <div className="flex flex-wrap gap-2 mb-3">{msg.metadata.attachedCards.map((card: any, i: number) => ( <AttachedFileCard key={i} data={card} themeColors={themeColors} onClick={() => handleViewCard(card)} /> ))}</div> )} 
                        {msg.role === 'nano_quasar' && <Terminal className="w-3 h-3 mb-1 inline-block mr-2 opacity-70" />} 
                        <MessageRenderer content={displayContent} role={msg.role} themeColors={themeColors} states={sysStates} isNoLeds={isNoLeds || isLowPerf} textColor={forcedTextColor} /> 
                        {msg.versions && msg.versions.length > 1 && ( <div className="mt-2 pt-2 border-t border-white/10 flex items-center gap-2 text-[10px] font-mono opacity-70"><button onClick={() => onVersionChange && onVersionChange(msg.id, 'PREV')} disabled={msg.currentVersionIndex === 0} className="p-1 hover:bg-white/10 rounded disabled:opacity-30"><ChevronLeft size={12}/></button><span>{msg.currentVersionIndex + 1}/{msg.versions.length}</span><button onClick={() => onVersionChange && onVersionChange(msg.id, 'NEXT')} disabled={msg.currentVersionIndex === msg.versions.length - 1} className="p-1 hover:bg-white/10 rounded disabled:opacity-30"><ChevronRight size={12}/></button></div> )} 
                        {flipCardData && <div className="mt-4"><FlipCard frontText={flipCardData.front} backText={flipCardData.back} type={flipCardData.type} themeColors={themeColors} customStyle={config.flipCardStyle} customColors={config.flipCardColors} /></div>} 
                        {begCardData && <div className="mt-4"><BegCard itemName={begCardData.name} price={begCardData.price} icon={begCardData.icon} onBuy={() => handleBuyBegItem(begCardData.name, begCardData.price)} canAfford={(config.gameStats?.gold || 0) >= begCardData.price} themeColors={themeColors} /></div>} 
                    </> 
                )}
            </div>
            {!isSystem && <span className={`text-[10px] mt-1 px-1 opacity-40 font-mono ${themeColors.textDim} ${config.customBackground ? 'text-white/60 shadow-black drop-shadow-md' : ''}`}>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>}
        </div>
    );
}, (prev, next) => {
    return ( prev.msg.id === next.msg.id && prev.msg.content === next.msg.content && prev.msg.currentVersionIndex === next.msg.currentVersionIndex && prev.msg.feedback === next.msg.feedback && prev.isLowPerf === next.isLowPerf && prev.editingMessageId === next.editingMessageId && (prev.editingMessageId === next.msg.id ? prev.editContent === next.editContent : true) && prev.isNoLeds === next.isNoLeds && prev.config.customBackground === next.config.customBackground && prev.config.userBubbleOpacity === next.config.userBubbleOpacity && prev.config.charBubbleOpacity === next.config.charBubbleOpacity && prev.config.userBubbleColor === next.config.userBubbleColor && prev.config.charBubbleColor === next.config.charBubbleColor && prev.config.userBubbleTheme === next.config.userBubbleTheme && prev.config.charBubbleTheme === next.config.charBubbleTheme && prev.config.userTextColor === next.config.userTextColor && prev.config.charTextColor === next.config.charTextColor && prev.config.fontFamily === next.config.fontFamily && prev.config.fontSize === next.config.fontSize && prev.config.flipCardStyle === next.config.flipCardStyle && prev.regeneratingId === next.regeneratingId && prev.themeColors === next.themeColors && prev.onDeleteMessage === next.onDeleteMessage && prev.onDeleteFromHere === next.onDeleteFromHere );
});

// ... ChatInterface ...
const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages, onSendMessage, onSendSticker, onReset, onResetChat, onClearChatLog, kernel, onOpenSettings, config, setConfig, onImportData, onExportData, onDeleteMessage, onDeleteFromHere, onEditMessage, onRerunMessage, onFastReload, isTyping, setIsTyping, setMessages, onVersionChange, onFeedback, regeneratingId, onSystemSync }) => {
  // ... (All existing hooks and logic) ...
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const topSentinelRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [visibleCount, setVisibleCount] = useState(15); 
  const [isFetchingHistory, setIsFetchingHistory] = useState(false);
  const [activePopup, setActivePopup] = useState<{ type: string; content: string; color: string } | null>(null);
  const [showAdvancedSettings, setShowAdvancedSettings] = useState(false);
  const [showThemeStore, setShowThemeStore] = useState(false);
  const [showToolBox, setShowToolBox] = useState(false);
  const [showUnityMenu, setShowUnityMenu] = useState(false);
  const [showResetMenu, setShowResetMenu] = useState(false);
  const [showShop, setShowShop] = useState(false);
  const [showInventory, setShowInventory] = useState(false);
  const [showBank, setShowBank] = useState(false);
  const [showEconomy, setShowEconomy] = useState(false);
  const [isShopLoading, setIsShopLoading] = useState(false);
  const [showGarden, setShowGarden] = useState(false);
  const [showNodeBoard, setShowNodeBoard] = useState<'TIMELINE' | 'RELATION' | null>(null);
  const [showSaveSlots, setShowSaveSlots] = useState(false);
  const [showAchievements, setShowAchievements] = useState(false);
  const [showMerchant, setShowMerchant] = useState(false);
  const [showPhone, setShowPhone] = useState(false);
  const [showCharConfig, setShowCharConfig] = useState(false); 
  const [showMindConfig, setShowMindConfig] = useState(false);
  const [showDiary, setShowDiary] = useState(false); 
  const [showVectorMemory, setShowVectorMemory] = useState(false);
  const [showRerunModal, setShowRerunModal] = useState(false);
  const [showDirectorMode, setShowDirectorMode] = useState(false);
  const [showChatInput, setShowChatInput] = useState(true);
  const [rerunTarget, setRerunTarget] = useState<{ id: string, role: string, content: string } | null>(null);
  const [attachedAction, setAttachedAction] = useState<{ type: 'GIFT' | 'USE' | 'EAT', items: InventoryItem[], message?: string, targetName?: string } | null>(null);
  const [showWhatIf, setShowWhatIf] = useState(false);
  const [sysStates, setSysStates] = useState({ drunk: false, excited: false, scared: false, heat: false, sinvesta: false, sinvestaLite: false });
  const [isNoLeds, setIsNoLeds] = useState(false);
  const [isLowPerf, setIsLowPerf] = useState(false);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const [isFocusMode, setIsFocusMode] = useState(false);
  const [importMenuOpen, setImportMenuOpen] = useState(false);
  const [exportMenuOpen, setExportMenuOpen] = useState(false);
  const [importType, setImportType] = useState<'FULL' | 'RESOURCE' | 'CHAT_CONFIG' | 'BOARD_DATA'>('FULL');

  const themeConfig = THEMES.find(t => t.id === config.theme) || THEMES[0];
  const themeColors = themeConfig.colors;
  const isScenarioStarted = messages.some(m => m.role === 'user' || m.role === 'assistant');
  const isDiceEnabled = config.activeModules?.includes("TTRPG_Dice");
  const isStatsEnabled = config.activeModules?.includes("TTRPG_Dice");
  const isFlappingEnabled = !!config.betaFeatures?.includes("Flapping (Visualizer)");
  const visibleMessages = messages.filter(m => !m.isHidden && m.role !== 'system' && !m.content.trim().startsWith("[SYSTEM SYNC"));
  const displayMessages = visibleMessages.slice(Math.max(visibleMessages.length - visibleCount, 0));
  const containerClass = config.customBackground ? 'bg-transparent text-white' : `${themeColors.bgMain} ${themeColors.textMain}`;
  const headerClass = config.customBackground ? 'bg-black/60 backdrop-blur-md border-b border-white/10' : `${themeColors.bgMain} border-b ${themeColors.border}`;

  useEffect(() => { if (messages.length > 50 && !isLowPerf) { setIsLowPerf(true); } }, [messages.length]);
  const messagesRef = useRef(messages);
  const configRef = useRef(config);
  useEffect(() => { messagesRef.current = messages; }, [messages]);
  useEffect(() => { configRef.current = config; }, [config]);
  useLayoutEffect(() => { if (isFetchingHistory && scrollContainerRef.current) { setIsFetchingHistory(false); } }, [displayMessages]);
  useEffect(() => { const observer = new IntersectionObserver((entries) => { if (entries[0].isIntersecting && visibleCount < visibleMessages.length) { setIsFetchingHistory(true); const container = scrollContainerRef.current; const previousScrollHeight = container?.scrollHeight || 0; setVisibleCount((prev) => Math.min(prev + 15, visibleMessages.length)); requestAnimationFrame(() => { if (container) { const newScrollHeight = container.scrollHeight; container.scrollTop = newScrollHeight - previousScrollHeight; } }); } }, { threshold: 0.5 }); if (topSentinelRef.current) observer.observe(topSentinelRef.current); return () => observer.disconnect(); }, [visibleCount, visibleMessages.length]);
  
  // UPDATED: Scroll to bottom immediately on load and when messages change
  useEffect(() => { 
      if (!isFetchingHistory) { 
          // Force instant scroll first, then smooth for UI feel
          if (messagesEndRef.current) {
              messagesEndRef.current.scrollIntoView({ behavior: 'auto' });
              setTimeout(() => {
                  messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
              }, 100);
          }
      } 
  }, [messages.length, isFetchingHistory]);

  const handleSystemMessage = (msg: string) => { onSendMessage(`[SYSTEM LOG]: ${msg}`); };
  const handleBuyItem = (item: ShopItem) => { if ((config.gameStats?.gold || 0) < item.price) { alert("Not enough Gold!"); return; } setConfig(prev => ({ ...prev, gameStats: { ...prev.gameStats!, gold: (prev.gameStats?.gold || 0) - item.price }, inventory: [...(prev.inventory || []), { ...item, quantity: 1, usageType: item.usageType || 'CONSUMABLE' } as InventoryItem] })); handleSystemMessage(`Purchased ${item.name} for ${item.price} G.`); };
  const handleBuyBegItem = (itemName: string, price: number) => { if ((config.gameStats?.gold || 0) < price) return; setConfig(prev => ({ ...prev, gameStats: { ...prev.gameStats!, gold: (prev.gameStats?.gold || 0) - price } })); onSendMessage(`[SYSTEM]: User purchased '${itemName}' for the character.`); };
  const getCurrentBalance = () => config.gameStats?.gold || 0;
  const handleRefreshShop = () => { setIsShopLoading(true); setTimeout(async () => { const currentBalance = getCurrentBalance(); const newItems = await generateShopItems(config, messages, currentBalance); setConfig(prev => ({ ...prev, shopItems: newItems })); setIsShopLoading(false); }, 1000); };
  const handleGiftItems = (items: InventoryItem[], targetName: string, message?: string) => { setAttachedAction({ type: 'GIFT', items, targetName, message }); setShowInventory(false); };
  const handleUseItem = (item: InventoryItem) => { const lowerName = item.name.toLowerCase(); const moneyKeywords = ['cash', 'money', 'coin', 'xu', 'tiền', 'lì xì', 'phong bì', 'gold', 'túi tiền', 'ví']; const isMoneyPack = moneyKeywords.some(k => lowerName.includes(k)) && (item.price > 0 || (item.name.match(/\d+/) && !item.name.match(/level|lvl/i))); if (isMoneyPack) { let amount = 0; const match = item.name.match(/(\d+(?:[.,]\d+)?)\s*(k|m|b|tr|tỷ|nghìn|ngàn|d|đ)/i); if (match) { amount = parseBalance(match[0]); } else { amount = item.price; } if (amount > 0) { setConfig(prev => { const inv = [...(prev.inventory || [])]; const idx = inv.findIndex(i => i.id === item.id); if (idx > -1) { if (inv[idx].quantity > 1) inv[idx].quantity--; else inv.splice(idx, 1); } const newGold = (prev.gameStats?.gold || 0) + amount; const newUserCard = prev.userCard ? { ...prev.userCard, phone: { ...prev.userCard.phone, bankBalance: formatVND(newGold) } } : prev.userCard; return { ...prev, inventory: inv, gameStats: { ...prev.gameStats!, gold: newGold }, userCard: newUserCard }; }); handleSystemMessage(`Opened [${item.name}]: +${formatVND(amount)}`); return; } } if (item.usageType === 'EQUIP') { setConfig(prev => { const inv = [...(prev.inventory || [])]; const idx = inv.findIndex(i => i.id === item.id); if (idx > -1) { const isNowEquipped = !inv[idx].isEquipped; inv[idx] = { ...inv[idx], isEquipped: isNowEquipped }; const currentEquipCount = (prev.gameStats?.equippedItemCount || 0); const newEquipCount = isNowEquipped ? currentEquipCount + 1 : Math.max(0, currentEquipCount - 1); return { ...prev, inventory: inv, gameStats: { ...prev.gameStats!, equippedItemCount: newEquipCount } }; } return prev; }); return; } if (item.type === 'CONSUMABLE' || item.type === 'INGREDIENT') { setAttachedAction({ type: 'EAT', items: [item] }); setShowInventory(false); return; } setAttachedAction({ type: 'USE', items: [item] }); setShowInventory(false); };
  const handleSellItem = (item: InventoryItem) => { const sellPrice = Math.floor(item.price * 0.5); setConfig(prev => ({ ...prev, gameStats: { ...prev.gameStats!, gold: (prev.gameStats?.gold || 0) + sellPrice }, inventory: prev.inventory?.filter(i => i.id !== item.id) })); handleSystemMessage(`Sold ${item.name} for ${sellPrice} G.`); };
  const handleBankTransfer = (targetName: string, amount: number, note: string) => {
    if ((config.gameStats?.gold || 0) < amount) {
      alert("Số dư không đủ!");
      return;
    }
    setConfig(prev => {
      const currentGold = prev.gameStats?.gold || 0;
      return {
        ...prev,
        gameStats: {
          ...prev.gameStats!,
          gold: currentGold - amount
        }
      };
    });
    
    const formattedAmount = new Intl.NumberFormat('en-US').format(amount);
    onSendMessage(`[BANK TRANSFER]: Đã chuyển Ⓠ${formattedAmount} cho ${targetName}.\nNội dung: ${note}`);
    setShowBank(false);
  };
  const handleOpenShop = () => { setShowShop(true); setShowToolBox(false); if (!config.shopItems || config.shopItems.length === 0) { handleRefreshShop(); } };
  const handleImportClick = (type: 'FULL' | 'RESOURCE' | 'CHAT_CONFIG' | 'BOARD_DATA') => { setImportType(type); setImportMenuOpen(false); fileInputRef.current?.click(); };
  const triggerExport = (type: 'FULL' | 'RESOURCE' | 'CHAT_CONFIG' | 'BOARD_DATA') => { onExportData(type); setExportMenuOpen(false); };
  const handleWhatIfCommit = (action: string) => { onSendMessage(action); };
  const handleUnsend = (id: string) => { setMessages(prev => prev.map(m => m.id === id ? { ...m, content: "[Tin nhắn đã được thu hồi]", metadata: { ...m.metadata, isUnsent: true } } : m)); };
  const startEditing = useCallback((msg: ChatMessage) => { setEditingMessageId(msg.id); setEditContent(msg.content); }, []);
  const cancelEditing = useCallback(() => { setEditingMessageId(null); setEditContent(''); }, []);
  const submitEdit = useCallback(() => { if (editingMessageId && editContent.trim()) { onEditMessage(editingMessageId, editContent); setEditingMessageId(null); setEditContent(''); } }, [editingMessageId, editContent, onEditMessage]);
  const rollDice = useCallback(() => { const roll = Math.floor(Math.random() * 20) + 1; onSendMessage(`[DICE ROLL]: D20 Result = ${roll}`); }, [onSendMessage]);
  const handleViewCard = useCallback((card: any) => { setActivePopup({ type: card.name, content: card.content, color: card.type === 'IDENTITY' ? 'blue' : 'yellow' }); }, []);
  const handleRerunRequest = useCallback((id: string, role: string, content: string) => { if (role === 'assistant') { setRerunTarget({ id, role, content }); setShowRerunModal(true); } else { onRerunMessage(id, role, content); } }, [onRerunMessage]);
  const confirmRerunWithFeedback = (instruction: string) => { if (rerunTarget) { let finalInstruction = instruction; if (!finalInstruction || !finalInstruction.trim()) { finalInstruction = ` [SYSTEM COMMAND: REGENERATE RESPONSE - QUALITY ASSURANCE] - **ISSUE**: Previous output might have been too short or rushed. - **CORRECTION**: REWRITE the last turn with MAXIMUM DETAIL and SENSORY DEPTH. - **CONSTRAINT**: ABSOLUTELY NO TIME SKIPS. Do NOT summarize. - **LENGTH**: EXPAND the narrative. Write more, not less. `; } onRerunMessage(rerunTarget.id, rerunTarget.role, rerunTarget.content, finalInstruction); setShowRerunModal(false); setRerunTarget(null); } };

  // --- SCRUB TAGS HANDLER ---
  const handleScrubTags = () => {
      setMessages(prev => prev.map(m => ({
          ...m,
          content: cleanThinking(m.content)
      })));
      setShowToolBox(false);
  };

  // ... UnityButton, UnityLongButton, ToolBoxItem, ToggleBtn ...
  const UnityButton = ({ icon, label, color, onClick }: any) => ( <button onClick={onClick} className="p-4 bg-[#0a0c14] border border-[#1e2330] rounded-xl flex flex-col items-center gap-2 hover:border-white/20 hover:bg-[#1e2330]/50 transition-all group"> <div className={`group-hover:scale-110 transition-transform ${color}`}>{icon}</div> <span className={`text-[10px] font-bold text-gray-300 group-hover:text-white uppercase tracking-tight`}>{label}</span> </button> );
  const UnityLongButton = ({ icon, label, color, onClick }: any) => ( <button onClick={onClick} className="p-3 bg-[#0a0c14] border border-[#1e2330] rounded-xl flex items-center justify-center gap-3 hover:border-white/20 hover:bg-[#1e2330]/50 transition-all group w-full"> <div className={color}>{icon}</div> <span className={`text-[10px] font-bold text-gray-300 uppercase tracking-wider group-hover:text-white`}>{label}</span> </button> );
  const ToolBoxItem = ({ icon, title, desc, onClick, color }: any) => ( <button onClick={onClick} className={`w-full p-3 rounded-lg border flex items-center gap-3 transition-all group ${color}`} > <div className="p-2 bg-black/20 rounded-lg">{icon}</div> <div className="flex flex-col items-start"> <span className="text-xs font-bold text-white uppercase">{title}</span> <span className="text-[9px] text-gray-400 font-mono text-left">{desc}</span> </div> </button> );
  const ToggleBtn = ({ label, active, icon, onClick }: any) => ( <button onClick={onClick} className={`p-3 rounded-lg border flex flex-col items-center gap-1 transition-all ${active ? 'bg-indigo-900/30 border-indigo-500 text-indigo-400' : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:border-zinc-700'}`} > {icon} <span className="text-[9px] font-bold font-mono">{label}</span> <div className={`w-8 h-1 rounded-full mt-1 ${active ? 'bg-indigo-500 shadow-[0_0_5px_#6366f1]' : 'bg-zinc-800'}`}></div> </button> );

  return (
    <div className={`flex flex-col h-full relative overflow-hidden ${containerClass} z-10`} style={{ fontFamily: config.fontFamily || 'Inter, sans-serif' }}>
      {!isFocusMode && (
        <div className={`shrink-0 z-30 transition-all duration-300 shadow-sm ${headerClass}`}>
            <div className={`h-12 md:h-16 border-b flex items-center justify-center md:justify-between px-2 md:px-6 ${themeColors.border} ${config.customBackground ? 'border-white/10' : ''}`}>
                <div className="flex items-center gap-4">
                  {/* Removed Kernel Display as requested */}
                </div>
                <div className="flex items-center gap-1 md:gap-2">
                  <HeaderMetaButton icon={<Brain className="text-pink-400 fill-pink-400/20" />} label="Cortex (Mem)" themeColors={themeColors} onClick={() => setShowVectorMemory(true)} />
                  <HeaderMetaButton icon={<Zap className="text-cyan-400 fill-cyan-400/20" />} label="What If..." themeColors={themeColors} onClick={() => setShowWhatIf(true)} />
                  <div className={`h-4 md:h-6 w-px mx-0.5 md:mx-1 ${themeColors.border} bg-current opacity-20`}></div>
                  <HeaderMetaButton icon={<BadgeDollarSign />} label="Economy" themeColors={themeColors} onClick={() => setShowEconomy(true)} />
                  <HeaderMetaButton icon={<LayoutGrid />} label="Unity" themeColors={themeColors} onClick={() => setShowUnityMenu(true)} />
                  <HeaderMetaButton icon={<Briefcase />} label="ToolBox" themeColors={themeColors} onClick={() => setShowToolBox(true)} />
                  <HeaderMetaButton icon={<Store />} label="Store" themeColors={themeColors} onClick={() => setShowThemeStore(true)} />
                  <div className={`h-4 md:h-6 w-px mx-0.5 md:mx-1 ${themeColors.border} bg-current opacity-20`}></div>
                  <HeaderMetaButton icon={<RefreshCw className="text-amber-400" />} label="Sync" themeColors={themeColors} onClick={onSystemSync} />
                  <HeaderMetaButton icon={<Settings2 />} label="Config" themeColors={themeColors} onClick={onOpenSettings} />
                  <button onClick={() => setShowAdvancedSettings(true)} className={`p-1.5 md:p-2 rounded-full ${themeColors.textDim} hover:${themeColors.textMain}`}><Settings className="w-4 h-4 md:w-5 md:h-5" /></button>
                  <div className="relative">
                      <button onClick={() => setShowResetMenu(!showResetMenu)} className={`p-1.5 md:p-2 rounded-full text-red-500/50 hover:text-red-400 transition-colors ${showResetMenu ? 'bg-red-500/10 text-red-400' : ''}`} title="Reset Options"><Eraser className="w-4 h-4 md:w-[18px] md:h-[18px]" /></button>
                      {showResetMenu && (
                          <>
                              <div className="fixed inset-0 z-40" onClick={() => setShowResetMenu(false)}></div>
                              <div className={`absolute right-0 top-full mt-2 w-48 rounded-xl border shadow-2xl z-50 flex flex-col overflow-hidden ${isLowPerf ? '' : 'animate-in fade-in zoom-in-95 duration-200'} ${config.customBackground ? 'bg-black/90 backdrop-blur-md border-white/10' : `${themeColors.bgPanel} ${themeColors.border}`}`}>
                                  <button onClick={() => { onClearChatLog(); setShowResetMenu(false); }} className={`p-3 text-left transition-colors flex flex-col gap-0.5 border-b ${themeColors.border} hover:bg-white/5 group`}><span className={`text-xs font-bold font-mono ${themeColors.textMain} group-hover:text-white`}>Clear Chat Log</span><span className={`text-[9px] font-mono ${themeColors.textDim}`}>Keep Memories & Settings</span></button>
                                  <button onClick={() => { onResetChat(); setShowResetMenu(false); }} className={`p-3 text-left transition-colors flex flex-col gap-0.5 border-b ${themeColors.border} hover:bg-white/5 group`}><span className={`text-xs font-bold font-mono text-orange-400 group-hover:text-orange-300`}>Clear History</span><span className={`text-[9px] font-mono text-orange-500/50`}>Wipe Messages + Memories</span></button>
                                  <button onClick={() => { onReset(); setShowResetMenu(false); }} className={`p-3 text-left transition-colors flex flex-col gap-0.5 hover:bg-red-900/20 group`}><span className="text-xs font-bold font-mono text-red-500 group-hover:text-red-400">Factory Reset</span><span className="text-[9px] font-mono text-red-500/50">Wipe Everything</span></button>
                              </div>
                          </>
                      )}
                  </div>
                </div>
            </div>
            <div className={`text-[10px] md:text-xs px-2 md:px-4 py-1.5 flex items-center justify-between border-b ${themeColors.border} bg-black/20 text-blue-200 font-mono tracking-wide`}>
                <div className="flex items-center gap-3 md:gap-6 w-full md:w-auto overflow-x-auto custom-scrollbar pb-0.5 md:pb-0">
                    <span className="flex items-center gap-1.5 shrink-0 text-emerald-400"><Map size={12}/> {config.currentLocation || 'Unknown Location'}</span>
                    <span className="flex items-center gap-1.5 shrink-0 text-amber-300"><Clock size={12}/> {config.currentTime || '--:--'}</span>
                    <span className="flex items-center gap-1.5 shrink-0 text-cyan-300"><CloudRain size={12}/> {config.currentWeather || 'Unknown Weather'}</span>
                </div>
                {config.locationDescription && <span className="opacity-70 truncate max-w-md hidden lg:inline-block ml-4 shrink-0 text-teal-100" title={config.locationDescription}>{config.locationDescription}</span>}
            </div>
        </div>
      )}

      {/* ... Modals (ASCIIPopup, ThemeStoreModal, AdvancedSettingsModal, etc.) ... */}
      {activePopup && <ASCIIPopup title={activePopup.type} content={activePopup.content} color={activePopup.color} onClose={() => setActivePopup(null)} themeColors={themeColors} />}
      {showThemeStore && <ThemeStoreModal onClose={() => setShowThemeStore(false)} config={config} setConfig={setConfig} themeColors={themeColors} />}
      {showAdvancedSettings && <AdvancedSettingsModal config={config} setConfig={setConfig} onClose={() => setShowAdvancedSettings(false)} onFastReload={onFastReload} />}
      {showGarden && <GardenMiniGame config={config} setConfig={setConfig} themeColors={themeColors} onClose={() => setShowGarden(false)} onLogInteraction={handleSystemMessage} />}
      {showEconomy && <EconomyModal config={config} setConfig={setConfig} onClose={() => setShowEconomy(false)} onLogMessage={handleSystemMessage} onSendMessage={onSendMessage} themeColors={themeColors} />}
      {showShop && <ShopModal onClose={() => setShowShop(false)} shopItems={config.shopItems || []} isLoading={isShopLoading} onBuy={handleBuyItem} userBalance={getCurrentBalance()} themeColors={themeColors} onRefresh={handleRefreshShop} messages={messages} />}
      {showInventory && <InventoryModal onClose={() => setShowInventory(false)} inventory={config.inventory || []} characters={config.characterCards} user={config.userCard} onGift={handleGiftItems} onUse={handleUseItem} onSell={handleSellItem} themeColors={themeColors} />}
      {showBank && <BankModal onClose={() => setShowBank(false)} characters={config.characterCards} userBalance={getCurrentBalance()} themeColors={themeColors} onTransfer={handleBankTransfer} />}
      
      {showVectorMemory && <VectorMemoryModal config={config} setConfig={setConfig} onClose={() => setShowVectorMemory(false)} themeColors={themeColors} messages={messages} />}
      {showRerunModal && ( <RerunFeedbackModal onClose={() => { setShowRerunModal(false); setRerunTarget(null); }} onConfirm={confirmRerunWithFeedback} themeColors={themeColors} /> )}
      {showWhatIf && ( <WhatIfModal onClose={() => setShowWhatIf(false)} config={config} messages={messages} onCommit={handleWhatIfCommit} themeColors={themeColors} /> )}
      {showNodeBoard && ( <NodeBoardModal mode={showNodeBoard} config={config} setConfig={setConfig} onClose={() => setShowNodeBoard(null)} /> )}
      {showSaveSlots && ( <SaveSlotsModal config={config} messages={messages} setConfig={setConfig} setMessages={setMessages} onClose={() => setShowSaveSlots(false)} themeColors={themeColors} /> )}
      {showAchievements && <AchievementModal onClose={() => setShowAchievements(false)} config={config} setConfig={setConfig} onLog={handleSystemMessage} themeColors={themeColors} messagesCount={config.gameStats?.messagesSent || 0} />}
      {showMerchant && <MerchantModal config={config} setConfig={setConfig} onClose={() => setShowMerchant(false)} onLog={handleSystemMessage} themeColors={themeColors} /> }
      {showPhone && config.userCard && <SmartPhone character={config.userCard} isUser={true} balance={getCurrentBalance()} onClose={() => setShowPhone(false)} onTransfer={handleBankTransfer} />}
      {showCharConfig && ( <CharacterConfigModal config={config} setConfig={setConfig} onClose={() => setShowCharConfig(false)} themeColors={themeColors} /> )}
      {showMindConfig && ( <MindConfigModal config={config} setConfig={setConfig} onClose={() => setShowMindConfig(false)} themeColors={themeColors} /> )}
      {showDiary && ( <DiaryModal config={config} setConfig={setConfig} messages={messages} onClose={() => setShowDiary(false)} themeColors={themeColors} /> )}
      {showDirectorMode && <DirectorModeModal config={config} setConfig={setConfig} onClose={() => setShowDirectorMode(false)} themeColors={themeColors} />}
      
      {showUnityMenu && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-[#050510] border border-[#1e2330] rounded-2xl shadow-2xl p-6 flex flex-col gap-6 relative overflow-hidden h-[85vh] overflow-y-auto custom-scrollbar">
            <div className="flex justify-between items-center z-10">
                <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-gray-400">Unity Control</h3>
                <button onClick={() => setShowUnityMenu(false)} className="text-gray-500 hover:text-white transition-colors"><X size={18} /></button>
            </div>
            
            <div className="grid grid-cols-2 gap-3 z-10">
                <UnityButton icon={<Spade size={20} className="text-emerald-500" />} label="Khu Vườn Chibi" color="text-emerald-400" onClick={() => {setShowGarden(true); setShowUnityMenu(false);}} />
                <UnityButton icon={<HardDrive size={20} className="text-green-500" />} label="Save Slots" color="text-green-400" onClick={() => {setShowSaveSlots(true); setShowUnityMenu(false);}} />
            </div>

            <div className="flex flex-col gap-3 z-10">
                <UnityLongButton icon={<Book size={18} className="text-pink-500" />} label="SECRET DIARY (NHẬT KÝ)" color="text-pink-400" onClick={() => {setShowDiary(true); setShowUnityMenu(false);}} />
                <UnityLongButton icon={<Ruler size={18} className="text-rose-500" />} label="BODY SCULPTING (THỂ CHẤT)" color="text-rose-400" onClick={() => {setShowCharConfig(true); setShowUnityMenu(false);}} />
                <UnityLongButton icon={<Brain size={18} className="text-cyan-500" />} label="MIND SCULPTING (TÂM TRÍ)" color="text-cyan-400" onClick={() => {setShowMindConfig(true); setShowUnityMenu(false);}} />
            </div>

            <div className="h-px bg-[#1e2330] w-full z-10"></div>
            <div className="grid grid-cols-2 gap-3 z-10">
                <UnityButton icon={<Clock size={20} className="text-blue-500" />} label="Time Line" color="text-blue-400" onClick={() => {setShowNodeBoard('TIMELINE'); setShowUnityMenu(false);}} />
                <UnityButton icon={<Users size={20} className="text-pink-500" />} label="Relation Line" color="text-pink-400" onClick={() => {setShowNodeBoard('RELATION'); setShowUnityMenu(false);}} />
            </div>
          </div>
        </div>
      )}
      {showToolBox && (
        <div className="fixed inset-0 z-50 flex items-start justify-end p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="w-full max-w-sm bg-[#050510] border border-[#1e2330] rounded-2xl shadow-2xl p-5 flex flex-col gap-4 relative animate-in slide-in-from-right-10 mr-0 mt-14 h-[85vh] overflow-y-auto custom-scrollbar">
                <div className="flex justify-between items-center mb-2"> <h3 className="font-mono text-sm font-bold uppercase tracking-widest text-white">TOOLBOX</h3> <button onClick={() => setShowToolBox(false)} className="text-gray-500 hover:text-white"><X size={18}/></button> </div>
                <div className="flex flex-col gap-3">
                     <ToolBoxItem icon={<ShoppingCart size={20} className="text-yellow-500"/>} title="CONTEXT SHOP" desc="Buy items based on situation" onClick={() => {setShowShop(true); setShowToolBox(false);}} color="border-yellow-900/50 bg-yellow-950/10 hover:bg-yellow-950/20" />
                     <ToolBoxItem icon={<Package size={20} className="text-blue-500"/>} title="INVENTORY" desc="Manage gifts & items" onClick={() => {setShowInventory(true); setShowToolBox(false);}} color="border-blue-900/50 bg-blue-950/10 hover:bg-blue-950/20" />
                     <ToolBoxItem icon={<RefreshCw size={20} className="text-cyan-500"/>} title="FAST-RELOAD" desc="Đồng bộ lại dữ liệu & bộ nhớ AI" onClick={() => {onFastReload(); setShowToolBox(false);}} color="border-cyan-900/50 bg-cyan-950/10 hover:bg-cyan-950/20" />
                     <ToolBoxItem icon={<Eraser size={20} className="text-pink-500"/>} title="SCRUB TAGS" desc="Remove leaked [System] tags" onClick={handleScrubTags} color="border-pink-900/50 bg-pink-950/10 hover:bg-pink-950/20" />
                </div>
                <div className="grid grid-cols-2 gap-3 mt-2">
                    <ToggleBtn label="SINVESTA" active={sysStates.sinvesta} icon={<Sparkles size={16}/>} onClick={() => setSysStates(prev => ({...prev, sinvesta: !prev.sinvesta}))} />
                    <ToggleBtn label="LITE MODE" active={sysStates.sinvestaLite} icon={<ZapOff size={16}/>} onClick={() => setSysStates(prev => ({...prev, sinvestaLite: !prev.sinvestaLite}))} />
                    <ToggleBtn label="NO LEDS" active={isNoLeds} icon={<EyeOff size={16}/>} onClick={() => setIsNoLeds(!isNoLeds)} />
                    <ToggleBtn label={`LOW PERF: ${isLowPerf ? 'ON' : 'OFF'}`} active={isLowPerf} icon={<BatteryLow size={16}/>} onClick={() => setIsLowPerf(!isLowPerf)} />
                </div>
                <div className="mt-4 pt-4 border-t border-white/5">
                    <h4 className="text-[10px] font-bold text-gray-500 uppercase mb-3">DATA MANAGEMENT</h4>
                    <div className="flex flex-col gap-2">
                        <button onClick={() => setImportMenuOpen(true)} className="flex justify-between items-center p-3 rounded-lg border border-white/5 bg-white/5 hover:bg-white/10 transition-all text-xs font-mono text-gray-300 group"> <span className="flex items-center gap-2"><Upload size={14}/> Import Session</span> <ChevronRight size={14} className="text-gray-600 group-hover:text-white" /> </button>
                        <button onClick={() => setExportMenuOpen(true)} className="flex justify-between items-center p-3 rounded-lg border border-white/5 bg-white/5 hover:bg-white/10 transition-all text-xs font-mono text-gray-300 group"> <span className="flex items-center gap-2"><Download size={14}/> Export Session</span> <ChevronRight size={14} className="text-gray-600 group-hover:text-white" /> </button>
                    </div>
                </div>
            </div>
        </div>
      )}
      {importMenuOpen && (
          <div className={`fixed inset-0 z-[70] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4`}>
              <div className={`bg-zinc-900 border border-zinc-700 p-6 rounded-xl shadow-2xl flex flex-col gap-4 w-full max-w-sm`}>
                  <h3 className="text-white font-bold text-lg">Import Data</h3>
                  <button onClick={() => handleImportClick('FULL')} className="p-3 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold text-sm">Full Backup (Recommended)</button>
                  <button onClick={() => handleImportClick('CHAT_CONFIG')} className="p-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded font-bold text-sm">Chat Only</button>
                  <button onClick={() => handleImportClick('RESOURCE')} className="p-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded font-bold text-sm">Config Only</button>
                  <button onClick={() => handleImportClick('BOARD_DATA')} className="p-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded font-bold text-sm">Board Data Only</button>
                  <button onClick={() => setImportMenuOpen(false)} className="mt-2 text-zinc-500 hover:text-white text-xs">Cancel</button>
              </div>
          </div>
      )}
      {exportMenuOpen && (
          <div className={`fixed inset-0 z-[70] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4`}>
              <div className={`bg-zinc-900 border border-zinc-700 p-6 rounded-xl shadow-2xl flex flex-col gap-4 w-full max-w-sm`}>
                  <h3 className="text-white font-bold text-lg">Export Data</h3>
                  <button onClick={() => triggerExport('FULL')} className="p-3 bg-green-600 hover:bg-green-500 text-white rounded font-bold text-sm">Full Backup (Recommended)</button>
                  <button onClick={() => triggerExport('CHAT_CONFIG')} className="p-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded font-bold text-sm">Chat Log Only</button>
                  <button onClick={() => triggerExport('RESOURCE')} className="p-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded font-bold text-sm">Config/Resource Only</button>
                  <button onClick={() => triggerExport('BOARD_DATA')} className="p-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded font-bold text-sm">Board Data Only</button>
                  <button onClick={() => setExportMenuOpen(false)} className="mt-2 text-zinc-500 hover:text-white text-xs">Cancel</button>
              </div>
          </div>
      )}
      <input type="file" ref={fileInputRef} className="hidden" accept=".json" onChange={(e) => { if (e.target.files && e.target.files.length > 0) { onImportData(e.target.files[0], importType); } e.target.value = ''; }} />
      <div ref={scrollContainerRef} className="flex-1 overflow-y-auto custom-scrollbar p-2 md:p-4 space-y-4 scroll-smooth relative">
          <div ref={topSentinelRef} className="h-1 w-full"></div>
          {displayMessages.map((msg, index) => (
              <MessageItem key={msg.id} msg={msg} index={index} themeColors={themeColors} config={config} sysStates={sysStates} isNoLeds={isNoLeds} isLowPerf={isLowPerf} isFlappingEnabled={isFlappingEnabled} editingMessageId={editingMessageId} editContent={editContent} setEditContent={setEditContent} startEditing={startEditing} cancelEditing={cancelEditing} submitEdit={submitEdit} onRerunMessage={handleRerunRequest} onDeleteMessage={onDeleteMessage} onDeleteFromHere={onDeleteFromHere} handleViewCard={handleViewCard} handleBuyBegItem={handleBuyBegItem} onUnsend={handleUnsend} onVersionChange={onVersionChange} onFeedback={onFeedback} regeneratingId={regeneratingId} />
          ))}
          {isTyping && !regeneratingId && ( <div className="flex items-center gap-2 p-4 text-zinc-500 animate-pulse"> <div className="w-2 h-2 bg-current rounded-full animate-bounce"></div> <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div> <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div> </div> )}
          <div ref={messagesEndRef} className="h-1" />
      </div>
      <div className={`transition-all duration-500 ease-in-out overflow-hidden ${showChatInput ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0 pointer-events-none'}`}>
          <ChatInputBar onSendMessage={onSendMessage} onSendSticker={onSendSticker} attachedAction={attachedAction} setAttachedAction={setAttachedAction} config={config} setConfig={setConfig} isTyping={isTyping} themeColors={themeColors} isDiceEnabled={isDiceEnabled} rollDice={rollDice} isFocusMode={isFocusMode} setIsFocusMode={setIsFocusMode} isScenarioStarted={isScenarioStarted} isNoLeds={isNoLeds} isLowPerf={isLowPerf} messages={messages} onOpenDirectorMode={() => setShowDirectorMode(true)} />
      </div>
      {!showChatInput && (
          <button 
            onClick={() => setShowChatInput(true)}
            className="fixed bottom-6 right-6 z-50 p-4 bg-nano-600 text-white rounded-full shadow-2xl hover:bg-nano-500 transition-all active:scale-95 animate-in fade-in zoom-in duration-300"
            title="Show Chat Input"
          >
            <MessageCircle size={24} />
          </button>
      )}
    </div>
  );
};

export default ChatInterface;
