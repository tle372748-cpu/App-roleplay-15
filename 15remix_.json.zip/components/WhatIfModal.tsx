
import React, { useState } from 'react';
import { X, Sparkles, AlertCircle, ArrowRight, Zap, Play, Send, RotateCcw } from 'lucide-react';
import { AppConfig, ChatMessage } from '../types';
import { generateWhatIfSimulation } from '../services/aiService';

interface WhatIfModalProps {
  onClose: () => void;
  config: AppConfig;
  messages: ChatMessage[];
  onCommit: (action: string) => void;
  themeColors: any;
}

const WhatIfModal: React.FC<WhatIfModalProps> = ({ onClose, config, messages, onCommit, themeColors }) => {
  const [inputAction, setInputAction] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<{ analysis: string, response: string } | null>(null);

  const handleSimulate = async () => {
      if (!inputAction.trim()) return;
      setIsProcessing(true);
      try {
          const res = await generateWhatIfSimulation(config, messages, inputAction);
          setResult(res);
      } catch (e) {
          console.error(e);
      } finally {
          setIsProcessing(false);
      }
  };

  const handleCommit = () => {
      onCommit(inputAction);
      onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-300">
      <div className={`w-full max-w-4xl h-[90vh] flex flex-col rounded-2xl border-2 border-cyan-500/50 bg-black/80 shadow-[0_0_50px_rgba(6,182,212,0.2)] overflow-hidden relative`}>
        
        {/* Holographic Grid Background */}
        <div className="absolute inset-0 pointer-events-none opacity-20 bg-[linear-gradient(rgba(6,182,212,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.1)_1px,transparent_1px)] bg-[size:20px_20px]"></div>
        <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-cyan-900/10 via-transparent to-cyan-900/10"></div>

        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-cyan-500/30 bg-cyan-950/20 z-10 shrink-0">
            <div className="flex items-center gap-3">
                <div className="p-2 rounded-full border border-cyan-400 bg-cyan-900/30 shadow-[0_0_15px_cyan] animate-pulse">
                    <Sparkles size={24} className="text-cyan-300" />
                </div>
                <div>
                    <h2 className="text-2xl font-black italic tracking-widest text-white uppercase drop-shadow-md">WHAT IF... <span className="text-cyan-400">SIMULATOR</span></h2>
                    <p className="text-[10px] font-mono text-cyan-500/80 uppercase tracking-[0.2em]">Quantum Probability Engine v3.0 (Gemini Pro)</p>
                </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors text-cyan-500 hover:text-white"><X size={24}/></button>
        </div>

        {/* Content Body */}
        <div className="flex-1 flex flex-col p-6 overflow-y-auto custom-scrollbar z-10 relative">
            
            {!result ? (
                <div className="flex-1 flex flex-col items-center justify-center gap-8 max-w-2xl mx-auto w-full">
                    <div className="text-center space-y-2">
                        <h3 className="text-xl font-bold text-white">Enter a Hypothetical Action</h3>
                        <p className="text-sm text-cyan-200/60 font-mono">
                            Simulate the outcome of an action without committing to reality.<br/>
                            The AI will analyze psychological impact and project the likely response.
                        </p>
                    </div>

                    <div className="w-full relative group">
                        <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl blur opacity-20 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
                        <textarea 
                            value={inputAction}
                            onChange={(e) => setInputAction(e.target.value)}
                            placeholder="E.g., I slap him in the face... / I suddenly kiss her..."
                            className="relative w-full h-40 bg-black border border-cyan-500/30 rounded-xl p-6 text-lg text-white placeholder-zinc-600 outline-none focus:border-cyan-400 focus:shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all font-mono resize-none"
                        />
                    </div>

                    <button 
                        onClick={handleSimulate}
                        disabled={isProcessing || !inputAction.trim()}
                        className={`w-full max-w-sm py-4 rounded-full font-black text-lg uppercase tracking-widest flex items-center justify-center gap-3 transition-all
                            ${isProcessing 
                                ? 'bg-zinc-800 text-zinc-500 cursor-wait' 
                                : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-[0_0_30px_rgba(6,182,212,0.4)] hover:shadow-[0_0_50px_rgba(6,182,212,0.6)] active:scale-95'}
                        `}
                    >
                        {isProcessing ? (
                            <><Zap size={20} className="animate-spin"/> PROCESSING...</>
                        ) : (
                            <><Play size={20} className="fill-current"/> RUN SIMULATION</>
                        )}
                    </button>
                </div>
            ) : (
                <div className="flex flex-col gap-6 w-full max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-500">
                    
                    {/* User Action Recap */}
                    <div className="flex items-start gap-4 p-4 rounded-xl border border-white/10 bg-white/5">
                        <div className="text-zinc-400 font-mono text-xs uppercase w-20 shrink-0 pt-1">Input Action</div>
                        <div className="text-white italic">"{inputAction}"</div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-full">
                        
                        {/* LEFT: ANALYSIS */}
                        <div className="flex flex-col gap-2">
                            <h4 className="text-cyan-400 font-mono font-bold uppercase tracking-widest text-sm flex items-center gap-2">
                                <AlertCircle size={16}/> Predictive Analysis
                            </h4>
                            <div className="flex-1 bg-cyan-950/30 border border-cyan-500/30 p-5 rounded-xl text-cyan-100/90 text-sm leading-relaxed font-mono shadow-inner overflow-y-auto max-h-[400px]">
                                {result.analysis}
                            </div>
                        </div>

                        {/* RIGHT: SIMULATION */}
                        <div className="flex flex-col gap-2">
                            <h4 className="text-purple-400 font-mono font-bold uppercase tracking-widest text-sm flex items-center gap-2">
                                <Sparkles size={16}/> Projected Outcome
                            </h4>
                            <div className="flex-1 bg-black/60 border border-purple-500/30 p-5 rounded-xl shadow-inner relative overflow-hidden flex flex-col">
                                <div className="absolute top-0 right-0 p-2 bg-purple-500/20 rounded-bl-xl text-[10px] font-mono text-purple-300 uppercase">Simulation</div>
                                <div className="text-white text-base leading-relaxed italic">
                                    "{result.response}"
                                </div>
                            </div>
                        </div>

                    </div>

                    <div className="flex gap-4 mt-4 pt-4 border-t border-white/10">
                        <button 
                            onClick={() => setResult(null)}
                            className="flex-1 py-3 rounded-lg border border-zinc-600 hover:bg-white/5 text-zinc-300 font-bold uppercase tracking-wider transition-all"
                        >
                            <RotateCcw size={16} className="inline mr-2 mb-0.5"/> Try Another
                        </button>
                        <button 
                            onClick={handleCommit}
                            className="flex-1 py-3 rounded-lg bg-green-600 hover:bg-green-500 text-white font-bold uppercase tracking-wider shadow-lg shadow-green-900/50 transition-all flex items-center justify-center gap-2"
                        >
                            <Send size={16}/> Make it Real
                        </button>
                    </div>

                </div>
            )}

        </div>

      </div>
    </div>
  );
};

export default WhatIfModal;
