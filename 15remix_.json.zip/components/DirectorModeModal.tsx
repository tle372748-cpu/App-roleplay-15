import React, { useState } from 'react';
import { AppConfig, DirectorPreferences } from '../types';
import { X, Save, ArrowUp, ArrowDown } from 'lucide-react';

interface Props {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  onClose: () => void;
  themeColors: any;
}

export default function DirectorModeModal({ config, setConfig, onClose, themeColors }: Props) {
  const [prefs, setPrefs] = useState<DirectorPreferences>(
    config.directorPreferences || {
      enabled: false,
      elements: [
        { id: 'action', label: 'Hành động (Action)', weight: 50, order: 1 },
        { id: 'dialogue', label: 'Lời thoại (Dialogue)', weight: 50, order: 2 },
        { id: 'environment', label: 'Môi trường (Environment)', weight: 30, order: 3 },
        { id: 'internal', label: 'Nội tâm (Internal Thoughts)', weight: 30, order: 4 }
      ]
    }
  );

  const handleSave = () => {
    setConfig(prev => ({ ...prev, directorPreferences: prefs }));
    onClose();
  };

  const moveElement = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === prefs.elements.length - 1) return;

    const newElements = [...prefs.elements];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    // Swap
    const temp = newElements[index];
    newElements[index] = newElements[targetIndex];
    newElements[targetIndex] = temp;

    // Update orders
    newElements.forEach((el, i) => { el.order = i + 1; });

    setPrefs({ ...prefs, elements: newElements });
  };

  const updateWeight = (index: number, weight: number) => {
    const newElements = [...prefs.elements];
    newElements[index].weight = weight;
    setPrefs({ ...prefs, elements: newElements });
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100] p-4 backdrop-blur-sm">
      <div className={`w-full max-w-md rounded-2xl border flex flex-col overflow-hidden ${themeColors.bgPanel} ${themeColors.border} shadow-2xl`}>
        <div className={`p-4 border-b flex justify-between items-center ${themeColors.border} bg-black/20`}>
          <h2 className={`font-bold text-lg ${themeColors.text}`}>🎬 Director Mode (Đạo Diễn)</h2>
          <button onClick={onClose} className={`p-1 rounded-lg hover:bg-white/10 ${themeColors.textDim} transition-colors`}>
            <X size={20} />
          </button>
        </div>

        <div className="p-4 overflow-y-auto max-h-[70vh] space-y-6">
          <div className="flex items-center justify-between p-3 rounded-xl bg-black/20 border border-white/5">
            <div>
              <div className={`font-medium ${themeColors.text}`}>Kích hoạt Director Mode</div>
              <div className={`text-xs ${themeColors.textDim} mt-1`}>Ép AI viết theo tỷ lệ và thứ tự bạn muốn</div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" checked={prefs.enabled} onChange={(e) => setPrefs({ ...prefs, enabled: e.target.checked })} />
              <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
            </label>
          </div>

          <div className="space-y-3">
            <div className={`text-sm font-medium ${themeColors.textDim} mb-2`}>Thứ tự ưu tiên & Tỷ lệ chi tiết</div>
            {prefs.elements.map((el, idx) => (
              <div key={el.id} className={`p-3 rounded-xl border ${themeColors.border} bg-black/10 flex flex-col gap-3`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold bg-yellow-500/20 text-yellow-500`}>
                      {idx + 1}
                    </div>
                    <span className={`font-medium ${themeColors.text}`}>{el.label}</span>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => moveElement(idx, 'up')} disabled={idx === 0} className={`p-1 rounded hover:bg-white/10 disabled:opacity-30 ${themeColors.textDim}`}>
                      <ArrowUp size={16} />
                    </button>
                    <button onClick={() => moveElement(idx, 'down')} disabled={idx === prefs.elements.length - 1} className={`p-1 rounded hover:bg-white/10 disabled:opacity-30 ${themeColors.textDim}`}>
                      <ArrowDown size={16} />
                    </button>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-xs w-8 text-right ${themeColors.textDim}`}>{el.weight}%</span>
                  <input 
                    type="range" 
                    min="0" max="100" step="5"
                    value={el.weight}
                    onChange={(e) => updateWeight(idx, parseInt(e.target.value))}
                    className="flex-1 h-1.5 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-yellow-500"
                  />
                </div>
              </div>
            ))}
          </div>
          
          <div className={`text-xs ${themeColors.textDim} p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20 text-yellow-200/80`}>
            Mẹo: Kéo thanh tỷ lệ về 0% nếu bạn không muốn AI miêu tả phần đó. Thứ tự 1 sẽ được AI ưu tiên viết đầu tiên trong câu trả lời.
          </div>
        </div>

        <div className={`p-4 border-t ${themeColors.border} bg-black/20 flex justify-end gap-2`}>
          <button onClick={onClose} className={`px-4 py-2 rounded-xl text-sm font-medium hover:bg-white/5 ${themeColors.textDim} transition-colors`}>
            Hủy
          </button>
          <button onClick={handleSave} className="px-4 py-2 rounded-xl text-sm font-medium bg-yellow-600 hover:bg-yellow-500 text-white transition-colors flex items-center gap-2 shadow-[0_0_15px_rgba(202,138,4,0.3)]">
            <Save size={16} />
            Lưu Cài Đặt
          </button>
        </div>
      </div>
    </div>
  );
}
