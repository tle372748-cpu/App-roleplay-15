
import React, { useState, useEffect } from 'react';
import { AppConfig, CardData, PhysicalAttributes, VisualFeature, CharacterRole } from '../types';
import { X, User, Heart, Baby, Ruler, Weight, Zap, Award, Layers, Droplets, Save, Scissors, Circle, Palette, Plus, Trash2, PenTool, Activity, Sparkles, Flame, UserCheck, Wind, Gauge, Ban, AlertTriangle } from 'lucide-react';

interface CharacterConfigModalProps {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  onClose: () => void;
  themeColors: any;
  initialTarget?: 'USER' | number;
}

const DEFAULT_PHYSICAL: PhysicalAttributes = {
    height: 165,
    weight: 50,
    muscle: 10,
    fat: 20,
    beauty: 70,
    sensitivity: 50,
    measurements: { bust: 85, waist: 60, hips: 90, cup: 'B' },
    genitals: { depth: 0, length: 0, girth: 0, wetness: 10, traits: [] }, // DEFAULT 0 to prevent mismatch
    pregnancy: { isPregnant: false, weeks: 0, isVisible: false },
    fluids: { lactation: false, capacity: 20, flowMode: 'NORMAL', valve: 'NORMAL', scent: 'Natural' },
    rear: { depth: 10, tightness: 80 },
    grooming: { style: 'Natural' },
    visuals: { 
        skinTone: 'Fair', 
        hairColor: 'Black', 
        eyeColor: 'Brown', 
        bodyType: 'Hourglass',
        bodyFeatures: [], 
        tattoos: [],
        scars: []
    }
};

const GROOMING_STYLES = [
    'Natural', 'Trimmed', 'Shaved', 'Triangle', 'Landing Strip', 'Heart', 'Bush', 'Wild'
];

const BODY_TYPE_OPTIONS = [
    'Hourglass', 'Pear', 'Apple', 'Rectangle', 'Inverted Triangle',
    'Slim Thick', 'Petite', 'Amazonian', 'Muscular/Fit', 
    'Chubby/Soft', 'BBW', 'Voluptuous', 'Lanky/Slender', 'Gymnast', 'Swimmer'
];

const CUP_SIZES = [
    'AA', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 
    'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'
];

const WAIST_PRESETS = [
    { label: 'Kiến (Wasp)', val: 55 },
    { label: 'Thon (Slim)', val: 60 },
    { label: 'Vừa (Avg)', val: 68 },
    { label: 'Đầy (Chubby)', val: 80 },
    { label: 'Béo (BBW)', val: 100 }
];

const HIP_PRESETS = [
    { label: 'Lép (Flat)', val: 80 },
    { label: 'Vừa (Avg)', val: 90 },
    { label: 'Cong (Curvy)', val: 100 },
    { label: 'Căng (Thicc)', val: 110 },
    { label: 'Đại (Huge)', val: 125 }
];

const BELLY_PRESETS = [
    { label: 'Phẳng (Flat)', fat: 10, preg: 0 },
    { label: 'Mềm (Soft)', fat: 25, preg: 0 },
    { label: 'Mỡ (Chubby)', fat: 40, preg: 0 },
    { label: 'Bầu Nhỏ (Early)', fat: 25, preg: 12 },
    { label: 'Bầu To (Late)', fat: 30, preg: 36 }
];

const THIGH_PRESETS = [
    { label: 'Tăm Tre (Thin)', muscle: 5, fat: 5 },
    { label: 'Thon Thả (Slim)', muscle: 15, fat: 15 },
    { label: 'Mật Ong (Thick)', muscle: 30, fat: 25 },
    { label: 'Cột Đình (Chubby)', muscle: 10, fat: 50 },
    { label: 'Cơ Bắp (Muscle)', muscle: 60, fat: 10 }
];

const StatInputControl = ({ label, value, step, suffix, onChange, colorClass = "accent-pink-500", min = 0 }: any) => {
    const textColor = colorClass.replace('accent-', 'text-');
    
    return (
      <div className={`flex items-center justify-between p-3 rounded-xl border border-white/5 bg-zinc-900/50 hover:bg-zinc-900 transition-all group`}>
          <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider group-hover:text-zinc-300 transition-colors">{label}</span>
          <div className="flex items-center gap-2 bg-black/20 px-3 py-1.5 rounded-lg border border-white/5 group-hover:border-white/10">
              <input 
                  type="number"
                  value={value}
                  onChange={(e) => {
                      const val = e.target.value === '' ? 0 : parseFloat(e.target.value);
                      onChange(val);
                  }}
                  className={`w-20 bg-transparent text-right text-sm font-mono font-bold outline-none ${textColor} placeholder-zinc-700`}
                  step={step}
                  min={min}
                  placeholder="0"
              />
              <span className="text-[10px] text-zinc-600 font-mono select-none w-8 text-right border-l border-white/5 pl-2">{suffix ? suffix.trim() : ''}</span>
          </div>
      </div>
    );
};

const FeatureManager = ({ 
    title, 
    items, 
    onAdd, 
    onRemove, 
    colorClass, 
    icon,
    placeholderLoc = "Location",
    placeholderDesc = "Description..."
}: { 
    title: string;
    items: VisualFeature[]; 
    onAdd: (feat: VisualFeature) => void; 
    onRemove: (idx: number) => void;
    colorClass: string;
    icon: React.ReactNode;
    placeholderLoc?: string;
    placeholderDesc?: string;
}) => {
    const [newLoc, setNewLoc] = useState('');
    const [newDesc, setNewDesc] = useState('');

    const handleAdd = () => {
        if (newLoc.trim() && newDesc.trim()) {
            onAdd({ location: newLoc.trim(), description: newDesc.trim() });
            setNewLoc('');
            setNewDesc('');
        }
    };

    return (
        <div className={`rounded-xl border bg-black/20 p-4 flex flex-col gap-4 ${colorClass}`}>
            <div className="flex items-center gap-2 border-b border-white/5 pb-2">
                {icon}
                <span className="text-xs font-bold uppercase tracking-widest text-white">{title}</span>
                <span className="text-[9px] bg-white/10 px-1.5 rounded-full">{items.length}</span>
            </div>

            {/* Input Area */}
            <div className="flex flex-col gap-2 bg-zinc-900/50 p-2 rounded-lg border border-white/5">
                <input 
                    type="text" 
                    value={newLoc} 
                    onChange={(e) => setNewLoc(e.target.value)} 
                    placeholder={placeholderLoc}
                    className="w-full bg-black/40 border border-white/10 rounded px-2 py-1.5 text-xs text-white placeholder-zinc-600 outline-none focus:border-white/30"
                />
                <div className="flex gap-2">
                    <input 
                        type="text" 
                        value={newDesc} 
                        onChange={(e) => setNewDesc(e.target.value)} 
                        placeholder={placeholderDesc}
                        className="flex-1 bg-black/40 border border-white/10 rounded px-2 py-1.5 text-xs text-white placeholder-zinc-600 outline-none focus:border-white/30"
                        onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
                    />
                    <button 
                        onClick={handleAdd}
                        disabled={!newLoc || !newDesc}
                        className="px-3 bg-white/10 hover:bg-white/20 text-white rounded text-xs font-bold transition-colors disabled:opacity-50"
                    >
                        <Plus size={14} />
                    </button>
                </div>
            </div>

            {/* List Area */}
            <div className="flex flex-col gap-2 max-h-40 overflow-y-auto custom-scrollbar">
                {items.length === 0 ? (
                    <div className="text-center text-[10px] text-zinc-600 italic py-2">No data recorded.</div>
                ) : (
                    items.map((item, idx) => (
                        <div key={idx} className="flex justify-between items-start p-2 rounded bg-white/5 hover:bg-white/10 border border-white/5 group">
                            <div className="flex flex-col">
                                <span className="text-[10px] font-bold text-white uppercase">{item.location}</span>
                                <span className="text-[10px] text-zinc-400 leading-tight">{item.description}</span>
                            </div>
                            <button 
                                onClick={() => onRemove(idx)} 
                                className="text-zinc-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all p-1"
                            >
                                <Trash2 size={12} />
                            </button>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

const CharacterConfigModal: React.FC<CharacterConfigModalProps> = ({ config, setConfig, onClose, themeColors, initialTarget }) => {
  const [selectedTarget, setSelectedTarget] = useState<'USER' | number>(initialTarget !== undefined ? initialTarget : 'USER');
  const [activeTab, setActiveTab] = useState<'IDENTITY' | 'BODY' | 'MEASURE' | 'TABOO'>('IDENTITY');

  const getStatsFromConfig = (target: 'USER' | number): PhysicalAttributes => {
      const card = target === 'USER' ? config.userCard : config.characterCards[target as number];
      
      // If card has explicit physical data, use it. Otherwise, init with DEFAULT but handle gender.
      const base = card?.physical ? JSON.parse(JSON.stringify(card.physical)) : JSON.parse(JSON.stringify(DEFAULT_PHYSICAL));
      
      if (!base.fluids) base.fluids = { lactation: false, capacity: 20, flowMode: 'NORMAL', valve: 'NORMAL', scent: 'Natural' };
      if (!base.rear) base.rear = { depth: 10, tightness: 80 };
      if (!base.grooming) base.grooming = { style: 'Natural' };
      if (!base.visuals) base.visuals = { skinTone: 'Fair', hairColor: 'Black', eyeColor: 'Brown', bodyType: 'Hourglass', bodyFeatures: [], tattoos: [], scars: [] };
      if (!base.genitals) base.genitals = { depth: 0, length: 0, girth: 0, wetness: 10, traits: [] }; // Set to 0 default
      if (!base.genitals.traits) base.genitals.traits = []; 
      
      // Force clean defaults if gender is present but stats are default-mixed
      // This is crucial to prevent "Female" cards showing "Male" due to old defaults
      const gender = card?.gender?.toLowerCase() || "";
      if (gender.includes("female") || gender.includes("nữ") || gender.includes("girl") || gender.includes("women")) {
          // STRICT FORCE ZERO FOR FEMALE
          base.genitals.length = 0;
          // IF NO DEPTH IS SET, GENERATE IT (Height based fallback for UI consistency)
          if (!base.genitals.depth || base.genitals.depth === 0) {
              const h = base.height || 160;
              const baseDepth = 12;
              const heightDiff = h - 160;
              base.genitals.depth = Math.max(8, parseFloat((baseDepth + (heightDiff * 0.1)).toFixed(1)));
          }
      } else if (gender.includes("male") || gender.includes("nam") || gender.includes("boy") || gender.includes("man")) {
          base.genitals.depth = 0;
      }

      if ((base.visuals as any).tattoos === true && (!base.visuals.tattoos || base.visuals.tattoos.length === 0)) {
          base.visuals.tattoos = [{ location: "General", description: "Visible tattoos" }];
      } else if (!Array.isArray(base.visuals.tattoos)) {
          base.visuals.tattoos = [];
      }

      if ((base.visuals as any).scars === true && (!base.visuals.scars || base.visuals.scars.length === 0)) {
          base.visuals.scars = [{ location: "General", description: "Visible scars" }];
      } else if (!Array.isArray(base.visuals.scars)) {
          base.visuals.scars = [];
      }

      if (!Array.isArray(base.visuals.bodyFeatures)) {
          base.visuals.bodyFeatures = [];
      }
      
      return base;
  };

  const [localPhysical, setLocalPhysical] = useState<PhysicalAttributes>(getStatsFromConfig(selectedTarget));
  const [genitalTraitsInput, setGenitalTraitsInput] = useState<string>('');
  const [genitalMode, setGenitalMode] = useState<'MALE' | 'FEMALE' | 'FUTA' | 'DOLL'>('DOLL');

  // Sync effect to handle target switching and data initialization
  useEffect(() => {
      // 1. Get new stats based on selected target
      const newStats = getStatsFromConfig(selectedTarget);
      
      // 2. Determine genital mode from the data
      const g = newStats.genitals;
      const hasR = (g?.length !== undefined && g.length !== 0); // Allow negative for inverted
      const hasH = (g?.depth !== undefined && g.depth !== 0);
      
      let mode: 'MALE' | 'FEMALE' | 'FUTA' | 'DOLL' = 'DOLL';
      
      if (hasR && hasH) mode = 'FUTA';
      else if (hasH) mode = 'FEMALE'; // Prioritize Female check if Hole exists
      else if (hasR) mode = 'MALE';
      else {
          // Fallback check on gender string if stats are empty/zero (prevents unintentional Doll)
          const targetCard = selectedTarget === 'USER' ? config.userCard : config.characterCards[selectedTarget as number];
          const gender = targetCard?.gender?.toLowerCase() || "";
          
          // FIX: Check Female first to avoid "Female" containing "male"
          if (gender.includes('female') || gender.includes('nữ') || gender.includes('gái') || gender.includes('women') || gender.includes('girl')) mode = 'FEMALE';
          else if (gender.includes('male') || gender.includes('nam') || gender.includes('trai') || gender.includes('boy') || gender.includes('man')) mode = 'MALE';
      }
      
      // 3. Update states
      setLocalPhysical(newStats);
      setGenitalMode(mode);
      setGenitalTraitsInput(g?.traits?.join(', ') || '');
      
  }, [selectedTarget]);

  const saveToConfig = (target: 'USER' | number, stats: PhysicalAttributes) => {
      setConfig(prev => {
          const legacyUpdates: Partial<CardData> = {};
          if (stats.height) legacyUpdates.height = `${stats.height}cm`;

          if (target === 'USER') {
              return prev.userCard ? { 
                  ...prev, 
                  userCard: { 
                      ...prev.userCard, 
                      ...legacyUpdates,
                      physical: stats 
                  } 
              } : prev;
          } else {
              const idx = target as number;
              const newChars = [...prev.characterCards];
              if (newChars[idx]) {
                  newChars[idx] = { 
                      ...newChars[idx], 
                      ...legacyUpdates,
                      physical: stats 
                  };
              }
              return { ...prev, characterCards: newChars };
          }
      });
  };

  const handleSwitchTarget = (newTarget: 'USER' | number) => {
      if (newTarget === selectedTarget) return;
      saveToConfig(selectedTarget, localPhysical);
      setSelectedTarget(newTarget);
      // The useEffect above will handle state updates for the new target
  };

  const handleClose = () => {
      saveToConfig(selectedTarget, localPhysical);
      onClose();
  };

  const getTargetCardName = (target: 'USER' | number) => {
      if (target === 'USER') return config.userCard?.name || "User";
      return config.characterCards[target as number]?.name || "Unknown";
  };

  const currentCardName = getTargetCardName(selectedTarget);

  const updatePhysical = (updates: Partial<PhysicalAttributes>) => {
      setLocalPhysical(prev => ({ ...prev, ...updates }));
  };

  const updateVisuals = (updates: Partial<PhysicalAttributes['visuals']>) => {
      setLocalPhysical(prev => ({
          ...prev,
          visuals: { ...prev.visuals, ...updates }
      }));
  };

  const addVisualFeature = (type: 'tattoos' | 'scars' | 'bodyFeatures', feature: VisualFeature) => {
      setLocalPhysical(prev => {
          const currentList = prev.visuals?.[type] || [];
          return {
              ...prev,
              visuals: {
                  ...prev.visuals,
                  [type]: [...currentList, feature]
              }
          };
      });
  };

  const removeVisualFeature = (type: 'tattoos' | 'scars' | 'bodyFeatures', index: number) => {
      setLocalPhysical(prev => {
          const currentList = prev.visuals?.[type] || [];
          return {
              ...prev,
              visuals: {
                  ...prev.visuals,
                  [type]: currentList.filter((_, i) => i !== index)
              }
          };
      });
  };

  const calculateBust = (cup: string) => {
      const baseUnderbust = 70;
      const cupIndex = CUP_SIZES.indexOf(cup.toUpperCase());
      if (cupIndex === -1) return 85; 
      const diff = 7.5 + (cupIndex * 2.5);
      return Math.round(baseUnderbust + diff);
  };

  const updateMeasurements = (updates: Partial<PhysicalAttributes['measurements']>) => {
      setLocalPhysical(prev => {
          const newMeasurements = { ...prev.measurements, ...updates };
          if (updates.cup) {
              newMeasurements.bust = calculateBust(updates.cup);
          }
          return { 
              ...prev, 
              measurements: newMeasurements 
          };
      });
  };

  const updateGenitals = (updates: Partial<PhysicalAttributes['genitals']>) => {
      setLocalPhysical(prev => ({
          ...prev,
          genitals: { ...prev.genitals, ...updates }
      }));
  };

  const setGenitalType = (type: 'MALE' | 'FEMALE' | 'FUTA' | 'DOLL') => {
      const current = localPhysical.genitals || { length: 0, depth: 0, girth: 0, wetness: 0, traits: [] };
      let updates: any = {};

      setGenitalMode(type);

      if (type === 'MALE') {
          updates.length = current.length && current.length !== 0 ? current.length : 12;
          updates.girth = current.girth && current.girth > 0 ? current.girth : 10;
          updates.depth = 0;
      } else if (type === 'FEMALE') {
          updates.length = 0;
          // IMPORTANT: If explicit Female mode is selected but no depth exists, default to 12.
          updates.depth = current.depth && current.depth > 0 ? current.depth : 12;
          // For Female, 'girth' is reused for tightness/width in this UI logic, usually default 2-3cm
          updates.girth = current.girth && current.girth > 0 && current.girth < 10 ? current.girth : 2.5; 
      } else if (type === 'FUTA') {
          updates.length = current.length && current.length !== 0 ? current.length : 15;
          updates.depth = current.depth && current.depth > 0 ? current.depth : 12;
          updates.girth = current.girth && current.girth > 0 ? current.girth : 12;
      } else {
          updates.length = 0;
          updates.depth = 0;
          updates.girth = 0;
      }
      
      updateGenitals(updates);
  };

  const applyPreset = (type: 'BELLY' | 'THIGHS', preset: any) => {
      if (type === 'BELLY') {
          updatePhysical({ fat: preset.fat });
      } else if (type === 'THIGHS') {
          updatePhysical({ muscle: preset.muscle, fat: preset.fat });
      }
  };

  // Determine visibility based on MODE, not values
  const hasRod = genitalMode === 'MALE' || genitalMode === 'FUTA';
  const hasHole = genitalMode === 'FEMALE' || genitalMode === 'FUTA';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
      <div className="w-full max-w-2xl bg-[#09090b] border border-pink-500/20 rounded-xl shadow-2xl flex flex-col h-[85vh] overflow-hidden">
        
        {/* HEADER */}
        <div className="p-4 border-b border-pink-500/20 bg-pink-950/10 flex justify-between items-center shrink-0">
            <div className="flex items-center gap-3 text-pink-400">
                <User size={24} />
                <div>
                    <h2 className="font-mono font-bold uppercase tracking-widest text-lg text-white">Character Config</h2>
                    <p className="text-[10px] font-mono text-pink-400/60 uppercase">Body Sculpting • Physical Stats</p>
                </div>
            </div>
            <div className="flex gap-2">
                <button 
                    onClick={handleClose} 
                    className="px-4 py-2 bg-pink-600 hover:bg-pink-500 text-white rounded-lg text-xs font-bold uppercase flex items-center gap-2 transition-all shadow-lg shadow-pink-900/20"
                >
                    <Save size={14} /> Save & Close
                </button>
            </div>
        </div>

        {/* CHARACTER SELECTOR */}
        <div className="flex gap-2 p-3 bg-black/40 border-b border-white/5 overflow-x-auto custom-scrollbar shrink-0">
            {config.userCard && (
                <button 
                    onClick={() => handleSwitchTarget('USER')}
                    className={`px-4 py-2 rounded-lg border text-xs font-bold uppercase whitespace-nowrap transition-all flex items-center gap-2
                        ${selectedTarget === 'USER' ? 'bg-pink-600 text-white border-pink-500' : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:border-pink-500/50'}
                    `}
                >
                    <User size={14} /> User (You)
                </button>
            )}
            {config.characterCards.map((char, idx) => (
                <button 
                    key={idx}
                    onClick={() => handleSwitchTarget(idx)}
                    className={`px-4 py-2 rounded-lg border text-xs font-bold uppercase whitespace-nowrap transition-all flex items-center gap-2
                        ${selectedTarget === idx ? 'bg-pink-600 text-white border-pink-500' : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:border-pink-500/50'}
                    `}
                >
                    {char.name}
                </button>
            ))}
        </div>

        {/* TABS */}
        <div className="flex border-b border-white/10 shrink-0 bg-zinc-900/50">
            <button onClick={() => setActiveTab('IDENTITY')} className={`flex-1 py-3 text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'IDENTITY' ? 'text-nano-400 border-nano-400 bg-nano-900/10' : 'text-zinc-500 hover:text-zinc-300'}`}>Danh Tính (Identity)</button>
            <button onClick={() => setActiveTab('BODY')} className={`flex-1 py-3 text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'BODY' ? 'text-pink-400 border-b-2 border-pink-500 bg-pink-500/5' : 'text-zinc-500 hover:text-zinc-300'}`}>Cơ Thể (Body)</button>
            <button onClick={() => setActiveTab('MEASURE')} className={`flex-1 py-3 text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'MEASURE' ? 'text-pink-400 border-b-2 border-pink-500 bg-pink-500/5' : 'text-zinc-500 hover:text-zinc-300'}`}>3 Vòng (Meas.)</button>
            <button onClick={() => setActiveTab('TABOO')} className={`flex-1 py-3 text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'TABOO' ? 'text-red-500 border-b-2 border-red-600 bg-red-900/10' : 'text-zinc-500 hover:text-zinc-300'}`}>Vùng Cấm (NSFW)</button>
        </div>

        {/* CONTENT */}
        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar bg-zinc-950">
            <div className="space-y-8 max-w-lg mx-auto">
                <div className="flex justify-between items-center pb-4 border-b border-white/5">
                    <span className="text-xs font-mono text-zinc-500 uppercase">Editing: <span className="text-white font-bold">{currentCardName}</span></span>
                    <span className="text-[10px] text-zinc-600 italic">Auto-saves on switch/close.</span>
                </div>

                {/* --- TAB: IDENTITY --- */}
                {activeTab === 'IDENTITY' && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                        <div className="bg-zinc-900/30 p-4 rounded-xl border border-white/5 space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-[10px] font-bold text-zinc-500 uppercase mb-1 block">Tên (Name)</label>
                                    <input 
                                        type="text" 
                                        value={selectedTarget === 'USER' ? config.userCard?.name || '' : config.characterCards[selectedTarget as number]?.name || ''} 
                                        onChange={(e) => {
                                            const newName = e.target.value;
                                            setConfig(prev => {
                                                if (selectedTarget === 'USER') {
                                                    return prev.userCard ? { ...prev, userCard: { ...prev.userCard, name: newName } } : prev;
                                                } else {
                                                    const newChars = [...prev.characterCards];
                                                    if (newChars[selectedTarget as number]) {
                                                        newChars[selectedTarget as number] = { ...newChars[selectedTarget as number], name: newName };
                                                    }
                                                    return { ...prev, characterCards: newChars };
                                                }
                                            });
                                        }}
                                        className="w-full bg-black/40 border border-white/10 rounded p-2 text-xs text-white outline-none focus:border-nano-500"
                                    />
                                </div>
                                <div>
                                    <label className="text-[10px] font-bold text-zinc-500 uppercase mb-1 block">Vai Trò (Role)</label>
                                    <select 
                                        value={selectedTarget === 'USER' ? 'MAIN' : config.characterCards[selectedTarget as number]?.role || 'SIDE'} 
                                        disabled={selectedTarget === 'USER'}
                                        onChange={(e) => {
                                            const newRole = e.target.value as any;
                                            setConfig(prev => {
                                                const newChars = [...prev.characterCards];
                                                if (newChars[selectedTarget as number]) {
                                                    newChars[selectedTarget as number] = { ...newChars[selectedTarget as number], role: newRole };
                                                }
                                                return { ...prev, characterCards: newChars };
                                            });
                                        }}
                                        className="w-full bg-black/40 border border-white/10 rounded p-2 text-xs text-white outline-none focus:border-nano-500 disabled:opacity-50"
                                    >
                                        <option value="MAIN">MAIN (Nhân vật chính)</option>
                                        <option value="SIDE">SIDE (Nhân vật phụ)</option>
                                        <option value="BACKGROUND">BACKGROUND (Quần chúng)</option>
                                    </select>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-[10px] font-bold text-zinc-500 uppercase mb-1 block">Tuổi (Age)</label>
                                    <input 
                                        type="text" 
                                        value={selectedTarget === 'USER' ? config.userCard?.age || '' : config.characterCards[selectedTarget as number]?.age || ''} 
                                        onChange={(e) => {
                                            const newAge = e.target.value;
                                            setConfig(prev => {
                                                if (selectedTarget === 'USER') {
                                                    return prev.userCard ? { ...prev, userCard: { ...prev.userCard, age: newAge } } : prev;
                                                } else {
                                                    const newChars = [...prev.characterCards];
                                                    if (newChars[selectedTarget as number]) {
                                                        newChars[selectedTarget as number] = { ...newChars[selectedTarget as number], age: newAge };
                                                    }
                                                    return { ...prev, characterCards: newChars };
                                                }
                                            });
                                        }}
                                        className="w-full bg-black/40 border border-white/10 rounded p-2 text-xs text-white outline-none focus:border-nano-500"
                                    />
                                </div>
                                <div>
                                    <label className="text-[10px] font-bold text-zinc-500 uppercase mb-1 block">Giới Tính (Gender)</label>
                                    <input 
                                        type="text" 
                                        value={selectedTarget === 'USER' ? config.userCard?.gender || '' : config.characterCards[selectedTarget as number]?.gender || ''} 
                                        onChange={(e) => {
                                            const newGender = e.target.value;
                                            setConfig(prev => {
                                                if (selectedTarget === 'USER') {
                                                    return prev.userCard ? { ...prev, userCard: { ...prev.userCard, gender: newGender } } : prev;
                                                } else {
                                                    const newChars = [...prev.characterCards];
                                                    if (newChars[selectedTarget as number]) {
                                                        newChars[selectedTarget as number] = { ...newChars[selectedTarget as number], gender: newGender };
                                                    }
                                                    return { ...prev, characterCards: newChars };
                                                }
                                            });
                                        }}
                                        className="w-full bg-black/40 border border-white/10 rounded p-2 text-xs text-white outline-none focus:border-nano-500"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="text-[10px] font-bold text-zinc-500 uppercase mb-1 block">Mô Tả (Description)</label>
                                <textarea 
                                    value={selectedTarget === 'USER' ? config.userCard?.description || '' : config.characterCards[selectedTarget as number]?.description || ''} 
                                    onChange={(e) => {
                                        const newDesc = e.target.value;
                                        setConfig(prev => {
                                            if (selectedTarget === 'USER') {
                                                return prev.userCard ? { ...prev, userCard: { ...prev.userCard, description: newDesc } } : prev;
                                            } else {
                                                const newChars = [...prev.characterCards];
                                                if (newChars[selectedTarget as number]) {
                                                    newChars[selectedTarget as number] = { ...newChars[selectedTarget as number], description: newDesc };
                                                }
                                                return { ...prev, characterCards: newChars };
                                            }
                                        });
                                    }}
                                    className="w-full h-24 bg-black/40 border border-white/10 rounded p-2 text-xs text-white outline-none focus:border-nano-500 resize-none font-mono"
                                />
                            </div>

                            <div>
                                <label className="text-[10px] font-bold text-zinc-500 uppercase mb-1 block">Tính Cách (Traits - Ngăn cách bằng dấu phẩy)</label>
                                <input 
                                    type="text" 
                                    value={selectedTarget === 'USER' ? config.userCard?.traits?.join(', ') || '' : config.characterCards[selectedTarget as number]?.traits?.join(', ') || ''} 
                                    onChange={(e) => {
                                        const newTraits = e.target.value.split(',').map(t => t.trim()).filter(Boolean);
                                        setConfig(prev => {
                                            if (selectedTarget === 'USER') {
                                                return prev.userCard ? { ...prev, userCard: { ...prev.userCard, traits: newTraits } } : prev;
                                            } else {
                                                const newChars = [...prev.characterCards];
                                                if (newChars[selectedTarget as number]) {
                                                    newChars[selectedTarget as number] = { ...newChars[selectedTarget as number], traits: newTraits };
                                                }
                                                return { ...prev, characterCards: newChars };
                                            }
                                        });
                                    }}
                                    className="w-full bg-black/40 border border-white/10 rounded p-2 text-xs text-white outline-none focus:border-nano-500 font-mono"
                                />
                            </div>
                        </div>
                    </div>
                )}
                
                {/* --- TAB: BODY --- */}
                {activeTab === 'BODY' && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                        
                        {/* VISUALS SECTION */}
                        <div className="bg-zinc-900/30 p-4 rounded-xl border border-white/5 space-y-6">
                            <h4 className="text-zinc-400 font-bold text-xs uppercase flex items-center gap-2 border-b border-white/5 pb-2"><Palette size={14}/> Ngoại Hình Chi Tiết (Visuals)</h4>
                            
                            <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className="text-[9px] font-bold text-zinc-500 uppercase mb-1 block">Màu Da (Skin)</label>
                                    <input 
                                        type="text" 
                                        value={localPhysical.visuals?.skinTone || ''} 
                                        onChange={(e) => updateVisuals({ skinTone: e.target.value })} 
                                        className="w-full bg-black/40 border border-white/10 rounded p-2 text-xs text-white placeholder-zinc-700 outline-none focus:border-pink-500"
                                        placeholder="e.g. Pale, Tan..."
                                    />
                                </div>
                                <div>
                                    <label className="text-[9px] font-bold text-zinc-500 uppercase mb-1 block">Dáng (Body Type)</label>
                                    <select 
                                        value={localPhysical.visuals?.bodyType || 'Hourglass'} 
                                        onChange={(e) => updateVisuals({ bodyType: e.target.value })} 
                                        className="w-full bg-black/40 border border-white/10 rounded p-2 text-xs text-white outline-none focus:border-pink-500"
                                    >
                                        {BODY_TYPE_OPTIONS.map(opt => (
                                            <option key={opt} value={opt}>{opt}</option>
                                        ))}
                                    </select>
                                </div>
                            </div>

                            <div className="grid grid-cols-3 gap-3">
                                <div>
                                    <label className="text-[9px] font-bold text-zinc-500 uppercase mb-1 block">Màu Tóc</label>
                                    <input type="text" value={localPhysical.visuals?.hairColor || ''} onChange={(e) => updateVisuals({ hairColor: e.target.value })} className="w-full bg-black/40 border border-white/10 rounded p-2 text-xs text-white placeholder-zinc-700 outline-none focus:border-pink-500" placeholder="Black" />
                                </div>
                                <div>
                                    <label className="text-[9px] font-bold text-zinc-500 uppercase mb-1 block">Kiểu Tóc</label>
                                    <input type="text" value={localPhysical.visuals?.hairStyle || ''} onChange={(e) => updateVisuals({ hairStyle: e.target.value })} className="w-full bg-black/40 border border-white/10 rounded p-2 text-xs text-white placeholder-zinc-700 outline-none focus:border-pink-500" placeholder="Long" />
                                </div>
                                <div>
                                    <label className="text-[9px] font-bold text-zinc-500 uppercase mb-1 block">Màu Mắt</label>
                                    <input type="text" value={localPhysical.visuals?.eyeColor || ''} onChange={(e) => updateVisuals({ eyeColor: e.target.value })} className="w-full bg-black/40 border border-white/10 rounded p-2 text-xs text-white placeholder-zinc-700 outline-none focus:border-pink-500" placeholder="Brown" />
                                </div>
                            </div>

                            {/* --- BELLY & THIGHS PRESETS --- */}
                            <div className="space-y-4 pt-2 border-t border-white/5">
                                <div className="space-y-2">
                                    <label className="text-[9px] font-bold text-zinc-500 uppercase">Hình Dáng Bụng (Belly)</label>
                                    <div className="flex flex-wrap gap-2">
                                        {BELLY_PRESETS.map((p, i) => (
                                            <button 
                                                key={i}
                                                onClick={() => applyPreset('BELLY', p)}
                                                className="px-2 py-1 rounded bg-zinc-800 text-[9px] font-bold text-zinc-300 hover:text-white hover:bg-zinc-700 transition-colors border border-zinc-700"
                                            >
                                                {p.label}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[9px] font-bold text-zinc-500 uppercase">Cặp Đùi (Thighs)</label>
                                    <div className="flex flex-wrap gap-2">
                                        {THIGH_PRESETS.map((p, i) => (
                                            <button 
                                                key={i}
                                                onClick={() => applyPreset('THIGHS', p)}
                                                className="px-2 py-1 rounded bg-zinc-800 text-[9px] font-bold text-zinc-300 hover:text-white hover:bg-zinc-700 transition-colors border border-zinc-700"
                                            >
                                                {p.label}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            {/* Feature Lists */}
                            <div className="space-y-4 border-t border-white/5 pt-4">
                                <FeatureManager 
                                    title="Đặc Điểm Cơ Thể (Body Features)" 
                                    items={localPhysical.visuals?.bodyFeatures || []} 
                                    onAdd={(f) => addVisualFeature('bodyFeatures', f)}
                                    onRemove={(i) => removeVisualFeature('bodyFeatures', i)}
                                    colorClass="border-amber-500/30"
                                    icon={<UserCheck size={16} className="text-amber-400"/>}
                                    placeholderLoc="Feature (e.g. Abs)"
                                    placeholderDesc="Details (e.g. Defined)"
                                />

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <FeatureManager 
                                        title="Tattoos (Ink)" 
                                        items={localPhysical.visuals?.tattoos || []} 
                                        onAdd={(f) => addVisualFeature('tattoos', f)}
                                        onRemove={(i) => removeVisualFeature('tattoos', i)}
                                        colorClass="border-fuchsia-500/30"
                                        icon={<PenTool size={16} className="text-fuchsia-400"/>}
                                        placeholderLoc="Pos (e.g. Neck)"
                                        placeholderDesc="Design (e.g. Rose)"
                                    />
                                    <FeatureManager 
                                        title="Scars & Marks" 
                                        items={localPhysical.visuals?.scars || []} 
                                        onAdd={(f) => addVisualFeature('scars', f)}
                                        onRemove={(i) => removeVisualFeature('scars', i)}
                                        colorClass="border-red-500/30"
                                        icon={<Activity size={16} className="text-red-400"/>}
                                        placeholderLoc="Pos (e.g. Eye)"
                                        placeholderDesc="Type (e.g. Slash)"
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <StatInputControl label="Chiều Cao (Height)" value={localPhysical.height} step={1} suffix="cm" onChange={(v: number) => updatePhysical({ height: v })} colorClass="accent-blue-400" />
                            <StatInputControl label="Cân Nặng (Weight)" value={localPhysical.weight} step={1} suffix="kg" onChange={(v: number) => updatePhysical({ weight: v })} colorClass="accent-green-400" />
                        </div>
                        
                        <div className="h-px bg-white/5 w-full my-2"></div>

                        <StatInputControl label="Sắc Đẹp (Beauty Rating)" value={localPhysical.beauty} step={1} suffix="/100" onChange={(v: number) => updatePhysical({ beauty: v })} colorClass="accent-yellow-400" />
                        <StatInputControl label="Cơ Bắp (Muscle Mass)" value={localPhysical.muscle} step={1} suffix="%" onChange={(v: number) => updatePhysical({ muscle: v })} colorClass="accent-red-400" />
                        <StatInputControl label="Mỡ Thừa (Body Fat)" value={localPhysical.fat} step={1} suffix="%" onChange={(v: number) => updatePhysical({ fat: v })} colorClass="accent-orange-400" />
                    </div>
                )}

                {/* --- TAB: MEASUREMENTS --- */}
                {activeTab === 'MEASURE' && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                        {/* Cup Size Selector */}
                        <div className="flex flex-col gap-2 bg-zinc-900/30 p-4 rounded-xl border border-white/5">
                            <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-2 block">Cỡ Ngực (Cup Size) - Auto Bust Calc.</label>
                            
                            {/* Expanded Grid */}
                            <div className="grid grid-cols-6 md:grid-cols-8 gap-2 mb-3 max-h-[200px] overflow-y-auto custom-scrollbar">
                                {CUP_SIZES.map(cup => (
                                    <button 
                                        key={cup}
                                        onClick={() => updateMeasurements({ cup })}
                                        className={`py-2 rounded-lg border text-[10px] font-bold transition-all ${localPhysical.measurements.cup === cup ? 'bg-pink-600 border-pink-400 text-white shadow-lg shadow-pink-900/20' : 'bg-black/40 border-zinc-800 text-zinc-500 hover:text-white hover:border-zinc-600'}`}
                                    >
                                        {cup}
                                    </button>
                                ))}
                            </div>

                            {/* Custom Input */}
                            <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                                <span className="text-[9px] font-bold text-zinc-500 uppercase whitespace-nowrap">Custom Size:</span>
                                <input 
                                    type="text" 
                                    value={localPhysical.measurements.cup} 
                                    onChange={(e) => updateMeasurements({ cup: e.target.value })}
                                    className="flex-1 bg-black/40 border border-white/10 rounded px-2 py-1.5 text-xs text-white placeholder-zinc-700 outline-none focus:border-pink-500 font-mono"
                                    placeholder="Type custom size (e.g. Omega)"
                                />
                            </div>
                        </div>

                        {/* WAIST PRESETS */}
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold text-zinc-500 uppercase flex items-center gap-2">Vòng Eo (Waist) Presets</label>
                            <div className="flex flex-wrap gap-2">
                                {WAIST_PRESETS.map((p, i) => (
                                    <button 
                                        key={i}
                                        onClick={() => updateMeasurements({ waist: p.val })}
                                        className="px-2 py-1.5 rounded bg-cyan-900/20 border border-cyan-500/20 text-[9px] font-bold text-cyan-300 hover:text-white hover:bg-cyan-900/40 transition-colors"
                                    >
                                        {p.label}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* HIP PRESETS */}
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold text-zinc-500 uppercase flex items-center gap-2">Vòng Mông (Hips) Presets</label>
                            <div className="flex flex-wrap gap-2">
                                {HIP_PRESETS.map((p, i) => (
                                    <button 
                                        key={i}
                                        onClick={() => updateMeasurements({ hips: p.val })}
                                        className="px-2 py-1.5 rounded bg-purple-900/20 border border-purple-500/20 text-[9px] font-bold text-purple-300 hover:text-white hover:bg-purple-900/40 transition-colors"
                                    >
                                        {p.label}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="space-y-4 pt-4 border-t border-white/5">
                            <StatInputControl label="Vòng 1 (Bust)" value={localPhysical.measurements.bust} step={1} suffix="cm" onChange={(v: number) => updateMeasurements({ bust: v })} colorClass="accent-pink-400" />
                            <StatInputControl label="Vòng 2 (Waist)" value={localPhysical.measurements.waist} step={1} suffix="cm" onChange={(v: number) => updateMeasurements({ waist: v })} colorClass="accent-cyan-400" />
                            <StatInputControl label="Vòng 3 (Hips)" value={localPhysical.measurements.hips} step={1} suffix="cm" onChange={(v: number) => updateMeasurements({ hips: v })} colorClass="accent-purple-400" />
                        </div>
                    </div>
                )}

                {/* --- TAB: TABOO (NSFW) --- */}
                {activeTab === 'TABOO' && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                        
                        {/* Genital Type Selector */}
                        <div className="space-y-3 p-4 rounded-xl border border-red-900/30 bg-red-950/10">
                            <label className="text-[10px] font-bold text-red-400 uppercase flex items-center gap-2">
                                <Activity size={14}/> Cấu Tạo Sinh Học (Genital Type)
                            </label>
                            <div className="grid grid-cols-4 gap-2">
                                <button onClick={() => setGenitalType('MALE')} className={`flex flex-col items-center gap-1 p-2 rounded border transition-all ${genitalMode === 'MALE' ? 'bg-blue-600/30 border-blue-500 text-blue-200' : 'bg-black/30 border-white/10 text-zinc-500 hover:bg-white/5'}`}>
                                    <span className="text-xl">🍆</span>
                                    <span className="text-[9px] font-bold">NAM</span>
                                </button>
                                <button onClick={() => setGenitalType('FEMALE')} className={`flex flex-col items-center gap-1 p-2 rounded border transition-all ${genitalMode === 'FEMALE' ? 'bg-pink-600/30 border-pink-500 text-pink-200' : 'bg-black/30 border-white/10 text-zinc-500 hover:bg-white/5'}`}>
                                    <span className="text-xl">🍑</span>
                                    <span className="text-[9px] font-bold">NỮ</span>
                                </button>
                                <button onClick={() => setGenitalType('FUTA')} className={`flex flex-col items-center gap-1 p-2 rounded border transition-all ${genitalMode === 'FUTA' ? 'bg-purple-600/30 border-purple-500 text-purple-200' : 'bg-black/30 border-white/10 text-zinc-500 hover:bg-white/5'}`}>
                                    <span className="text-xl">🍆🍑</span>
                                    <span className="text-[9px] font-bold">FUTA/BOTH</span>
                                </button>
                                <button onClick={() => setGenitalType('DOLL')} className={`flex flex-col items-center gap-1 p-2 rounded border transition-all ${genitalMode === 'DOLL' ? 'bg-zinc-600/30 border-zinc-500 text-zinc-200' : 'bg-black/30 border-white/10 text-zinc-500 hover:bg-white/5'}`}>
                                    <Ban size={20} />
                                    <span className="text-[9px] font-bold">DOLL</span>
                                </button>
                            </div>
                        </div>

                        {/* MALE STATS */}
                        {hasRod && (
                            <div className="space-y-4 p-4 rounded-xl border border-blue-900/30 bg-blue-950/10">
                                <h4 className="text-[10px] font-bold text-blue-400 uppercase flex items-center gap-2"><Ruler size={14}/> Chỉ Số Dương Vật (Rod Stats)</h4>
                                <StatInputControl label="Chiều Dài (Length)" value={localPhysical.genitals?.length || 0} step={0.5} min={-10} suffix="cm" onChange={(v: number) => updateGenitals({ length: v })} colorClass="accent-blue-500" />
                                <StatInputControl label="Chu Vi (Girth/Thick)" value={localPhysical.genitals?.girth || 0} step={0.5} suffix="cm" onChange={(v: number) => updateGenitals({ girth: v })} colorClass="accent-blue-400" />
                            </div>
                        )}

                        {/* FEMALE STATS */}
                        {hasHole && (
                            <div className="space-y-4 p-4 rounded-xl border border-pink-900/30 bg-pink-950/10">
                                <h4 className="text-[10px] font-bold text-pink-400 uppercase flex items-center gap-2"><Circle size={14}/> Chỉ Số Âm Đạo (Hole Stats)</h4>
                                <StatInputControl label="Độ Sâu (Depth)" value={localPhysical.genitals?.depth || 0} step={0.5} suffix="cm" onChange={(v: number) => updateGenitals({ depth: v })} colorClass="accent-pink-500" />
                                <StatInputControl label="Độ Khít / Chu Vi (Tightness)" value={localPhysical.genitals?.girth || 0} step={0.5} suffix="cm" onChange={(v: number) => updateGenitals({ girth: v })} colorClass="accent-pink-400" />
                            </div>
                        )}

                        {/* UNIVERSAL STATS */}
                        {(hasRod || hasHole) && (
                            <div className="space-y-4 p-4 rounded-xl border border-indigo-900/30 bg-indigo-950/10">
                                <h4 className="text-[10px] font-bold text-indigo-400 uppercase flex items-center gap-2"><Droplets size={14}/> Sinh Lý Chung</h4>
                                <StatInputControl label="Độ Ẩm Ướt / Dịch (Wetness)" value={localPhysical.genitals?.wetness || 0} max={100} step={1} suffix="%" onChange={(v: number) => updateGenitals({ wetness: v })} colorClass="accent-indigo-400" />
                            </div>
                        )}

                        {/* PATHOLOGY & TRAITS SELECTOR */}
                        <div className="space-y-3 p-4 rounded-xl border border-amber-900/30 bg-amber-950/10">
                            <label className="text-[10px] font-bold text-amber-400 uppercase flex items-center gap-2">
                                <AlertTriangle size={14}/> Bệnh Lý & Đặc Tính (Tự Ghi)
                            </label>
                            <div className="flex flex-col gap-2">
                                <textarea
                                    value={genitalTraitsInput}
                                    onChange={(e) => {
                                        const val = e.target.value;
                                        setGenitalTraitsInput(val);
                                        const traits = val.split(',').map(t => t.trim()).filter(Boolean);
                                        updateGenitals({ traits });
                                    }}
                                    className="w-full h-24 bg-black/40 border border-amber-500/30 rounded-xl p-3 text-xs text-amber-100 placeholder-amber-500/30 outline-none focus:border-amber-500 transition-colors resize-none font-mono"
                                    placeholder="Ví dụ: Siêu Nhạy Cảm, Lồn Khít, Yếu Sinh Lý, Cuồng Dâm... (Ngăn cách bằng dấu phẩy)"
                                />
                                <p className="text-[9px] text-zinc-500 italic text-right">
                                    *Tự động lưu khi nhập. Dùng dấu phẩy (,) để tách các đặc tính.
                                </p>
                            </div>
                        </div>

                        {!hasRod && !hasHole && (
                            <div className="text-center text-zinc-500 text-xs italic py-10">
                                Nhân vật này không có cơ quan sinh dục (Doll/Smooth).
                            </div>
                        )}

                    </div>
                )}
            </div>
        </div>

      </div>
    </div>
  );
};

export default CharacterConfigModal;