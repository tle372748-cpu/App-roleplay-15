
import React, { useState, useRef } from 'react';
import { AppConfig, Tempo, Entropy, SensoryLOD, Psyche, HistoryCard, AIModel, SafetySettings } from '../types';
import { THEMES, AGENCY_MODES_DATA, BACKUP_CATEGORIES } from '../constants';
import { X, Cpu, Zap, Shield, Save, Sliders, EyeOff, Lock, Skull, Activity, Mic2, FastForward, Flag, CloudRain, Users, Ghost, AlertTriangle, BookOpen, Upload, FileClock, Trash2, Edit2, Sparkles, ArrowDownToLine, Loader2, HelpCircle, FileText, Info, Target, Book, Wand2, Heart, Feather, Flame, Brain, Baby, MessageSquare, Dog, Minimize2, MessageCircle, RefreshCw, Feather as FeatherIcon, Scale, AlertOctagon } from 'lucide-react';
import { cleanChatLogWithAI, autoPickAgencyModes } from '../services/aiService';

interface AdvancedSettingsModalProps {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  onClose: () => void;
  onFastReload?: () => void; 
}

interface HelpDetailContent {
    title: string;
    overview: string;
    impact: string[];
}

// REMOVED TABS: 'LỚP THỰC TẠI', 'CÔNG CỤ BETA', 'DỰ PHÒNG'
const Tabs = ['QUYỀN HẠN', 'NÂNG CAO', 'KÝ ỨC', 'MESSENGER'];

const ADVANCED_EXPLANATIONS = [
    { title: "Temperature (0.0 - 2.0)", desc: "Độ ngẫu nhiên sáng tạo (Cao = Điên rồ)." },
    { title: "Top P (Nucleus)", desc: "Bộ lọc đa dạng từ vựng." },
    { title: "Top K", desc: "Giới hạn lựa chọn token." },
    { title: "Prose Density", desc: "Mật độ văn chương (Đối thoại vs Tả cảnh)." },
    { title: "Logical Adherence", desc: "Độ bám sát logic (Bay bổng vs Thực tế)." },
    { title: "Tempo", desc: "Tốc độ mô phỏng (Thời gian thực vs Điện ảnh)." },
    { title: "Entropy", desc: "Mức độ hỗn loạn và ngẫu nhiên." },
    { title: "Sensory LOD", desc: "Mức độ chi tiết của mô tả giác quan." },
    { title: "Psyche", desc: "Độ ổn định cảm xúc của nhân vật." },
];

const HELP_DETAILS_MAP: Record<string, HelpDetailContent> = {};

const getHelpContent = (id: string, label: string, desc: string): HelpDetailContent => {
    if (HELP_DETAILS_MAP[id]) return HELP_DETAILS_MAP[id];
    if (HELP_DETAILS_MAP[label]) return HELP_DETAILS_MAP[label]; 

    return {
        title: label,
        overview: desc,
        impact: [
            `Chế độ này ảnh hưởng đến "${label}".`,
            `Thay đổi logic xử lý của hệ thống.`
        ]
    };
};

const ConfigSection: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode; colors: any }> = ({ title, icon, children, colors }) => (
  <div className={`p-4 rounded-xl border ${colors.border} ${colors.bgPanel} space-y-4`}>
    <div className={`flex items-center gap-2 border-b ${colors.border} pb-2`}>
      <div className={colors.accent}>{icon}</div>
      <h3 className={`font-mono font-bold text-xs md:text-sm uppercase tracking-wider ${colors.textMain}`}>{title}</h3>
    </div>
    {children}
  </div>
);

const RangeControl: React.FC<{ label: string; value: number; min: number; max: number; step: number; onChange: (val: number) => void; colors: any; desc?: string }> = ({ label, value, min, max, step, onChange, colors, desc }) => (
  <div className="space-y-2">
    <div className="flex justify-between items-center">
      <span className={`text-xs font-bold font-mono uppercase ${colors.textDim}`}>{label}</span>
      <span className={`text-xs font-mono font-bold ${colors.textMain}`}>{value}</span>
    </div>
    <input 
      type="range" 
      min={min} max={max} step={step} 
      value={value} 
      onChange={(e) => onChange(parseFloat(e.target.value))}
      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-current"
      style={{ color: 'inherit' }}
    />
    {desc && <p className={`text-[10px] ${colors.textDim} opacity-70`}>{desc}</p>}
  </div>
);

const MilestoneSlider: React.FC<{ 
    label: string; 
    value: number; 
    onChange: (val: number) => void; 
    options: string[]; 
    colorClass: string;
    icon: React.ReactNode;
    min?: number;
}> = ({ label, value, onChange, options, colorClass, icon, min = 0 }) => {
    const effectiveValue = Math.max(min, value);
    return (
        <div className="space-y-3 pt-2">
            <div className="flex justify-between items-center">
                <div className={`flex items-center gap-2 font-mono font-bold text-xs uppercase ${colorClass}`}>
                    {icon} {label}
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded bg-black/40 border border-white/10 ${colorClass}`}>
                    {options[effectiveValue]}
                </span>
            </div>
            <div className="relative h-6 flex items-center">
                <div className="absolute w-full h-1.5 bg-gray-800 rounded-full">
                    <div 
                        className={`h-full rounded-full transition-all duration-300 ${colorClass.replace('text-', 'bg-')}`} 
                        style={{ width: `${(effectiveValue / (options.length - 1)) * 100}%` }}
                    ></div>
                </div>
                <div className="absolute w-full flex justify-between px-0.5 pointer-events-none">
                    {options.map((_, idx) => (
                        <div key={idx} className={`w-1.5 h-1.5 rounded-full ${idx <= effectiveValue ? 'bg-white' : 'bg-gray-600'} ${idx < min ? 'opacity-20' : ''}`}></div>
                    ))}
                </div>
                <input 
                    type="range" 
                    min={min} max={options.length - 1} step={1} 
                    value={effectiveValue} 
                    onChange={(e) => onChange(parseInt(e.target.value))}
                    className="w-full h-6 opacity-0 cursor-pointer absolute z-20"
                />
                <div 
                    className={`absolute w-4 h-4 rounded-full border-2 border-white shadow-md transition-all duration-200 pointer-events-none ${colorClass.replace('text-', 'bg-')}`}
                    style={{ left: `calc(${(effectiveValue / (options.length - 1)) * 100}% - 8px)` }}
                ></div>
            </div>
        </div>
    );
};

const SelectGrid: React.FC<{ options: string[]; current: string; onChange: (val: any) => void; colors: any }> = ({ options, current, onChange, colors }) => (
  <div className="grid grid-cols-2 gap-2">
    {options.map(opt => (
      <button
        key={opt}
        onClick={() => onChange(opt)}
        className={`px-3 py-2 rounded border text-[10px] font-bold font-mono uppercase transition-all
          ${current === opt 
            ? `${colors.activeItem} ${colors.accent}` 
            : `${colors.inputBg} ${colors.border} ${colors.textDim} hover:${colors.textMain}`}
        `}
      >
        {opt}
      </button>
    ))}
  </div>
);

const ToggleSwitch: React.FC<{ active: boolean; onClick: () => void }> = ({ active, onClick }) => (
  <button 
    onClick={onClick}
    className={`w-10 h-5 rounded-full relative transition-colors duration-200 ease-in-out ${active ? 'bg-green-500' : 'bg-gray-700'}`}
  >
    <div className={`absolute top-1 w-3 h-3 rounded-full bg-white shadow-sm transform transition-transform duration-200 ${active ? 'translate-x-6' : 'translate-x-1'}`} />
  </button>
);

const AdvancedSettingsModal: React.FC<AdvancedSettingsModalProps> = ({ config, setConfig, onClose, onFastReload }) => {
  const [activeTab, setActiveTab] = useState('QUYỀN HẠN');
  const [showHelp, setShowHelp] = useState(false);
  const [selectedHelpDetail, setSelectedHelpDetail] = useState<HelpDetailContent | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [editingCardId, setEditingCardId] = useState<string | null>(null);
  const [editNameValue, setEditNameValue] = useState('');
  const [editContentValue, setEditContentValue] = useState('');
  const [isProcessingCardId, setIsProcessingCardId] = useState<string | null>(null);

  const theme = THEMES.find(t => t.id === config.theme) || THEMES[0];
  const t = theme.colors;

  const updateConfig = (key: keyof AppConfig, value: any) => {
    setConfig(prev => ({ ...prev, [key]: value }));
  };

  const updateBias = (key: keyof AppConfig['biases'], value: number) => {
      setConfig(prev => ({
          ...prev,
          biases: {
              ...(prev.biases || { lewdness: 0, cruelness: 0, flawless: 2, softness: 2, love: 0 }),
              [key]: value
          }
      }));
  };

  const updateSafety = (key: keyof SafetySettings, value: number) => {
      // Direct update to prevent slider lock issues
      setConfig(prev => ({
          ...prev,
          safety: {
              ...(prev.safety || { harassment: 1, hateSpeech: 1, sexuallyExplicit: 1, dangerousContent: 1 }),
              [key]: value
          }
      }));
  };

  const updateMessengerConfig = (key: keyof NonNullable<AppConfig['messengerConfig']>, val: any) => {
      setConfig(prev => ({
          ...prev,
          messengerConfig: {
              ...prev.messengerConfig!,
              [key]: val
          }
      }));
  };

  const handleHistoryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files.length > 0) {
          const file = e.target.files[0];
          const reader = new FileReader();
          reader.onload = (event) => {
              const text = event.target?.result as string;
              if (text) {
                  let content = text;
                  let name = file.name.replace(/\.[^/.]+$/, "");
                  let sourceType: any = 'FILE';
                  try {
                      const json = JSON.parse(text);
                      if (json.messages && Array.isArray(json.messages)) {
                          content = json.messages.map((m: any) => `[${m.role === 'user' ? 'User' : 'Char'}]: ${m.content}`).join('\n');
                          sourceType = 'EXPORT_JSON';
                      }
                  } catch (e) {}
                  const newCard: HistoryCard = { id: `hist-${Date.now()}`, name: name, content: content, dateAdded: Date.now(), sourceType: sourceType };
                  setConfig(prev => ({ ...prev, historyCards: [...(prev.historyCards || []), newCard] }));
              }
          };
          reader.readAsText(file);
          e.target.value = '';
      }
  };
  const deleteHistoryCard = (id: string) => { setConfig(prev => ({ ...prev, historyCards: prev.historyCards.filter(c => c.id !== id) })); };
  const startEditCard = (card: HistoryCard) => { setEditingCardId(card.id); setEditNameValue(card.name); setEditContentValue(card.content); };
  const saveEditCard = (id: string) => { if (editNameValue.trim()) { setConfig(prev => ({ ...prev, historyCards: prev.historyCards.map(c => c.id === id ? { ...c, name: editNameValue, content: editContentValue, sourceType: 'MANUAL' } : c) })); } setEditingCardId(null); };
  const handleAIClean = async (card: HistoryCard) => { if (isProcessingCardId) return; setIsProcessingCardId(card.id); try { const cleanedText = await cleanChatLogWithAI(card.content); setConfig(prev => ({ ...prev, historyCards: prev.historyCards.map(c => c.id === card.id ? { ...c, content: cleanedText, sourceType: 'AI_EXTRACT' } : c) })); } catch (e) { console.error("AI Clean Failed", e); } finally { setIsProcessingCardId(null); } };

  const getProactivityLabel = (val: number) => { if (val < 20) return "Thụ Động (Chỉ Phản Ứng)"; if (val < 45) return "Thụ Động (Chờ User)"; if (val < 65) return "Cân Bằng (Lành Mạnh)"; if (val < 85) return "Chủ Động (Dẫn Dắt)"; return "Hổ Báo (Chiếm Quyền)"; };
  const getGodmodeLabel = (val: number) => { if (val === 0) return "CẤM TUYỆT ĐỐI (None)"; if (val === 1) return "Chỉ Hành Động (Không Thoại)"; if (val === 2) return "Lai (Cho Phép Thoại Ít)"; if (val === 3) return "Godmode (Toàn Quyền)"; return "Unknown"; };
  const getTimeSkipLabel = (val: number) => { if (val === 0) return "Thời Gian Thực (Không Tua)"; if (val === 1) return "Tua Ít (Phút/Giờ)"; if (val === 2) return "Tua Nhiều (Ngày/Tuần)"; if (val === 3) return "Điện Ảnh (Năm/Kỷ Nguyên)"; return "Unknown"; };
  const getPacingLabel = (val: number) => { if (val <= 2) return "Chậm Rì (Vi Mô)"; if (val <= 5) return "Chậm Rãi (Thơ)"; if (val <= 9) return "Thong Thả"; if (val <= 13) return "Tiêu Chuẩn (Tự Nhiên)"; if (val <= 16) return "Nhanh (Hành Động)"; return "Chớp Nhoáng (Cực Nhanh)"; };
  const handleOpenDetail = (id: string, label: string, desc: string) => { setSelectedHelpDetail(getHelpContent(id, label, desc)); };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className={`w-full max-w-2xl ${t.bgPanel} border ${t.border} rounded-xl shadow-2xl flex flex-col max-h-[85vh]`}>
        
        {/* Header */}
        <div className={`flex items-center justify-between p-4 border-b ${t.border} ${t.bgMain} rounded-t-xl shrink-0`}>
          <div className={`flex items-center gap-2 ${t.accent} overflow-hidden`}>
            <Cpu size={20} className="shrink-0" />
            <h2 className="font-mono font-bold tracking-widest text-lg truncate">CẤU HÌNH HỆ THỐNG (RÚT GỌN)</h2>
          </div>
          <div className="flex items-center gap-2">
              <button onClick={onClose} className={`${t.textDim} hover:${t.textMain} transition-colors shrink-0 ml-2`}>
                <X size={20} />
              </button>
          </div>
        </div>

        <div className={`flex border-b ${t.border} ${t.bgPanel} overflow-x-auto shrink-0 custom-scrollbar`}>
          {Tabs.map(tab => {
              if (tab === 'MESSENGER' && !config.messengerConfig?.enabled) return null; 
              return (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`min-w-fit px-4 py-3 text-xs md:text-sm font-mono font-bold tracking-wider transition-colors whitespace-nowrap
                    ${activeTab === tab ? `${t.textMain} border-b-2 border-current ${t.inputBg}` : `${t.textDim} hover:${t.textMain}`}
                  `}
                >
                  {tab}
                </button>
              );
          })}
        </div>

        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar space-y-8">
          
          {/* TAB: QUYỀN HẠN (STRIPPED) */}
          {activeTab === 'QUYỀN HẠN' && (
             <div className="space-y-8">
                 <div className="p-4 rounded-lg bg-blue-900/10 border border-blue-500/30">
                    <div className="flex items-center gap-2 mb-2 text-blue-400">
                        <Activity size={18} />
                        <h3 className="font-mono font-bold text-sm uppercase">Cơ Chế Điều Khiển</h3>
                    </div>
                    <p className="text-xs text-blue-300/80 font-mono leading-relaxed">
                        Các thiết lập cơ bản về hành vi của AI. Các mô-đun nâng cao đã bị loại bỏ theo yêu cầu.
                    </p>
                 </div>

                 <div className="space-y-4">
                    <div className="flex justify-between items-end">
                        <div className="flex items-center gap-2 text-yellow-400">
                            <Zap size={16} />
                            <span className="font-mono font-bold text-xs uppercase tracking-wider">Độ Chủ Động AI</span>
                        </div>
                        <span className="font-mono text-xs font-bold text-yellow-200 bg-yellow-900/40 px-2 py-1 rounded border border-yellow-500/30">
                            {getProactivityLabel(config.aiProactivity || 50)}
                        </span>
                    </div>
                    <input 
                        type="range" 
                        min="0" max="100" step="5" 
                        value={config.aiProactivity || 50} 
                        onChange={(e) => updateConfig('aiProactivity', parseInt(e.target.value))}
                        className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-yellow-500"
                    />
                 </div>

                 <div className={`h-px w-full ${t.border} bg-current opacity-10`} />

                 <div className="space-y-4">
                    <div className="flex justify-between items-end">
                        <div className="flex items-center gap-2 text-red-400">
                            <Mic2 size={16} />
                            <span className="font-mono font-bold text-xs uppercase tracking-wider">Quyền Lực User (Godmode)</span>
                        </div>
                        <span className="font-mono text-xs font-bold text-red-200 bg-red-900/40 px-2 py-1 rounded border border-red-500/30">
                            {getGodmodeLabel(config.aiSpeakForUser || 0)}
                        </span>
                    </div>
                    <input 
                        type="range" 
                        min="0" max="3" step="1" 
                        value={config.aiSpeakForUser || 0} 
                        onChange={(e) => updateConfig('aiSpeakForUser', parseInt(e.target.value))}
                        className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-red-500"
                    />
                 </div>

                 <div className={`h-px w-full ${t.border} bg-current opacity-10`} />

                 <div className="space-y-4">
                    <div className="flex justify-between items-end">
                        <div className="flex items-center gap-2 text-purple-400">
                            <FastForward size={16} />
                            <span className="font-mono font-bold text-xs uppercase tracking-wider">Quyền Tua Thời Gian</span>
                        </div>
                        <span className="font-mono text-xs font-bold text-purple-200 bg-purple-900/40 px-2 py-1 rounded border border-purple-500/30">
                            {getTimeSkipLabel(config.aiTimeSkip || 0)}
                        </span>
                    </div>
                    <input 
                        type="range" 
                        min="0" max="3" step="1" 
                        value={config.aiTimeSkip || 0} 
                        onChange={(e) => updateConfig('aiTimeSkip', parseInt(e.target.value))}
                        className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-purple-500"
                    />
                 </div>

                 <div className={`h-px w-full ${t.border} bg-current opacity-10`} />

                 <div className="space-y-4">
                    <MilestoneSlider 
                        label="Tốc Độ Dẫn Truyện (Burning Cheese)" 
                        value={config.burningCheese ?? 10} 
                        onChange={(v) => updateConfig('burningCheese', v)}
                        options={Array.from({length: 20}, (_, i) => getPacingLabel(i))}
                        colorClass="text-orange-500"
                        icon={<Flame size={16} />}
                        min={0}
                    />
                 </div>

             </div>
          )}

          {/* TAB: NÂNG CAO (STRIPPED) */}
          {activeTab === 'NÂNG CAO' && (
            <div className="space-y-6">
              
              <div className="p-3 border border-red-900/30 bg-red-950/10 rounded-lg">
                  <h4 className="text-red-400 font-bold text-xs uppercase flex items-center gap-2 mb-2"><AlertOctagon size={16}/> Bộ Lọc An Toàn</h4>
                  <p className="text-[10px] text-zinc-500 italic">Đã xóa bỏ hoàn toàn.</p>
              </div>

              <div className={`h-px w-full ${t.border} bg-current opacity-10`} />

              {/* PROSE & LOGIC */}
              <ConfigSection title="VĂN PHONG & LOGIC" icon={<FeatherIcon size={16} />} colors={t}>
                  <div className="space-y-6 p-2">
                      <MilestoneSlider 
                          label="Mật Độ Văn Chương (Prose Density)" 
                          value={Math.round((config.proseDensity ?? 0.5) * 10)} 
                          onChange={(v) => updateConfig('proseDensity', v / 10)} 
                          options={['Thuần Đối Thoại', 'Script', 'Hỗn Hợp', 'Cân Bằng', 'Giàu Cảm Xúc', 'Văn Hào', 'Tiểu Thuyết']}
                          colorClass="text-indigo-400"
                          icon={<FeatherIcon size={16} />}
                          min={0}
                      />
                      
                      <MilestoneSlider 
                          label="Độ Bám Sát Logic (Logical Adherence)" 
                          value={Math.round((config.logicalAdherence ?? 0.5) * 10)} 
                          onChange={(v) => updateConfig('logicalAdherence', v / 10)} 
                          options={['Mơ Mộng (Dreamy)', 'Hư Cấu', 'Lỏng Lẻo', 'Cân Bằng', 'Logic Chặt', 'Thực Tế (Strict)']}
                          colorClass="text-teal-400"
                          icon={<Scale size={16} />}
                          min={0}
                      />
                  </div>
              </ConfigSection>

              <ConfigSection title="CHẾ ĐỘ ĐẶC BIỆT (Agency Modes)" icon={<Wand2 size={16} />} colors={t}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-2">
                      {AGENCY_MODES_DATA.map(mode => {
                          const isActive = config.agencyModes?.includes(mode.id);
                          return (
                              <button
                                  key={mode.id}
                                  onClick={() => {
                                      const currentModes = config.agencyModes || [];
                                      const newModes = isActive 
                                          ? currentModes.filter(m => m !== mode.id)
                                          : [...currentModes, mode.id];
                                      updateConfig('agencyModes', newModes);
                                  }}
                                  className={`p-3 rounded-lg border text-left transition-all ${
                                      isActive 
                                          ? 'bg-purple-900/30 border-purple-500/50 shadow-[0_0_15px_rgba(168,85,247,0.15)]' 
                                          : 'bg-black/40 border-white/10 hover:border-white/20 hover:bg-white/5'
                                  }`}
                              >
                                  <div className="flex items-center justify-between mb-1">
                                      <span className={`text-xs font-bold uppercase ${isActive ? 'text-purple-400' : 'text-zinc-400'}`}>
                                          {mode.label}
                                      </span>
                                      {isActive && <div className="w-2 h-2 rounded-full bg-purple-500 shadow-[0_0_5px_rgba(168,85,247,0.8)]" />}
                                  </div>
                                  <p className="text-[10px] text-zinc-500 leading-relaxed">
                                      {mode.desc}
                                  </p>
                              </button>
                          );
                      })}
                  </div>
              </ConfigSection>

              <ConfigSection title="THÔNG SỐ THẦN KINH (AI Tuning)" icon={<Sliders size={16} />} colors={t}>
                <div className="grid grid-cols-1 gap-6 p-2">
                  <RangeControl label="Temperature" value={config.temperature} min={0} max={2} step={0.1} onChange={(v) => updateConfig('temperature', v)} colors={t} desc="Cao = Sáng tạo ngẫu nhiên. Thấp = Chính xác, lặp lại." />
                  <RangeControl label="Top P" value={config.topP} min={0} max={1} step={0.01} onChange={(v) => updateConfig('topP', v)} colors={t} desc="Kiểm soát sự đa dạng từ vựng." />
                  <RangeControl label="Top K" value={config.topK} min={1} max={128} step={1} onChange={(v) => updateConfig('topK', v)} colors={t} desc="Giới hạn lựa chọn token." />
                </div>
              </ConfigSection>
              <div className={`h-px w-full ${t.border} bg-current opacity-10`} />
              <ConfigSection title="DÒNG THỜI GIAN (Tempo)" icon={<Zap size={16} />} colors={t}>
                <SelectGrid options={Object.values(Tempo)} current={config.tempo} onChange={(v) => updateConfig('tempo', v)} colors={t} />
              </ConfigSection>
              <ConfigSection title="MỨC ĐỘ HỖN LOẠN (Entropy)" icon={<Zap size={16} />} colors={t}>
                <SelectGrid options={Object.values(Entropy)} current={config.entropy} onChange={(v) => updateConfig('entropy', v)} colors={t} />
              </ConfigSection>
              <ConfigSection title="ĐỘ CHI TIẾT GIÁC QUAN (Sensory)" icon={<Zap size={16} />} colors={t}>
                <SelectGrid options={Object.values(SensoryLOD)} current={config.sensory} onChange={(v) => updateConfig('sensory', v)} colors={t} />
              </ConfigSection>
              <ConfigSection title="ĐỘ ỔN ĐỊNH TÂM LÝ (Psyche)" icon={<Zap size={16} />} colors={t}>
                <SelectGrid options={Object.values(Psyche)} current={config.psyche} onChange={(v) => updateConfig('psyche', v)} colors={t} />
              </ConfigSection>
            </div>
          )}

          {/* TAB: KÝ ỨC (UNCHANGED) */}
          {activeTab === 'KÝ ỨC' && (
              <div className="space-y-6">
                  <div className="p-4 rounded-lg bg-indigo-900/10 border border-indigo-500/30">
                      <div className="flex items-center gap-2 mb-2 text-indigo-400">
                          <BookOpen size={18} />
                          <h3 className="font-mono font-bold text-sm uppercase">Ký Ức Dài Hạn</h3>
                      </div>
                      <p className="text-xs text-indigo-300/80 font-mono leading-relaxed">
                          Phần này chứa tóm tắt cốt truyện mà AI ghi nhớ ngay cả khi bạn xóa nhật ký trò chuyện.
                      </p>
                  </div>
                  
                  <div className={`h-px w-full ${t.border} bg-current opacity-10`} />

                  <div className="flex flex-col gap-4">
                      <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2 text-cyan-400">
                              <FileClock size={16} />
                              <span className="font-mono font-bold text-xs uppercase tracking-wider">Lưu Trữ Lịch Sử / Thẻ Ngữ Cảnh</span>
                          </div>
                          <button 
                              onClick={() => fileInputRef.current?.click()}
                              className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-mono font-bold text-[10px] flex items-center gap-2 uppercase transition-all"
                          >
                              <Upload size={12} /> Tải File Lên
                          </button>
                          <input type="file" ref={fileInputRef} className="hidden" accept=".txt,.json" onChange={handleHistoryUpload} />
                      </div>

                      <div className="flex flex-col gap-2">
                          {(config.historyCards || []).length === 0 ? (
                              <div className="p-4 border border-dashed border-white/10 rounded-lg text-center text-xs text-gray-500 font-mono">
                                  Chưa có file lịch sử. Tải lên bản xuất (.json) hoặc file text (.txt) để cung cấp bối cảnh quá khứ cho AI.
                              </div>
                          ) : (
                              (config.historyCards || []).map((card) => (
                                  <div key={card.id} className="p-3 rounded border bg-cyan-900/10 border-cyan-500/20 flex flex-col gap-2 group relative">
                                      {editingCardId === card.id ? (
                                          <div className="flex flex-col gap-2 w-full animate-in fade-in">
                                              <input type="text" value={editNameValue} onChange={(e) => setEditNameValue(e.target.value)} className="bg-black/40 border border-cyan-500/50 rounded px-2 py-1 text-xs font-mono text-white outline-none w-full" placeholder="Tên thẻ..." autoFocus />
                                              <textarea value={editContentValue} onChange={(e) => setEditContentValue(e.target.value)} className="bg-black/40 border border-cyan-500/50 rounded px-2 py-2 text-[10px] font-mono text-white outline-none w-full h-64 resize-none" placeholder="Nội dung..." />
                                              <div className="flex justify-end gap-2">
                                                  <button onClick={() => setEditingCardId(null)} className="text-zinc-500 hover:text-white text-[10px] px-2 py-1">Hủy</button>
                                                  <button onClick={() => saveEditCard(card.id)} className="bg-green-600 hover:bg-green-500 text-white rounded px-3 py-1 text-[10px] font-bold uppercase">Lưu</button>
                                              </div>
                                          </div>
                                      ) : (
                                          <>
                                              <div className="flex justify-between items-center">
                                                  <div className="flex items-center gap-2 overflow-hidden flex-1">
                                                      <FileClock size={14} className="text-cyan-500 shrink-0" />
                                                      <span className="text-xs font-bold font-mono text-cyan-100 truncate">{card.name}</span>
                                                      <span className="text-[9px] text-cyan-600 font-mono bg-cyan-900/30 px-1 rounded">{card.sourceType}</span>
                                                  </div>
                                                  <div className="flex gap-1 items-center">
                                                      <button onClick={() => handleAIClean(card)} disabled={isProcessingCardId === card.id} className={`p-1.5 rounded hover:bg-white/10 ${isProcessingCardId === card.id ? 'text-yellow-400 animate-pulse' : 'text-cyan-400 hover:text-cyan-200'} transition-colors`} title="AI Dọn Dẹp">{isProcessingCardId === card.id ? <Loader2 size={12} className="animate-spin"/> : <Sparkles size={12}/>}</button>
                                                      <button onClick={() => startEditCard(card)} className="p-1.5 rounded hover:bg-white/10 text-gray-400 hover:text-white transition-colors" title="Sửa"><Edit2 size={12}/></button>
                                                      <button onClick={() => deleteHistoryCard(card.id)} className="p-1.5 rounded hover:bg-red-500/20 text-red-500/50 hover:text-red-400 transition-colors" title="Xóa"><Trash2 size={12}/></button>
                                                  </div>
                                              </div>
                                              <div className="text-[10px] font-mono text-gray-400 line-clamp-3 bg-black/20 p-2 rounded border border-white/5">{card.content.substring(0, 300)}...</div>
                                          </>
                                      )}
                                  </div>
                              ))
                          )}
                      </div>
                  </div>
              </div>
          )}

          {activeTab === 'MESSENGER' && config.messengerConfig?.enabled && (
              <div className="space-y-6 animate-in slide-in-from-right-4 fade-in duration-300">
                  <ConfigSection title="CẤU HÌNH NHẮN TIN (MESSENGER)" icon={<MessageSquare size={16} />} colors={t}>
                      <div className="space-y-4 p-2">
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                  <label className="text-[10px] font-bold text-zinc-500 uppercase mb-1 block">Tone (Thái Độ)</label>
                                  <select 
                                      value={config.messengerConfig.tone} 
                                      onChange={(e) => updateMessengerConfig('tone', e.target.value)}
                                      className="w-full bg-black/40 border border-white/10 rounded p-2 text-xs text-white outline-none focus:border-blue-500"
                                  >
                                      {["Casual", "Flirty", "Cold", "Angry", "Cute", "Clingy"].map(opt => (
                                          <option key={opt} value={opt}>{opt}</option>
                                      ))}
                                  </select>
                              </div>
                              <div>
                                  <label className="text-[10px] font-bold text-zinc-500 uppercase mb-1 block">Tốc độ Gõ (Delay)</label>
                                  <div className="flex items-center gap-2">
                                      <input 
                                          type="range" 
                                          min="0.5" max="3.0" step="0.1" 
                                          value={config.messengerConfig.typingSpeed} 
                                          onChange={(e) => updateMessengerConfig('typingSpeed', parseFloat(e.target.value))}
                                          className="flex-1 h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                                      />
                                      <span className="text-xs font-mono w-10 text-right">{config.messengerConfig.typingSpeed}x</span>
                                  </div>
                              </div>
                          </div>

                          <div className="flex items-center justify-between p-3 bg-black/30 rounded-lg border border-white/5">
                              <div className="flex flex-col">
                                  <span className="text-xs font-bold text-white uppercase">Cho Phép Emoji</span>
                                  <span className="text-[10px] text-zinc-500">AI sẽ học dùng icon cảm xúc.</span>
                              </div>
                              <ToggleSwitch active={config.messengerConfig.allowEmoji} onClick={() => updateMessengerConfig('allowEmoji', !config.messengerConfig.allowEmoji)} />
                          </div>

                          <div className="flex items-center justify-between p-3 bg-black/30 rounded-lg border border-white/5">
                              <div className="flex flex-col">
                                  <span className="text-xs font-bold text-white uppercase">Chế Độ Hối Thúc (Nudge)</span>
                                  <span className="text-[10px] text-zinc-500">Tự nhắn tin (Flash) sau 5p im lặng.</span>
                              </div>
                              <ToggleSwitch active={config.messengerConfig.nudgeEnabled} onClick={() => updateMessengerConfig('nudgeEnabled', !config.messengerConfig.nudgeEnabled)} />
                          </div>

                          <div className="space-y-2">
                              <div className="flex justify-between text-[10px] font-bold text-zinc-500 uppercase">
                                  <span>Số Tin Tối Đa (Max Burst)</span>
                                  <span className="text-white">{config.messengerConfig.maxBurst}</span>
                              </div>
                              <input 
                                  type="range" 
                                  min="1" max="6" step="1" 
                                  value={config.messengerConfig.maxBurst} 
                                  onChange={(e) => updateMessengerConfig('maxBurst', parseInt(e.target.value))}
                                  className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                              />
                              <p className="text-[10px] text-zinc-600 italic">Số lượng tin nhắn liên tục tối đa AI có thể gửi một lần.</p>
                          </div>

                      </div>
                  </ConfigSection>
              </div>
          )}

        </div>

        {/* Footer */}
        <div className={`p-4 border-t ${t.border} ${t.bgMain} flex justify-end`}>
          <button 
            onClick={onClose}
            className="px-6 py-2 bg-nano-600 hover:bg-nano-500 text-white font-mono font-bold rounded text-sm flex items-center gap-2 shadow-[0_0_15px_rgba(14,165,233,0.3)] transition-all active:scale-95"
          >
            <Save size={16} />
            ÁP DỤNG & ĐỒNG BỘ
          </button>
        </div>
      </div>

    </div>
  );
};

export default AdvancedSettingsModal;
