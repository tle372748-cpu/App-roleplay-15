import React, { useState } from 'react';
import { X, Brain, Plus, Trash2, Search, Wand2, Loader2, FileText, Activity } from 'lucide-react';
import { AppConfig, VectorMemoryItem, ChatMessage } from '../types';
import { getAI, cleanJson } from '../services/aiService';

interface VectorMemoryModalProps {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  onClose: () => void;
  themeColors?: any;
  messages: ChatMessage[]; 
}

const VectorMemoryModal: React.FC<VectorMemoryModalProps> = ({ config, setConfig, onClose, themeColors, messages }) => {
  const [memories, setMemories] = useState<VectorMemoryItem[]>(config.vectorDb || []);
  const [newKeys, setNewKeys] = useState('');
  const [newContent, setNewContent] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [extractInput, setExtractInput] = useState('');
  const [isExtracting, setIsExtracting] = useState(false);
  const [activeTab, setActiveTab] = useState<'AUTO_KIUC' | 'VECTOR_DB'>('AUTO_KIUC');

  const addMemory = () => {
      if (!newKeys.trim() || !newContent.trim()) return;
      
      const newItem: VectorMemoryItem = {
          id: `mem-${Date.now()}`,
          keys: newKeys.split(',').map(k => k.trim()).filter(k => k.length > 0),
          memory: newContent.trim(),
          isActive: true,
          activationCount: 0
      };

      const updated = [newItem, ...memories];
      setMemories(updated);
      setConfig(prev => ({ ...prev, vectorDb: updated }));
      
      setNewKeys('');
      setNewContent('');
  };

  const removeMemory = (id: string) => {
      const updated = memories.filter(m => m.id !== id);
      setMemories(updated);
      setConfig(prev => ({ ...prev, vectorDb: updated }));
  };

  const toggleActive = (id: string) => {
      const updated = memories.map(m => m.id === id ? { ...m, isActive: !m.isActive } : m);
      setMemories(updated);
      setConfig(prev => ({ ...prev, vectorDb: updated }));
  };

  const handleAutoExtract = async () => {
      setIsExtracting(true);
      
      try {
          const ai = getAI(config);
          let textToAnalyze = extractInput.trim();
          let mode = "TEXT_SNIPPET";

          if (!textToAnalyze) {
              if (messages.length === 0) {
                  alert("Chat history is empty. Type something or chat first.");
                  setIsExtracting(false);
                  return;
              }
              mode = "FULL_HISTORY";
              textToAnalyze = messages
                  .filter(m => m.role !== 'system' && m.role !== 'nano_quasar')
                  .map(m => `[${m.role === 'user' ? 'User' : 'Character'}]: ${m.content}`)
                  .join('\n');
          }

          const prompt = `
          [SYSTEM]: MEMORY_EXTRACTION_ENGINE
          [MODE]: ${mode}
          [TASK]: Analyze the provided text/history and extract CRITICAL LONG-TERM MEMORIES.
          
          [INPUT DATA]:
          """
          ${textToAnalyze}
          """
          
          [INSTRUCTION]:
          1. Identify specific facts, preferences, events, or secrets that should be remembered forever.
          2. Ignore casual greetings or trivial chit-chat.
          3. Consolidate multiple findings into a single coherent memory block or a list of facts.
          4. Generate relevant trigger keywords (Keys).

          [OUTPUT FORMAT - JSON ONLY]:
          {
            "keys": ["key1", "key2", "key3"],
            "memory": "concise_summary_of_important_facts"
          }
          `;
          
          if (!ai) {
             alert('Missing API Key');
             return;
          }
          const result = await ai.models.generateContent({
              model: "gemini-3.5-flash",
              contents: [{ parts: [{ text: prompt }] }],
              config: { responseMimeType: "application/json" }
          });
          
          const data = JSON.parse(cleanJson(result.text || "{}"));
          
          if (data.keys && data.memory) {
              setNewKeys(Array.isArray(data.keys) ? data.keys.join(', ') : data.keys);
              setNewContent(data.memory);
              if (mode === "TEXT_SNIPPET") setExtractInput('');
          } else {
              alert("Could not extract memory.");
          }
      } catch (e) {
          console.error(e);
          alert("Extraction failed. Check API Key.");
      } finally {
          setIsExtracting(false);
      }
  };

  const filteredMemories = memories.filter(m => 
      m.memory.toLowerCase().includes(searchTerm.toLowerCase()) || 
      m.keys.some(k => k.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
      <div className="w-full max-w-2xl bg-[#09090b] border border-cyan-500/30 rounded-xl shadow-[0_0_50px_rgba(6,182,212,0.2)] flex flex-col h-[85vh] overflow-hidden relative">
        
        {/* HEADER */}
        <div className="flex flex-col shrink-0 border-b border-cyan-500/20 bg-cyan-950/20">
            <div className="p-4 flex justify-between items-center">
                <div className="flex items-center gap-3 text-cyan-400">
                    <Brain size={24} />
                    <div>
                        <h2 className="font-mono font-black uppercase tracking-widest text-lg text-white">SYSTEM MEMORY</h2>
                        <p className="text-[10px] font-mono text-cyan-400/60 uppercase">Cortex DB & Auto-Kiuc Tracking</p>
                    </div>
                </div>
                <button onClick={onClose} className="p-2 text-zinc-500 hover:text-white transition-colors"><X size={20} /></button>
            </div>
            
            <div className="flex gap-2 px-4 shadow-[inset_0_-2px_0_rgba(255,255,255,0.05)] overflow-x-auto custom-scrollbar">
                <button 
                    onClick={() => setActiveTab('AUTO_KIUC')}
                    className={`pb-3 px-2 text-xs font-mono font-bold uppercase transition-colors whitespace-nowrap ${activeTab === 'AUTO_KIUC' ? 'border-b-2 border-cyan-400 text-cyan-300' : 'text-zinc-500 hover:text-zinc-300'}`}
                >
                    <Activity size={12} className="inline mr-2" /> Auto-Kiuc (Timeline)
                </button>
                <button 
                    onClick={() => setActiveTab('VECTOR_DB')}
                    className={`pb-3 px-2 text-xs font-mono font-bold uppercase transition-colors whitespace-nowrap ${activeTab === 'VECTOR_DB' ? 'border-b-2 border-cyan-400 text-cyan-300' : 'text-zinc-500 hover:text-zinc-300'}`}
                >
                    <Brain size={12} className="inline mr-2" /> Cortex DB (Vector)
                </button>
            </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-6">
            
            {activeTab === 'AUTO_KIUC' && (
                <div className="flex flex-col h-full space-y-4 animate-in fade-in">
                    <div className="flex justify-between items-center">
                        <div className="text-xs font-mono font-bold text-cyan-400 uppercase">Core Narrative Timeline</div>
                        <div className="text-[10px] text-zinc-500 font-mono">Auto-updates every ~10 messages</div>
                    </div>
                    <p className="text-xs text-zinc-400 font-mono leading-relaxed">
                        This is the continuous long-term memory of the AI. It records major story beats over time so characters don't suffer amnesia. You can edit this manually if the AI makes a mistake or gets confused.
                    </p>
                    <textarea
                        value={config.autokiuc || ''}
                        onChange={(e) => setConfig(prev => ({ ...prev, autokiuc: e.target.value }))}
                        placeholder="Empty timeline."
                        className="flex-1 w-full min-h-[300px] bg-[#0a0a0c] border border-cyan-900/50 rounded-lg p-4 text-xs font-mono text-zinc-300 outline-none focus:border-cyan-500/50 resize-y leading-loose"
                    />
                    <div className="flex justify-between items-center bg-black/40 p-3 rounded border border-white/5 mt-4 text-zinc-500 hover:text-zinc-300 transition-colors">
                        <span className="text-[10px] font-mono text-cyan-600">Last Scanned Timestamp: {config.autokiucLastTimestamp}</span>
                        <button 
                            onClick={() => {
                                if (window.confirm('Clearing this timestamp will force the system to manually rescan the whole chat history from scratch. Continue?')) {
                                    setConfig(prev => ({ ...prev, autokiucLastTimestamp: 0, autokiuc: '' }));
                                }
                            }}
                            className="px-3 py-1 bg-red-900/10 text-red-500 hover:text-red-400 text-[10px] uppercase font-bold font-mono rounded hover:bg-red-900/30 border border-red-900/30 transition-all focus:outline-none"
                        >
                            Reset System Scanning
                        </button>
                    </div>
                </div>
            )}

            {activeTab === 'VECTOR_DB' && (
                <div className="space-y-6 animate-in fade-in">
                    {/* ADD NEW SECTION */}
                    <div className="flex flex-col gap-4 bg-zinc-900/50 p-4 rounded-xl border border-white/5">
                        <div className="flex justify-between items-center">
                            <h3 className="text-xs font-bold text-cyan-500 uppercase flex items-center gap-2"><Plus size={14}/> Inject New Memory</h3>
                            <div className="flex gap-2">
                                <button 
                                    onClick={() => setExtractInput(prev => prev ? '' : ' ')} 
                                    className={`text-[10px] font-mono px-2 py-1 rounded border transition-all flex items-center gap-1 ${extractInput ? 'bg-zinc-800 text-zinc-300 border-zinc-700' : 'bg-transparent text-zinc-500 border-transparent hover:text-cyan-400'}`}
                                >
                                    <FileText size={10}/> Manual Drop
                                </button>
                                <button 
                                    disabled={isExtracting}
                                    onClick={handleAutoExtract}
                                    className={`text-[10px] font-mono px-2 py-1 rounded border transition-all flex items-center gap-1 ${isExtracting ? 'bg-zinc-800 text-zinc-500 border-zinc-700' : 'bg-purple-900/30 text-purple-400 border-purple-500/30 hover:bg-purple-900/50'}`}
                                >
                                    {isExtracting ? <Loader2 size={10} className="animate-spin" /> : <Wand2 size={10}/>}
                                    Auto-Extract Chat
                                </button>
                            </div>
                        </div>

                        {extractInput !== '' && (
                            <div className="flex flex-col gap-2">
                                <textarea 
                                    placeholder="Paste specific text here if you don't want to scan the full history..." 
                                    value={extractInput}
                                    onChange={(e) => setExtractInput(e.target.value)}
                                    className="w-full h-24 bg-black/40 border border-white/10 rounded p-3 text-xs text-zinc-300 outline-none focus:border-cyan-500/50 font-mono resize-none"
                                />
                            </div>
                        )}

                        <div className="flex flex-col gap-3">
                            <div className="flex flex-col gap-1">
                                <label className="text-[10px] text-zinc-500 font-mono uppercase">Search Keys (comma separated)</label>
                                <input 
                                    type="text" 
                                    value={newKeys}
                                    onChange={(e) => setNewKeys(e.target.value)}
                                    placeholder="e.g. ring, gold, promise"
                                    className="w-full bg-black/40 border border-white/10 rounded px-3 py-2 text-xs text-white outline-none focus:border-cyan-500/50 font-mono"
                                />
                            </div>
                            <div className="flex flex-col gap-1">
                                <label className="text-[10px] text-zinc-500 font-mono uppercase">Concrete Fact</label>
                                <textarea 
                                    value={newContent}
                                    onChange={(e) => setNewContent(e.target.value)}
                                    placeholder="User gave Anna a gold ring..."
                                    className="w-full h-16 bg-black/40 border border-white/10 rounded p-3 text-xs text-white outline-none focus:border-cyan-500/50 font-mono resize-none leading-relaxed"
                                />
                            </div>
                            <button 
                                onClick={addMemory}
                                className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-bold text-xs uppercase transition-all shadow-lg shadow-cyan-900/20"
                            >
                                Save to Cortex
                            </button>
                        </div>
                    </div>

                    {/* SEARCH & LIST */}
                    <div className="flex flex-col gap-4">
                        <div className="relative">
                            <Search size={14} className="absolute left-3 top-2.5 text-zinc-500" />
                            <input 
                                type="text" 
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                placeholder="Search memories..."
                                className="w-full bg-black/20 border border-white/10 rounded-full pl-9 pr-4 py-2 text-xs text-white outline-none focus:border-white/30"
                            />
                        </div>

                        <div className="grid gap-3">
                            {filteredMemories.length === 0 ? (
                                <div className="text-center text-zinc-700 text-xs italic py-10">Cortex Empty.</div>
                            ) : (
                                filteredMemories.map(mem => (
                                    <div key={mem.id} className={`p-3 rounded-lg border transition-all group relative ${mem.isActive ? 'bg-cyan-900/10 border-cyan-500/30 hover:border-cyan-500/50' : 'bg-black/40 border-white/5 opacity-50'}`}>
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="flex flex-wrap gap-1">
                                                {mem.keys.map((k, i) => (
                                                    <span key={i} className="text-[9px] font-mono text-cyan-400 bg-cyan-950/50 px-1.5 py-0.5 rounded border border-cyan-500/20">{k}</span>
                                                ))}
                                            </div>
                                            <div className="flex items-center gap-2">
                                                {mem.activationCount > 0 && <span className="text-[9px] text-zinc-600 font-mono">Hits: {mem.activationCount}</span>}
                                                <button onClick={() => toggleActive(mem.id)} className={`w-2 h-2 rounded-full transition-all ${mem.isActive ? 'bg-green-500 shadow-[0_0_5px_lime]' : 'bg-red-900'}`}></button>
                                            </div>
                                        </div>
                                        <p className="text-xs text-zinc-300 leading-relaxed font-mono whitespace-pre-wrap">{mem.memory}</p>
                                        
                                        <button 
                                            onClick={() => removeMemory(mem.id)}
                                            className="absolute top-2 right-2 p-1.5 bg-black/60 rounded text-zinc-500 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                                        >
                                            <Trash2 size={12}/>
                                        </button>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default VectorMemoryModal;
