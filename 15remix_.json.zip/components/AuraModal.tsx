
// FILE DEPRECATED - FEATURE REMOVED
import React from 'react';
export default () => null;
