
import React, { useState } from 'react';
import { AppConfig, ChatMessage, CardData } from '../types';
import { generateDiaryEntries } from '../services/aiService';
import { X, Book, Sparkles, Plus, Trash2, Edit2, User, Save, Loader2 } from 'lucide-react';

interface DiaryModalProps {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  messages: ChatMessage[];
  onClose: () => void;
  themeColors: any;
}

const DiaryModal: React.FC<DiaryModalProps> = ({ config, setConfig, messages, onClose, themeColors }) => {
  const [selectedTarget, setSelectedTarget] = useState<'USER' | number>('USER');
  const [isGenerating, setIsGenerating] = useState(false);
  const [editingEntry, setEditingEntry] = useState<{ index: number, date: string, title: string, content: string } | null>(null);

  // --- HELPERS ---
  const getTargetCard = (target: 'USER' | number): CardData => {
      const card = target === 'USER' ? config.userCard : config.characterCards[target as number];
      return card || { name: "Unknown", diary: [] } as any;
  };

  const currentCard = getTargetCard(selectedTarget);
  const diaryEntries = currentCard.diary || [];

  // --- ACTIONS ---
  const handleSwitchTarget = (newTarget: 'USER' | number) => {
      setSelectedTarget(newTarget);
      setEditingEntry(null);
  };

  const updateDiary = (newEntries: { date: string, title: string, content: string }[]) => {
      setConfig(prev => {
          if (selectedTarget === 'USER') {
              const currentUser = prev.userCard || { name: 'User', diary: [] } as CardData;
              return {
                  ...prev,
                  userCard: { ...currentUser, diary: newEntries }
              };
          } else {
              const idx = selectedTarget as number;
              const chars = [...prev.characterCards];
              if (chars[idx]) {
                  chars[idx] = { ...chars[idx], diary: newEntries };
              }
              return { ...prev, characterCards: chars };
          }
      });
  };

  const handleGenerate = async () => {
      setIsGenerating(true);
      try {
          const currentDate = config.calendar?.currentDate || new Date().toISOString().split('T')[0];
          // Pass current diary entries to avoid duplicates
          const newEntries = await generateDiaryEntries(config, messages, currentCard.name, currentDate, diaryEntries);
          
          if (newEntries && newEntries.length > 0) {
              updateDiary([...diaryEntries, ...newEntries]);
          } else {
              alert("AI couldn't think of anything to write.");
          }
      } catch (e) {
          console.error(e);
          alert("Generation failed.");
      } finally {
          setIsGenerating(false);
      }
  };

  const handleManualAdd = () => {
      const currentDate = config.calendar?.currentDate || new Date().toISOString().split('T')[0];
      const newEntry = { date: currentDate, title: "New Entry", content: "..." };
      updateDiary([...diaryEntries, newEntry]);
      // Immediately edit the new entry
      setEditingEntry({ index: diaryEntries.length, ...newEntry });
  };

  const handleDelete = (index: number) => {
      const newEntries = diaryEntries.filter((_, i) => i !== index);
      updateDiary(newEntries);
      if (editingEntry?.index === index) setEditingEntry(null);
  };

  const handleSaveEdit = () => {
      if (!editingEntry) return;
      const newEntries = [...diaryEntries];
      newEntries[editingEntry.index] = {
          date: editingEntry.date,
          title: editingEntry.title,
          content: editingEntry.content
      };
      updateDiary(newEntries);
      setEditingEntry(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 md:p-4 bg-black/90 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
      <div className="w-full max-w-4xl bg-[#1a1a1a] border border-[#333] md:rounded-xl shadow-2xl flex flex-col h-full md:h-[85vh] overflow-hidden">
        
        {/* HEADER */}
        <div className="p-4 border-b border-[#333] bg-[#222] flex justify-between items-center shrink-0">
            <div className="flex items-center gap-3 text-pink-300">
                <Book size={24} />
                <div>
                    <h2 className="font-bold text-xl md:text-2xl text-white leading-none" style={{ fontFamily: '"JetBrains Mono", monospace' }}>Secret Diary</h2>
                    <p className="text-[10px] font-mono text-zinc-500 uppercase mt-1">Personal Thoughts & Memories</p>
                </div>
            </div>
            <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors p-2"><X size={20} /></button>
        </div>

        {/* CHARACTER SELECTOR (Horizontal Scroll) */}
        <div className="flex gap-2 p-3 bg-black/40 border-b border-white/5 overflow-x-auto custom-scrollbar shrink-0">
            {config.userCard && (
                <button 
                    onClick={() => handleSwitchTarget('USER')}
                    className={`px-4 py-2 rounded-lg border text-xs font-bold uppercase whitespace-nowrap transition-all flex items-center gap-2 shrink-0
                        ${selectedTarget === 'USER' ? 'bg-pink-600 text-white border-pink-500' : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:border-pink-500/50'}
                    `}
                >
                    <User size={14} /> {config.userCard.name}
                </button>
            )}
            {config.characterCards.map((char, idx) => (
                <button 
                    key={idx}
                    onClick={() => handleSwitchTarget(idx)}
                    className={`px-4 py-2 rounded-lg border text-xs font-bold uppercase whitespace-nowrap transition-all flex items-center gap-2 shrink-0
                        ${selectedTarget === idx ? 'bg-pink-600 text-white border-pink-500' : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:border-pink-500/50'}
                    `}
                >
                    {char.name}
                </button>
            ))}
        </div>

        {/* MAIN CONTENT */}
        <div className="flex-1 flex flex-col bg-[#161616] relative overflow-hidden">
            
            {/* Toolbar */}
            <div className="p-3 border-b border-[#333] flex justify-between items-center bg-[#1a1a1a] shrink-0">
                <div className="text-xs font-mono text-zinc-500">
                    {diaryEntries.length} Entries
                </div>
                <div className="flex gap-2">
                    <button 
                        onClick={handleGenerate} 
                        disabled={isGenerating}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-bold flex items-center gap-2 transition-all disabled:opacity-50 font-mono"
                    >
                        {isGenerating ? <Loader2 size={12} className="animate-spin"/> : <Sparkles size={12}/>}
                        <span className="hidden md:inline">Write (AI)</span> <span className="md:hidden">AI</span>
                    </button>
                    <button 
                        onClick={handleManualAdd}
                        className="px-3 py-1.5 bg-[#333] hover:bg-[#444] text-white rounded text-xs font-bold flex items-center gap-2 transition-all font-mono"
                    >
                        <Plus size={12}/> <span className="hidden md:inline">Manual</span> <span className="md:hidden">Add</span>
                    </button>
                </div>
            </div>

            {/* Entries List */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-4 md:p-6 space-y-6 md:space-y-8">
                {diaryEntries.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-zinc-600 gap-4 opacity-50">
                        <Book size={48} strokeWidth={1} />
                        <p className="font-mono text-xs italic">The pages are empty...</p>
                    </div>
                ) : (
                    diaryEntries.map((entry, idx) => (
                        <div key={idx} className="group relative pl-4 md:pl-6 border-l-2 border-[#333] hover:border-pink-500/50 transition-colors">
                            {/* Dot */}
                            <div className="absolute -left-[5px] top-0 w-2.5 h-2.5 rounded-full bg-[#333] group-hover:bg-pink-500 transition-colors border-2 border-[#161616]"></div>
                            
                            {editingEntry?.index === idx ? (
                                <div className="bg-[#222] p-3 md:p-4 rounded-lg border border-pink-500/50 space-y-3 animate-in fade-in">
                                    <div className="flex flex-col md:flex-row gap-2">
                                        <input 
                                            type="text" 
                                            value={editingEntry.date} 
                                            onChange={e => setEditingEntry({...editingEntry, date: e.target.value})}
                                            className="w-full md:w-32 bg-black/40 border border-[#444] rounded p-2 text-xs font-mono text-zinc-300 outline-none focus:border-pink-500"
                                            placeholder="Date"
                                        />
                                        <input 
                                            type="text" 
                                            value={editingEntry.title} 
                                            onChange={e => setEditingEntry({...editingEntry, title: e.target.value})}
                                            className="flex-1 bg-black/40 border border-[#444] rounded p-2 text-sm font-bold text-white outline-none focus:border-pink-500"
                                            placeholder="Title..."
                                            style={{ fontFamily: '"JetBrains Mono", monospace' }}
                                        />
                                    </div>
                                    <textarea 
                                        value={editingEntry.content}
                                        onChange={e => setEditingEntry({...editingEntry, content: e.target.value})}
                                        className="w-full h-48 md:h-64 bg-black/40 border border-[#444] rounded p-3 text-sm text-zinc-300 outline-none focus:border-pink-500 resize-none leading-relaxed tracking-wide"
                                        placeholder="Dear Diary..."
                                        style={{ fontFamily: '"JetBrains Mono", monospace' }}
                                    />
                                    <div className="flex justify-end gap-2">
                                        <button onClick={() => setEditingEntry(null)} className="px-3 py-1.5 text-xs text-zinc-400 hover:text-white font-mono">Cancel</button>
                                        <button onClick={handleSaveEdit} className="px-4 py-1.5 bg-green-600 hover:bg-green-500 text-white rounded text-xs font-bold flex items-center gap-2 font-mono">
                                            <Save size={12}/> Save
                                        </button>
                                    </div>
                                </div>
                            ) : (
                                <div className="space-y-2">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <span className="text-[10px] font-mono text-zinc-500 bg-[#222] px-1.5 py-0.5 rounded">{entry.date}</span>
                                            <h3 className="text-sm md:text-base font-bold text-pink-300 mt-1" style={{ fontFamily: '"JetBrains Mono", monospace' }}>{entry.title}</h3>
                                        </div>
                                        {/* REMOVED: md:opacity-0 md:group-hover:opacity-100 to make buttons always visible */}
                                        <div className="flex gap-1 transition-opacity">
                                            <button onClick={() => setEditingEntry({ index: idx, ...entry })} className="p-2 bg-[#222] rounded hover:bg-white/10 text-zinc-400 hover:text-white transition-colors" title="Edit"><Edit2 size={14}/></button>
                                            <button onClick={() => handleDelete(idx)} className="p-2 bg-[#222] rounded hover:bg-red-900/30 text-zinc-400 hover:text-red-400 transition-colors" title="Delete"><Trash2 size={14}/></button>
                                        </div>
                                    </div>
                                    <p className="text-xs md:text-sm text-zinc-300 leading-loose whitespace-pre-wrap pl-2 border-l-2 border-zinc-800 group-hover:border-pink-500/10 transition-colors" style={{ fontFamily: '"JetBrains Mono", monospace' }}>
                                        {entry.content}
                                    </p>
                                </div>
                            )}
                        </div>
                    ))
                )}
            </div>

        </div>
      </div>
    </div>
  );
};

export default DiaryModal;
