import React, { useState, useEffect } from 'react';
import { AppConfig, ChatMessage } from '../types';
import { X, Lock, Unlock, Wand2, Save } from 'lucide-react';
import { generateOutfitDescription } from '../services/aiService';

interface OutfitManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AppConfig;
  messages: ChatMessage[];
  onUpdateConfig: (newConfig: AppConfig) => void;
  initialTab?: 'USER' | number;
}

export default function OutfitManagerModal({ isOpen, onClose, config, messages, onUpdateConfig, initialTab = 'USER' }: OutfitManagerModalProps) {
  const [activeTab, setActiveTab] = useState<'USER' | number>(initialTab);
  const [userOutfit, setUserOutfit] = useState(config.userCard?.outfitDescription || '');
  const [userLocked, setUserLocked] = useState(config.userCard?.outfitLocked || false);
  const [charOutfits, setCharOutfits] = useState<string[]>([]);
  const [charLocks, setCharLocks] = useState<boolean[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      setUserOutfit(config.userCard?.outfitDescription || '');
      setUserLocked(config.userCard?.outfitLocked || false);
      setCharOutfits(config.characterCards?.map(c => c.outfitDescription || '') || []);
      setCharLocks(config.characterCards?.map(c => c.outfitLocked || false) || []);
    }
  }, [isOpen, initialTab]); // Removed config from dependencies to prevent resetting activeTab on every keystroke

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      if (activeTab === 'USER') {
        const targetName = config.userCard?.name || 'User';
        const currentOutfit = userOutfit;
        const result = await generateOutfitDescription(config, messages, targetName, currentOutfit);
        setUserOutfit(result);
      } else {
        const charIndex = activeTab;
        if (config.characterCards && config.characterCards[charIndex]) {
          const targetName = config.characterCards[charIndex].name || 'Character';
          const currentOutfit = charOutfits[charIndex];
          const result = await generateOutfitDescription(config, messages, targetName, currentOutfit);
          setCharOutfits(prev => {
            const newOutfits = [...prev];
            newOutfits[charIndex] = result;
            return newOutfits;
          });
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = () => {
    const newConfig = { ...config };
    
    if (newConfig.userCard) {
      newConfig.userCard.outfitDescription = userOutfit;
      newConfig.userCard.outfitLocked = userLocked;
    }
    
    if (newConfig.characterCards) {
      newConfig.characterCards = newConfig.characterCards.map((char, index) => ({
        ...char,
        outfitDescription: charOutfits[index] !== undefined ? charOutfits[index] : char.outfitDescription,
        outfitLocked: charLocks[index] !== undefined ? charLocks[index] : char.outfitLocked
      }));
    }
    
    onUpdateConfig(newConfig);
    onClose();
  };

  if (!isOpen) return null;

  const currentOutfit = activeTab === 'USER' ? userOutfit : (charOutfits[activeTab] || '');
  const currentLocked = activeTab === 'USER' ? userLocked : (charLocks[activeTab] || false);

  const setCurrentOutfit = (val: string) => {
    if (activeTab === 'USER') {
      setUserOutfit(val);
    } else {
      setCharOutfits(prev => {
        const newOutfits = [...prev];
        newOutfits[activeTab] = val;
        return newOutfits;
      });
    }
  };

  const toggleLock = () => {
    if (activeTab === 'USER') {
      setUserLocked(!userLocked);
    } else {
      setCharLocks(prev => {
        const newLocks = [...prev];
        newLocks[activeTab] = !newLocks[activeTab];
        return newLocks;
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[300] flex items-center justify-center p-4 font-mono">
      <div className="bg-slate-900 border border-cyan-500/30 rounded-lg w-full max-w-2xl shadow-2xl shadow-cyan-900/20 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-cyan-500 rounded-full animate-pulse"></div>
            <h2 className="text-cyan-400 font-bold tracking-widest">OUTFIT_MANAGER_OS</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-800 overflow-x-auto">
          <button 
            onClick={() => setActiveTab('USER')}
            className={`px-6 py-3 text-sm font-bold tracking-wider transition-colors whitespace-nowrap ${activeTab === 'USER' ? 'bg-cyan-950/30 text-cyan-400 border-b-2 border-cyan-500' : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800/50'}`}
          >
            [ USER ]
          </button>
          {config.characterCards?.map((char, index) => (
            <button 
              key={index}
              onClick={() => setActiveTab(index)}
              className={`px-6 py-3 text-sm font-bold tracking-wider transition-colors whitespace-nowrap ${activeTab === index ? 'bg-cyan-950/30 text-cyan-400 border-b-2 border-cyan-500' : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800/50'}`}
            >
              [ {char.name.toUpperCase()} ]
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-6 flex-1 overflow-y-auto space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-slate-300 text-sm uppercase tracking-widest">Current Description</h3>
            <div className="flex gap-2">
              <button 
                onClick={toggleLock}
                className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-bold transition-colors ${currentLocked ? 'bg-rose-500/20 text-rose-400 border border-rose-500/50' : 'bg-slate-800 text-slate-400 border border-slate-700 hover:bg-slate-700'}`}
              >
                {currentLocked ? <Lock size={14} /> : <Unlock size={14} />}
                {currentLocked ? 'LOCKED' : 'UNLOCKED'}
              </button>
              <button 
                onClick={handleGenerate}
                disabled={isGenerating}
                className="flex items-center gap-2 px-3 py-1.5 rounded text-xs font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/50 hover:bg-cyan-500/30 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isGenerating ? <div className="w-3 h-3 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"></div> : <Wand2 size={14} />}
                AUTO GENERATE
              </button>
            </div>
          </div>

          <textarea
            value={currentOutfit}
            onChange={(e) => setCurrentOutfit(e.target.value)}
            className="w-full h-64 bg-slate-950 border border-slate-800 rounded p-4 text-slate-300 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 resize-none"
            placeholder="Đang mặc:&#10;- Áo: ...&#10;- Quần/Váy: ...&#10;- Chân: ...&#10;- Tóc: ...&#10;- Tình trạng: ..."
          />
          
          <div className="text-xs text-slate-500 bg-slate-950/50 p-3 rounded border border-slate-800/50">
            <p className="mb-1">INFO: When locked, the AI will not be able to change this outfit during the scene.</p>
            <p>INFO: Auto Generate will read the last 10 messages to infer the current outfit.</p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 flex justify-end">
          <button 
            onClick={handleSave}
            className="flex items-center gap-2 px-6 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-bold tracking-wider transition-colors"
          >
            <Save size={16} />
            SAVE CHANGES
          </button>
        </div>

      </div>
    </div>
  );
}
