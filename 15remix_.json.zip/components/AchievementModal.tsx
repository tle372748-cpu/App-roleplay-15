
import React from 'react';
import { AppConfig, Achievement } from '../types';
import { X, Trophy, Lock, CheckCircle, Coins, Award } from 'lucide-react';
import { formatVND } from '../utils/mockDataGenerator';

interface AchievementModalProps {
  onClose: () => void;
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  onLog: (msg: string) => void;
  themeColors: any;
  messagesCount: number;
}

const ACHIEVEMENTS_LIST = [
    { id: 'first_blood', title: 'First Words', desc: 'Send your first message.', target: 1, type: 'MSG_COUNT', reward: { gold: 1000 } },
    { id: 'talkative', title: 'Chatterbox', desc: 'Send 100 messages.', target: 100, type: 'MSG_COUNT', reward: { gold: 50000 } },
    { id: 'novelist', title: 'Novelist', desc: 'Send 1000 messages.', target: 1000, type: 'MSG_COUNT', reward: { gold: 500000 } },
    { id: 'rich', title: 'Millionaire', desc: 'Hoard 1,000,000 Gold.', target: 1000000, type: 'GOLD_HOARD', reward: { gold: 100000 } },
    { id: 'tycoon', title: 'Tycoon', desc: 'Hoard 100,000,000 Gold.', target: 100000000, type: 'GOLD_HOARD', reward: { gold: 10000000 } },
];

const AchievementModal: React.FC<AchievementModalProps> = ({ onClose, config, setConfig, onLog, themeColors, messagesCount }) => {
  const currentGold = config.gameStats?.gold || 0;
  const unlocked = config.gameStats?.achievements || [];

  const handleClaim = (ach: any) => {
      if (unlocked.some(a => a.id === ach.id)) return; // Already claimed

      setConfig(prev => ({
          ...prev,
          gameStats: {
              ...prev.gameStats!,
              gold: (prev.gameStats?.gold || 0) + ach.reward.gold,
              achievements: [...(prev.gameStats?.achievements || []), { ...ach, isUnlocked: true, currentValue: ach.target }]
          }
      }));
      onLog(`🏆 ACHIEVEMENT UNLOCKED: [${ach.title}] - Received ${formatVND(ach.reward.gold)}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className={`w-full max-w-lg border rounded-xl shadow-2xl flex flex-col bg-zinc-900 border-yellow-500/30 overflow-hidden max-h-[85vh]`}>
        
        <div className="p-4 border-b border-yellow-500/20 bg-yellow-900/10 flex justify-between items-center">
            <div className="flex items-center gap-2 text-yellow-500">
                <Trophy size={20} />
                <h3 className="font-mono font-bold uppercase tracking-widest text-sm">Hall of Fame</h3>
            </div>
            <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors"><X size={18} /></button>
        </div>

        <div className="p-4 overflow-y-auto custom-scrollbar flex flex-col gap-3">
            {ACHIEVEMENTS_LIST.map((ach) => {
                const isUnlocked = unlocked.some(a => a.id === ach.id);
                let progress = 0;
                let currentVal = 0;

                if (ach.type === 'MSG_COUNT') {
                    currentVal = messagesCount;
                    progress = Math.min(100, (messagesCount / ach.target) * 100);
                } else if (ach.type === 'GOLD_HOARD') {
                    currentVal = currentGold;
                    progress = Math.min(100, (currentGold / ach.target) * 100);
                }

                const canClaim = !isUnlocked && progress >= 100;

                return (
                    <div key={ach.id} className={`p-3 rounded-xl border flex items-center justify-between transition-all ${isUnlocked ? 'bg-yellow-900/10 border-yellow-500/30' : 'bg-black/40 border-white/5 opacity-80'}`}>
                        <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isUnlocked ? 'bg-yellow-500 text-black' : canClaim ? 'bg-green-500 animate-pulse text-white' : 'bg-zinc-800 text-zinc-600'}`}>
                                {isUnlocked ? <Trophy size={18} /> : canClaim ? <Award size={18}/> : <Lock size={18} />}
                            </div>
                            <div>
                                <h4 className={`font-bold text-sm ${isUnlocked ? 'text-yellow-200' : 'text-zinc-300'}`}>{ach.title}</h4>
                                <p className="text-[10px] text-zinc-500">{ach.desc}</p>
                                <div className="mt-1 w-32 h-1 bg-zinc-800 rounded-full overflow-hidden">
                                    <div className="h-full bg-yellow-500 transition-all duration-500" style={{ width: `${progress}%` }}></div>
                                </div>
                            </div>
                        </div>
                        
                        {isUnlocked ? (
                            <div className="flex items-center gap-1 text-green-400 text-[10px] font-bold uppercase border border-green-500/30 px-2 py-1 rounded bg-green-900/20">
                                <CheckCircle size={12}/> Claimed
                            </div>
                        ) : canClaim ? (
                            <button 
                                onClick={() => handleClaim(ach)}
                                className="px-3 py-1.5 bg-yellow-600 hover:bg-yellow-500 text-black font-bold text-[10px] uppercase rounded shadow-lg animate-bounce"
                            >
                                Claim
                            </button>
                        ) : (
                            <div className="flex items-center gap-1 text-zinc-600 text-[10px] font-mono">
                                <Coins size={10}/> {formatVND(ach.reward.gold)}
                            </div>
                        )}
                    </div>
                );
            })}
        </div>

      </div>
    </div>
  );
};

export default AchievementModal;
