
import React, { useState } from 'react';
import { CardData } from '../types';
import { X, Signal, Battery, Wifi, ChevronLeft, Send, Image as ImageIcon, MapPin, Phone, Video } from 'lucide-react';
import { formatVND } from '../utils/mockDataGenerator';

interface SmartPhoneProps {
  character: CardData;
  isUser: boolean;
  balance: number;
  onClose: () => void;
  onTransfer?: (target: string, amount: number, note: string) => void;
}

const SmartPhone: React.FC<SmartPhoneProps> = ({ character, isUser, balance, onClose, onTransfer }) => {
  const [activeApp, setActiveApp] = useState<'HOME' | 'MESSAGES' | 'BANK'>('HOME');
  const [currentTime, setCurrentTime] = useState(new Date());

  React.useEffect(() => {
      const timer = setInterval(() => setCurrentTime(new Date()), 1000);
      return () => clearInterval(timer);
  }, []);

  const messages = character.phone?.messages || [];
  const wallpaper = character.phone?.wallpaper || "linear-gradient(to bottom, #1a1a2e, #16213e)";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in zoom-in-95 duration-200">
      <div className="w-[320px] h-[640px] bg-black rounded-[40px] border-4 border-zinc-800 shadow-2xl relative overflow-hidden flex flex-col">
        
        {/* Notch & Status Bar */}
        <div className="absolute top-0 left-0 right-0 h-8 z-20 flex justify-between items-center px-6 text-white text-[10px] font-medium pt-1">
            <span>{currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            <div className="flex gap-1.5">
                <Signal size={10} />
                <Wifi size={10} />
                <Battery size={10} />
            </div>
        </div>
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-6 bg-black rounded-b-xl z-20"></div>

        {/* Screen Content */}
        <div className="flex-1 relative overflow-hidden bg-cover bg-center text-white" style={{ background: wallpaper.includes('gradient') || wallpaper.includes('#') ? wallpaper : `url(${wallpaper})`, backgroundColor: '#1a1a2e' }}>
            
            {/* HOME SCREEN */}
            {activeApp === 'HOME' && (
                <div className="absolute inset-0 p-4 pt-12 flex flex-col justify-between animate-in fade-in">
                    
                    {/* Time Widget */}
                    <div className="text-center mt-8 drop-shadow-md">
                        <div className="text-5xl font-thin">{currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}</div>
                        <div className="text-sm font-medium opacity-80">{currentTime.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })}</div>
                    </div>

                    {/* App Grid */}
                    <div className="grid grid-cols-4 gap-4 mb-4 p-2 bg-black/20 rounded-3xl backdrop-blur-sm">
                        <button onClick={() => setActiveApp('MESSAGES')} className="flex flex-col items-center gap-1 group">
                            <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center shadow-lg group-active:scale-90 transition-transform"><Send size={24} className="text-white fill-current"/></div>
                            <span className="text-[9px] drop-shadow-md">Messages</span>
                        </button>
                        <button onClick={() => setActiveApp('BANK')} className="flex flex-col items-center gap-1 group">
                            <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg group-active:scale-90 transition-transform"><span className="font-bold text-lg">Q</span></div>
                            <span className="text-[9px] drop-shadow-md">Q-Bank</span>
                        </button>
                        <button className="flex flex-col items-center gap-1 group">
                            <div className="w-12 h-12 bg-gradient-to-tr from-yellow-400 to-pink-500 rounded-xl flex items-center justify-center shadow-lg group-active:scale-90 transition-transform"><ImageIcon size={24}/></div>
                            <span className="text-[9px] drop-shadow-md">Photos</span>
                        </button>
                        <button className="flex flex-col items-center gap-1 group">
                            <div className="w-12 h-12 bg-gray-800 rounded-xl flex items-center justify-center shadow-lg group-active:scale-90 transition-transform"><MapPin size={24}/></div>
                            <span className="text-[9px] drop-shadow-md">Maps</span>
                        </button>
                    </div>
                </div>
            )}

            {/* MESSAGES APP */}
            {activeApp === 'MESSAGES' && (
                <div className="absolute inset-0 bg-white text-black flex flex-col animate-in slide-in-from-right">
                    <div className="h-20 bg-gray-100 flex items-end pb-3 px-4 border-b">
                        <button onClick={() => setActiveApp('HOME')} className="mr-2"><ChevronLeft size={24} className="text-blue-500"/></button>
                        <span className="font-bold text-xl">Messages</span>
                    </div>
                    <div className="flex-1 overflow-y-auto p-0">
                        {messages.length === 0 ? (
                            <div className="flex flex-col items-center justify-center h-full text-gray-400 gap-2">
                                <Send size={32} />
                                <span className="text-sm">No messages yet</span>
                            </div>
                        ) : (
                            messages.map((msg: any, i: number) => (
                                <div key={i} className="p-3 border-b flex flex-col gap-1 hover:bg-gray-50 active:bg-gray-100">
                                    <div className="flex justify-between items-center">
                                        <span className="font-bold text-sm">{msg.sender}</span>
                                        <span className="text-[10px] text-gray-400">{msg.timestamp}</span>
                                    </div>
                                    <p className="text-xs text-gray-600 line-clamp-1">{msg.content}</p>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            )}

            {/* BANK APP */}
            {activeApp === 'BANK' && (
                <div className="absolute inset-0 bg-blue-900 text-white flex flex-col animate-in slide-in-from-right">
                    <div className="h-20 flex items-end pb-3 px-4">
                        <button onClick={() => setActiveApp('HOME')} className="mr-2"><ChevronLeft size={24} /></button>
                        <span className="font-bold text-xl">Q-Bank</span>
                    </div>
                    <div className="p-6 flex flex-col gap-6">
                        <div className="bg-white/10 rounded-2xl p-6 flex flex-col gap-1 border border-white/20 shadow-xl">
                            <span className="text-xs opacity-70 uppercase tracking-widest">Total Balance</span>
                            <span className="text-3xl font-bold font-mono">{formatVND(balance)}</span>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <button onClick={() => { if(onClose) onClose(); }} className="bg-blue-600 p-4 rounded-xl flex flex-col items-center gap-2 active:bg-blue-700 transition-colors">
                                <Send size={20} /> <span className="text-xs font-bold">Transfer</span>
                            </button>
                            <button onClick={() => { if(onClose) onClose(); }} className="bg-blue-800 p-4 rounded-xl flex flex-col items-center gap-2 active:bg-blue-900 transition-colors">
                                <X size={20} /> <span className="text-xs font-bold">Close</span>
                            </button>
                        </div>
                    </div>
                </div>
            )}

        </div>

        {/* Home Bar */}
        <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-32 h-1 bg-white/50 rounded-full z-30"></div>
        
        {/* Close Overlay Button */}
        <button onClick={onClose} className="absolute -right-12 top-4 p-2 bg-white text-black rounded-full hover:scale-110 transition-transform shadow-xl">
            <X size={24} />
        </button>

      </div>
    </div>
  );
};

export default SmartPhone;
