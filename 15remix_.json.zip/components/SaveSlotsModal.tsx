
import React, { useState, useEffect, useRef } from 'react';
import { X, Save, Play, Trash2, Download, Upload, HardDrive, Clock, FileJson, Plus, Check, RefreshCw, Cpu, Database, Sparkles, Globe, Edit2 } from 'lucide-react';
import { AppConfig, ChatMessage, SaveSlotData } from '../types';
import { formatVND } from '../utils/mockDataGenerator';
import { DEFAULT_CONFIG } from '../constants';

interface SaveSlotsModalProps {
    config: AppConfig;
    messages: ChatMessage[];
    setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
    setMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
    onClose: () => void;
    themeColors: any;
}

const SLOT_STORAGE_KEY = 'NMGX_SAVE_SLOTS_V1';
const MAX_SLOTS = 12;

const SaveSlotsModal: React.FC<SaveSlotsModalProps> = ({ config, messages, setConfig, setMessages, onClose, themeColors }) => {
    const [slots, setSlots] = useState<(SaveSlotData | null)[]>(Array(MAX_SLOTS).fill(null));
    const [confirmAction, setConfirmAction] = useState<{ type: 'DELETE' | 'LOAD' | 'SAVE', index: number } | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [importTargetIndex, setImportTargetIndex] = useState<number | null>(null);
    
    // Rename States
    const [renamingIndex, setRenamingIndex] = useState<number | null>(null);
    const [renameValue, setRenameValue] = useState("");

    // Load slots from local storage on mount
    useEffect(() => {
        try {
            const saved = localStorage.getItem(SLOT_STORAGE_KEY);
            if (saved) {
                const parsed = JSON.parse(saved);
                const loadedSlots = Array(MAX_SLOTS).fill(null);
                parsed.forEach((slot: SaveSlotData | null, i: number) => {
                    if (i < MAX_SLOTS) loadedSlots[i] = slot;
                });
                setSlots(loadedSlots);
            }
        } catch (e) {
            console.error("Failed to load save slots", e);
        }
    }, []);

    const saveSlotsToStorage = (newSlots: (SaveSlotData | null)[]) => {
        setSlots(newSlots);
        localStorage.setItem(SLOT_STORAGE_KEY, JSON.stringify(newSlots));
    };

    const performSave = (index: number) => {
        const now = new Date();
        const timeString = now.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
        
        const gold = config.gameStats?.gold || 0;
        const charCount = config.characterCards.length;
        const msgCount = messages.length;
        const userRole = config.userCard?.name || "User";
        
        // Create Deep Copy of Current State to prevent reference issues
        const stateSnapshot = {
            config: JSON.parse(JSON.stringify(config)),
            messages: JSON.parse(JSON.stringify(messages))
        };

        const newSlot: SaveSlotData = {
            id: `slot-${Date.now()}`,
            timestamp: Date.now(),
            label: `${userRole}`,
            summary: `${timeString} • ${formatVND(gold)} • ${msgCount} Msgs`,
            data: stateSnapshot
        };

        const newSlots = [...slots];
        newSlots[index] = newSlot;
        saveSlotsToStorage(newSlots);
        setConfirmAction(null);
    };

    const performLoad = (index: number) => {
        const slot = slots[index];
        if (!slot || !slot.data) return;

        try {
            // 1. Extract Data
            const loadedConfig = (slot.data.config || {}) as Partial<AppConfig>;
            const loadedMessages = slot.data.messages || [];

            // 2. Safe Merge with Default Config
            // This ensures all new fields (biases, garden, etc.) are present even if old saves
            const safeConfig = {
                ...DEFAULT_CONFIG,
                ...loadedConfig,
                biases: { ...DEFAULT_CONFIG.biases, ...(loadedConfig.biases || {}) },
                gameStats: { ...DEFAULT_CONFIG.gameStats, ...(loadedConfig.gameStats || {}) },
                garden: { ...DEFAULT_CONFIG.garden, ...(loadedConfig.garden || {}) },
                merchantState: { ...DEFAULT_CONFIG.merchantState, ...(loadedConfig.merchantState || {}) },
                musicPlayer: { ...DEFAULT_CONFIG.musicPlayer, ...(loadedConfig.musicPlayer || {}) },
                liveState: { ...DEFAULT_CONFIG.liveState, ...(loadedConfig.liveState || {}) }
            };

            // 3. Deep Clone Messages & Normalize
            let nextMessages: any[] = [];
            if (Array.isArray(loadedMessages)) {
                nextMessages = loadedMessages.map((m: any) => ({
                    ...m,
                    content: m.content || "",
                    versions: (Array.isArray(m.versions) && m.versions.length > 0) ? m.versions : [m.content || ""],
                    currentVersionIndex: m.currentVersionIndex !== undefined ? m.currentVersionIndex : 0
                }));
            }

            // 4. State Replacement (Critical: This triggers the app refresh)
            setConfig(safeConfig as AppConfig);
            setMessages(nextMessages);

            // 5. Close Modal
            setConfirmAction(null);
            onClose();
        } catch (e) {
            console.error("Load Failed:", e);
            alert("Save file is corrupted.");
        }
    };

    const performDelete = (index: number) => {
        const newSlots = [...slots];
        newSlots[index] = null;
        saveSlotsToStorage(newSlots);
        setConfirmAction(null);
    };

    const handleExport = (index: number) => {
        const slot = slots[index];
        if (!slot) return;

        const dataStr = JSON.stringify(slot.data, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `NMGX_Save_${slot.label.replace(/[^a-z0-9]/gi, '_')}_${Date.now()}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const triggerImport = (index: number) => {
        setImportTargetIndex(index);
        fileInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file || importTargetIndex === null) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const jsonStr = event.target?.result as string;
                const json = JSON.parse(jsonStr);
                
                // SUPPORT LEGACY ARRAY FORMAT
                let impMsgs: any[] = [];
                let impConfig: any = DEFAULT_CONFIG;

                if (Array.isArray(json)) {
                    // Legacy Format: Just an array of messages
                    impMsgs = json;
                } else {
                    // New Format: { config, messages }
                    if (!json.config && !json.messages) {
                        alert("Invalid Save File.");
                        return;
                    }
                    impMsgs = json.messages || [];
                    impConfig = json.config || DEFAULT_CONFIG;
                }

                const now = new Date();
                const timeString = now.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
                const gold = impConfig.gameStats?.gold || 0;
                const msgCount = impMsgs.length || 0;
                const userRole = impConfig.userCard?.name || "Imported";

                const newSlot: SaveSlotData = {
                    id: `import-${Date.now()}`,
                    timestamp: Date.now(),
                    label: `[IMP] ${userRole}`,
                    summary: `${timeString} • ${formatVND(gold)} • ${msgCount} Msgs`,
                    data: {
                        config: impConfig,
                        messages: impMsgs
                    }
                };

                const newSlots = [...slots];
                newSlots[importTargetIndex] = newSlot;
                saveSlotsToStorage(newSlots);

            } catch (err) {
                console.error(err);
                alert("Error parsing file.");
            } finally {
                setImportTargetIndex(null);
                if (fileInputRef.current) fileInputRef.current.value = '';
            }
        };
        reader.readAsText(file);
    };

    const startRenaming = (index: number, currentLabel: string) => {
        setRenamingIndex(index);
        setRenameValue(currentLabel);
    };

    const saveRename = (index: number) => {
        if (!renameValue.trim()) return;
        const newSlots = [...slots];
        if (newSlots[index]) {
            newSlots[index] = { ...newSlots[index]!, label: renameValue.trim() };
            saveSlotsToStorage(newSlots);
        }
        setRenamingIndex(null);
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
            <div className={`w-full max-w-4xl border rounded-2xl shadow-2xl flex flex-col bg-[#09090b] border-white/10 overflow-hidden max-h-[85vh]`}>
                
                {/* Header */}
                <div className="p-5 border-b border-white/10 bg-zinc-900/50 flex justify-between items-center shrink-0">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-green-500/20 rounded-lg text-green-400">
                            <Database size={24} />
                        </div>
                        <div>
                            <h3 className="font-mono font-bold uppercase tracking-widest text-lg text-white">Memory Cards</h3>
                            <p className="text-[10px] text-zinc-500 font-mono">Local Storage Manager • {MAX_SLOTS} Slots Available</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full text-zinc-500 hover:text-white transition-colors"><X size={24} /></button>
                </div>

                {/* Grid Content */}
                <div className="flex-1 overflow-y-auto custom-scrollbar p-6 bg-black/20">
                    <input type="file" ref={fileInputRef} className="hidden" accept=".json" onChange={handleFileChange} />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {slots.map((slot, index) => {
                            const isEmpty = !slot;
                            const isConfirming = confirmAction?.index === index;
                            const isRenaming = renamingIndex === index;

                            return (
                                <div 
                                    key={index}
                                    className={`
                                        relative rounded-xl border-2 transition-all duration-300 flex flex-col h-[180px] group overflow-hidden
                                        ${isEmpty 
                                            ? 'border-dashed border-zinc-800 bg-zinc-900/30 hover:border-zinc-700 hover:bg-zinc-900/50' 
                                            : 'border-zinc-700 bg-zinc-900 hover:border-green-500/50 hover:shadow-lg hover:shadow-green-900/20'}
                                    `}
                                >
                                    {/* Slot Number Background */}
                                    <div className="absolute top-2 right-3 text-4xl font-black text-white/5 select-none pointer-events-none">
                                        {String(index + 1).padStart(2, '0')}
                                    </div>

                                    {/* Card Content */}
                                    <div className="flex-1 p-4 flex flex-col z-10">
                                        {isEmpty ? (
                                            <div className="flex-1 flex flex-col items-center justify-center gap-2 text-zinc-600">
                                                <Cpu size={32} className="opacity-50" />
                                                <span className="text-xs font-mono font-bold uppercase tracking-widest">Empty Slot</span>
                                            </div>
                                        ) : (
                                            <>
                                                <div className="flex items-center gap-2 mb-2">
                                                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                                                    <span className="text-xs font-bold text-green-400 font-mono uppercase tracking-wider">Active Data</span>
                                                </div>
                                                
                                                {isRenaming ? (
                                                    <div className="flex items-center gap-2 mb-1">
                                                        <input 
                                                            autoFocus
                                                            type="text" 
                                                            value={renameValue} 
                                                            onChange={(e) => setRenameValue(e.target.value)}
                                                            onKeyDown={(e) => e.key === 'Enter' && saveRename(index)}
                                                            className="w-full bg-black/50 border border-green-500/50 rounded px-2 py-1 text-sm font-bold text-white outline-none focus:ring-1 focus:ring-green-500"
                                                        />
                                                        <button onClick={() => saveRename(index)} className="p-1 text-green-400 hover:text-white bg-green-900/20 rounded"><Check size={14}/></button>
                                                    </div>
                                                ) : (
                                                    <div className="flex items-center justify-between mb-1 group/title">
                                                        <h4 className="text-white font-bold text-lg truncate max-w-[180px]" title={slot.label}>{slot.label}</h4>
                                                        <button 
                                                            onClick={() => startRenaming(index, slot.label)}
                                                            className="opacity-0 group-hover/title:opacity-100 text-zinc-500 hover:text-white transition-opacity"
                                                        >
                                                            <Edit2 size={12} />
                                                        </button>
                                                    </div>
                                                )}
                                                
                                                <div className="text-[10px] text-zinc-400 font-mono space-y-1">
                                                    <p className="flex items-center gap-1.5"><Clock size={10}/> {new Date(slot.timestamp).toLocaleDateString()}</p>
                                                    <p className="opacity-70">{slot.summary}</p>
                                                </div>
                                            </>
                                        )}
                                    </div>

                                    {/* Action Bar (Slide Up) */}
                                    <div className={`p-2 bg-black/60 backdrop-blur-sm border-t border-white/5 grid ${isEmpty ? 'grid-cols-2' : 'grid-cols-4'} gap-1 transition-transform duration-300 ${isEmpty ? 'opacity-50 group-hover:opacity-100' : ''}`}>
                                        
                                        {isConfirming ? (
                                            <div className="col-span-full flex gap-2 animate-in fade-in slide-in-from-bottom-2">
                                                <button 
                                                    onClick={() => {
                                                        if (confirmAction.type === 'LOAD') performLoad(index);
                                                        if (confirmAction.type === 'SAVE') performSave(index);
                                                        if (confirmAction.type === 'DELETE') performDelete(index);
                                                    }}
                                                    className={`flex-1 py-1.5 rounded text-[10px] font-bold uppercase text-white shadow-lg
                                                        ${confirmAction.type === 'DELETE' ? 'bg-red-600 hover:bg-red-500' : 'bg-green-600 hover:bg-green-500'}
                                                    `}
                                                >
                                                    Confirm {confirmAction.type}
                                                </button>
                                                <button 
                                                    onClick={() => setConfirmAction(null)}
                                                    className="px-3 py-1.5 rounded bg-zinc-700 hover:bg-zinc-600 text-white text-[10px] font-bold uppercase"
                                                >
                                                    Cancel
                                                </button>
                                            </div>
                                        ) : (
                                            <>
                                                {isEmpty ? (
                                                    <>
                                                        <button 
                                                            onClick={() => setConfirmAction({ type: 'SAVE', index })}
                                                            className="flex items-center justify-center gap-1.5 py-1.5 rounded hover:bg-green-600/20 text-zinc-400 hover:text-green-400 transition-colors"
                                                        >
                                                            <Save size={14} /> <span className="text-[10px] font-bold uppercase">Save</span>
                                                        </button>
                                                        <button 
                                                            onClick={() => triggerImport(index)}
                                                            className="flex items-center justify-center gap-1.5 py-1.5 rounded hover:bg-blue-600/20 text-zinc-400 hover:text-blue-400 transition-colors"
                                                        >
                                                            <Upload size={14} /> <span className="text-[10px] font-bold uppercase">Import</span>
                                                        </button>
                                                    </>
                                                ) : (
                                                    <>
                                                        <button 
                                                            onClick={() => setConfirmAction({ type: 'LOAD', index })}
                                                            className={`flex flex-col items-center justify-center py-1 rounded hover:bg-green-600/20 text-zinc-400 hover:text-green-400 transition-colors`}
                                                            title="Load"
                                                        >
                                                            <Play size={14} className="fill-current"/>
                                                        </button>
                                                        <button 
                                                            onClick={() => setConfirmAction({ type: 'SAVE', index })}
                                                            className="flex flex-col items-center justify-center py-1 rounded hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
                                                            title="Overwrite"
                                                        >
                                                            <Save size={14}/>
                                                        </button>
                                                        <button 
                                                            onClick={() => handleExport(index)}
                                                            className="flex flex-col items-center justify-center py-1 rounded hover:bg-blue-600/20 text-zinc-400 hover:text-blue-400 transition-colors"
                                                            title="Export JSON"
                                                        >
                                                            <Download size={14}/>
                                                        </button>
                                                        <button 
                                                            onClick={() => setConfirmAction({ type: 'DELETE', index })}
                                                            className="flex flex-col items-center justify-center py-1 rounded hover:bg-red-600/20 text-zinc-400 hover:text-red-400 transition-colors"
                                                            title="Delete"
                                                        >
                                                            <Trash2 size={14}/>
                                                        </button>
                                                    </>
                                                )}
                                            </>
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
                
                <div className="p-3 bg-black/40 border-t border-white/5 text-center flex justify-between items-center px-6">
                    <span className="text-[10px] text-zinc-500 font-mono">v4.0.1 Storage System</span>
                    <span className="text-[10px] text-zinc-500 font-mono">QuasarNguyen</span>
                </div>
            </div>
        </div>
    );
};

export default SaveSlotsModal;
