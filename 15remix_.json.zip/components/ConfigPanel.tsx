
import React, { useRef, useState, useEffect } from 'react';
import { AppConfig, CoreMode, Relationship, WorldSetting, CultureOS, NarrativeLength, Perspective, Difficulty, Kernel, AIModel, CardData, Mindset, DisplayMode, Physics, NarrativeTone, CharacterRole, ChatMessage, Theme, ApiSlot, CharacterPromptConfig, TimelineNode } from '../types';
import { KERNELS, CORE_MODES, RELATIONSHIPS, WORLDS, CULTURES, DIFFICULTIES, MODELS, PRESETS, EXTRA_MODULES, THEMES, MINDSETS, PERSPECTIVES, DISPLAY_MODES, PHYSICS_MODES, NARRATIVE_TONES, CHARACTER_ROLES, AVAILABLE_FONTS } from '../constants';
import { Settings, Cpu, Globe, BookOpen, ShieldAlert, Terminal, LayoutTemplate, Zap, CheckSquare, Square, Upload, FileText, X, Loader2, FileCode, RefreshCw, RotateCcw, Maximize2, Minimize2, Edit2, Trash2, Plus, UserPlus, Sparkles, Film, User, VenetianMask, Check, Save, Book, Ghost, Star, Users, Download, Camera, Image as ImageIcon, ScanEye, Wand2, Store, ChevronDown, ChevronUp, Type, HelpCircle, Info, Target, Brain, CheckCircle, Palette, Monitor, Activity, Lock, HardDrive, Layers, Command, Key, Mic, Eye, MessageCircle, AlertTriangle, Wind, Ruler, PenTool, FileJson, Shirt, MapPin } from 'lucide-react';
import { parseTextCard } from '../utils/cardParser';
import { enrichCardWithAI, generateScenarioWithAI, smartEditCardWithAI, getEffectiveApiKey } from '../services/aiService';
import { autoCropAvatar } from '../services/aiService';
import { parseBalance, formatVND } from '../utils/mockDataGenerator';
import FlipCard from './FlipCard'; 
import CharacterConfigModal from './CharacterConfigModal';
import MindConfigModal from './MindConfigModal';
import OutfitManagerModal from './OutfitManagerModal';

// --- HELPER COMPONENTS FOR NEW UI ---

const SectionTitle = ({ icon, title, color = "text-cyan-400" }: { icon: React.ReactNode, title: string, color?: string }) => (
    <div className={`flex items-center gap-2 mb-4 pb-2 border-b border-white/5 ${color}`}>
        {icon}
        <h3 className="font-mono font-bold text-xs uppercase tracking-widest">{title}</h3>
    </div>
);

const GridSelect = ({ 
    options, 
    selected, 
    onChange, 
    multi = false,
    cols = 3 
}: { 
    options: { id: string, label: string, desc?: string }[], 
    selected: string | string[], 
    onChange: (val: any) => void, 
    multi?: boolean,
    cols?: number
}) => {
    const handleSelect = (id: string) => {
        if (multi) {
            const current = Array.isArray(selected) ? selected : [];
            if (current.includes(id)) {
                onChange(current.filter(item => item !== id));
            } else {
                onChange([...current, id]);
            }
        } else {
            onChange(id);
        }
    };

    const gridClass = cols === 2 ? 'grid-cols-2' : cols === 3 ? 'grid-cols-2 md:grid-cols-3' : 'grid-cols-2 md:grid-cols-4';

    return (
        <div className={`grid ${gridClass} gap-3`}>
            {options.map(opt => {
                const isSelected = multi 
                    ? (Array.isArray(selected) && selected.includes(opt.id))
                    : selected === opt.id;
                
                return (
                    <button
                        key={opt.id}
                        onClick={() => handleSelect(opt.id)}
                        className={`
                            relative p-3 rounded-xl border text-left transition-all group overflow-hidden flex flex-col justify-between min-h-[70px]
                            ${isSelected 
                                ? 'bg-gradient-to-br from-cyan-950 to-slate-900 border-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.2)]' 
                                : 'bg-white/5 border-white/5 hover:border-white/20 hover:bg-white/10'}
                        `}
                    >
                        {isSelected && <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(6,182,212,0.15),transparent_70%)] pointer-events-none"></div>}
                        
                        <div className="flex justify-between items-start w-full relative z-10">
                            <span className={`font-bold text-xs font-mono uppercase tracking-tight ${isSelected ? 'text-cyan-300' : 'text-slate-400 group-hover:text-slate-200'}`}>
                                {opt.label}
                            </span>
                            {isSelected && <div className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_5px_cyan]"></div>}
                        </div>
                        {opt.desc && (
                            <p className={`text-[10px] mt-2 line-clamp-2 leading-relaxed ${isSelected ? 'text-cyan-100/60' : 'text-slate-500 group-hover:text-slate-400'}`}>
                                {opt.desc}
                            </p>
                        )}
                    </button>
                );
            })}
        </div>
    );
};

// ... CONSTANTS ...
const BASIC_MANUAL_DATA = [ { id: "kernel", title: "Narrative Kernel", desc: "The core engine logic.", details: { overview: "Selects the foundational prompt structure and logic.", impact: ["NM+ (Standard): Balanced roleplay.", "SE Series: Psychological depth."] } }, ];
const PROFILE_EFFECTS = [ { id: 'none', name: 'Standard', desc: 'Default look', class: 'border-white/10' }, { id: 'neon', name: 'Neon', desc: 'Glowing borders', class: 'shadow-[0_0_10px_#06b6d4] border-cyan-400' }, { id: 'gold', name: 'Gold', desc: 'Shiny wealth effect', class: 'shadow-[0_0_10px_#eab308] border-yellow-400' }, { id: 'rgb', name: 'RGB', desc: 'Gamer style rainbow', class: 'bg-gradient-to-br from-green-500/20 via-red-500/20 to-blue-500/20 border-white/20' }, { id: 'glass', name: 'Glass', desc: 'Frosted glass UI', class: 'backdrop-blur-md bg-white/5 border-white/30' }, { id: 'glitch', name: 'Glitch', desc: 'Digital distortion', class: 'border-red-500/50 border-r-4 border-l-4' }, ];
const FLIP_CARD_STYLES = [ { id: 'default', name: 'Standard (Black/Gray)', desc: 'Professional default style', class: 'bg-zinc-900 border-zinc-700' }, { id: 'luxury', name: 'Luxury (Gold)', desc: 'Rich golden gradients', class: 'bg-gradient-to-br from-yellow-900/40 to-black border-yellow-500/50' }, { id: 'cyber', name: 'Cyber (Neon Blue)', desc: 'Futuristic interface', class: 'bg-black border-cyan-500 shadow-[0_0_10px_#06b6d4]' }, { id: 'cute', name: 'Cute (Pink)', desc: 'Soft pastel colors', class: 'bg-pink-50 border-pink-200 text-pink-900' }, { id: 'gothic', name: 'Gothic (Red/Black)', desc: 'Dark and edgy', class: 'bg-red-950 border-red-900 text-red-100' }, ];
const BUBBLE_STYLES = [ { id: 'default', name: 'Theme Default', class: 'bg-zinc-700' }, { id: 'blue-ocean', name: 'Blue Ocean', class: 'bg-gradient-to-r from-blue-600 to-cyan-500' }, { id: 'sunset', name: 'Sunset', class: 'bg-gradient-to-r from-orange-500 to-pink-500' }, { id: 'midas', name: 'Midas Touch', class: 'bg-gradient-to-r from-yellow-700 to-yellow-500 border border-yellow-300' }, { id: 'glass', name: 'Frosted Glass', class: 'bg-white/10 backdrop-blur-md border border-white/20' }, { id: 'paper', name: 'Paper Note', class: 'bg-[#fef9c3] text-stone-800 border border-yellow-200' }, { id: 'nebula', name: 'Nebula', class: 'bg-gradient-to-r from-indigo-900 to-purple-800 border border-purple-500/30' }, { id: 'netrunner', name: 'Netrunner', class: 'bg-black border border-green-500 shadow-[0_0_5px_rgba(34,197,94,0.5)]' }, { id: 'terminal', name: 'Terminal', class: 'bg-zinc-900 border border-zinc-700' }, ];

const BufferedTextarea = ({ value, onChange, className, placeholder }: { value: string, onChange: (val: string) => void, className?: string, placeholder?: string }) => {
    const [localValue, setLocalValue] = useState(value);
    useEffect(() => setLocalValue(value), [value]);
    return (
        <textarea
            className={className}
            placeholder={placeholder}
            value={localValue}
            onChange={(e) => setLocalValue(e.target.value)}
            onBlur={() => onChange(localValue)}
        />
    );
};

const MiniMapPreview = ({ nodes, title, t }: { nodes: TimelineNode[], title: string, t: any }) => {
    if (!nodes || nodes.length === 0) return null;

    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    nodes.forEach(n => {
        if (n.position.x < minX) minX = n.position.x;
        if (n.position.x > maxX) maxX = n.position.x;
        if (n.position.y < minY) minY = n.position.y;
        if (n.position.y > maxY) maxY = n.position.y;
    });

    const pad = 500;
    minX -= pad; maxX += pad; minY -= pad; maxY += pad;

    const worldW = maxX - minX;
    const worldH = maxY - minY;

    const containerW = 280; 
    const scale = containerW / worldW;
    const containerH = Math.min(worldH * scale, 120);

    return (
        <div className="mt-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
            <div className="flex items-center justify-between mb-2 px-1">
                <div className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse"></div>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">{title}</span>
                </div>
                <span className="text-[9px] font-mono text-zinc-600">{nodes.length} NODES</span>
            </div>
            <div 
                className={`relative rounded-xl border overflow-hidden group cursor-crosshair ${t.border} bg-black/40 backdrop-blur-sm shadow-inner`}
                style={{ width: '100%', height: containerH }}
            >
                <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
                
                {nodes.map(n => (
                    <div 
                        key={n.id}
                        className={`absolute w-1.5 h-1.5 rounded-full shadow-[0_0_5px_rgba(255,255,255,0.2)] transition-transform hover:scale-150
                            ${n.id.startsWith('core-') ? 'bg-yellow-400 shadow-yellow-400/50' : 'bg-cyan-400 shadow-cyan-400/50'}`}
                        style={{
                            left: (n.position.x - minX) * scale,
                            top: (n.position.y - minY) * scale,
                            transform: 'translate(-50%, -50%)'
                        }}
                    />
                ))}
                
                <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-cyan-500/5 to-transparent h-1/2 w-full animate-scanline"></div>
            </div>
        </div>
    );
};

const CardLoadingSkeleton = ({ colors, label }: any) => ( <div className={`animate-pulse flex flex-col gap-2 p-4 rounded border ${colors.border}`}> <div className="h-4 bg-white/10 rounded w-3/4"></div> <div className="h-32 bg-white/5 rounded"></div> <div className="h-4 bg-white/10 rounded w-1/2"></div> <span className="text-xs text-center opacity-50">{label}</span> </div> );
const getProfileEffectStyles = (effect: string | undefined, colorType: 'nano' | 'purple' = 'nano') => { if (!effect || effect === 'none') return ''; return 'profile-effect-' + effect; };
const ProfileEffectParticles = ({ type }: { type: string }) => { if (!type || type === 'none') return null; return <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-30"><div className="particle"></div></div>; };
const hexToRgba = (hex: string, alpha: number) => { if (!hex) return undefined; const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i; hex = hex.replace(shorthandRegex, (m, r, g, b) => r + r + g + g + b + b); const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex); return result ? `rgba(${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}, ${alpha})` : hex; };

export const ThemeStoreModal = ({ onClose, config, setConfig, themeColors, onOpenThemeManager }: any) => {
    // ... (Keep existing ThemeStoreModal code) ...
    const [activeTab, setActiveTab] = useState('THEMES');
    const wallpaperInputRef = useRef<HTMLInputElement>(null);

    const handleWallpaperUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        
        if (file.size > 50 * 1024 * 1024) {
            alert("File quá lớn! Vui lòng chọn file dưới 50MB.");
            return;
        }

        const reader = new FileReader();
        reader.onload = (ev) => {
            if (ev.target?.result) {
                let finalResult = ev.target.result as string;
                if (file.type.startsWith('video/')) {
                    finalResult = `video|${finalResult}`;
                }
                setConfig({ ...config, customBackground: finalResult });
            }
        };
        reader.readAsDataURL(file);
        e.target.value = '';
    };

    const updateCustomTheme = (key: string, value: string) => {
        const currentCustom = config.customThemeColors || { bgMain: '#000000', bgPanel: '#1a1a1a', accent: '#3b82f6' };
        const newCustom = { ...currentCustom, [key]: value };
        setConfig({
            ...config,
            theme: Theme.CUSTOM,
            customThemeColors: newCustom
        });
    };

    return (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
            <div className={`w-full max-w-5xl h-[85vh] bg-[#0b0e14] border border-[#1e293b] rounded-xl shadow-2xl flex flex-col overflow-hidden`}>
                <div className={`p-5 border-b border-[#1e293b] flex justify-between items-center bg-[#0f172a]`}>
                    <div className="flex items-center gap-3">
                        <Store size={24} className="text-blue-400" />
                        <h3 className={`font-mono font-black text-xl uppercase tracking-[0.2em] text-white`}>THEME STORE</h3>
                    </div>
                    <button onClick={onClose} className={`p-2 rounded-full hover:bg-white/10 transition-colors text-zinc-400 hover:text-white`}><X size={20} /></button>
                </div>

                <div className={`flex border-b border-[#1e293b] bg-[#0b0e14] overflow-x-auto shrink-0`}>
                    {['THEMES', 'CARDS', 'BUBBLES', 'FONTS', 'TEXT', 'WALLPAPER'].map(tab => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`px-8 py-4 text-xs font-bold font-mono tracking-widest transition-all relative
                                ${activeTab === tab ? 'text-white bg-[#1e293b]' : `text-zinc-500 hover:text-zinc-300 hover:bg-[#1e293b]/50`}
                            `}
                        >
                            {tab}
                            {activeTab === tab && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-blue-500 shadow-[0_0_10px_#3b82f6]"></div>}
                        </button>
                    ))}
                    {/* NEW: Manage Overlays Button in Tabs */}
                    <button
                        onClick={onOpenThemeManager}
                        className={`px-8 py-4 text-xs font-bold font-mono tracking-widest transition-all relative text-purple-400 hover:text-purple-300 hover:bg-purple-900/20 flex items-center gap-2`}
                    >
                        <Layers size={14} /> OVERLAYS
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto custom-scrollbar p-6 bg-[#020617]">
                    {activeTab === 'THEMES' && (
                        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2">
                            <div className="p-5 rounded-lg border border-white/10 bg-white/5">
                                <div className="flex justify-between items-center mb-4">
                                    <h4 className="text-sm font-bold text-white font-mono uppercase tracking-widest flex items-center gap-2">
                                        <Palette size={16}/> Tự Phối Màu (Custom RGB)
                                    </h4>
                                    {config.theme === Theme.CUSTOM && <span className="text-[10px] bg-blue-600 text-white px-2 py-1 rounded font-bold uppercase">Active</span>}
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                    {[
                                        { label: 'Nền Chính (Main BG)', key: 'bgMain', def: '#000000' },
                                        { label: 'Khung / Bảng (Panel)', key: 'bgPanel', def: '#1a1a1a' },
                                        { label: 'Điểm Nhấn (Accent)', key: 'accent', def: '#3b82f6' }
                                    ].map(field => (
                                        <div key={field.key} className="flex flex-col gap-2">
                                            <label className="text-[10px] text-zinc-400 font-mono uppercase">{field.label}</label>
                                            <div className="flex items-center gap-3 bg-black/40 p-2 rounded border border-white/10">
                                                <input 
                                                    type="color" 
                                                    value={config.customThemeColors?.[field.key as keyof typeof config.customThemeColors] || field.def}
                                                    onChange={(e) => updateCustomTheme(field.key, e.target.value)}
                                                    className="w-8 h-8 rounded cursor-pointer bg-transparent border-none p-0"
                                                />
                                                <span className="text-xs font-mono text-white">
                                                    {config.customThemeColors?.[field.key as keyof typeof config.customThemeColors] || field.def}
                                                </span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {THEMES.filter(t => t.id !== Theme.CUSTOM).map(t => {
                                    const isActive = config.theme === t.id;
                                    return (
                                        <button
                                            key={t.id}
                                            onClick={() => setConfig({ ...config, theme: t.id })}
                                            className={`group relative p-5 rounded-lg border text-left transition-all overflow-hidden flex flex-col gap-3 min-h-[120px]
                                                ${isActive 
                                                    ? 'border-blue-500 bg-[#0f172a] shadow-[0_0_15px_rgba(59,130,246,0.1)]' 
                                                    : `border-[#1e293b] bg-[#0f172a]/50 hover:border-[#334155] hover:bg-[#1e293b]`}
                                            `}
                                        >
                                            <div className="flex justify-between items-start z-10 relative w-full">
                                                <div>
                                                    <h4 className={`font-bold text-sm ${isActive ? 'text-white' : 'text-zinc-300'}`}>{t.name}</h4>
                                                    <p className="text-[11px] text-zinc-500 mt-1 font-mono">{t.desc}</p>
                                                </div>
                                                {isActive && <Check size={16} className="text-blue-500" />}
                                            </div>
                                            <div className="flex gap-2 mt-auto pt-4 relative z-10 w-full">
                                                <div className={`h-1.5 w-1/3 rounded-full ${t.colors.bgMain.replace('text-', 'bg-').replace('bg-slate-950', 'bg-[#020617]')} ring-1 ring-white/5`}></div>
                                                <div className={`h-1.5 w-1/3 rounded-full ${t.colors.bgPanel.replace('text-', 'bg-').replace('bg-slate-900', 'bg-[#0f172a]')} ring-1 ring-white/5`}></div>
                                                <div className={`h-1.5 w-1/3 rounded-full ${t.colors.accent.replace('text-', 'bg-')} ring-1 ring-white/5`}></div>
                                            </div>
                                        </button>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                    {/* ... Other tabs ... */}
                    {activeTab === 'CARDS' && (
                        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2">
                            <div className="flex flex-col items-center p-6 bg-[#0f172a] border border-[#1e293b] rounded-xl relative">
                                <h4 className="text-xs font-mono font-bold text-zinc-500 uppercase tracking-widest absolute top-4 left-4">Live Preview</h4>
                                <FlipCard 
                                    frontText="Preview Front" 
                                    backText="Back Side" 
                                    type="LOVE" 
                                    themeColors={themeColors} 
                                    customStyle={config.flipCardStyle} 
                                    customColors={config.flipCardColors}
                                />
                            </div>
                            <div className="space-y-4 p-4 rounded-xl border border-[#1e293b] bg-[#0f172a]/50">
                                <div className="flex justify-between items-center">
                                    <h4 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-widest flex items-center gap-2"><Palette size={14}/> Custom Colors</h4>
                                    {config.flipCardColors && (
                                        <button 
                                            onClick={() => setConfig({ ...config, flipCardColors: undefined })} 
                                            className="text-[10px] text-red-400 hover:text-red-300 uppercase font-bold"
                                        >
                                            Reset to Preset
                                        </button>
                                    )}
                                </div>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                    {[
                                        { label: 'Front BG', key: 'front', def: '#000000' },
                                        { label: 'Back BG', key: 'back', def: '#1a1a1a' },
                                        { label: 'Text', key: 'text', def: '#ffffff' },
                                        { label: 'Border', key: 'border', def: '#333333' }
                                    ].map(item => (
                                        <div key={item.key} className="flex flex-col gap-1.5">
                                            <label className="text-[10px] font-mono text-zinc-500 uppercase">{item.label}</label>
                                            <div className="flex items-center gap-2 bg-[#020617] p-1.5 rounded border border-[#1e293b]">
                                                <input 
                                                    type="color" 
                                                    value={config.flipCardColors?.[item.key as keyof typeof config.flipCardColors] || item.def}
                                                    onChange={(e) => setConfig({
                                                        ...config,
                                                        flipCardColors: {
                                                            front: config.flipCardColors?.front || '#000000',
                                                            back: config.flipCardColors?.back || '#1a1a1a',
                                                            text: config.flipCardColors?.text || '#ffffff',
                                                            border: config.flipCardColors?.border || '#333333',
                                                            [item.key]: e.target.value
                                                        }
                                                    })}
                                                    className="w-6 h-6 rounded cursor-pointer bg-transparent border-none p-0"
                                                />
                                                <span className="text-[10px] font-mono text-zinc-400 uppercase">
                                                    {config.flipCardColors?.[item.key as keyof typeof config.flipCardColors] || item.def}
                                                </span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <div>
                                <h4 className="text-xs font-mono font-bold text-zinc-500 uppercase mb-4 tracking-widest">Flip Card Presets</h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                                    {FLIP_CARD_STYLES.map(style => (
                                        <button
                                            key={style.id}
                                            onClick={() => setConfig({ ...config, flipCardStyle: style.id, flipCardColors: undefined })}
                                            className={`p-4 rounded-xl border text-left transition-all relative overflow-hidden
                                                ${config.flipCardStyle === style.id && !config.flipCardColors ? 'border-yellow-500 bg-yellow-900/10' : 'border-[#1e293b] bg-[#0f172a] hover:bg-[#1e293b]'}
                                            `}
                                        >
                                            <div className={`h-12 w-full mb-3 rounded-lg flex items-center justify-center shadow-inner ${style.class}`}>
                                                <div className="w-8 h-1 bg-white/20 rounded-full"></div>
                                            </div>
                                            <div className="flex justify-between items-start">
                                                <div>
                                                    <h4 className={`font-bold text-xs ${config.flipCardStyle === style.id && !config.flipCardColors ? 'text-white' : 'text-zinc-300'}`}>{style.name}</h4>
                                                    <p className="text-[10px] text-zinc-500 mt-0.5">{style.desc}</p>
                                                </div>
                                                {config.flipCardStyle === style.id && !config.flipCardColors && <div className="w-2 h-2 rounded-full bg-yellow-500"></div>}
                                            </div>
                                        </button>
                                    ))}
                                </div>
                            </div>
                            <div>
                                <h4 className="text-xs font-mono font-bold text-zinc-500 uppercase mb-4 tracking-widest">Profile Visual Effects</h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                                    {PROFILE_EFFECTS.map(effect => (
                                        <button
                                            key={effect.id}
                                            onClick={() => setConfig({ ...config, profileEffect: effect.id })}
                                            className={`p-4 rounded-xl border text-left transition-all relative overflow-hidden group
                                                ${config.profileEffect === effect.id ? 'border-blue-500 bg-blue-900/10' : 'border-[#1e293b] bg-[#0f172a] hover:bg-[#1e293b]'}
                                            `}
                                        >
                                            <div className={`absolute top-2 right-2 w-2 h-2 rounded-full ${config.profileEffect === effect.id ? 'bg-blue-500' : 'bg-transparent'}`}></div>
                                            <div className={`h-16 w-full mb-3 rounded-lg border border-white/5 relative overflow-hidden bg-black/40 ${effect.class}`}>
                                                <div className="absolute inset-0 opacity-50"><div className="w-1 h-1 bg-white rounded-full absolute top-1/2 left-1/4"></div><div className="w-1 h-1 bg-white rounded-full absolute top-1/3 left-2/3"></div></div>
                                            </div>
                                            <h4 className={`font-bold text-xs ${config.profileEffect === effect.id ? 'text-white' : 'text-zinc-300'}`}>{effect.name}</h4>
                                            <p className="text-[10px] text-zinc-500 mt-0.5">{effect.desc}</p>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                    {activeTab === 'BUBBLES' && (
                        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2">
                            {/* ... Bubble content ... */}
                            <div className="flex flex-col gap-4">
                                <div className="flex justify-between items-center mb-2">
                                    <h4 className="text-xs font-mono font-bold text-zinc-500 uppercase tracking-widest">User Bubble Style</h4>
                                    <div className="flex items-center gap-2">
                                        <span className="text-[10px] font-mono text-zinc-400">Custom Hex:</span>
                                        <div className="flex items-center gap-2 bg-[#0f172a] px-2 py-1 rounded border border-[#1e293b]">
                                            <input 
                                                type="color" 
                                                value={config.userBubbleColor || '#2563eb'} 
                                                onChange={(e) => setConfig({ ...config, userBubbleColor: e.target.value, userBubbleTheme: undefined })}
                                                className="w-5 h-5 cursor-pointer bg-transparent border-none p-0"
                                            />
                                            {config.userBubbleColor && <button onClick={() => setConfig({...config, userBubbleColor: undefined})} className="text-red-400 hover:text-red-300"><X size={12}/></button>}
                                        </div>
                                    </div>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                                    {BUBBLE_STYLES.map(style => (
                                        <button
                                            key={`user-${style.id}`}
                                            onClick={() => setConfig({ ...config, userBubbleTheme: style.class, userBubbleColor: undefined })}
                                            className={`p-4 rounded-xl border text-left transition-all relative group
                                                ${config.userBubbleTheme === style.class && !config.userBubbleColor ? 'border-blue-500 bg-blue-900/10' : 'border-[#1e293b] bg-[#0f172a] hover:bg-[#1e293b]'}
                                            `}
                                        >
                                            <h4 className="font-bold text-xs text-zinc-400 mb-2">{style.name}</h4>
                                            <div className={`h-8 w-full rounded-lg ${style.class} shadow-sm`}></div>
                                        </button>
                                    ))}
                                </div>
                            </div>
                            <div className="h-px bg-[#1e293b] w-full"></div>
                            <div className="flex flex-col gap-4">
                                <div className="flex justify-between items-center mb-2">
                                    <h4 className="text-xs font-mono font-bold text-zinc-500 uppercase tracking-widest">Character Bubble Style</h4>
                                    <div className="flex items-center gap-2">
                                        <span className="text-[10px] font-mono text-zinc-400">Custom Hex:</span>
                                        <div className="flex items-center gap-2 bg-[#0f172a] px-2 py-1 rounded border border-[#1e293b]">
                                            <input 
                                                type="color" 
                                                value={config.charBubbleColor || '#4b5563'} 
                                                onChange={(e) => setConfig({ ...config, charBubbleColor: e.target.value, charBubbleTheme: undefined })}
                                                className="w-5 h-5 cursor-pointer bg-transparent border-none p-0"
                                            />
                                            {config.charBubbleColor && <button onClick={() => setConfig({...config, charBubbleColor: undefined})} className="text-red-400 hover:text-red-300"><X size={12}/></button>}
                                        </div>
                                    </div>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                                    {BUBBLE_STYLES.map(style => (
                                        <button
                                            key={`char-${style.id}`}
                                            onClick={() => setConfig({ ...config, charBubbleTheme: style.class, charBubbleColor: undefined })}
                                            className={`p-4 rounded-xl border text-left transition-all relative group
                                                ${config.charBubbleTheme === style.class && !config.charBubbleColor ? 'border-purple-500 bg-purple-900/10' : 'border-[#1e293b] bg-[#0f172a] hover:bg-[#1e293b]'}
                                            `}
                                        >
                                            <h4 className="font-bold text-xs text-zinc-400 mb-2">{style.name}</h4>
                                            <div className={`h-8 w-full rounded-lg ${style.class} shadow-sm`}></div>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                    {/* ... (Fonts, Text, Wallpaper tabs remain unchanged) ... */}
                    {activeTab === 'FONTS' && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {AVAILABLE_FONTS.map(font => (
                                    <button
                                        key={font.id}
                                        onClick={() => setConfig({ ...config, fontFamily: font.id })}
                                        className={`p-6 rounded-xl border text-left transition-all relative group flex flex-col justify-between min-h-[140px]
                                            ${config.fontFamily === font.id ? 'border-blue-500 bg-blue-900/10' : 'border-[#1e293b] bg-[#0f172a] hover:bg-[#1e293b]'}
                                        `}
                                    >
                                        <div>
                                            <div className="flex justify-between items-center mb-2">
                                                <h4 className={`font-bold text-lg ${config.fontFamily === font.id ? 'text-blue-400' : 'text-white'}`}>{font.name}</h4>
                                                {config.fontFamily === font.id && <CheckCircle size={18} className="text-blue-500"/>}
                                            </div>
                                            <p className="text-[10px] text-zinc-500 font-mono mb-4">{font.desc}</p>
                                        </div>
                                        <div className="text-sm text-zinc-300 opacity-80" style={{ fontFamily: font.id }}>
                                            The quick brown fox jumps over the lazy dog.<br/>
                                            1234567890
                                        </div>
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                    {activeTab === 'TEXT' && (
                        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2">
                            {/* ... Text preview and settings ... */}
                            <div className="p-6 bg-[#0f172a] border border-[#1e293b] rounded-xl flex flex-col gap-4">
                                <h4 className="text-xs font-mono font-bold text-zinc-500 uppercase tracking-widest">Text Style Preview</h4>
                                <div className="flex flex-col gap-2">
                                    <div 
                                        className="self-end bg-blue-600 rounded-lg p-3 rounded-tr-none max-w-[80%]" 
                                        style={{ 
                                            backgroundColor: config.userBubbleColor ? hexToRgba(config.userBubbleColor, config.userBubbleOpacity ?? 0.9) : undefined,
                                            '--tw-bg-opacity': config.userBubbleColor ? undefined : (config.userBubbleOpacity ?? 0.9)
                                        } as React.CSSProperties}
                                    >
                                        <p style={{ fontSize: `${config.fontSize}px`, color: config.userTextColor || 'white', fontFamily: config.fontFamily }}>Hello! This is a user message preview.</p>
                                    </div>
                                    <div 
                                        className="self-start bg-zinc-700 rounded-lg p-3 rounded-tl-none max-w-[80%]" 
                                        style={{ 
                                            backgroundColor: config.charBubbleColor ? hexToRgba(config.charBubbleColor, config.charBubbleOpacity ?? 0.9) : undefined,
                                            '--tw-bg-opacity': config.charBubbleColor ? undefined : (config.charBubbleOpacity ?? 0.9)
                                        } as React.CSSProperties}
                                    >
                                        <p style={{ fontSize: `${config.fontSize}px`, color: config.charTextColor || 'white', fontFamily: config.fontFamily }}>Hi there! This is how I will look like.</p>
                                    </div>
                                </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="p-6 rounded-xl border border-[#1e293b] bg-[#0f172a] space-y-4">
                                    <div className="flex justify-between items-center">
                                        <label className="text-xs font-bold uppercase text-zinc-400">Global Font Size</label>
                                        <span className="text-xs font-mono text-white bg-black/40 px-2 py-1 rounded">{config.fontSize}px</span>
                                    </div>
                                    <input 
                                        type="range" min="10" max="24" step="1" 
                                        value={config.fontSize} 
                                        onChange={(e) => setConfig({ ...config, fontSize: parseInt(e.target.value) })}
                                        className="w-full h-2 bg-zinc-800 rounded-lg cursor-pointer accent-blue-500"
                                    />
                                    <div className="flex justify-between text-[9px] text-zinc-500 font-mono">
                                        <span>Tiny</span>
                                        <span>Standard</span>
                                        <span>Large</span>
                                    </div>
                                </div>
                                <div className="p-6 rounded-xl border border-[#1e293b] bg-[#0f172a] space-y-6">
                                    <div className="space-y-2">
                                        <div className="flex justify-between items-center">
                                            <label className="text-xs font-bold uppercase text-zinc-400">User Text Color</label>
                                            {config.userTextColor && <button onClick={() => setConfig({...config, userTextColor: undefined})} className="text-[9px] text-red-400 hover:underline">Reset</button>}
                                        </div>
                                        <div className="flex items-center gap-2 bg-[#020617] p-2 rounded border border-[#1e293b]">
                                            <input 
                                                type="color" 
                                                value={config.userTextColor || '#ffffff'} 
                                                onChange={(e) => setConfig({ ...config, userTextColor: e.target.value })}
                                                className="w-full h-8 rounded cursor-pointer bg-transparent border-none p-0"
                                            />
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <div className="flex justify-between items-center">
                                            <label className="text-xs font-bold uppercase text-zinc-400">Character Text Color</label>
                                            {config.charTextColor && <button onClick={() => setConfig({...config, charTextColor: undefined})} className="text-[9px] text-red-400 hover:underline">Reset</button>}
                                        </div>
                                        <div className="flex items-center gap-2 bg-[#020617] p-2 rounded border border-[#1e293b]">
                                            <input 
                                                type="color" 
                                                value={config.charTextColor || '#ffffff'} 
                                                onChange={(e) => setConfig({ ...config, charTextColor: e.target.value })}
                                                className="w-full h-8 rounded cursor-pointer bg-transparent border-none p-0"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                    {activeTab === 'WALLPAPER' && (
                        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2">
                            <div className="aspect-video w-full rounded-2xl border-2 border-dashed border-[#1e293b] bg-[#0f172a] relative overflow-hidden flex items-center justify-center group">
                                {config.customBackground ? (
                                    <>
                                        {config.customBackground.startsWith('video|') ? (
                                            <video src={config.customBackground.replace('video|', '')} autoPlay loop muted className="w-full h-full object-cover" />
                                        ) : (
                                            <div className="w-full h-full bg-cover bg-center" style={{ backgroundImage: `url(${config.customBackground})` }}></div>
                                        )}
                                        <button 
                                            onClick={() => setConfig({ ...config, customBackground: null })}
                                            className="absolute top-4 right-4 p-2 bg-red-600/80 hover:bg-red-500 text-white rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                                        >
                                            <Trash2 size={16}/>
                                        </button>
                                    </>
                                ) : (
                                    <div className="flex flex-col items-center gap-4 text-zinc-600">
                                        <ImageIcon size={64} strokeWidth={1} />
                                        <span className="font-mono text-sm">No Active Wallpaper</span>
                                    </div>
                                )}
                            </div>
                            <div className="space-y-6 max-w-2xl mx-auto">
                                <div className="flex gap-2">
                                    <input 
                                        type="text" 
                                        value={config.customBackground || ''}
                                        onChange={(e) => setConfig({ ...config, customBackground: e.target.value })}
                                        placeholder="Paste Image URL..."
                                        className="flex-1 bg-[#0f172a] border border-[#1e293b] rounded-lg px-4 py-3 text-xs text-white outline-none focus:border-blue-500 font-mono"
                                    />
                                    <button className="px-6 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold text-xs uppercase shadow-lg shadow-blue-500/20">
                                        Set
                                    </button>
                                </div>
                                <div className="flex items-center gap-4">
                                    <div className="h-px bg-[#1e293b] flex-1"></div>
                                    <span className="text-[10px] font-bold text-zinc-600 uppercase">OR UPLOAD</span>
                                    <div className="h-px bg-[#1e293b] flex-1"></div>
                                </div>
                                <button 
                                    onClick={() => wallpaperInputRef.current?.click()}
                                    className="w-full py-4 border border-[#1e293b] hover:border-[#334155] rounded-xl text-zinc-400 hover:text-white flex items-center justify-center gap-2 transition-all hover:bg-[#1e293b]/50 group"
                                >
                                    <Upload size={16} className="group-hover:-translate-y-1 transition-transform"/> Upload Local File
                                </button>
                                <input type="file" ref={wallpaperInputRef} className="hidden" accept="image/*,video/*" onChange={handleWallpaperUpload} />
                                <div className="p-6 rounded-xl border border-[#1e293b] bg-[#0f172a] space-y-6">
                                    <h4 className="text-xs font-mono font-bold text-zinc-500 uppercase tracking-widest mb-4">Bubble Transparency</h4>
                                    <div className="space-y-2">
                                        <div className="flex justify-between text-[10px] font-mono text-zinc-400">
                                            <span>User Bubble</span>
                                            {/* FIX: Use Nullish Coalescing ?? to allow 0 */}
                                            <span>{Math.round((config.userBubbleOpacity ?? 0.9) * 100)}%</span>
                                        </div>
                                        <input 
                                            type="range" min="0" max="1" step="0.05"
                                            value={config.userBubbleOpacity ?? 0.9} 
                                            onChange={(e) => setConfig({ ...config, userBubbleOpacity: parseFloat(e.target.value) })}
                                            className="w-full h-2 bg-zinc-800 rounded-lg cursor-pointer accent-white"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <div className="flex justify-between text-[10px] font-mono text-zinc-400">
                                            <span>Character Bubble</span>
                                            {/* FIX: Use Nullish Coalescing ?? to allow 0 */}
                                            <span>{Math.round((config.charBubbleOpacity ?? 0.9) * 100)}%</span>
                                        </div>
                                        <input 
                                            type="range" min="0" max="1" step="0.05"
                                            value={config.charBubbleOpacity ?? 0.9} 
                                            onChange={(e) => setConfig({ ...config, charBubbleOpacity: parseFloat(e.target.value) })}
                                            className="w-full h-2 bg-zinc-800 rounded-lg cursor-pointer accent-white"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const getAutoBalance = (wealthClass: string): number => {
    const w = (wealthClass || "").toUpperCase();
    if (w.includes("DESTITUTE")) return 500_000; 
    if (w.includes("POOR")) return 5_000_000;
    if (w.includes("STUDENT")) return 20_000_000;
    if (w.includes("WORKING")) return 100_000_000;
    if (w.includes("MIDDLE")) return 1_000_000_000;
    if (w.includes("WEALTHY")) return 10_000_000_000;
    if (w.includes("RICH")) return 50_000_000_000;
    if (w.includes("ELITE")) return 200_000_000_000;
    if (w.includes("BILLIONAIRE")) return 999_000_000_000;
    return 50_000_000; // Default Average
};

interface ConfigPanelProps {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  messages: ChatMessage[];
  setMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
  onLaunch: () => void;
  hasLaunched: boolean;
  onClose?: () => void;
  onOpenThemeManager?: () => void;
}

const ConfigPanel: React.FC<ConfigPanelProps> = ({ config, setConfig, messages, setMessages, onLaunch, hasLaunched, onClose, onOpenThemeManager }) => {
  // ... (Existing state)
  const [activeTab, setActiveTab] = useState<'IDENTITY' | 'WORLD' | 'SYSTEM' | 'PROMPT' | 'ENGINE'>('IDENTITY');
  const [isInitializing, setIsInitializing] = useState(true);
  const [showAllChars, setShowAllChars] = useState(false);
  const [showBasicManual, setShowBasicManual] = useState(false);
  const [selectedManualItem, setSelectedManualItem] = useState<typeof BASIC_MANUAL_DATA[0] | null>(null);

  // NEW STATE: Active Prompt Target
  const [activePromptTarget, setActivePromptTarget] = useState<'GLOBAL' | number>('GLOBAL');

  // MODAL STATES FOR BODY/MIND
  const [showBodyModal, setShowBodyModal] = useState(false);
  const [showMindModal, setShowMindModal] = useState(false);
  const [showOutfitModal, setShowOutfitModal] = useState(false);
  const [activeOutfitTarget, setActiveOutfitTarget] = useState<'USER' | number>('USER');

  // File Refs
  const userFileRef = useRef<HTMLInputElement>(null);
  const charFileRef = useRef<HTMLInputElement>(null);
  const userAvatarRef = useRef<HTMLInputElement>(null);
  const charAvatarRef = useRef<HTMLInputElement>(null);
  const sysFileRef = useRef<HTMLInputElement>(null);
  const scenarioFileRef = useRef<HTMLInputElement>(null);
  const loreFileRef = useRef<HTMLInputElement>(null);

  // Component States
  const [activeCharAvatarIndex, setActiveCharAvatarIndex] = useState<number | null>(null);
  const [isProcessingAvatar, setIsProcessingAvatar] = useState(false);
  const [isProfilingUser, setIsProfilingUser] = useState(false);
  const [isProfilingChar, setIsProfilingChar] = useState(false); 
  const [isGeneratingScenario, setIsGeneratingScenario] = useState(false);
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false);
  const [sysInstructionMode, setSysInstructionMode] = useState<'CARD' | 'EDITOR'>('CARD');
  const [viewThemedCommands, setViewThemedCommands] = useState(false); // Collapsed by default
  const [viewSystemPrompt, setViewSystemPrompt] = useState(false); // Collapsed by default
  const [creatorMode, setCreatorMode] = useState<'USER' | 'CHAR' | 'LORE' | null>(null);
  const [editingLoreId, setEditingLoreId] = useState<string | null>(null);
  const [creatorContent, setCreatorContent] = useState('');
  const [creatorName, setCreatorName] = useState('');
  const [smartEditTarget, setSmartEditTarget] = useState<{ type: 'USER' | 'CHAR', index?: number } | null>(null);
  const [smartEditPrompt, setSmartEditPrompt] = useState('');
  const [isSmartEditing, setIsSmartEditing] = useState(false);
  
  // NEW: Raw Edit State
  const [rawEditTarget, setRawEditTarget] = useState<{ type: 'USER' | 'CHAR', index?: number } | null>(null);
  const [rawJsonContent, setRawJsonContent] = useState('');

  // API VAULT STATE
  const [newApiName, setNewApiName] = useState('');
  const [newApiKey, setNewApiKey] = useState('');

  // Theme Store State
  const [showThemeStore, setShowThemeStore] = useState(false);

  // Initial Load Delay to prevent UI freeze
  useEffect(() => {
      const timer = setTimeout(() => setIsInitializing(false), 300);
      return () => clearTimeout(timer);
  }, []);

  const theme = THEMES.find(t => t.id === config.theme) || THEMES[0];
  const t = theme.colors;

  // ... (Existing handlers: handleFileUpload, handleAvatarUpload, processCardContent, etc. kept same) ...
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'user' | 'character') => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      const textContent = event.target?.result as string;
      if (!textContent) return;
      processCardContent(textContent, type);
    };
    reader.readAsText(file);
    e.target.value = ''; 
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'USER' | 'CHAR') => {
      const file = e.target.files?.[0];
      if (!file) return;
      if (file.size > 5 * 1024 * 1024) {
          alert("File quá lớn! Vui lòng chọn ảnh < 5MB để tránh lỗi bộ nhớ.");
          e.target.value = '';
          return;
      }
      const reader = new FileReader();
      reader.onload = async (event) => {
          const base64 = event.target?.result as string;
          setIsProcessingAvatar(true);
          try {
              const croppedAvatar = await autoCropAvatar(base64);
              if (type === 'USER') {
                  setConfig(prev => prev.userCard ? ({ ...prev, userCard: { ...prev.userCard, avatar: croppedAvatar } }) : prev);
              } else if (type === 'CHAR' && activeCharAvatarIndex !== null) {
                  setConfig(prev => {
                      const newCards = [...prev.characterCards];
                      if (newCards[activeCharAvatarIndex]) {
                          newCards[activeCharAvatarIndex] = { ...newCards[activeCharAvatarIndex], avatar: croppedAvatar };
                      }
                      return { ...prev, characterCards: newCards };
                  });
              }
          } catch (e) {
              console.error("Avatar Crop Failed", e);
              alert("Lỗi xử lý ảnh. Vui lòng thử ảnh khác.");
          } finally {
              setIsProcessingAvatar(false);
          }
      };
      reader.readAsDataURL(file);
      e.target.value = '';
  };

  const processCardContent = async (textContent: string, type: 'user' | 'character') => {
      let initialData;
      try {
        initialData = parseTextCard(textContent);
        initialData.rawContent = textContent;
      } catch (e) {
         alert("Parse Error: Invalid card format."); return;
      }
      const apiKey = getEffectiveApiKey(config);
      if (type === 'user') {
          setIsProfilingUser(true);
          try {
             const enriched = await enrichCardWithAI(initialData, textContent, apiKey);
             enriched.rawContent = textContent;
             let finalBalance = 0;
             const existingBalanceStr = enriched.phone?.bankBalance || "0";
             const parsedExisting = parseBalance(existingBalanceStr);
             if (parsedExisting > 0) {
                 finalBalance = parsedExisting;
             } else {
                 const wealthClass = (enriched as any).wealthClass || "AVERAGE";
                 finalBalance = getAutoBalance(wealthClass);
                 if (enriched.phone) enriched.phone.bankBalance = formatVND(finalBalance);
             }
             setConfig(prev => {
                 const newRelationData = [...(prev.relationData || [])];
                 const exists = newRelationData.find(n => n.title === enriched.name);
                 if (!exists) {
                     newRelationData.push({
                         id: `node-${Date.now()}-${Math.random()}`,
                         title: enriched.name,
                         content: `${enriched.age || '?'} - ${enriched.role || 'PROTAGONIST'}`,
                         position: { x: Math.random() * 200 - 100, y: Math.random() * 200 - 100 },
                         connections: [],
                         connectionLabels: {},
                         type: 'RELATION'
                     });
                 }
                 return { 
                    ...prev, 
                    userCard: enriched,
                    gameStats: { ...prev.gameStats!, gold: finalBalance },
                    relationData: newRelationData
                 };
             });
          } catch (err) {
             console.error("AI Enrichment Failed:", err);
             setConfig(prev => ({ ...prev, userCard: initialData }));
          } finally {
             setIsProfilingUser(false);
          }
      } else {
          setIsProfilingChar(true);
          try {
             const enriched = await enrichCardWithAI(initialData, textContent, apiKey);
             enriched.rawContent = textContent;
             if (!enriched.role) enriched.role = 'SIDE';
             const existingBalanceStr = enriched.phone?.bankBalance || "0";
             if (parseBalance(existingBalanceStr) === 0) {
                 const wealthClass = (enriched as any).wealthClass || "AVERAGE";
                 const autoBal = getAutoBalance(wealthClass);
                 if(enriched.phone) enriched.phone.bankBalance = formatVND(autoBal);
             }
             setConfig(prev => {
                const newCards = [...(prev.characterCards || [])];
                const newRelationData = [...(prev.relationData || [])];
                newCards.push(enriched);
                
                // Add to relationData
                const exists = newRelationData.find(n => n.title === enriched.name);
                if (!exists) {
                    newRelationData.push({
                        id: `node-${Date.now()}-${Math.random()}`,
                        title: enriched.name,
                        content: `${enriched.age || '?'} - ${enriched.role || 'SIDE'}`,
                        position: { x: Math.random() * 200 - 100, y: Math.random() * 200 - 100 },
                        connections: [],
                        connectionLabels: {},
                        type: 'RELATION'
                    });
                }
                
                return { ...prev, characterCards: newCards, relationData: newRelationData };
             });
          } catch (err) {
             console.error("AI Enrichment Failed:", err);
             setConfig(prev => {
                const newCards = [...(prev.characterCards || [])];
                newCards.push(initialData);
                return { ...prev, characterCards: newCards };
             });
          } finally {
             setIsProfilingChar(false);
          }
      }
  };

  const handleDownloadCard = (card: CardData) => {
    let content = "";
    content += `Name: ${card.name}\n`;
    content += `Role: ${card.role || 'SIDE'}\n`;
    if (card.age) content += `Age: ${card.age}\n`;
    if (card.gender) content += `Gender: ${card.gender}\n`;
    if (card.pronouns) content += `Pronouns: ${card.pronouns}\n`;
    if (card.height) content += `Height: ${card.height}\n`;
    if (card.traits && card.traits.length > 0) content += `Traits: ${card.traits.join(', ')}\n`;
    if (card.status) {
        if (card.status.hp) content += `HP: ${card.status.hp}\n`;
        if (card.status.stress) content += `Stress: ${card.status.stress}\n`;
        if (card.status.secret) content += `Secret: ${card.status.secret}\n`;
    }
    if (card.description) content += `Description: ${card.description}\n`;
    if (card.phone) {
        if (card.phone.model) content += `Phone Model: ${card.phone.model}\n`;
        if (card.phone.wallpaper) content += `Wallpaper: ${card.phone.wallpaper}\n`;
        if (card.phone.bankBalance) content += `Bank: ${card.phone.bankBalance}\n`;
    }
    
    // ADDED: Include Diary Entries in Export
    if (card.diary && card.diary.length > 0) {
        content += `\nDiary:\n`;
        card.diary.forEach(entry => {
            content += `[${entry.date}] ${entry.title} | ${entry.content}\n`;
        });
    }

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${card.name.replace(/[^a-z0-9]/gi, '_')}_Card.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSaveCreator = () => {
    if (!creatorMode) return;
    if (creatorMode === 'LORE') {
        if (!creatorName.trim()) { alert("Please enter a name for the Lore Entry."); return; }
        setConfig(prev => {
            if (editingLoreId) {
                return {
                    ...prev,
                    loreItems: prev.loreItems.map(l => l.id === editingLoreId ? { ...l, name: creatorName, content: creatorContent } : l)
                };
            }
            return {
                ...prev,
                loreItems: [...(prev.loreItems || []), { id: Date.now().toString(), name: creatorName, content: creatorContent }]
            };
        });
    } else {
        processCardContent(creatorContent, creatorMode === 'USER' ? 'user' : 'character');
    }
    setCreatorMode(null); setCreatorContent(''); setCreatorName(''); setEditingLoreId(null);
  };

  const handleSmartEditSubmit = async () => {
    if (!smartEditTarget || !smartEditPrompt.trim()) return;
    setIsSmartEditing(true);
    try {
        let currentCard = smartEditTarget.type === 'USER' ? config.userCard : config.characterCards[smartEditTarget.index!];
        if (!currentCard) return;
        const apiKey = getEffectiveApiKey(config);
        const updatedCard = await smartEditCardWithAI(currentCard, smartEditPrompt, apiKey);
        if (smartEditTarget.type === 'USER') {
            setConfig(prev => ({ ...prev, userCard: updatedCard }));
        } else {
            setConfig(prev => {
                const newChars = [...prev.characterCards];
                newChars[smartEditTarget.index!] = updatedCard;
                return { ...prev, characterCards: newChars };
            });
        }
        setSmartEditTarget(null); setSmartEditPrompt('');
    } catch (e) {
        console.error(e);
        alert("Smart Edit Failed.");
    } finally {
        setIsSmartEditing(false);
    }
  };

  // --- RAW EDIT HANDLERS ---
  const handleOpenRawEdit = (target: { type: 'USER' | 'CHAR', index?: number }) => {
      let card = target.type === 'USER' ? config.userCard : config.characterCards[target.index!];
      if (card) {
          setRawEditTarget(target);
          setRawJsonContent(JSON.stringify(card, null, 2));
      }
  };

  const handleSaveRawEdit = () => {
      if (!rawEditTarget) return;
      try {
          const parsed = JSON.parse(rawJsonContent);
          if (rawEditTarget.type === 'USER') {
              setConfig(prev => ({ ...prev, userCard: parsed }));
          } else {
              setConfig(prev => {
                  const newChars = [...prev.characterCards];
                  newChars[rawEditTarget.index!] = parsed;
                  return { ...prev, characterCards: newChars };
              });
          }
          setRawEditTarget(null);
          setRawJsonContent('');
      } catch (e) {
          alert("Invalid JSON! Please check syntax.");
      }
  };

  // --- API VAULT FUNCTIONS ---
  const handleAddApiSlot = () => {
      if (!newApiName.trim() || !newApiKey.trim()) return;
      const newSlot: ApiSlot = {
          id: `api-${Date.now()}`,
          name: newApiName.trim(),
          key: newApiKey.trim()
      };
      setConfig(prev => ({
          ...prev,
          apiSlots: [...(prev.apiSlots || []), newSlot],
          activeApiKey: newSlot.key 
      }));
      setNewApiName('');
      setNewApiKey('');
  };

  const handleDeleteApiSlot = (id: string) => {
      setConfig(prev => {
          const newSlots = (prev.apiSlots || []).filter(s => s.id !== id);
          let newActive = prev.activeApiKey;
          const deletedSlot = prev.apiSlots?.find(s => s.id === id);
          if (deletedSlot && deletedSlot.key === prev.activeApiKey) {
              newActive = undefined;
          }
          return {
              ...prev,
              apiSlots: newSlots,
              activeApiKey: newActive
          };
      });
  };

  const handleActivateApiSlot = (key: string) => {
      setConfig(prev => ({ ...prev, activeApiKey: key }));
  };

  // --- PROMPT UPDATE HANDLERS ---
  const updateGlobalPrompt = (val: string) => {
      setConfig(prev => ({ ...prev, globalWorldPrompt: val }));
  };

  const updateStyleReference = (val: string) => {
      setConfig(prev => ({ ...prev, styleReference: val }));
  };

  const updateCharacterPrompt = (index: number, field: keyof CharacterPromptConfig, val: string) => {
      setConfig(prev => {
          const currentPrompts = prev.characterCustomPrompts || {};
          const charPrompt = currentPrompts[index] || {};
          
          return {
              ...prev,
              characterCustomPrompts: {
                  ...currentPrompts,
                  [index]: {
                      ...charPrompt,
                      [field]: val
                  }
              }
          };
      });
  };

  const userEffectClass = getProfileEffectStyles(config.profileEffect, 'nano');
  const charEffectClass = getProfileEffectStyles(config.profileEffect, 'purple');
  const containerClass = config.customBackground ? 'bg-transparent text-white' : `${t.bgMain} ${t.textMain}`;
  const headerClass = config.customBackground ? 'bg-black/60 backdrop-blur-md border-b border-white/10' : `${t.bgPanel} border-b ${t.border}`;

  if (isInitializing) {
      return (
          <div className={`h-full flex flex-col items-center justify-center ${t.bgMain} ${t.textMain}`}>
              <Loader2 size={32} className="animate-spin text-nano-400 mb-2"/>
              <p className="text-xs font-mono opacity-50">Loading Configuration Interface...</p>
          </div>
      );
  }

  const isActiveKeyCustom = !!config.activeApiKey;

  return (
    <div className={`h-full flex flex-col ${containerClass} border-r ${t.border} relative z-[200]`}>
      
      {/* 1. TOP HEADER */}
      <div className={`p-4 ${headerClass} sticky top-0 z-10 shrink-0`}>
        <div className="flex justify-between items-center gap-2">
          {/* Marquee Banner */}
          <div className={`hidden md:flex w-1/3 h-10 bg-black border border-nano-500/30 rounded overflow-hidden relative items-center shadow-[inset_0_0_10px_rgba(0,0,0,0.5)]`}>
             <div className="absolute inset-0 z-10 pointer-events-none bg-[linear-gradient(rgba(14,165,233,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(14,165,233,0.1)_1px,transparent_1px)] bg-[size:2px_2px] opacity-20"></div>
             <div className="animate-marquee whitespace-nowrap will-change-transform" style={{ paddingLeft: '100%' }}>
                <span className="text-nano-400 font-mono text-[10px] font-bold tracking-widest drop-shadow-[0_0_5px_rgba(14,165,233,0.8)] mx-4">
                   Quasar Nguyễn - Nếu bạn trả tiền để mua thì là bị SCAM rồi đó~
                </span>
             </div>
          </div>
          
          <button
            onClick={onLaunch}
            className={`flex-1 px-4 py-2.5 ${hasLaunched ? 'bg-purple-600 hover:bg-purple-500 border-purple-400' : 'bg-nano-600 hover:bg-nano-500 border-nano-400'} text-white font-mono font-bold rounded border shadow-[0_0_15px_rgba(14,165,233,0.3)] transition-all active:scale-95 flex items-center justify-center gap-2 text-[11px] uppercase`}
          >
            {hasLaunched ? <RefreshCw size={14} className="fill-current animate-spin-once" /> : <Zap size={14} className="fill-current" />}
            {hasLaunched ? "Update System" : "Initialize System"}
          </button>
          
          {onClose && (
             <button onClick={onClose} className={`p-2.5 rounded border ${t.border} ${t.hover} ${t.textDim} hover:text-red-400 transition-colors shadow-sm active:scale-95`}>
                <X size={16} />
             </button>
          )}
        </div>
        
        {/* TABS NAVIGATION */}
        <div className="flex border-t border-white/5 mt-3 pt-1 gap-1 items-center">
            {['IDENTITY', 'WORLD', 'SYSTEM', 'PROMPT', 'ENGINE'].map((tab) => (
                <button
                    key={tab}
                    onClick={() => setActiveTab(tab as any)}
                    className={`flex-1 py-2 text-[10px] font-bold font-mono tracking-wider transition-colors uppercase border-b-2 
                        ${activeTab === tab 
                            ? `text-nano-400 border-nano-400 bg-nano-900/10` 
                            : `${t.textDim} border-transparent hover:text-white hover:bg-white/5`}
                    `}
                >
                    {tab}
                </button>
            ))}
            <button 
                onClick={() => setShowBasicManual(true)} 
                className={`p-2 hover:bg-white/10 rounded transition-colors text-nano-400`}
                title="System Manual"
            >
                <HelpCircle size={14} />
            </button>
        </div>
      </div>

      {/* 2. SCROLLABLE CONTENT AREA */}
      <div className="flex-1 overflow-y-auto p-4 space-y-8 custom-scrollbar pb-10">
        
        {/* IDENTITY TAB */}
        {activeTab === 'IDENTITY' && (
            <div className="space-y-6 animate-in slide-in-from-right-4 fade-in duration-300">
                {/* ... (Existing Identity Code) ... */}
                <div>
                    <SectionTitle icon={<FileText size={16} />} title="Identity Matrix (.txt)" />
                    <div className="mb-4">
                        <div className="flex justify-between items-center mb-2">
                            <h4 className={`text-[10px] font-bold font-mono uppercase ${t.textDim}`}>User Identity</h4>
                            {config.userCard && !isProfilingUser && (
                                <span className="text-[8px] font-bold bg-green-500/20 text-green-400 px-1.5 py-0.5 rounded border border-green-500/20 uppercase">Active</span>
                            )}
                        </div>
                        {isProfilingUser ? (
                            <CardLoadingSkeleton colors={t} label="Analyzing Identity Matrix..." />
                        ) : config.userCard ? (
                            <div className={`rounded-xl border transition-all flex flex-col gap-0 bg-nano-900/10 overflow-hidden group relative ${userEffectClass}`}>
                                <ProfileEffectParticles type={config.profileEffect || 'standard'} />
                                <div className="relative h-40 w-full overflow-hidden bg-black/50 z-10">
                                    {config.userCard.avatar && (
                                        <div className="absolute inset-0 z-0">
                                            <img src={config.userCard.avatar} className="w-full h-full object-cover object-[80%_30%] opacity-90 group-hover:opacity-100 transition-all duration-500 filter contrast-110" />
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent"></div>
                                        </div>
                                    )}
                                    <div className="absolute top-2 right-2 flex gap-1 z-20">
                                        <button onClick={() => handleOpenRawEdit({ type: 'USER' })} className={`p-1.5 rounded-full bg-black/60 hover:bg-yellow-500/80 text-yellow-400 hover:text-white transition-colors border border-white/10 backdrop-blur-sm`} title="Raw JSON Edit"><FileJson size={12} /></button>
                                        <button onClick={() => { setActivePromptTarget('GLOBAL'); setShowBodyModal(true); }} className={`p-1.5 rounded-full bg-black/60 hover:bg-rose-500/80 text-rose-400 hover:text-white transition-colors border border-white/10 backdrop-blur-sm`} title="Edit Identity & Body"><User size={12} /></button>
                                        <button onClick={() => { setActivePromptTarget('GLOBAL'); setShowMindModal(true); }} className={`p-1.5 rounded-full bg-black/60 hover:bg-cyan-500/80 text-cyan-400 hover:text-white transition-colors border border-white/10 backdrop-blur-sm`} title="Mind Sculpting"><Brain size={12} /></button>
                                        <button onClick={() => { setActiveOutfitTarget('USER'); setShowOutfitModal(true); }} className={`p-1.5 rounded-full bg-black/60 hover:bg-emerald-500/80 text-emerald-400 hover:text-white transition-colors border border-white/10 backdrop-blur-sm`} title="Outfit Manager"><Shirt size={12} /></button>
                                        <button onClick={() => setSmartEditTarget({ type: 'USER' })} className={`p-1.5 rounded-full bg-black/60 hover:bg-indigo-500/80 text-indigo-400 hover:text-white transition-colors border border-white/10 backdrop-blur-sm`}><Wand2 size={12} /></button>
                                        <button onClick={() => userAvatarRef.current?.click()} className={`p-1.5 rounded-full bg-black/60 hover:bg-nano-500/80 text-nano-400 hover:text-white transition-colors border border-white/10 backdrop-blur-sm`}>{isProcessingAvatar ? <ScanEye size={12} className="animate-pulse text-yellow-400"/> : <Camera size={12} />}</button>
                                        <button onClick={() => config.userCard && handleDownloadCard(config.userCard)} className={`p-1.5 rounded-full bg-black/60 hover:bg-nano-500/80 text-nano-400 hover:text-white transition-colors border border-white/10 backdrop-blur-sm`}><Download size={12} /></button>
                                        <button onClick={() => setConfig(prev => ({ ...prev, userCard: null }))} className={`p-1.5 rounded-full bg-black/60 hover:bg-red-500/80 text-nano-400 hover:text-red-100 transition-colors border border-white/10 backdrop-blur-sm`}><X size={12} /></button>
                                    </div>
                                    <div className="absolute bottom-2 left-3 right-3 z-10 flex flex-col items-start">
                                        <span className={`text-base font-bold text-white truncate drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]`}>{config.userCard.name}</span>
                                        <div className="flex items-center gap-2 mt-0.5">
                                            {(config.userCard.age) && <span className={`text-[10px] text-gray-200 drop-shadow-md`}>{config.userCard.age}y</span>}
                                            {config.userCard.gender && <span className={`text-[10px] text-gray-200 drop-shadow-md flex items-center gap-1`}>| <User size={10}/> {config.userCard.gender}</span>}
                                        </div>
                                    </div>
                                </div>
                                {config.userCard.traits && config.userCard.traits.length > 0 && (
                                    <div className="p-2 bg-black/40 border-t border-white/10 flex flex-wrap gap-1 z-10 min-h-[34px] content-center">
                                        {config.userCard.traits.map((trait, i) => (
                                            <span key={i} className="text-[9px] font-mono px-2 py-0.5 bg-white/5 border border-white/10 rounded text-white/70 hover:bg-white/10 transition-colors">{trait}</span>
                                        ))}
                                    </div>
                                )}
                            </div>
                        ) : (
                            <div className="grid grid-cols-2 gap-2">
                                <button onClick={() => userFileRef.current?.click()} className={`flex flex-col items-center justify-center gap-1 p-3 rounded border border-dashed ${t.border} ${t.hover} text-xs font-mono opacity-90 hover:opacity-100 transition-all`}><Upload size={14} /> Import File</button>
                                <button onClick={() => setCreatorMode('USER')} className={`flex flex-col items-center justify-center gap-1 p-3 rounded border border-dashed ${t.border} ${t.hover} text-xs font-mono opacity-90 hover:opacity-100 transition-all`}><Edit2 size={14} /> Create</button>
                            </div>
                        )}
                        <input type="file" ref={userFileRef} className="hidden" accept=".txt" onChange={(e) => handleFileUpload(e, 'user')} />
                        <input type="file" ref={userAvatarRef} className="hidden" accept="image/*" onChange={(e) => handleAvatarUpload(e, 'USER')} />
                    </div>
                </div>
                <div>
                    <div className="flex justify-between items-center mb-2">
                        <h4 className={`text-[10px] font-bold font-mono uppercase ${t.textDim}`}>Character Roster</h4>
                        <span className={`text-[9px] font-mono ${t.accent}`}>{config.characterCards?.length || 0} Loaded</span>
                    </div>
                    <div className="grid grid-cols-1 gap-2">
                        {(showAllChars ? config.characterCards : config.characterCards.slice(0, 3)).map((card, idx) => (
                            <div key={idx} className={`rounded-xl border transition-all flex flex-col gap-0 group bg-purple-900/10 overflow-hidden relative ${charEffectClass}`}>
                                <ProfileEffectParticles type={config.profileEffect || 'standard'} />
                                <div className="relative h-40 w-full overflow-hidden bg-black/50 z-10">
                                    {card.avatar && (
                                        <div className="absolute inset-0 z-0">
                                            <img src={card.avatar} className="w-full h-full object-cover object-[80%_30%] opacity-90 group-hover:opacity-100 transition-all duration-500 filter contrast-110 sepia-[0.2]" />
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent"></div>
                                        </div>
                                    )}
                                    <div className="absolute top-2 right-2 flex gap-1 z-20">
                                        <button onClick={() => handleOpenRawEdit({ type: 'CHAR', index: idx })} className={`p-1.5 rounded-full bg-black/60 hover:bg-yellow-500/80 text-yellow-400 hover:text-white transition-colors border border-white/10 backdrop-blur-sm`} title="Raw JSON Edit"><FileJson size={12} /></button>
                                        <button onClick={() => { setActivePromptTarget(idx); setShowBodyModal(true); }} className={`p-1.5 rounded-full bg-black/60 hover:bg-rose-500/80 text-rose-400 hover:text-white transition-colors border border-white/10 backdrop-blur-sm`} title="Edit Identity & Body"><User size={12} /></button>
                                        <button onClick={() => { setActivePromptTarget(idx); setShowMindModal(true); }} className={`p-1.5 rounded-full bg-black/60 hover:bg-cyan-500/80 text-cyan-400 hover:text-white transition-colors border border-white/10 backdrop-blur-sm`} title="Mind Sculpting"><Brain size={12} /></button>
                                        <button onClick={() => { setActiveOutfitTarget(idx); setShowOutfitModal(true); }} className={`p-1.5 rounded-full bg-black/60 hover:bg-emerald-500/80 text-emerald-400 hover:text-white transition-colors border border-white/10 backdrop-blur-sm`} title="Outfit Manager"><Shirt size={12} /></button>
                                        <button onClick={() => setSmartEditTarget({ type: 'CHAR', index: idx })} className={`p-1.5 rounded-full bg-black/60 hover:bg-indigo-500/80 text-indigo-400 hover:text-white transition-colors border border-white/10 backdrop-blur-sm`}><Wand2 size={12} /></button>
                                        <button onClick={() => { setActiveCharAvatarIndex(idx); charAvatarRef.current?.click(); }} className={`p-1.5 rounded-full bg-black/60 hover:bg-purple-500/80 text-purple-400 hover:text-white transition-colors border border-white/10 backdrop-blur-sm`}><Camera size={12} /></button>
                                        <button onClick={() => setConfig(prev => ({ ...prev, characterCards: prev.characterCards.filter((_, i) => i !== idx) }))} className={`p-1.5 rounded-full bg-black/60 hover:bg-red-500/80 text-purple-400 hover:text-red-100 transition-colors border border-white/10 backdrop-blur-sm`}><Trash2 size={12} /></button>
                                    </div>
                                    <div className="absolute bottom-2 left-3 right-3 z-10 flex flex-col items-start">
                                        <div className="flex items-center gap-2">
                                            <span className={`text-base font-bold text-white truncate drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]`}>{card.name}</span>
                                            <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-tighter
                                                ${card.role === 'MAIN' ? 'bg-rose-500/20 text-rose-400 border-rose-500/30' : 
                                                  card.role === 'SIDE' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' : 
                                                  'bg-zinc-500/20 text-zinc-400 border-zinc-500/30'}
                                            `}>
                                                {card.role || 'SIDE'}
                                            </span>
                                        </div>
                                        <div className="flex flex-wrap items-center gap-2 mt-0.5 text-[10px] text-gray-200 drop-shadow-md">
                                            {card.age && <span>{card.age}y</span>}
                                            {card.gender && <span className="flex items-center gap-1">| <User size={10}/> {card.gender}</span>}
                                            {card.pronouns && <span className="flex items-center gap-1">| 🗣️ {card.pronouns}</span>}
                                        </div>
                                    </div>
                                </div>
                                {card.traits && card.traits.length > 0 && (
                                    <div className="p-2 bg-black/40 border-t border-white/10 flex flex-wrap gap-1 z-10 min-h-[34px] content-center">
                                        {card.traits.map((trait, i) => (
                                            <span key={i} className="text-[9px] font-mono px-2 py-0.5 bg-white/5 border border-white/10 rounded text-white/70 hover:bg-white/10 transition-colors">{trait}</span>
                                        ))}
                                    </div>
                                )}
                            </div>
                        ))}
                        {config.characterCards.length > 3 && (
                            <button onClick={() => setShowAllChars(!showAllChars)} className={`w-full py-2 flex items-center justify-center gap-2 text-[10px] font-mono font-bold uppercase border border-dashed rounded ${t.border} ${t.textDim} hover:${t.textMain}`}>
                                {showAllChars ? <ChevronUp size={12}/> : <ChevronDown size={12}/>}
                                {showAllChars ? "Collapse List" : `Show All (${config.characterCards.length})`}
                            </button>
                        )}
                        <div className="grid grid-cols-2 gap-2 mt-2">
                            <button onClick={() => charFileRef.current?.click()} className={`p-3 rounded border border-dashed ${t.border} ${t.hover} flex flex-col items-center justify-center gap-1 transition-all group opacity-90 hover:opacity-100`}>
                               {isProfilingChar ? <Loader2 size={14} className="animate-spin text-purple-400" /> : <UserPlus size={14} />}
                               <span className="text-xs font-mono">Import</span>
                            </button>
                            <button onClick={() => setCreatorMode('CHAR')} className={`p-3 rounded border border-dashed ${t.border} ${t.hover} flex flex-col items-center justify-center gap-1 transition-all group opacity-90 hover:opacity-100`}>
                               <Edit2 size={14} /><span className="text-xs font-mono">Create</span>
                            </button>
                        </div>
                        <input type="file" ref={charFileRef} className="hidden" accept=".txt" onChange={(e) => handleFileUpload(e, 'character')} />
                        <input type="file" ref={charAvatarRef} className="hidden" accept="image/*" onChange={(e) => handleAvatarUpload(e, 'CHAR')} />
                    </div>
                </div>
            </div>
        )}

        {/* ... (Existing WORLD, SYSTEM, PROMPT, ENGINE tabs content remains same) ... */}
        {activeTab === 'WORLD' && (
            <div className="space-y-6 animate-in slide-in-from-right-4 fade-in duration-300">
               
               {/* NEW: WORLD SETTING SELECTOR MOVED HERE */}
               <section>
                    <SectionTitle icon={<Globe size={16} />} title="World Setting (Archetype)" />
                    <div className="bg-[#0f1115] border border-white/10 rounded-xl p-4">
                        <GridSelect 
                            options={WORLDS} 
                            selected={config.world} 
                            onChange={(val) => setConfig(prev => ({ ...prev, world: val }))} 
                            multi 
                            cols={2} // Wider cards to read descriptions
                        />
                    </div>
               </section>

               <section>
                    <SectionTitle icon={<Book size={16} />} title="LoreBook / World Info" />
                    <div className="flex flex-col gap-2">
                         {config.loreItems && config.loreItems.map((item) => (
                             <div key={item.id} className={`p-2 rounded border bg-amber-900/10 border-amber-500/30 hover:border-amber-500/60 flex justify-between items-center transition-all group`}>
                                 <div className="flex items-center gap-2 overflow-hidden">
                                     <Book size={12} className="text-amber-500 shrink-0" />
                                     <span className={`text-[10px] font-mono font-bold ${t.textMain} truncate`}>{item.name}</span>
                                 </div>
                                 <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all">
                                     <button onClick={() => { setCreatorName(item.name); setCreatorContent(item.content); setEditingLoreId(item.id); setCreatorMode('LORE'); }} className={`p-1 rounded hover:bg-amber-500/20 text-amber-500 transition-colors`}><Edit2 size={12} /></button>
                                     <button onClick={() => setConfig(prev => ({ ...prev, loreItems: prev.loreItems.filter(l => l.id !== item.id) }))} className={`p-1 rounded hover:bg-red-500/20 text-amber-500 hover:text-red-400 transition-colors`}><X size={12} /></button>
                                 </div>
                             </div>
                         ))}
                         <div className="grid grid-cols-2 gap-2 mt-2">
                            <button onClick={() => loreFileRef.current?.click()} className={`p-3 rounded border border-dashed ${t.border} ${t.hover} flex flex-col items-center justify-center gap-1 transition-all group opacity-90 hover:opacity-100`}>
                               <Upload size={14} /><span className="text-xs font-mono">Upload</span>
                            </button>
                            <button onClick={() => { setCreatorName(''); setCreatorContent(''); setEditingLoreId(null); setCreatorMode('LORE'); }} className={`p-3 rounded border border-dashed ${t.border} ${t.hover} flex flex-col items-center justify-center gap-1 transition-all group opacity-90 hover:opacity-100`}>
                               <Edit2 size={14} /><span className="text-xs font-mono">Create</span>
                            </button>
                         </div>
                         <input type="file" ref={loreFileRef} className="hidden" accept=".txt" onChange={(e) => {
                             const file = e.target.files?.[0];
                             if (file) {
                                 const reader = new FileReader();
                                 reader.onload = (ev) => {
                                     const content = ev.target?.result as string;
                                     setConfig(prev => ({ ...prev, loreItems: [...(prev.loreItems || []), { id: Date.now().toString(), name: file.name.replace('.txt',''), content }] }));
                                 };
                                 reader.readAsText(file);
                             }
                             e.target.value = '';
                         }} />
                    </div>
                </section>
                <section>
                    <SectionTitle icon={<Film size={16} />} title="Starting Scenario" />
                    <div className={`p-3 rounded border flex flex-col gap-2 ${config.customBackground ? 'bg-black/40 border-white/20' : `${t.bgPanel} ${t.border} ${t.inputBg}`}`}>
                        <div className="flex gap-2">
                            <BufferedTextarea 
                                className={`flex-1 bg-transparent text-xs font-mono resize-none h-24 outline-none ${t.textMain} placeholder:${t.textDim}`}
                                placeholder="// Define the opening scene here..." 
                                value={config.scenario || ''}
                                onChange={(val) => setConfig(prev => ({ ...prev, scenario: val }))} 
                            />
                            <div className="flex flex-col gap-2">
                                <button onClick={() => scenarioFileRef.current?.click()} className={`p-2 rounded border border-dashed hover:bg-white/5 ${t.border} ${t.textDim}`} title="Upload"><Upload size={14}/></button>
                                <button 
                                    onClick={async () => {
                                        setIsGeneratingScenario(true);
                                        const newScen = await generateScenarioWithAI(config, config.scenario || '');
                                        setConfig(prev => ({ ...prev, scenario: newScen }));
                                        setIsGeneratingScenario(false);
                                    }}
                                    className={`p-2 rounded border border-dashed hover:bg-white/5 ${t.border} ${t.textDim} ${isGeneratingScenario ? 'animate-pulse text-yellow-400' : ''}`} 
                                    title="AI Generate"
                                >
                                    {isGeneratingScenario ? <Loader2 size={14} className="animate-spin"/> : <Sparkles size={14}/>}
                                </button>
                            </div>
                        </div>
                        <input type="file" ref={scenarioFileRef} className="hidden" accept=".txt" onChange={(e) => {
                             const file = e.target.files?.[0];
                             if (file) {
                                 const reader = new FileReader();
                                 reader.onload = (ev) => {
                                     setConfig(prev => ({ ...prev, scenario: ev.target?.result as string }));
                                 };
                                 reader.readAsText(file);
                             }
                             e.target.value = '';
                        }} />
                    </div>
                </section>

                <section className="animate-in fade-in slide-in-from-bottom-4 duration-700 delay-150">
                    <SectionTitle icon={<Brain size={16} />} title="Long-Term Memory (Context Memory)" />
                    <div className={`p-4 rounded-xl border ${t.border} bg-black/20 flex flex-col gap-4 group/kiuc`}>
                        <div className="flex flex-col gap-2">
                             <div className="flex items-center justify-between text-[10px] uppercase font-bold text-emerald-400 font-mono tracking-wider">
                                 <span className="flex items-center gap-1"><Terminal size={10}/> INFINITE CONTEXT ENABLED</span>
                                 <span className="bg-emerald-900/30 px-1 py-0.5 rounded text-emerald-300">SYSTEM ACTIVE</span>
                             </div>
                             <p className="text-white/50 text-xs mt-2 font-mono">
                                 &gt; The AI now uses the entire chat history natively (up to 2,000,000+ tokens).<br/>
                                 &gt; Autokiuc summarizer is disabled to prevent hallucinations and maintain 100% accurate recall.
                             </p>
                        </div>

                        {/* Scanner Settings */}
                        <div className="space-y-4 pt-4 border-t border-white/5">
                            <div>
                                <div className="flex justify-between text-xs mb-1">
                                    <span className="text-white/70">Context Scanner Interval</span>
                                    <span className="text-emerald-400 font-mono">{config.contextScanInterval ? `Every ${config.contextScanInterval} msgs` : 'Disabled'}</span>
                                </div>
                                <input 
                                    type="range" 
                                    min="0" max="20" step="1" 
                                    value={config.contextScanInterval || 0} 
                                    onChange={(e) => setConfig(prev => ({...prev, contextScanInterval: parseInt(e.target.value)}))}
                                    className="w-full accent-emerald-500" 
                                />
                                <p className="text-[10px] text-white/40 mt-1">Gợi nhắc AI tự rà soát lại các cảnh vật, đồ đạc trước đó sau mỗi X tin nhắn để tránh lỗi cá vàng.</p>
                            </div>
                            
                            {config.contextScanInterval && config.contextScanInterval > 0 ? (
                                <div>
                                    <div className="flex justify-between text-xs mb-1">
                                        <span className="text-white/70">Scan Scope (Length)</span>
                                        <span className="text-emerald-400 font-mono">{config.contextScanLength || 5} msgs</span>
                                    </div>
                                    <input 
                                        type="range" 
                                        min="2" max="30" step="1" 
                                        value={config.contextScanLength || 5} 
                                        onChange={(e) => setConfig(prev => ({...prev, contextScanLength: parseInt(e.target.value)}))}
                                        className="w-full accent-emerald-500 opacity-80" 
                                    />
                                    <p className="text-[10px] text-white/40 mt-1">Số lượng tin nhắn gần nhất AI sẽ tập trung "quét" lại tính liên kết vật lý (đồ vật, nhiệt độ).</p>
                                </div>
                            ) : null}
                        </div>
                    </div>
                </section>

                <section className="animate-in fade-in slide-in-from-bottom-4 duration-700 delay-175">
                    <SectionTitle icon={<MapPin size={16} />} title="Spatial & Temporal Tracker" />
                    <div className={`p-4 rounded-xl border ${t.border} bg-black/20 flex flex-col gap-3`}>
                        <div className="flex items-center justify-between text-[10px] uppercase font-bold text-blue-400 font-mono tracking-wider mb-1">
                             <span className="flex items-center gap-1"><MapPin size={10}/> REALTIME ENVIRONMENT</span>
                             <span className="bg-blue-900/30 px-1 py-0.5 rounded text-blue-300">AUTO-SCANNED</span>
                        </div>
                        <div className="flex flex-col gap-2">
                             <input 
                                 className="w-full bg-black/40 rounded p-2 text-sm font-bold text-white uppercase placeholder:text-white/20 focus:outline-none focus:ring-1 focus:ring-blue-500/50" 
                                 value={config.currentLocation || ''} 
                                 onChange={(e) => setConfig(prev => ({...prev, currentLocation: e.target.value}))} 
                                 placeholder="CURRENT LOCATION..."
                             />
                             <input 
                                 className="w-full bg-black/40 rounded p-2 text-sm text-yellow-400 font-mono placeholder:text-yellow-400/20 focus:outline-none focus:ring-1 focus:ring-blue-500/50" 
                                 value={config.currentTime || ''} 
                                 onChange={(e) => setConfig(prev => ({...prev, currentTime: e.target.value}))} 
                                 placeholder="CURRENT TIME..."
                             />
                             <input 
                                 className="w-full bg-black/40 rounded p-2 text-sm text-cyan-400 font-mono placeholder:text-cyan-400/20 focus:outline-none focus:ring-1 focus:ring-blue-500/50" 
                                 value={config.currentWeather || ''} 
                                 onChange={(e) => setConfig(prev => ({...prev, currentWeather: e.target.value}))} 
                                 placeholder="CURRENT WEATHER/LIGHTING..."
                             />
                             <textarea 
                                 className="w-full bg-black/40 rounded p-2 text-sm text-white/80 resize-none h-20 placeholder:text-white/20 focus:outline-none focus:ring-1 focus:ring-blue-500/50 leading-relaxed" 
                                 value={config.locationDescription || ''} 
                                 onChange={(e) => setConfig(prev => ({...prev, locationDescription: e.target.value}))} 
                                 placeholder="Location details and atmosphere..."
                             />
                        </div>
                    </div>
                </section>


            </div>
        )}

        {activeTab === 'SYSTEM' && (
            <div className="space-y-6 animate-in slide-in-from-right-4 fade-in duration-300">
                <section>
                    <SectionTitle icon={<Key size={16} />} title="API KEY VAULT (API SLOTS)" />
                    <div className={`p-4 rounded-lg border ${t.border} bg-black/20 flex flex-col gap-4`}>
                        <div className={`p-3 rounded border flex items-center justify-between ${isActiveKeyCustom ? 'bg-green-900/30 border-green-500/50' : 'bg-yellow-900/30 border-yellow-500/50'}`}>
                            <span className="text-[10px] font-bold font-mono uppercase text-zinc-300">Current API Source:</span>
                            <div className="flex items-center gap-2">
                                <span className={`text-xs font-black font-mono uppercase ${isActiveKeyCustom ? 'text-green-400' : 'text-yellow-400'}`}>
                                    {isActiveKeyCustom ? 'CUSTOM KEY (Active)' : 'ENV DEFAULT (Fallback)'}
                                </span>
                                {isActiveKeyCustom && <CheckCircle size={14} className="text-green-400" />}
                            </div>
                        </div>
                        <div className="flex flex-col gap-2 p-3 bg-black/40 rounded border border-white/5">
                            <div className="flex gap-2">
                                <input 
                                    type="text" 
                                    value={newApiName} 
                                    onChange={(e) => setNewApiName(e.target.value)} 
                                    onKeyDown={(e) => e.key === 'Enter' && handleAddApiSlot()}
                                    placeholder="Name (e.g. My Paid Key)" 
                                    className={`flex-1 bg-transparent border-b ${t.border} text-xs ${t.textMain} outline-none px-2 py-1 placeholder:text-zinc-600 font-mono`}
                                />
                                <button 
                                    onClick={handleAddApiSlot}
                                    disabled={!newApiName || !newApiKey}
                                    className={`px-3 py-1 bg-green-600 hover:bg-green-500 text-white rounded text-[10px] font-bold uppercase transition-all disabled:opacity-50`}
                                >
                                    Add & Activate
                                </button>
                            </div>
                            <input 
                                type="password" 
                                value={newApiKey} 
                                onChange={(e) => setNewApiKey(e.target.value)} 
                                onKeyDown={(e) => e.key === 'Enter' && handleAddApiSlot()}
                                placeholder="Paste API Key here..." 
                                className={`w-full bg-transparent border-b ${t.border} text-xs ${t.textMain} outline-none px-2 py-1 placeholder:text-zinc-600 font-mono`}
                            />
                        </div>
                        <div className="flex flex-col gap-2">
                            <div className={`flex items-center justify-between p-3 rounded border transition-all ${!isActiveKeyCustom ? 'bg-green-900/20 border-green-500/50 shadow-[0_0_10px_rgba(34,197,94,0.1)]' : `${t.bgPanel} ${t.border} opacity-70`}`}>
                                <div className="flex flex-col">
                                    <span className={`text-xs font-bold uppercase ${!isActiveKeyCustom ? 'text-green-400' : t.textDim}`}>Default (Env)</span>
                                    <span className="text-[9px] font-mono text-zinc-500">process.env.API_KEY</span>
                                </div>
                                {!isActiveKeyCustom ? (
                                    <span className="text-[9px] font-bold bg-green-900/40 text-green-400 px-2 py-1 rounded border border-green-500/20 uppercase flex items-center gap-1"><CheckCircle size={10}/> Active</span>
                                ) : (
                                    <button 
                                        onClick={() => setConfig(prev => ({ ...prev, activeApiKey: undefined }))}
                                        className="text-[9px] font-bold bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-2 py-1 rounded uppercase transition-colors"
                                    >
                                        Use Default
                                    </button>
                                )}
                            </div>
                            {(config.apiSlots || []).map(slot => {
                                const isActive = config.activeApiKey === slot.key;
                                return (
                                    <div key={slot.id} className={`flex items-center justify-between p-3 rounded border transition-all group ${isActive ? 'bg-green-900/20 border-green-500/50 shadow-[0_0_10px_rgba(34,197,94,0.1)]' : `${t.bgPanel} ${t.border}`}`}>
                                        <div className="flex flex-col flex-1 min-w-0 pr-4">
                                            <span className={`text-xs font-bold uppercase truncate ${isActive ? 'text-green-400' : t.textMain}`}>{slot.name}</span>
                                            <span className="text-[9px] font-mono text-zinc-500 truncate">••••••••••••{slot.key.slice(-4)}</span>
                                        </div>
                                        <div className="flex items-center gap-2 shrink-0">
                                            {isActive ? (
                                                <span className="text-[9px] font-bold bg-green-900/40 text-green-400 px-2 py-1 rounded border border-green-500/20 uppercase flex items-center gap-1"><CheckCircle size={10}/> Active</span>
                                            ) : (
                                                <button 
                                                    onClick={() => handleActivateApiSlot(slot.key)}
                                                    className="text-[9px] font-bold bg-zinc-800 hover:bg-green-600 hover:text-white text-zinc-300 px-2 py-1 rounded uppercase transition-colors"
                                                >
                                                    Use Key
                                                </button>
                                            )}
                                            <button 
                                                onClick={() => handleDeleteApiSlot(slot.id)}
                                                className="p-1 text-zinc-600 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100"
                                            >
                                                <Trash2 size={14}/>
                                            </button>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </section>
                <section>
                    <SectionTitle icon={<FileCode size={16} />} title="Themed Commands (ASCII)" />
                    <div className="bg-[#0B1221] border border-[#1E293B] rounded-lg overflow-hidden">
                        <div 
                            className="flex justify-between items-center px-4 py-3 bg-[#162032] border-b border-[#1E293B] cursor-pointer hover:bg-[#1e293b] transition-colors"
                            onClick={() => setViewThemedCommands(!viewThemedCommands)}
                        >
                            <div className="flex items-center gap-2">
                                <span className="text-emerald-500"><Command size={14}/></span>
                                <span className="text-xs font-bold text-emerald-400 tracking-wider">SLASH COMMAND PROTOCOL</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <button className="text-slate-500 hover:text-white transition-colors"><Edit2 size={12}/></button>
                                {viewThemedCommands ? <ChevronUp size={14} className="text-slate-500"/> : <ChevronDown size={14} className="text-slate-500"/>}
                            </div>
                        </div>
                        {viewThemedCommands && (
                            <div className="p-0 animate-in slide-in-from-top-2">
                                <BufferedTextarea 
                                    className="w-full h-48 bg-[#0a0a0a] p-4 text-[10px] font-mono text-green-400 outline-none resize-none"
                                    value={config.themedCommandsInstruction || ''}
                                    onChange={(val) => setConfig(prev => ({ ...prev, themedCommandsInstruction: val }))}
                                    placeholder="// DEFINE UI RENDERING LOGIC..."
                                />
                            </div>
                        )}
                    </div>
                </section>
                <section>
                    <SectionTitle icon={<HardDrive size={16} />} title="Auto-Export Strategy" />
                    <div className="bg-[#0B1221] border border-[#1E293B] rounded-lg p-4">
                        <div className="flex justify-between items-center mb-4">
                            <div className="flex flex-col">
                                <span className="text-xs font-bold text-slate-300 uppercase">Export Interval</span>
                                <span className="text-[10px] text-slate-500">Auto-save full JSON backup every X turns.</span>
                            </div>
                            <div className={`px-2 py-1 rounded text-[10px] font-bold border ${config.autoExportInterval > 0 ? 'bg-cyan-900/30 text-cyan-400 border-cyan-500/30' : 'bg-slate-800 text-slate-500 border-slate-700'}`}>
                                {config.autoExportInterval > 0 ? 'ENABLED' : 'DISABLED'}
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <span className="text-[10px] font-mono text-slate-500">Off</span>
                            <input 
                                type="range" 
                                min="0" max="50" step="5" 
                                value={config.autoExportInterval} 
                                onChange={(e) => setConfig(prev => ({ ...prev, autoExportInterval: parseInt(e.target.value) }))}
                                className="flex-1 h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                            />
                            <span className="text-[10px] font-mono text-cyan-400 font-bold">{config.autoExportInterval}</span>
                        </div>
                    </div>
                </section>
            </div>
        )}

        {/* ... (PROMPT TAB & ENGINE TAB & Creator Modals remain same) ... */}
        {activeTab === 'PROMPT' && (
            <div className="space-y-4 animate-in slide-in-from-right-4 fade-in duration-300 pb-20">
                {/* Visual Overlays Section */}
                <section className="mb-8">
                    <SectionTitle icon={<Layers size={16} />} title="Visual Overlays" color="text-purple-400" />
                    <button
                        onClick={onOpenThemeManager}
                        className="w-full py-4 bg-gradient-to-r from-purple-900/20 to-blue-900/20 border border-white/10 hover:border-purple-500/50 rounded-xl flex items-center gap-4 px-4 group transition-all hover:bg-white/5"
                    >
                        <div className="p-3 bg-black/50 rounded-lg group-hover:bg-purple-500/20 transition-colors border border-white/5">
                            <ImageIcon size={24} className="text-purple-400" />
                        </div>
                        <div className="flex-1 text-left">
                            <div className="text-sm font-bold text-white group-hover:text-purple-300 uppercase tracking-wide">Manage Theme Overlays</div>
                            <div className="text-[10px] text-zinc-400 group-hover:text-zinc-300 mt-1">Add stickers, decorations, and custom layers</div>
                        </div>
                        <div className="p-2 bg-white/5 rounded-full group-hover:bg-purple-500/20">
                            <Settings size={16} className="text-zinc-500 group-hover:text-purple-300" />
                        </div>
                    </button>
                </section>

                {/* Warning */}
                <div className="p-3 rounded-lg border border-yellow-500/30 bg-yellow-900/10 flex items-center gap-2">
                     <AlertTriangle size={14} className="text-yellow-400 shrink-0"/>
                     <span className="text-[10px] text-yellow-200/70 font-mono">Overrides default behavior. Use caution.</span>
                </div>

                {/* Navigation Bar (The "1 thanh") */}
                <div className="flex gap-2 overflow-x-auto custom-scrollbar pb-2 border-b border-white/5">
                    <button
                        onClick={() => setActivePromptTarget('GLOBAL')}
                        className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-bold uppercase transition-all whitespace-nowrap
                            ${activePromptTarget === 'GLOBAL' ? 'bg-emerald-600 border-emerald-500 text-white shadow-lg shadow-emerald-900/20' : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-zinc-300 hover:border-zinc-700'}
                        `}
                    >
                        <Globe size={14} /> Global World
                    </button>
                    {config.characterCards.length > 0 ? (
                        config.characterCards.map((char, idx) => (
                            <button
                                key={idx}
                                onClick={() => setActivePromptTarget(idx)}
                                className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-bold uppercase transition-all whitespace-nowrap
                                    ${activePromptTarget === idx ? 'bg-pink-600 border-pink-500 text-white shadow-lg shadow-pink-900/20' : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-zinc-300 hover:border-zinc-700'}
                                `}
                            >
                                <User size={14} /> {char.name}
                            </button>
                        ))
                    ) : (
                        <div className="px-3 py-2 text-[10px] text-zinc-600 italic border border-dashed border-white/10 rounded-lg">No characters loaded</div>
                    )}
                </div>

                {/* Content Area */}
                <div className="bg-[#0f1115] border border-white/10 rounded-xl p-4 min-h-[300px]">
                    {activePromptTarget === 'GLOBAL' ? (
                        <div className="space-y-6 animate-in fade-in">
                            {/* Global World Rules */}
                            <div className="space-y-2">
                                <label className="text-xs font-bold text-emerald-400 uppercase flex items-center gap-2 mb-2">
                                    <Globe size={14}/> Global World Rules Override
                                </label>
                                <BufferedTextarea 
                                    className="w-full h-64 bg-black/40 border border-white/10 rounded-lg p-3 text-xs font-mono text-emerald-100 placeholder-emerald-800/50 outline-none resize-none focus:border-emerald-500/50 transition-colors leading-relaxed"
                                    value={config.globalWorldPrompt || ''}
                                    onChange={(val) => updateGlobalPrompt(val)}
                                    placeholder="// Describe how the world operates, physics, magic, technology level, society rules..."
                                />
                            </div>
                        </div>
                    ) : (
                        // Character Inputs
                        (() => {
                            const idx = activePromptTarget as number;
                            const char = config.characterCards[idx];
                            const p = config.characterCustomPrompts?.[idx] || {};
                            
                            if (!char) return null;

                            return (
                                <div className="space-y-6 animate-in fade-in">
                                    <div className="flex items-center gap-2 pb-4 border-b border-white/5">
                                        <div className="w-8 h-8 rounded-full overflow-hidden bg-black flex items-center justify-center border border-white/10">
                                            {char.avatar ? <img src={char.avatar} className="w-full h-full object-cover"/> : <User size={16} className="text-zinc-500"/>}
                                        </div>
                                        <span className="font-bold text-sm text-white uppercase tracking-wider">{char.name}</span>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="space-y-1">
                                            <label className="text-[10px] font-bold text-cyan-400 uppercase flex items-center gap-1">
                                                <Mic size={12}/> Speech Pattern
                                            </label>
                                            <BufferedTextarea 
                                                className="w-full h-24 bg-black/40 border border-white/5 rounded p-2 text-[11px] text-zinc-300 font-mono outline-none focus:border-cyan-500/30 resize-none"
                                                value={p.speechStyle || ''}
                                                onChange={(val) => updateCharacterPrompt(idx, 'speechStyle', val)}
                                                placeholder="e.g. Uses slang, speaks formally..."
                                            />
                                        </div>

                                        <div className="space-y-1">
                                            <label className="text-[10px] font-bold text-orange-400 uppercase flex items-center gap-1">
                                                <Zap size={12}/> Action Style
                                            </label>
                                            <BufferedTextarea 
                                                className="w-full h-24 bg-black/40 border border-white/5 rounded p-2 text-[11px] text-zinc-300 font-mono outline-none focus:border-orange-500/30 resize-none"
                                                value={p.actionStyle || ''}
                                                onChange={(val) => updateCharacterPrompt(idx, 'actionStyle', val)}
                                                placeholder="e.g. Aggressive movements, clumsy..."
                                            />
                                        </div>

                                        <div className="space-y-1">
                                            <label className="text-[10px] font-bold text-purple-400 uppercase flex items-center gap-1">
                                                <Brain size={12}/> Thought Process
                                            </label>
                                            <BufferedTextarea 
                                                className="w-full h-24 bg-black/40 border border-white/5 rounded p-2 text-[11px] text-zinc-300 font-mono outline-none focus:border-purple-500/30 resize-none"
                                                value={p.thoughtStyle || ''}
                                                onChange={(val) => updateCharacterPrompt(idx, 'thoughtStyle', val)}
                                                placeholder="e.g. Overthinks everything..."
                                            />
                                        </div>

                                        <div className="space-y-1">
                                            <label className="text-[10px] font-bold text-red-400 uppercase flex items-center gap-1">
                                                <Target size={12}/> Problem Solving
                                            </label>
                                            <BufferedTextarea 
                                                className="w-full h-24 bg-black/40 border border-white/5 rounded p-2 text-[11px] text-zinc-300 font-mono outline-none focus:border-red-500/30 resize-none"
                                                value={p.problemSolving || ''}
                                                onChange={(val) => updateCharacterPrompt(idx, 'problemSolving', val)}
                                                placeholder="e.g. Violence first, negotiation later."
                                            />
                                        </div>

                                        <div className="space-y-1">
                                            <label className="text-[10px] font-bold text-green-400 uppercase flex items-center gap-1">
                                                <Eye size={12}/> World View
                                            </label>
                                            <BufferedTextarea 
                                                className="w-full h-24 bg-black/40 border border-white/5 rounded p-2 text-[11px] text-zinc-300 font-mono outline-none focus:border-green-500/30 resize-none"
                                                value={p.worldView || ''}
                                                onChange={(val) => updateCharacterPrompt(idx, 'worldView', val)}
                                                placeholder="e.g. The world is cruel, trust no one."
                                            />
                                        </div>

                                        <div className="space-y-1">
                                            <label className="text-[10px] font-bold text-pink-400 uppercase flex items-center gap-1">
                                                <MessageCircle size={12}/> Whisper/Intimacy
                                            </label>
                                            <BufferedTextarea 
                                                className="w-full h-24 bg-black/40 border border-white/5 rounded p-2 text-[11px] text-zinc-300 font-mono outline-none focus:border-pink-500/30 resize-none"
                                                value={p.whisperStyle || ''}
                                                onChange={(val) => updateCharacterPrompt(idx, 'whisperStyle', val)}
                                                placeholder="e.g. Husky voice when close..."
                                            />
                                        </div>
                                    </div>
                                </div>
                            );
                        })()
                    )}
                </div>
            </div>
        )}

        {activeTab === 'ENGINE' && (
            <div className="space-y-8 animate-in slide-in-from-right-4 fade-in duration-300 pb-20">
                {/* 1. PRESETS */}
                <section>
                    <SectionTitle icon={<Layers size={16} />} title="Config Presets" color="text-cyan-400" />
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {PRESETS.map(preset => (
                            <button
                                key={preset.id}
                                onClick={() => setConfig(prev => ({ ...prev, ...preset.config }))}
                                className="relative p-3 bg-gradient-to-br from-slate-900 to-black border border-white/10 hover:border-cyan-500/50 rounded-xl text-left transition-all group overflow-hidden shadow-lg hover:shadow-cyan-500/10 min-h-[80px] flex flex-col justify-between"
                            >
                                <div className="absolute top-0 right-0 p-1 opacity-20 group-hover:opacity-100 transition-opacity">
                                    <Sparkles size={12} className="text-cyan-400"/>
                                </div>
                                <div className="text-xs font-bold text-slate-200 group-hover:text-cyan-300 uppercase tracking-tight relative z-10">{preset.name}</div>
                                <div className="text-[10px] text-slate-500 mt-1 relative z-10">{preset.description}</div>
                            </button>
                        ))}
                    </div>
                </section>

                {/* 2. CORE PARAMETERS */}
                <section>
                    <SectionTitle icon={<Settings size={16} />} title="Core Parameters" color="text-cyan-400" />
                    <div className="space-y-6">
                        <div>
                            <div className="text-[10px] font-bold text-slate-500 uppercase mb-2">Narrative Kernel</div>
                            <GridSelect 
                                options={KERNELS} 
                                selected={config.kernel} 
                                onChange={(val) => setConfig(prev => ({ ...prev, kernel: val }))} 
                                cols={4}
                            />
                        </div>
                        <div>
                            <div className="text-[10px] font-bold text-slate-500 uppercase mb-2">AI Model</div>
                            <GridSelect 
                                options={MODELS} 
                                selected={config.model} 
                                onChange={(val) => setConfig(prev => ({ ...prev, model: val }))} 
                                cols={4}
                            />
                        </div>
                    </div>
                </section>

                {/* 3. WORLD PARAMETERS */}
                <section>
                    <SectionTitle icon={<Globe size={16} />} title="World Parameters" color="text-blue-400" />
                    <div className="space-y-6">
                        <div>
                            <div className="text-[10px] font-bold text-slate-500 uppercase mb-2 flex justify-between">
                                <span>Core Mode (Multi)</span>
                                <span className="text-cyan-500/60">{config.coreMode.length} active</span>
                            </div>
                            <GridSelect 
                                options={CORE_MODES} 
                                selected={config.coreMode} 
                                onChange={(val) => setConfig(prev => ({ ...prev, coreMode: val }))} 
                                multi 
                                cols={4}
                            />
                        </div>
                        <div>
                            <div className="text-[10px] font-bold text-slate-500 uppercase mb-2">Relationship Dynamics</div>
                            <GridSelect 
                                options={RELATIONSHIPS} 
                                selected={config.relationship} 
                                onChange={(val) => setConfig(prev => ({ ...prev, relationship: val }))} 
                                multi 
                                cols={3}
                            />
                        </div>
                        <div>
                            <div className="text-[10px] font-bold text-slate-500 uppercase mb-2">World Setting</div>
                            <GridSelect 
                                options={WORLDS} 
                                selected={config.world} 
                                onChange={(val) => setConfig(prev => ({ ...prev, world: val }))} 
                                multi 
                                cols={4}
                            />
                        </div>
                        <div>
                            <div className="text-[10px] font-bold text-slate-500 uppercase mb-2">Culture OS</div>
                            <GridSelect 
                                options={CULTURES} 
                                selected={config.culture} 
                                onChange={(val) => setConfig(prev => ({ ...prev, culture: val }))} 
                                cols={2}
                            />
                        </div>
                        <div>
                            <div className="text-[10px] font-bold text-slate-500 uppercase mb-2">Narrative Length</div>
                            <GridSelect 
                                options={Object.values(NarrativeLength).map(l => ({ id: l, label: l.replace('_', ' '), desc: l === 'CHAT' ? 'Quick responses.' : 'Detailed prose.' }))} 
                                selected={config.length} 
                                onChange={(val) => setConfig(prev => ({ ...prev, length: val }))} 
                                cols={3}
                            />
                        </div>
                    </div>
                </section>

                <section>
                    <div className="space-y-6">
                        <div>
                            <div className="text-[10px] font-bold text-slate-500 uppercase mb-2">Perspective</div>
                            <GridSelect 
                                options={PERSPECTIVES} 
                                selected={config.perspective} 
                                onChange={(val) => setConfig(prev => ({ ...prev, perspective: val }))} 
                                cols={3}
                            />
                        </div>
                        <div>
                            <div className="text-[10px] font-bold text-slate-500 uppercase mb-2">Mindset</div>
                            <GridSelect 
                                options={MINDSETS} 
                                selected={config.mindset} 
                                onChange={(val) => setConfig(prev => ({ ...prev, mindset: val }))} 
                                cols={3}
                            />
                        </div>
                    </div>
                </section>

                <section>
                    <div className="space-y-6">
                        <div>
                            <div className="text-[10px] font-bold text-slate-500 uppercase mb-2">Narrative Tone</div>
                            <GridSelect 
                                options={NARRATIVE_TONES} 
                                selected={config.narrativeTone} 
                                onChange={(val) => setConfig(prev => ({ ...prev, narrativeTone: val }))} 
                                cols={4}
                            />
                        </div>
                        <div>
                            <div className="text-[10px] font-bold text-slate-500 uppercase mb-2">Difficulty</div>
                            <GridSelect 
                                options={DIFFICULTIES} 
                                selected={config.difficulty} 
                                onChange={(val) => setConfig(prev => ({ ...prev, difficulty: val }))} 
                                cols={3}
                            />
                        </div>
                    </div>
                </section>

                {/* 4. TECH SPECS */}
                <section>
                    <SectionTitle icon={<ShieldAlert size={16} />} title="Tech Specs" color="text-blue-400" />
                    <div className="space-y-6">
                        <div>
                            <div className="text-[10px] font-bold text-slate-500 uppercase mb-2">Display Mode</div>
                            <GridSelect 
                                options={DISPLAY_MODES} 
                                selected={config.displayMode} 
                                onChange={(val) => setConfig(prev => ({ ...prev, displayMode: val }))} 
                                cols={2}
                            />
                        </div>
                        <div>
                            <div className="text-[10px] font-bold text-slate-500 uppercase mb-2">Physics</div>
                            <GridSelect 
                                options={PHYSICS_MODES} 
                                selected={config.physics} 
                                onChange={(val) => setConfig(prev => ({ ...prev, physics: val }))} 
                                cols={2}
                            />
                        </div>
                    </div>
                </section>

                {/* 5. MODULES */}
                <section>
                    <SectionTitle icon={<Cpu size={16} />} title="Active Modules" color="text-cyan-400" />
                    <div className="space-y-2">
                        <div className="text-[10px] font-bold text-slate-500 uppercase mb-2">Engine Modules</div>
                        <GridSelect 
                            options={EXTRA_MODULES} 
                            selected={config.activeModules} 
                            onChange={(val) => setConfig(prev => ({ ...prev, activeModules: val }))} 
                            multi
                            cols={2}
                        />
                    </div>
                </section>

            </div>
        )}

        {/* ... (Creator Modals & Smart Edit Modals remain same) ... */}
        {creatorMode && (
            <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
                <div className={`w-full max-w-lg border rounded-xl shadow-2xl flex flex-col ${config.customBackground ? 'bg-black/90 border-white/20' : `${t.bgPanel} ${t.border}`} overflow-hidden`}>
                    <div className={`p-4 border-b ${t.border} flex justify-between items-center`}>
                        <h3 className={`font-mono font-bold uppercase tracking-widest ${t.textMain}`}>{editingLoreId ? 'Edit' : 'Create'} {creatorMode}</h3>
                        <button onClick={() => { setCreatorMode(null); setCreatorName(''); setCreatorContent(''); setEditingLoreId(null); }} className={`${t.textDim} hover:${t.textMain}`}><X size={18} /></button>
                    </div>
                    <div className="p-4 flex flex-col gap-4">
                        {(creatorMode === 'USER' || creatorMode === 'CHAR' || creatorMode === 'LORE') && (
                            <input 
                                type="text" 
                                value={creatorName} 
                                onChange={(e) => setCreatorName(e.target.value)} 
                                placeholder={creatorMode === 'LORE' ? "Entry Name" : "Name (e.g. Alice)"}
                                className={`w-full bg-black/20 border ${t.border} rounded p-2 text-xs font-mono outline-none focus:border-current transition-colors`}
                            />
                        )}
                        <textarea 
                            value={creatorContent} 
                            onChange={(e) => setCreatorContent(e.target.value)} 
                            placeholder={creatorMode === 'LORE' ? "Content..." : "Name: ...\nAge: ...\nDescription: ..."}
                            className={`w-full h-64 bg-black/20 border ${t.border} rounded p-3 text-xs font-mono resize-none outline-none focus:border-current transition-colors`}
                        />
                        <button 
                            onClick={handleSaveCreator}
                            disabled={!creatorContent.trim()}
                            className={`w-full py-2 rounded font-bold uppercase text-xs transition-all ${creatorContent.trim() ? 'bg-green-600 hover:bg-green-500 text-white shadow-lg' : 'bg-zinc-800 text-zinc-600 cursor-not-allowed'}`}
                        >
                            Save Entry
                        </button>
                    </div>
                </div>
            </div>
        )}

        {smartEditTarget && (
            <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
                <div className={`w-full max-w-md border rounded-xl shadow-2xl flex flex-col ${config.customBackground ? 'bg-black/90 border-white/20' : `${t.bgPanel} ${t.border}`} overflow-hidden relative`}>
                    <div className={`p-4 border-b ${t.border} flex justify-between items-center bg-indigo-900/20`}>
                        <div className="flex items-center gap-2 text-indigo-400">
                            <Wand2 size={18} />
                            <h3 className="font-mono font-bold uppercase tracking-widest text-xs">AI Smart Edit</h3>
                        </div>
                        <button onClick={() => setSmartEditTarget(null)} className={`${t.textDim} hover:${t.textMain}`}><X size={18} /></button>
                    </div>
                    <div className="p-4 flex flex-col gap-4">
                        <p className="text-[10px] text-zinc-400 font-mono">Describe the changes you want to make (e.g. "Make her taller and shyer", "Change outfit to school uniform").</p>
                        <textarea 
                            value={smartEditPrompt} 
                            onChange={(e) => setSmartEditPrompt(e.target.value)} 
                            placeholder="Instruction..."
                            className={`w-full h-32 bg-black/40 border border-indigo-500/30 rounded p-3 text-xs font-mono resize-none outline-none focus:border-indigo-500 transition-colors text-white`}
                        />
                        <button 
                            onClick={handleSmartEditSubmit}
                            disabled={isSmartEditing || !smartEditPrompt.trim()}
                            className={`w-full py-2 rounded font-bold uppercase text-xs transition-all flex items-center justify-center gap-2 ${isSmartEditing ? 'bg-indigo-900 text-indigo-400 cursor-wait' : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg'}`}
                        >
                            {isSmartEditing ? <Loader2 size={14} className="animate-spin"/> : <Wand2 size={14}/>}
                            {isSmartEditing ? 'Processing...' : 'Apply Changes'}
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* RAW JSON EDIT MODAL */}
        {rawEditTarget && (
            <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
                <div className={`w-full max-w-2xl border rounded-xl shadow-2xl flex flex-col ${config.customBackground ? 'bg-black/95 border-yellow-500/30' : `${t.bgPanel} ${t.border}`} overflow-hidden relative h-[80vh]`}>
                    <div className={`p-4 border-b ${t.border} flex justify-between items-center bg-yellow-900/10`}>
                        <div className="flex items-center gap-2 text-yellow-400">
                            <FileJson size={18} />
                            <h3 className="font-mono font-bold uppercase tracking-widest text-xs">Raw Data Editor</h3>
                        </div>
                        <button onClick={() => setRawEditTarget(null)} className={`${t.textDim} hover:${t.textMain}`}><X size={18} /></button>
                    </div>
                    <div className="flex-1 p-0 relative">
                        <textarea 
                            value={rawJsonContent}
                            onChange={(e) => setRawJsonContent(e.target.value)}
                            className="w-full h-full bg-black/80 p-4 text-xs font-mono text-green-400 outline-none resize-none leading-relaxed"
                            spellCheck={false}
                        />
                    </div>
                    <div className="p-4 border-t border-white/5 flex justify-end gap-2 bg-black/40">
                        <button onClick={() => setRawEditTarget(null)} className="px-4 py-2 text-xs font-bold text-zinc-400 hover:text-white transition-colors">Cancel</button>
                        <button 
                            onClick={handleSaveRawEdit}
                            className="px-6 py-2 bg-yellow-600 hover:bg-yellow-500 text-white rounded font-bold uppercase text-xs shadow-lg transition-all"
                        >
                            Save Changes
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* MODAL RENDERS */}
        {showBodyModal && (
            <CharacterConfigModal 
                config={config} 
                setConfig={setConfig} 
                onClose={() => setShowBodyModal(false)} 
                themeColors={t}
                initialTarget={activePromptTarget === 'GLOBAL' ? 'USER' : activePromptTarget}
            />
        )}
        {showMindModal && (
            <MindConfigModal 
                config={config} 
                setConfig={setConfig} 
                onClose={() => setShowMindModal(false)} 
                themeColors={t}
                initialTarget={activePromptTarget === 'GLOBAL' ? 'USER' : activePromptTarget}
            />
        )}
        <OutfitManagerModal
            isOpen={showOutfitModal}
            onClose={() => setShowOutfitModal(false)}
            config={config}
            messages={messages}
            onUpdateConfig={setConfig}
            initialTab={activeOutfitTarget}
        />

      </div>
    </div>
  );
};

export default ConfigPanel;
