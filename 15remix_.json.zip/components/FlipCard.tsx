
import React, { useState } from 'react';
import { RefreshCw } from 'lucide-react';

interface FlipCardProps {
  frontText: string;
  backText: string;
  type: string;
  themeColors: any;
  customStyle?: string;
  customColors?: { front: string; back: string; text: string; border: string };
}

const FlipCard: React.FC<FlipCardProps> = ({ frontText, backText, type, themeColors, customStyle, customColors }) => {
  const [isFlipped, setIsFlipped] = useState(false);

  // Default Colors (Fallback)
  let cardFrontBg = 'bg-zinc-900';
  let cardBackBg = 'bg-zinc-800';
  let cardBorder = 'border-zinc-700';
  let cardText = 'text-white';

  // Apply Preset Styles if no custom colors
  if (!customColors && customStyle) {
      switch (customStyle) {
          case 'luxury':
              cardFrontBg = 'bg-gradient-to-br from-yellow-900/40 to-black';
              cardBackBg = 'bg-black';
              cardBorder = 'border-yellow-500/50';
              cardText = 'text-yellow-100';
              break;
          case 'cyber':
              cardFrontBg = 'bg-black';
              cardBackBg = 'bg-slate-900';
              cardBorder = 'border-cyan-500 shadow-[0_0_10px_#06b6d4]';
              cardText = 'text-cyan-100';
              break;
          case 'cute':
              cardFrontBg = 'bg-pink-50';
              cardBackBg = 'bg-white';
              cardBorder = 'border-pink-200';
              cardText = 'text-pink-900';
              break;
          case 'gothic':
              cardFrontBg = 'bg-red-950';
              cardBackBg = 'bg-black';
              cardBorder = 'border-red-900';
              cardText = 'text-red-100';
              break;
      }
  }

  const containerStyle = customColors ? {
      backgroundColor: isFlipped ? customColors.back : customColors.front,
      borderColor: customColors.border,
      color: customColors.text
  } : undefined;

  return (
    <div 
      className={`relative w-full perspective-1000 cursor-pointer group h-24 my-2`} 
      onClick={() => setIsFlipped(!isFlipped)}
    >
      <div 
        className={`relative w-full h-full transition-all duration-500 transform-style-3d ${isFlipped ? 'rotate-y-180' : ''}`}
      >
        {/* FRONT */}
        <div 
            className={`absolute inset-0 backface-hidden flex flex-col items-center justify-center p-4 rounded-xl border-2 shadow-lg ${!customColors ? `${cardFrontBg} ${cardBorder} ${cardText}` : ''}`}
            style={!isFlipped && customColors ? containerStyle : undefined}
        >
            <span className="text-[10px] font-mono opacity-60 uppercase tracking-widest mb-1">{type || 'INFO'}</span>
            <span className="text-sm font-bold text-center">{frontText}</span>
            <RefreshCw size={12} className="absolute bottom-2 right-2 opacity-50" />
        </div>

        {/* BACK */}
        <div 
            className={`absolute inset-0 backface-hidden rotate-y-180 flex flex-col items-center justify-center p-4 rounded-xl border-2 shadow-lg ${!customColors ? `${cardBackBg} ${cardBorder} ${cardText}` : ''}`}
            style={isFlipped && customColors ? containerStyle : undefined}
        >
            <span className="text-xs text-center font-mono">{backText}</span>
        </div>
      </div>
    </div>
  );
};

export default FlipCard;
