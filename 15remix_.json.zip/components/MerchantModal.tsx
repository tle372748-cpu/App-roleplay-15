
import React, { useState } from 'react';
import { AppConfig, ShopItem } from '../types';
import { X, ShoppingBag, RefreshCw, Coins, Package } from 'lucide-react';
import { formatVND } from '../utils/mockDataGenerator';

interface MerchantModalProps {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  onClose: () => void;
  onLog: (msg: string) => void;
  themeColors: any;
}

const STOCK_ITEMS: ShopItem[] = [
    { id: 'm_potion', name: 'Love Potion', price: 500000, description: 'Tăng 50 Arousal ngay lập tức.', icon: '🧪', type: 'CONSUMABLE' },
    { id: 'm_camera', name: 'Spy Camera', price: 1200000, description: 'Mở khóa tính năng quan sát bí mật.', icon: '📷', type: 'TOOL' },
    { id: 'm_ticket', name: 'VIP Ticket', price: 5000000, description: 'Vé vào cửa các sự kiện đặc biệt.', icon: '🎫', type: 'KEY_ITEM' },
    { id: 'm_ring', name: 'Diamond Ring', price: 100000000, description: 'Vật phẩm cầu hôn tối thượng.', icon: '💍', type: 'GIFT' },
    { id: 'm_key', name: 'Master Key', price: 20000000, description: 'Mở mọi cánh cửa khóa.', icon: '🗝️', type: 'TOOL' },
];

const MerchantModal: React.FC<MerchantModalProps> = ({ config, setConfig, onClose, onLog, themeColors }) => {
  const [stock, setStock] = useState<ShopItem[]>(STOCK_ITEMS);
  const currentGold = config.gameStats?.gold || 0;

  const handleBuy = (item: ShopItem) => {
      if (currentGold < item.price) {
          alert("Not enough gold!");
          return;
      }

      setConfig(prev => ({
          ...prev,
          gameStats: { ...prev.gameStats!, gold: currentGold - item.price },
          inventory: [...(prev.inventory || []), { ...item, id: `bought-${Date.now()}`, quantity: 1, usageType: 'CONSUMABLE' } as any]
      }));
      onLog(`Bought ${item.name} for ${formatVND(item.price)}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className={`w-full max-w-lg border rounded-xl shadow-2xl flex flex-col bg-zinc-900 border-purple-500/30 overflow-hidden max-h-[85vh]`}>
        
        <div className="p-4 border-b border-purple-500/20 bg-purple-900/10 flex justify-between items-center">
            <div className="flex items-center gap-2 text-purple-400">
                <ShoppingBag size={20} />
                <h3 className="font-mono font-bold uppercase tracking-widest text-sm">Wandering Merchant</h3>
            </div>
            <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors"><X size={18} /></button>
        </div>

        <div className="p-4 bg-black/20 flex justify-between items-center border-b border-white/5">
            <span className="text-xs font-mono text-zinc-400">Rare items for sale...</span>
            <div className="flex items-center gap-1 text-yellow-500 font-bold font-mono text-xs">
                <Coins size={12}/> {formatVND(currentGold)}
            </div>
        </div>

        <div className="p-4 overflow-y-auto custom-scrollbar grid gap-3">
            {stock.map((item) => (
                <div key={item.id} className="p-3 rounded-xl border border-white/5 bg-white/5 hover:bg-white/10 transition-all flex items-center justify-between group">
                    <div className="flex items-center gap-3">
                        <div className="text-2xl w-10 h-10 flex items-center justify-center bg-black/40 rounded-lg">{item.icon}</div>
                        <div>
                            <h4 className="font-bold text-sm text-white">{item.name}</h4>
                            <p className="text-[10px] text-zinc-400">{item.description}</p>
                        </div>
                    </div>
                    <button 
                        onClick={() => handleBuy(item)}
                        className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-[10px] font-bold uppercase rounded shadow-lg active:scale-95"
                    >
                        {formatVND(item.price)}
                    </button>
                </div>
            ))}
        </div>

      </div>
    </div>
  );
};

export default MerchantModal;
