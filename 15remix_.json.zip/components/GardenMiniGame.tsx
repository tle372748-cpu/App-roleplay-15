import React, { useState, useEffect, useRef } from 'react';
import { AppConfig, GardenPlot, PlantType, InventoryItem, WeatherType } from '../types';
import { Sprout, Droplets, Shovel, Coins, ShoppingBag, X, AlertTriangle, Sparkles, Footprints, Users, User, Briefcase, Shield, Package, Cloud, Sun, CloudRain, CloudLightning, CloudSnow, Skull, Wind, Flower2, Gem, Clock, Hammer, ScanEye, ArrowLeft, Menu, Store, TrendingUp, Hand } from 'lucide-react';
import { formatVND, parseBalance } from '../utils/mockDataGenerator';

interface GardenMiniGameProps {
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  onClose: () => void;
  themeColors: any;
  onLogInteraction?: (msg: string) => void;
  initialViewMode?: 'USER' | 'CHAR' | 'FRIEND_LIST';
}

const PLANTS: Record<PlantType, { name: string; emoji: string; growthTime: number; sellPrice: number; seedCost: number }> = {
  carrot: { name: 'Cà Rốt', emoji: '🥕', growthTime: 20, sellPrice: 20000, seedCost: 5000 }, 
  tomato: { name: 'Cà Chua', emoji: '🍅', growthTime: 40, sellPrice: 50000, seedCost: 15000 },
  rose: { name: 'Hoa Hồng', emoji: '🌹', growthTime: 90, sellPrice: 150000, seedCost: 50000 },
  sunflower: { name: 'Hướng Dương', emoji: '🌻', growthTime: 180, sellPrice: 400000, seedCost: 120000 },
  wheat: { name: 'Lúa Mì', emoji: '🌾', growthTime: 300, sellPrice: 1000000, seedCost: 350000 }, 
  orchid: { name: 'Lan Đột Biến', emoji: '🪷', growthTime: 600, sellPrice: 500000000, seedCost: 100000000 }, 
  jade: { name: 'Ngọc Bích', emoji: '🎍', growthTime: 1200, sellPrice: 2500000000, seedCost: 500000000 }, 
  goldtree: { name: 'Cây Kim Tiền', emoji: '🌳', growthTime: 3600, sellPrice: 10000000000, seedCost: 2000000000 }, 
  ancient: { name: 'Cổ Thụ Tỷ Năm', emoji: '🌲', growthTime: 7200, sellPrice: 50000000000, seedCost: 10000000000 }, 
  divine: { name: 'Thần Mộc', emoji: '✨', growthTime: 14400, sellPrice: 100000000000, seedCost: 25000000000 },
};

const UPGRADES = [
    { tier: 2, name: 'Đất Phân (Fertile)', cost: 200_000_000, boost: 2.0, desc: 'Tốc độ x2' },
    { tier: 3, name: 'Chậu Vàng (Hydro)', cost: 5_000_000_000, boost: 5.0, desc: 'Tốc độ x5' },
];

const GROWTH_STAGES = ['🌱', '🌿', '🪴', '🌳']; 

// --- WEATHER & MUTATION SYSTEM ---

const WEATHERS: Record<WeatherType, { 
    name: string, 
    icon: React.ReactNode, 
    weight: number,
    mutation: { id: string, name: string, icon: string, chance: number, multiplier: number } 
}> = {
    SUN: { name: 'Nắng', icon: <Sun size={14} className="text-yellow-400"/>, weight: 30, mutation: { id: '', name: '', icon: '', chance: 0, multiplier: 1 } },
    RAIN: { name: 'Mưa', icon: <CloudRain size={14} className="text-blue-400"/>, weight: 30, mutation: { id: 'wet', name: 'Ướt', icon: '💧', chance: 0.3, multiplier: 1.3 } },
    WIND: { name: 'Bão Gió', icon: <Wind size={14} className="text-gray-300"/>, weight: 20, mutation: { id: 'windy', name: 'Gió', icon: '🍃', chance: 0.3, multiplier: 1.5 } }, 
    SNOW: { name: 'Bão Tuyết', icon: <CloudSnow size={14} className="text-white"/>, weight: 20, mutation: { id: 'frozen', name: 'Băng', icon: '❄️', chance: 0.3, multiplier: 1.7 } },
    ACID: { name: 'Mưa Acid', icon: <CloudLightning size={14} className="text-green-400"/>, weight: 10, mutation: { id: 'rad', name: 'Phóng Xạ', icon: '☢️', chance: 0.3, multiplier: 2.2 } },
    POLLEN: { name: 'Thụ Phấn', icon: <Flower2 size={14} className="text-pink-400"/>, weight: 15, mutation: { id: 'pollen', name: 'Phấn', icon: '🌸', chance: 0.7, multiplier: 2.0 } },
    METEOR: { name: 'Thiên Thạch', icon: <Briefcase size={14} className="text-orange-500"/>, weight: 5, mutation: { id: 'space', name: 'Vũ Trụ', icon: '☄️', chance: 0.3, multiplier: 3.0 } },
    FOSSIL: { name: 'Hóa Thạch', icon: <Gem size={14} className="text-amber-700"/>, weight: 5, mutation: { id: 'crystal', name: 'Tinh Thể', icon: '💎', chance: 0.3, multiplier: 4.0 } },
    ZOMBIE: { name: 'Zombie', icon: <Skull size={14} className="text-lime-500"/>, weight: 3, mutation: { id: 'zombie', name: 'Zombie', icon: '🧟', chance: 0.3, multiplier: 5.5 } },
    HOLY: { name: 'Thánh Thủy', icon: <Sparkles size={14} className="text-cyan-200"/>, weight: 3, mutation: { id: 'holy', name: 'Thánh', icon: '✨', chance: 0.3, multiplier: 7.0 } },
    ANCIENT: { name: 'Cổ Đại', icon: <Clock size={14} className="text-amber-400"/>, weight: 1, mutation: { id: 'ancient', name: 'Cổ Đại', icon: '📜', chance: 0.3, multiplier: 10.0 } },
};

const ToolButton: React.FC<{ icon: React.ReactNode; label: string; active: boolean; onClick: () => void }> = ({ icon, label, active, onClick }) => (
    <button 
        onClick={onClick}
        className={`flex flex-col items-center justify-center gap-1 p-2 rounded-2xl min-w-[64px] h-[64px] transition-all active:scale-95 duration-200
            ${active 
                ? 'bg-emerald-500 text-white shadow-[0_0_15px_rgba(16,185,129,0.4)] translate-y-[-4px] border border-emerald-400' 
                : 'bg-black/40 text-emerald-400/60 border border-emerald-500/10 hover:bg-black/60 hover:text-emerald-300'}
        `}
    >
        <div className={`${active ? 'scale-110' : 'scale-100'} transition-transform duration-200`}>{icon}</div>
        <span className="text-[9px] font-bold font-mono uppercase tracking-tight leading-none">{label}</span>
    </button>
);

const GardenMiniGame: React.FC<GardenMiniGameProps> = ({ config, setConfig, onClose, themeColors, onLogInteraction, initialViewMode = 'USER' }) => {
  const [activeTool, setActiveTool] = useState<'plant' | 'shop' | 'water' | 'harvest' | 'shovel' | 'upgrade' | 'trample' | 'apply_item' | 'harvest_bag' | 'steal'>('plant');
  const [selectedSeed, setSelectedSeed] = useState<PlantType>('carrot');
  const [selectedSupply, setSelectedSupply] = useState<string | null>(null); 
  const [aiAction, setAiAction] = useState<{ message: string; type: 'good' | 'bad' | 'idle' } | null>(null);
  
  const [viewMode, setViewMode] = useState<'USER' | 'FRIEND_LIST' | 'CHAR'>(initialViewMode);
  const [isSafeMode, setIsSafeMode] = useState(false);

  const [activeCharIndex, setActiveCharIndex] = useState<number | null>(null);
  const [charGardens, setCharGardens] = useState<Record<number, GardenPlot[]>>({});

  // SAFE FALLBACK INITIALIZATION
  // If config.garden is missing (old save), use default structure to prevent crash
  const garden = config.garden || {
      plots: Array.from({ length: 9 }, (_, i) => ({ id: i, plantType: null, growthStage: 0, isWatered: false, tier: 1 })),
      exp: 0,
      inventory: {} as Record<PlantType, number>,
      seeds: { carrot: 2 } as Record<PlantType, number>, 
      interactionCooldowns: { water: [], trample: [], steal: [] },
      weather: 'SUN' as WeatherType,
      weatherTimer: 300
  };

  const currentGold = config.gameStats?.gold || 0;
  
  const supplies = (config.inventory || []).filter(i => i.type === 'GARDEN' && i.id.startsWith('item_'));
  const mutatedItems = (config.inventory || []).filter(i => i.type === 'GARDEN' && !i.id.startsWith('item_'));

  // --- SELF HEALING DATA ---
  // Ensures that even if new plants are added to the game, the save file won't crash
  useEffect(() => {
      setConfig(prev => {
          // If garden is completely missing or broken
          if (!prev.garden || !prev.garden.plots) {
              // Create full default records to satisfy Record<PlantType, number>
              const defaultInventory = {} as Record<PlantType, number>;
              const defaultSeeds = {} as Record<PlantType, number>;
              (Object.keys(PLANTS) as PlantType[]).forEach(p => {
                  defaultInventory[p] = 0;
                  defaultSeeds[p] = 0;
              });
              defaultSeeds['carrot'] = 2; // Starting seed

              // Merge existing partial data if any
              if (prev.garden?.inventory) Object.assign(defaultInventory, prev.garden.inventory);
              if (prev.garden?.seeds) Object.assign(defaultSeeds, prev.garden.seeds);

              return {
                  ...prev,
                  garden: {
                      plots: Array.from({ length: 9 }, (_, i) => ({ id: i, plantType: null, growthStage: 0, isWatered: false, tier: 1 })),
                      exp: 0,
                      inventory: defaultInventory,
                      seeds: defaultSeeds,
                      interactionCooldowns: prev.garden?.interactionCooldowns || { water: [], trample: [], steal: [] },
                      weather: prev.garden?.weather || 'SUN',
                      weatherTimer: prev.garden?.weatherTimer ?? 300
                  }
              };
          }
          
          let needsUpdate = false;
          const healedSeeds = { ...prev.garden.seeds };
          const healedInv = { ...prev.garden.inventory };

          (Object.keys(PLANTS) as PlantType[]).forEach(plant => {
              if (healedSeeds[plant] === undefined) {
                  healedSeeds[plant] = 0;
                  needsUpdate = true;
              }
              if (healedInv[plant] === undefined) {
                  healedInv[plant] = 0;
                  needsUpdate = true;
              }
          });

          if (needsUpdate) {
              return {
                  ...prev,
                  garden: {
                      ...prev.garden,
                      seeds: healedSeeds,
                      inventory: healedInv
                  }
              };
          }
          return prev;
      });
  }, []);

  const getRemainingCharges = (type: 'water' | 'trample' | 'steal') => {
      const now = Date.now();
      const window = 600000; // 10 minutes
      const maxCharges = type === 'steal' ? 1 : 2;
      const history = garden.interactionCooldowns?.[type] || [];
      const recentUses = history.filter(t => now - t < window).length;
      return Math.max(0, maxCharges - recentUses);
  };

  const getCharWealthTier = (index: number) => {
      const char = config.characterCards[index];
      if (!char) return "UNKNOWN";
      const balanceStr = char.phone?.bankBalance || "0";
      const balance = parseBalance(balanceStr);
      
      if (balance < 2000000) return "LOW";
      if (balance < 25000000) return "AVERAGE";
      if (balance < 200000000) return "MIDDLE";
      if (balance < 1000000000) return "WEALTHY";
      return "ELITE";
  };

  const handleVisitChar = (index: number) => {
      setActiveCharIndex(index);
      setViewMode('CHAR');
      
      setCharGardens(prev => {
          if (prev[index]) return prev;
          
          const wealth = getCharWealthTier(index);
          let tier = 1;
          if (wealth === 'WEALTHY') tier = 2;
          if (wealth === 'ELITE') tier = 3;
          
          const plots: GardenPlot[] = Array.from({ length: 9 }, (_, i) => ({
              id: i,
              plantType: null,
              growthStage: 0,
              isWatered: false,
              tier: tier
          }));
          
          const plantTypes = Object.keys(PLANTS) as PlantType[];
          for (let i = 0; i < 9; i++) {
              if (Math.random() > 0.5) {
                  plots[i].plantType = plantTypes[Math.floor(Math.random() * plantTypes.length)];
                  plots[i].growthStage = Math.floor(Math.random() * 4);
                  plots[i].isWatered = Math.random() > 0.5;
              }
          }
          return { ...prev, [index]: plots };
      });
  };

  const weather = garden.weather || 'SUN';
  const weatherTimer = garden.weatherTimer ?? 300;

  useEffect(() => {
      const interval = setInterval(() => {
          setConfig(prev => {
              if (!prev.garden) return prev;
              
              let currentTimer = prev.garden.weatherTimer ?? 300;
              let currentWeather = prev.garden.weather || 'SUN';
              let newPlots = [...prev.garden.plots];
              
              if (currentTimer <= 1) {
                  const rand = Math.random() * 142;
                  let acc = 0;
                  let newWeather: WeatherType = 'SUN';
                  
                  for (const [key, data] of Object.entries(WEATHERS)) {
                      acc += data.weight;
                      if (rand <= acc) {
                          newWeather = key as WeatherType;
                          break;
                      }
                  }
                  
                  const mutationData = WEATHERS[newWeather].mutation;
                  if (mutationData.id && mutationData.chance > 0) {
                        newPlots = newPlots.map(plot => {
                            if (plot.plantType && Math.random() < mutationData.chance) {
                                const currentMutations = plot.mutations || [];
                                if (!currentMutations.includes(mutationData.id)) {
                                    return { ...plot, mutations: [...currentMutations, mutationData.id] };
                                }
                            }
                            return plot;
                        });
                  }
                  
                  currentWeather = newWeather;
                  currentTimer = 300;
              } else {
                  currentTimer -= 1;
              }

              newPlots = newPlots.map(plot => {
                  if (plot.buffs?.autoWater && !plot.isWatered) {
                      plot.isWatered = true;
                  }

                  if (plot.plantType && plot.isWatered && plot.growthStage < 3) {
                    const plantInfo = PLANTS[plot.plantType];
                    let multiplier = 1;
                    if (plot.tier === 2) multiplier = 2.0;
                    if (plot.tier === 3) multiplier = 5.0;
                    if (plot.buffs?.fertilizer) multiplier *= 2.0;
                    
                    const baseChance = (1 / Math.max(1, plantInfo.growthTime)) * 2; 
                    const finalChance = baseChance * multiplier;
                    
                    if (Math.random() < finalChance) {
                      return { ...plot, growthStage: plot.growthStage + 1, isWatered: false }; 
                    }
                  }
                  return plot;
              });

              return {
                  ...prev,
                  garden: {
                      ...prev.garden,
                      weather: currentWeather,
                      weatherTimer: currentTimer,
                      plots: newPlots
                  }
              };
          });
      }, 1000);

      return () => clearInterval(interval);
  }, []);

  const prevWeatherRef = useRef<WeatherType>(weather);
  useEffect(() => {
      if (weather !== prevWeatherRef.current) {
          if (onLogInteraction) {
              onLogInteraction(`[WEATHER]: ${WEATHERS[weather].name} has arrived!`);
          }
          prevWeatherRef.current = weather;
      }
  }, [weather, onLogInteraction]);

  useEffect(() => {
    if (viewMode !== 'USER') return;
    const interval = setInterval(() => {
        if (!isSafeMode && Math.random() < 0.01 && config.characterCards.length > 0) {
            triggerRandomAiTrample();
        }
    }, 1000);
    return () => clearInterval(interval);
  }, [viewMode, isSafeMode, config.characterCards]);

  const triggerRandomAiTrample = () => {
      setConfig(prev => {
          if (!prev.garden) return prev;
          const validPlots = prev.garden.plots.filter(p => p.plantType !== null);
          if (validPlots.length === 0) return prev;

          const targetPlotIndex = Math.floor(Math.random() * validPlots.length);
          const targetPlot = validPlots[targetPlotIndex];
          
          const attacker = prev.characterCards[Math.floor(Math.random() * prev.characterCards.length)];

          if (targetPlot.buffs?.trap) {
              setAiAction({ type: 'good', message: `🛡️ ${attacker.name} đạp trúng Bẫy!` });
              if (onLogInteraction) {
                  onLogInteraction(`[SYSTEM EVENT]: ${attacker.name} stepped on a TRAP in User's garden! Attack blocked.`);
              }
              const updatedPlots = prev.garden.plots.map(p => p.id === targetPlot.id ? { ...p, buffs: { ...p.buffs, trap: false } } : p);
              setTimeout(() => setAiAction(null), 4000);
              return { ...prev, garden: { ...prev.garden, plots: updatedPlots } };
          } else {
              setAiAction({ type: 'bad', message: `⚠️ ${attacker.name} vô tình làm hỏng cây!` });
              if (onLogInteraction) onLogInteraction(`[SYSTEM EVENT]: ${attacker.name} DAMAGED a plant in User's garden!`);
              const updatedPlots = prev.garden.plots.map(p => p.id === targetPlot.id ? { ...p, plantType: null, growthStage: 0, isWatered: false, buffs: undefined, mutations: [] } : p);
              setTimeout(() => setAiAction(null), 3000);
              return { ...prev, garden: { ...prev.garden, plots: updatedPlots } };
          }
      });
  };

  const renderMutations = (mutations: string[]) => {
      if (!mutations || mutations.length === 0) return null;
      return (
          <div className="flex gap-0.5 absolute bottom-1.5 right-1.5 bg-black/60 backdrop-blur-sm rounded-lg px-1.5 py-0.5 pointer-events-none z-20 border border-white/10 shadow-sm">
              {mutations.map(m => {
                  const w = Object.values(WEATHERS).find(x => x.mutation.id === m);
                  return <span key={m} className="text-[10px] leading-none animate-pulse">{w?.mutation.icon || '?'}</span>;
              })}
          </div>
      );
  };

  const handlePlotClick = (plotId: number) => {
    if (viewMode === 'USER') {
        setConfig(prev => {
            if (!prev.garden) return prev;
            const plot = prev.garden.plots.find(p => p.id === plotId);
            if (!plot) return prev;

            let newGarden = { ...prev.garden };
            let newGameStats = { ...prev.gameStats! };
            let newGlobalInventory = [...(prev.inventory || [])];

            if (activeTool === 'plant') {
                const currentSeeds = newGarden.seeds[selectedSeed] || 0;
                if (!plot.plantType && currentSeeds > 0) {
                    newGarden.seeds = { ...newGarden.seeds, [selectedSeed]: currentSeeds - 1 };
                    newGarden.plots = newGarden.plots.map(p => p.id === plotId ? { ...p, plantType: selectedSeed, growthStage: 0, isWatered: false, mutations: [] } : p);
                }
            } else if (activeTool === 'water') {
                if (plot.plantType && !plot.isWatered && plot.growthStage < 3) {
                    newGarden.plots = newGarden.plots.map(p => p.id === plotId ? { ...p, isWatered: true } : p);
                }
            } else if (activeTool === 'harvest') {
                if (plot.plantType && plot.growthStage === 3) {
                    const basePlant = PLANTS[plot.plantType];
                    const mutations = plot.mutations || [];
                    
                    if (mutations.length > 0) {
                        let totalMultiplier = 1; 
                        let mutationIcons = "";
                        let mutationNames = "";
                        let breakdownStr = `${formatVND(basePlant.sellPrice)}`;

                        mutations.forEach(m => {
                            const w = Object.values(WEATHERS).find(x => x.mutation.id === m);
                            if (w) {
                                totalMultiplier *= w.mutation.multiplier; 
                                mutationIcons += w.mutation.icon;
                                mutationNames += w.mutation.name + " ";
                                breakdownStr += ` x ${w.mutation.multiplier}`;
                            }
                        });

                        const finalPrice = Math.floor(basePlant.sellPrice * totalMultiplier);
                        breakdownStr += ` = ${formatVND(finalPrice)}`;

                        const newItem: InventoryItem = {
                            id: `${plot.plantType}-mutated-${Date.now()}-${Math.random()}`,
                            name: `${basePlant.name} ${mutationIcons}`,
                            description: `Đột biến: ${mutationNames.trim()}. Multiplier: x${totalMultiplier.toFixed(1)}. Giá trị cực cao!`,
                            icon: mutationIcons + basePlant.emoji,
                            type: 'GARDEN',
                            usageType: 'CONSUMABLE',
                            price: finalPrice,
                            quantity: 1,
                            rating: 'Prodigy',
                            stars: 5
                        };
                        newGlobalInventory.push(newItem);
                        setAiAction({ type: 'good', message: `Thu hoạch Đột Biến! +${newItem.name}` });
                        if (onLogInteraction) {
                            onLogInteraction(`[HARVEST LOG]: ${newItem.name} | MATH: ${breakdownStr}`);
                        }
                    } else {
                        // Safe Increment
                        const currentCropCount = newGarden.inventory[plot.plantType] || 0;
                        newGarden.inventory = { ...newGarden.inventory, [plot.plantType]: currentCropCount + 1 };
                    }

                    newGarden.exp += 10;
                    newGarden.plots = newGarden.plots.map(p => p.id === plotId ? { ...p, plantType: null, growthStage: 0, isWatered: false, mutations: [] } : p);
                }
            } else if (activeTool === 'shovel') {
                if (plot.plantType) {
                    newGarden.plots = newGarden.plots.map(p => p.id === plotId ? { ...p, plantType: null, growthStage: 0, isWatered: false, buffs: undefined, mutations: [] } : p);
                }
            } else if (activeTool === 'upgrade') {
                const currentTier = plot.tier || 1;
                if (currentTier < 3) {
                    const nextUpgrade = UPGRADES.find(u => u.tier === currentTier + 1);
                    if (nextUpgrade && newGameStats.gold >= nextUpgrade.cost) {
                        newGameStats.gold -= nextUpgrade.cost;
                        newGarden.plots = newGarden.plots.map(p => p.id === plotId ? { ...p, tier: p.tier + 1 } : p);
                        setAiAction({ type: 'good', message: `Upgraded to ${nextUpgrade.name}!` });
                        setTimeout(() => setAiAction(null), 2000);
                    } else {
                        setAiAction({ type: 'bad', message: `Thiếu tiền! Cần ${formatVND(nextUpgrade.cost)}` });
                        setTimeout(() => setAiAction(null), 2000);
                    }
                }
            } else if (activeTool === 'apply_item' && selectedSupply) {
                const item = (prev.inventory || []).find(i => i.id === selectedSupply);
                if (item && item.quantity > 0) {
                    let applied = false;
                    const currentBuffs = plot.buffs || {};

                    if (item.id === 'item_fertilizer') {
                        if (!currentBuffs.fertilizer) {
                            newGarden.plots = newGarden.plots.map(p => p.id === plotId ? { ...p, buffs: { ...p.buffs, fertilizer: true } } : p);
                            applied = true;
                        }
                    } else if (item.id === 'item_sprinkler') {
                        if (!currentBuffs.autoWater) {
                            newGarden.plots = newGarden.plots.map(p => p.id === plotId ? { ...p, buffs: { ...p.buffs, autoWater: true } } : p);
                            applied = true;
                        }
                    } else if (item.id === 'item_trap') {
                        if (!currentBuffs.trap) {
                            newGarden.plots = newGarden.plots.map(p => p.id === plotId ? { ...p, buffs: { ...p.buffs, trap: true } } : p);
                            applied = true;
                        }
                    }

                    if (applied) {
                        const invIdx = newGlobalInventory.findIndex(i => i.id === selectedSupply);
                        if (invIdx > -1) {
                            if (newGlobalInventory[invIdx].quantity > 1) {
                                newGlobalInventory[invIdx] = { ...newGlobalInventory[invIdx], quantity: newGlobalInventory[invIdx].quantity - 1 };
                            } else {
                                newGlobalInventory.splice(invIdx, 1);
                            }
                        }
                        return { ...prev, garden: newGarden, inventory: newGlobalInventory };
                    } else {
                        setAiAction({ type: 'bad', message: "Effect already active!" });
                        setTimeout(() => setAiAction(null), 1000);
                    }
                }
            }

            return { ...prev, garden: newGarden, gameStats: newGameStats, inventory: newGlobalInventory };
        });
    } 
    else if (viewMode === 'CHAR' && activeCharIndex !== null) {
        if (activeTool === 'water' || activeTool === 'trample' || activeTool === 'steal') {
            const remaining = getRemainingCharges(activeTool);
            if (remaining <= 0) {
                const history = garden.interactionCooldowns?.[activeTool] || [];
                const oldest = history[0] || 0;
                const waitTime = Math.ceil((oldest + 600000 - Date.now()) / 60000);
                setAiAction({ type: 'bad', message: `Hết lượt! Chờ ${waitTime} phút.` });
                setTimeout(() => setAiAction(null), 2000);
                return;
            }
        }

        setCharGardens(prev => {
            const charPlots = [...prev[activeCharIndex]];
            const plotIndex = charPlots.findIndex(p => p.id === plotId);
            if (plotIndex === -1) return prev;
            
            const targetPlot = charPlots[plotIndex];
            const targetCharName = config.characterCards[activeCharIndex].name;
            let actionSuccess = false;

            if (activeTool === 'water') {
                if (targetPlot.plantType) {
                    const newStage = Math.min(3, targetPlot.growthStage + 1);
                    charPlots[plotIndex] = { ...targetPlot, growthStage: newStage, isWatered: true };
                    
                    if (onLogInteraction) onLogInteraction(`[SYSTEM EVENT]: User WATERED a plant in ${targetCharName}'s garden. It grew instantly! (Positive Impact)`);
                    setAiAction({ type: 'good', message: `Đã tưới cây cho ${targetCharName}!` });
                    actionSuccess = true;
                }
            } else if (activeTool === 'trample') {
                if (targetPlot.plantType) {
                    charPlots[plotIndex] = { ...targetPlot, plantType: null, growthStage: 0, isWatered: false, mutations: [] };
                    
                    if (onLogInteraction) onLogInteraction(`[SYSTEM EVENT]: User DAMAGED a plant in ${targetCharName}'s garden! (Negative Impact/Provocation)`);
                    setAiAction({ type: 'bad', message: `Đã làm hỏng cây của ${targetCharName}!` });
                    actionSuccess = true;
                }
            } else if (activeTool === 'steal') {
                if (targetPlot.plantType) {
                    const plantInfo = PLANTS[targetPlot.plantType];
                    const stoleItem: InventoryItem = {
                        id: `stolen-${Date.now()}`,
                        name: plantInfo.name,
                        description: `Stolen from ${targetCharName}'s garden.`,
                        icon: plantInfo.emoji,
                        type: 'GARDEN',
                        usageType: 'CONSUMABLE',
                        price: plantInfo.sellPrice,
                        quantity: 1
                    };

                    charPlots[plotIndex] = { ...targetPlot, plantType: null, growthStage: 0, isWatered: false, mutations: [] };
                    
                    if (onLogInteraction) onLogInteraction(`[SYSTEM EVENT]: User STOLE a ${plantInfo.name} from ${targetCharName}'s garden! (Very Negative Impact)`);
                    setAiAction({ type: 'good', message: `Đã trộm ${plantInfo.name}!` });
                    actionSuccess = true;

                    // Trigger inventory update side effect via setConfig in main body or separate handling.
                    // NOTE: To fix the state update inside a state update (anti-pattern), we rely on config ref or separate effect.
                    // For simplicity in this mini-game, we update config directly if actionSuccess.
                    setConfig(prevConfig => {
                        return {
                            ...prevConfig,
                            inventory: [...(prevConfig.inventory || []), stoleItem]
                        };
                    });
                }
            }

            if (actionSuccess) {
                setConfig(prevConfig => {
                    const now = Date.now();
                    const window = 600000;
                    const prevHistory = prevConfig.garden?.interactionCooldowns?.[activeTool] || [];
                    const newHistory = [...prevHistory.filter(t => now - t < window), now];
                    return {
                        ...prevConfig,
                        garden: {
                            ...prevConfig.garden!,
                            interactionCooldowns: {
                                ...prevConfig.garden!.interactionCooldowns,
                                [activeTool]: newHistory
                            }
                        }
                    };
                });
            }

            setTimeout(() => setAiAction(null), 2000);
            return { ...prev, [activeCharIndex]: charPlots };
        });
    }
  };

  const buySeed = (type: PlantType) => {
    setConfig(prev => {
        if(!prev.garden || !prev.gameStats) return prev;
        const cost = PLANTS[type].seedCost;
        if (prev.gameStats.gold >= cost) {
            setAiAction({ type: 'good', message: `Mua thành công: ${PLANTS[type].name}` });
            setTimeout(() => setAiAction(null), 1000);
            
            const currentSeeds = prev.garden.seeds[type] || 0;
            return { 
                ...prev, 
                gameStats: { ...prev.gameStats, gold: prev.gameStats.gold - cost }, 
                garden: { 
                    ...prev.garden, 
                    seeds: { ...prev.garden.seeds, [type]: currentSeeds + 1 } 
                } 
            };
        } else {
            setAiAction({ type: 'bad', message: `Thiếu tiền! Cần ${formatVND(cost)}` });
            setTimeout(() => setAiAction(null), 1000);
        }
        return prev;
    });
  };

  const sellCrop = (type: PlantType) => {
    setConfig(prev => {
        if(!prev.garden || !prev.gameStats) return prev;
        const count = prev.garden.inventory[type] || 0;
        if (count > 0) {
            return { 
                ...prev, 
                gameStats: { ...prev.gameStats, gold: prev.gameStats.gold + PLANTS[type].sellPrice }, 
                garden: { ...prev.garden, inventory: { ...prev.garden.inventory, [type]: count - 1 } } 
            };
        }
        return prev;
    });
  };

  const sellMutatedItem = (itemId: string, price: number) => {
      setConfig(prev => {
          const newInv = (prev.inventory || []).filter(i => i.id !== itemId);
          const newGold = (prev.gameStats?.gold || 0) + price;
          
          return {
              ...prev,
              inventory: newInv,
              gameStats: { ...prev.gameStats!, gold: newGold }
          };
      });
      setAiAction({ type: 'good', message: `Sold for ${formatVND(price)}` });
      setTimeout(() => setAiAction(null), 1000);
  };

  const currentPlots = viewMode === 'USER' ? garden.plots : (activeCharIndex !== null ? charGardens[activeCharIndex] || [] : []);

  const waterCharges = getRemainingCharges('water');
  const trampleCharges = getRemainingCharges('trample');
  const stealCharges = getRemainingCharges('steal');

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center p-0 md:p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
      
      {/* BACKGROUND DECOR */}
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-emerald-900/40 via-black to-black"></div>

      {/* MAIN CONTAINER */}
      <div className={`w-full md:max-w-2xl h-full md:h-[90vh] bg-emerald-950/95 border-t md:border border-emerald-800/50 shadow-2xl flex flex-col relative overflow-hidden rounded-t-3xl md:rounded-3xl`}>
        
        {/* WEATHER EFFECT OVERLAY */}
        {weather !== 'SUN' && (
            <div className="absolute inset-0 pointer-events-none z-0 opacity-30 mix-blend-overlay">
                {weather === 'RAIN' && <div className="absolute inset-0 bg-blue-900/30 animate-pulse"></div>}
                {weather === 'ACID' && <div className="absolute inset-0 bg-green-900/30 animate-pulse"></div>}
                {weather === 'SNOW' && <div className="absolute inset-0 bg-white/10"></div>}
                {weather === 'ZOMBIE' && <div className="absolute inset-0 bg-red-900/20"></div>}
            </div>
        )}

        {/* FEEDBACK TOAST */}
        {aiAction && (
            <div className={`absolute top-20 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full font-bold text-xs shadow-2xl animate-in slide-in-from-top-4 z-[60] flex items-center gap-2 border backdrop-blur-md whitespace-nowrap ${aiAction.type === 'good' ? 'bg-emerald-600 text-white border-emerald-400' : 'bg-red-600 text-white border-red-400'}`}>
                {aiAction.type === 'good' ? <Sparkles size={14}/> : <AlertTriangle size={14}/>}
                {aiAction.message}
            </div>
        )}

        {/* --- HEADER --- */}
        <div className="flex items-center justify-between p-4 border-b border-emerald-800/50 bg-emerald-900/30 shrink-0 z-10">
            <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl ${viewMode === 'USER' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-blue-500/20 text-blue-300'}`}>
                    {viewMode === 'USER' ? <Sprout size={20} /> : <User size={20}/>}
                </div>
                <div>
                    <h2 className="font-mono font-bold tracking-widest text-sm text-emerald-100 uppercase">
                        {viewMode === 'USER' ? 'My Garden' : viewMode === 'FRIEND_LIST' ? 'Neighbors' : config.characterCards[activeCharIndex || 0]?.name.toUpperCase()}
                    </h2>
                    <div className="flex items-center gap-2 text-[10px] font-mono text-emerald-400/60 mt-0.5">
                        <span className="flex items-center gap-1 text-yellow-400"><Coins size={10}/> {formatVND(currentGold)}</span>
                        {isSafeMode && <span className="flex items-center gap-1 text-blue-400 ml-2 animate-pulse"><Shield size={10}/> SAFE</span>}
                    </div>
                </div>
            </div>

            <div className="flex gap-2">
                {/* Safe Mode Toggle */}
                {viewMode === 'USER' && (
                    <button 
                        onClick={() => {
                            setIsSafeMode(!isSafeMode);
                            if (!isSafeMode) {
                                setAiAction({ type: 'good', message: "🛡️ Safe Mode ON" });
                                setTimeout(() => setAiAction(null), 2000);
                            } else {
                                setAiAction({ type: 'bad', message: "⚠️ Safe Mode OFF" });
                                setTimeout(() => setAiAction(null), 2000);
                            }
                        }} 
                        className={`p-2 rounded-xl transition-all ${isSafeMode ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.5)] border border-blue-400' : 'bg-black/40 text-zinc-500 hover:text-white border border-white/10'}`}
                        title={isSafeMode ? "Disable Safe Mode" : "Enable Safe Mode (Anti-Trample)"}
                    >
                        <Shield size={18} />
                    </button>
                )}

                {/* Weather Pill */}
                <div className="flex items-center gap-2 px-2 py-1 rounded-lg bg-black/40 border border-white/10">
                    {WEATHERS[weather].icon}
                    <div className="flex flex-col leading-none">
                        <span className="text-[8px] font-bold text-white uppercase">{WEATHERS[weather].name}</span>
                        <span className="text-[7px] font-mono text-zinc-400">{Math.floor(weatherTimer / 60)}:{(weatherTimer % 60).toString().padStart(2, '0')}</span>
                    </div>
                </div>
                
                {/* Navigation */}
                {viewMode === 'USER' && (
                    <button onClick={() => setViewMode('FRIEND_LIST')} className="p-2 rounded-xl bg-emerald-800/50 text-emerald-300 hover:bg-emerald-700/50 transition-colors">
                        <Users size={18} />
                    </button>
                )}
                {viewMode !== 'USER' && (
                    <button onClick={() => setViewMode('USER')} className="p-2 rounded-xl bg-emerald-800/50 text-emerald-300 hover:bg-emerald-700/50 transition-colors">
                        <ArrowLeft size={18} />
                    </button>
                )}
                
                <button onClick={onClose} className="p-2 rounded-xl hover:bg-red-500/20 text-emerald-500 hover:text-red-400 transition-colors">
                    <X size={18} />
                </button>
            </div>
        </div>

        {/* --- MAIN CONTENT AREA --- */}
        <div className="flex-1 overflow-y-auto custom-scrollbar relative z-10 flex flex-col w-full">
            
            {viewMode === 'FRIEND_LIST' && (
                <div className="p-4 grid grid-cols-2 gap-3">
                    {config.characterCards.map((char, idx) => (
                        <button 
                            key={idx}
                            onClick={() => handleVisitChar(idx)}
                            className="flex flex-col items-center gap-2 p-4 rounded-2xl border border-emerald-800/50 bg-emerald-900/20 hover:bg-emerald-800/40 transition-all active:scale-95"
                        >
                            <div className="w-12 h-12 rounded-full bg-black/30 flex items-center justify-center overflow-hidden border border-emerald-500/20">
                                {char.avatar ? <img src={char.avatar} className="w-full h-full object-cover" /> : <User size={20} className="text-emerald-500"/>}
                            </div>
                            <div className="text-center">
                                <div className="font-bold text-xs text-emerald-100 truncate w-full max-w-[100px]">{char.name}</div>
                                <div className="text-[9px] font-mono text-emerald-500/60 mt-0.5">{getCharWealthTier(idx)}</div>
                            </div>
                        </button>
                    ))}
                    {config.characterCards.length === 0 && (
                        <div className="col-span-2 text-center text-emerald-500/40 py-10 font-mono text-xs italic">
                            No neighbors found.
                        </div>
                    )}
                </div>
            )}

            {(viewMode === 'USER' || viewMode === 'CHAR') && (
                <div className="flex-1 flex flex-col items-center p-4 pb-48"> 
                    {/* PLOTS GRID */}
                    <div className="grid grid-cols-3 gap-3 md:gap-4 w-full max-w-[400px] mx-auto mt-4 md:mt-10">
                        {currentPlots.map((plot) => {
                            let borderClass = 'border-emerald-800/60';
                            let bgClass = 'bg-emerald-900/20';
                            
                            if (plot.tier === 2) { borderClass = 'border-[#8d6e63]'; bgClass = 'bg-[#5d4037]/20'; }
                            else if (plot.tier === 3) { borderClass = 'border-cyan-500/50'; bgClass = 'bg-cyan-900/20'; }

                            const isInteractive = viewMode === 'USER' || (viewMode === 'CHAR' && (activeTool === 'water' || activeTool === 'trample' || activeTool === 'steal'));

                            return (
                                <button 
                                    key={plot.id}
                                    onClick={() => isInteractive && handlePlotClick(plot.id)}
                                    className={`
                                        aspect-square rounded-2xl border-2 transition-all relative flex items-center justify-center overflow-visible touch-manipulation w-full
                                        ${bgClass} ${borderClass}
                                        ${plot.isWatered ? 'ring-2 ring-blue-400/30' : ''}
                                        ${isInteractive ? 'active:scale-95' : 'cursor-default'}
                                    `}
                                >
                                    {/* Buffs */}
                                    <div className="absolute top-1 right-1 flex flex-col gap-0.5 pointer-events-none z-10">
                                        {plot.buffs?.trap && <div className="text-[10px]">🧀</div>}
                                        {plot.buffs?.autoWater && <div className="text-[10px]">🚿</div>}
                                        {plot.buffs?.fertilizer && <div className="text-[10px]">⚡</div>}
                                    </div>

                                    {/* Mutations */}
                                    {plot.mutations && plot.mutations.length > 0 && renderMutations(plot.mutations)}

                                    {plot.plantType ? (
                                        <div className="flex flex-col items-center animate-in zoom-in duration-300">
                                            <span className="text-4xl md:text-5xl filter drop-shadow-2xl">
                                                {plot.growthStage === 3 ? PLANTS[plot.plantType].emoji : GROWTH_STAGES[plot.growthStage]}
                                            </span>
                                            
                                            {/* Action Hints */}
                                            {viewMode === 'USER' && plot.growthStage === 3 && activeTool === 'harvest' && (
                                                <div className="absolute inset-0 bg-yellow-500/30 rounded-xl flex items-center justify-center animate-pulse">
                                                    <ShoppingBag size={20} className="text-white drop-shadow-md" />
                                                </div>
                                            )}
                                            {(viewMode === 'CHAR' || (viewMode === 'USER' && !plot.isWatered && plot.growthStage < 3)) && activeTool === 'water' && (
                                                <div className="absolute inset-0 bg-blue-500/20 rounded-xl flex items-center justify-center animate-pulse">
                                                    <Droplets size={20} className="text-blue-200" />
                                                </div>
                                            )}
                                            {viewMode === 'CHAR' && activeTool === 'trample' && (
                                                <div className="absolute inset-0 bg-red-500/20 rounded-xl flex items-center justify-center animate-pulse">
                                                    <Footprints size={20} className="text-red-200" />
                                                </div>
                                            )}
                                            {viewMode === 'CHAR' && activeTool === 'steal' && (
                                                <div className="absolute inset-0 bg-purple-500/20 rounded-xl flex items-center justify-center animate-pulse">
                                                    <Hand size={20} className="text-purple-200" />
                                                </div>
                                            )}
                                        </div>
                                    ) : (
                                        <div className="text-emerald-800/30 font-black text-sm">{plot.id + 1}</div>
                                    )}
                                </button>
                            );
                        })}
                    </div>
                </div>
            )}
        </div>

        {/* --- BOTTOM DOCK (TOOLBAR) --- */}
        {(viewMode === 'USER' || viewMode === 'CHAR') && (
            <div className="absolute bottom-0 left-0 right-0 z-40 flex flex-col pointer-events-none">
                
                {/* SLIDE-UP PANELS (Inventory / Seeds / Shop) */}
                {/* Add pointer-events-auto to children so they can be clicked */}
                {viewMode === 'USER' && (activeTool === 'plant' || activeTool === 'harvest_bag' || activeTool === 'apply_item' || activeTool === 'shop' || activeTool === 'upgrade') && (
                    <div className="bg-[#0f1f18] border-t border-emerald-800/50 p-4 pb-2 animate-in slide-in-from-bottom-10 rounded-t-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.5)] max-h-[40vh] overflow-y-auto custom-scrollbar pointer-events-auto">
                        
                        {/* UPGRADE INFO PANEL */}
                        {activeTool === 'upgrade' && (
                            <>
                                <h4 className="text-[10px] font-bold font-mono text-cyan-400 uppercase mb-3 flex items-center gap-2"><Hammer size={12}/> Land Upgrades</h4>
                                <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar snap-x">
                                    <div className="p-3 rounded-xl border border-emerald-800/50 bg-emerald-900/20 min-w-[120px] flex flex-col gap-1 shrink-0">
                                        <div className="text-xl">🟫</div>
                                        <div className="font-bold text-xs text-white">Tier 1: Đất Thường</div>
                                        <div className="text-[9px] font-mono text-zinc-400">Tốc độ: 1x (Mặc định)</div>
                                        <div className="text-[9px] font-mono text-green-400 mt-auto">FREE</div>
                                    </div>
                                    {UPGRADES.map(u => (
                                        <div key={u.tier} className={`p-3 rounded-xl border min-w-[140px] flex flex-col gap-1 shrink-0 snap-center
                                            ${u.tier === 2 ? 'border-[#8d6e63] bg-[#5d4037]/20' : 'border-yellow-500/50 bg-yellow-900/20'}
                                        `}>
                                            <div className="text-xl">{u.tier === 2 ? '💩' : '🏺'}</div>
                                            <div className={`font-bold text-xs ${u.tier === 2 ? 'text-[#d7ccc8]' : 'text-yellow-200'}`}>{u.name}</div>
                                            <div className="text-[9px] font-mono text-zinc-300">{u.desc}</div>
                                            <div className="text-[9px] font-mono font-bold text-yellow-400 mt-auto">{formatVND(u.cost)}</div>
                                        </div>
                                    ))}
                                </div>
                                <p className="text-[9px] text-zinc-500 mt-2 text-center italic">Chạm vào ô đất để nâng cấp.</p>
                            </>
                        )}

                        {/* SHOP PANEL (Dedicated for Buying) */}
                        {activeTool === 'shop' && (
                            <>
                                <h4 className="text-[10px] font-bold font-mono text-yellow-400 uppercase mb-3 flex items-center gap-2">
                                    <Store size={12}/> Seed Shop <span className="text-white/50">| Gold: {formatVND(currentGold)}</span>
                                </h4>
                                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pb-2">
                                    {(Object.keys(PLANTS) as PlantType[]).map(type => {
                                        const plant = PLANTS[type];
                                        const canAfford = currentGold >= plant.seedCost;
                                        const currentSeeds = garden.seeds[type] || 0;
                                        return (
                                            <div key={type} className={`p-2 rounded-xl border flex flex-col gap-1 relative ${canAfford ? 'bg-black/40 border-emerald-800/50' : 'bg-black/40 border-red-900/30 opacity-60'}`}>
                                                <div className="flex justify-between items-start">
                                                    <span className="text-xl">{plant.emoji}</span>
                                                    <span className="text-[9px] font-mono text-zinc-500">Own: {currentSeeds}</span>
                                                </div>
                                                <span className="text-[10px] font-bold text-white leading-tight">{plant.name}</span>
                                                
                                                <div className="mt-1 flex flex-col gap-0.5">
                                                    <div className="flex justify-between text-[9px] font-mono">
                                                        <span className="text-yellow-500">Buy:</span>
                                                        <span>{formatVND(plant.seedCost)}</span>
                                                    </div>
                                                    <div className="flex justify-between text-[9px] font-mono text-white/50">
                                                        <span>Sell:</span>
                                                        <span className="text-green-400">{formatVND(plant.sellPrice)}</span>
                                                    </div>
                                                </div>

                                                <button 
                                                    onClick={() => canAfford && buySeed(type)}
                                                    disabled={!canAfford}
                                                    className={`mt-1 w-full py-1 rounded text-[9px] font-bold uppercase transition-all ${canAfford ? 'bg-yellow-600 hover:bg-yellow-500 text-white active:scale-95' : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'}`}
                                                >
                                                    {canAfford ? 'Mua' : 'Thiếu Tiền'}
                                                </button>
                                            </div>
                                        );
                                    })}
                                </div>
                            </>
                        )}

                        {/* SEEDS PANEL (For Planting Only - Showing Owned) */}
                        {activeTool === 'plant' && (
                            <>
                                <h4 className="text-[10px] font-bold font-mono text-emerald-400 uppercase mb-3 flex items-center gap-2"><Sprout size={12}/> My Seeds (Select to Plant)</h4>
                                <div className="flex gap-3 overflow-x-auto pb-2 custom-scrollbar snap-x">
                                    {(Object.keys(garden.seeds) as PlantType[]).map(type => (
                                        <button 
                                            key={type}
                                            onClick={() => setSelectedSeed(type)}
                                            className={`
                                                flex flex-col items-center justify-between p-3 rounded-xl border transition-all shrink-0 min-w-[80px] snap-center
                                                ${selectedSeed === type ? 'bg-emerald-600 border-emerald-400 text-white shadow-lg' : 'bg-black/40 border-emerald-800/50 text-emerald-400/60'}
                                            `}
                                        >
                                            <span className="text-2xl mb-1">{PLANTS[type].emoji}</span>
                                            <span className="text-[10px] font-bold leading-tight">{PLANTS[type].name}</span>
                                            <div className="w-full text-center mt-2 pt-2 border-t border-white/10 text-[9px] font-mono">
                                                x{garden.seeds[type] || 0}
                                            </div>
                                        </button>
                                    ))}
                                </div>
                            </>
                        )}

                        {/* INVENTORY PANEL */}
                        {activeTool === 'harvest_bag' && (
                            <>
                                <h4 className="text-[10px] font-bold font-mono text-purple-400 uppercase mb-3 flex items-center gap-2"><Package size={12}/> Harvest Storage</h4>
                                <div className="space-y-3">
                                    {/* Mutated Items */}
                                    {mutatedItems.length > 0 && (
                                        <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar snap-x">
                                            {mutatedItems.map(item => (
                                                <div key={item.id} className="min-w-[140px] bg-purple-900/20 border border-purple-500/30 rounded-xl p-3 flex flex-col gap-2 shrink-0 snap-center relative overflow-hidden group">
                                                    <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-transparent pointer-events-none"></div>
                                                    <div className="flex justify-between items-start">
                                                        <span className="text-xl">{typeof item.icon === 'string' ? item.icon.slice(-2) : item.icon}</span> 
                                                        <span className="text-[9px] text-purple-300 font-bold border border-purple-500/30 px-1.5 rounded">RARE</span>
                                                    </div>
                                                    <div className="text-[10px] font-bold text-white truncate">{item.name}</div>
                                                    <button onClick={() => sellMutatedItem(item.id, item.price)} className="w-full py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-[9px] font-bold rounded uppercase mt-auto shadow-md active:scale-95">
                                                        Sell {formatVND(item.price)}
                                                    </button>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                    
                                    {/* Normal Crops */}
                                    <div className="grid grid-cols-2 gap-2">
                                        {(Object.keys(garden.inventory) as PlantType[]).map(type => {
                                            const count = garden.inventory[type] || 0;
                                            if (count <= 0) return null;
                                            return (
                                                <div key={type} className="flex items-center justify-between p-2 bg-black/40 rounded-lg border border-white/5">
                                                    <div className="flex items-center gap-2">
                                                        <span>{PLANTS[type].emoji}</span>
                                                        <div className="flex flex-col leading-none">
                                                            <span className="text-[10px] font-bold text-emerald-100">{PLANTS[type].name}</span>
                                                            <span className="text-[9px] text-zinc-500">x{count}</span>
                                                        </div>
                                                    </div>
                                                    <button onClick={() => sellCrop(type)} className="px-2 py-1 bg-green-900/30 text-green-400 border border-green-700/50 rounded text-[9px] font-bold active:scale-95">
                                                        SELL
                                                    </button>
                                                </div>
                                            );
                                        })}
                                    </div>
                                    
                                    {Object.values(garden.inventory).every(c => c === 0) && mutatedItems.length === 0 && (
                                        <div className="text-center text-zinc-500 text-xs italic py-4">Kho trống.</div>
                                    )}
                                </div>
                            </>
                        )}

                        {/* TOOLS PANEL */}
                        {activeTool === 'apply_item' && (
                            <>
                                <h4 className="text-[10px] font-bold font-mono text-blue-400 uppercase mb-3 flex items-center gap-2"><Briefcase size={12}/> Tools & Upgrades</h4>
                                <div className="flex gap-3 overflow-x-auto pb-2 custom-scrollbar">
                                    {supplies.map(item => (
                                        <button 
                                            key={item.id}
                                            onClick={() => setSelectedSupply(item.id)}
                                            className={`
                                                flex flex-col items-center gap-2 p-3 rounded-xl border transition-all shrink-0 min-w-[80px]
                                                ${selectedSupply === item.id ? 'bg-blue-600 border-blue-400 text-white shadow-lg' : 'bg-black/40 border-blue-900/30 text-blue-300/70'}
                                            `}
                                        >
                                            <span className="text-2xl">{item.icon}</span>
                                            <span className="text-[10px] font-bold text-center leading-tight">{item.name}</span>
                                            <span className="text-[9px] font-mono opacity-60">x{item.quantity}</span>
                                        </button>
                                    ))}
                                    {supplies.length === 0 && <div className="text-center w-full text-zinc-500 text-xs italic">Không có dụng cụ.</div>}
                                </div>
                            </>
                        )}
                    </div>
                )}

                {/* DOCK BAR */}
                <div className="bg-black/80 backdrop-blur-xl border-t border-white/10 p-2 pb-safe pointer-events-auto">
                    {viewMode === 'CHAR' ? (
                        <div className="flex justify-center gap-6 py-2">
                            <ToolButton icon={<Droplets size={24}/>} label={`Tưới (${waterCharges})`} active={activeTool === 'water'} onClick={() => setActiveTool('water')} />
                            <ToolButton icon={<Footprints size={24}/>} label={`Phá (${trampleCharges})`} active={activeTool === 'trample'} onClick={() => setActiveTool('trample')} />
                            <ToolButton icon={<Hand size={24}/>} label={`Trộm (${stealCharges})`} active={activeTool === 'steal'} onClick={() => setActiveTool('steal')} />
                        </div>
                    ) : (
                        <div className="flex justify-between items-center px-2 overflow-x-auto gap-2 custom-scrollbar snap-x">
                            <ToolButton icon={<Store size={20} />} label="Mua Hạt" active={activeTool === 'shop'} onClick={() => setActiveTool('shop')} />
                            <ToolButton icon={<Sprout size={20} />} label="Gieo" active={activeTool === 'plant'} onClick={() => setActiveTool('plant')} />
                            <ToolButton icon={<Droplets size={20} />} label="Tưới" active={activeTool === 'water'} onClick={() => setActiveTool('water')} />
                            <ToolButton icon={<ShoppingBag size={20} />} label="Hái" active={activeTool === 'harvest'} onClick={() => setActiveTool('harvest')} />
                            <ToolButton icon={<Package size={20} />} label="Kho" active={activeTool === 'harvest_bag'} onClick={() => setActiveTool('harvest_bag')} />
                            <ToolButton icon={<Briefcase size={20} />} label="Đồ Nghề" active={activeTool === 'apply_item'} onClick={() => setActiveTool('apply_item')} />
                            <ToolButton icon={<Hammer size={20} />} label="Nâng Cấp" active={activeTool === 'upgrade'} onClick={() => setActiveTool('upgrade')} />
                            <ToolButton icon={<Shovel size={20} />} label="Xới" active={activeTool === 'shovel'} onClick={() => setActiveTool('shovel')} />
                        </div>
                    )}
                </div>
            </div>
        )}

      </div>
    </div>
  );
};

export default GardenMiniGame;