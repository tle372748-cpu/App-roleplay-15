
import React, { useState, useEffect } from 'react';
import { Briefcase, X, Gift, Sparkles, Coins, Trash2, Send, Shield, RefreshCw, Infinity, CheckSquare, Square, PackagePlus, User, Filter, Layers, BookOpen, List, ChevronRight, ArrowLeft, Package, Utensils } from 'lucide-react';
import { InventoryItem, CardData } from '../types';
import { formatVND } from '../utils/mockDataGenerator';

interface InventoryModalProps {
  onClose: () => void;
  inventory: InventoryItem[];
  characters: CardData[]; 
  user?: CardData | null; 
  onGift: (items: InventoryItem[], targetName: string, message?: string) => void;
  onUse: (item: InventoryItem) => void;
  onSell: (item: InventoryItem) => void;
  themeColors: any;
}

type FilterType = 'ALL' | 'SKILL' | 'USE' | 'GEAR' | 'GIFT' | 'GARDEN' | 'OTHER';

const getSkillBaseName = (fullName: string) => {
    return fullName
        .replace('Skill Card: ', '')
        .replace(/ \[.+\]/, '') 
        .replace(/ (Sơ Cấp|Trung Cấp|Nâng Cao)/, '') 
        .trim();
};

const InventoryModal: React.FC<InventoryModalProps> = ({ onClose, inventory, characters, user, onGift, onUse, onSell, themeColors }) => {
  const [selectedItemForGift, setSelectedItemForGift] = useState<string | null>(null); 
  const [selectedIds, setSelectedIds] = useState<string[]>([]); 
  const [giftMessage, setGiftMessage] = useState('');
  const [recipient, setRecipient] = useState<string>(characters[0]?.name || "Unknown"); 
  const [now, setNow] = useState(Date.now());
  const [activeFilter, setActiveFilter] = useState<FilterType>('ALL');
  
  const [viewingSkillGroup, setViewingSkillGroup] = useState<string | null>(null); 

  useEffect(() => {
      const timer = setInterval(() => setNow(Date.now()), 1000);
      return () => clearInterval(timer);
  }, []);

  useEffect(() => {
      if (characters.length > 0 && !characters.find(c => c.name === recipient) && recipient !== user?.name) {
          setRecipient(characters[0].name);
      }
  }, [characters, user]);

  const toggleSelection = (id: string) => {
      setSelectedIds(prev => 
          prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
      );
  };

  const handleSingleGiftClick = (item: InventoryItem) => {
      setSelectedIds([]);
      setSelectedItemForGift(item.id);
      setGiftMessage('');
      if (characters.length > 0) setRecipient(characters[0].name);
  };

  const handleUseClick = (item: InventoryItem) => {
      if (item.type === 'SKILL_CARD') {
          setSelectedIds([]);
          setSelectedItemForGift(item.id);
          setGiftMessage('LEARN_MODE'); 
          if (user) setRecipient(user.name);
          else if (characters.length > 0) setRecipient(characters[0].name);
      } else {
          onUse(item);
      }
  };

  const confirmGift = () => {
      if (giftMessage === 'LEARN_MODE' && selectedItemForGift) {
          const item = inventory.find(i => i.id === selectedItemForGift);
          if (item) {
              onGift([item], recipient, "LEARN_SKILL");
          }
      } else if (selectedIds.length > 0) {
          const itemsToSend = inventory.filter(i => selectedIds.includes(i.id));
          if (itemsToSend.length > 0) {
              onGift(itemsToSend, recipient, giftMessage);
          }
      } else if (selectedItemForGift) {
          const item = inventory.find(i => i.id === selectedItemForGift);
          if (item) onGift([item], recipient, giftMessage);
      }
      setSelectedItemForGift(null);
      setSelectedIds([]);
      setGiftMessage('');
  };

  const getCooldownText = (item: InventoryItem) => {
      if (!item.cooldown || !item.lastUsed) return null;
      const remaining = Math.ceil((item.lastUsed + item.cooldown - now) / 60000);
      return remaining > 0 ? `${remaining}m` : null;
  };

  const isUsable = (item: InventoryItem) => {
      if (item.name === 'Banner 2026') return false; 
      if (item.usageType === 'INFINITE' && item.cooldown && item.lastUsed) {
          return now >= item.lastUsed + item.cooldown;
      }
      return true;
  };

  const renderRecipientSelector = () => {
      let targets: CardData[] = [...characters];
      if (giftMessage === 'LEARN_MODE' && user) {
          targets = [user, ...characters];
      }

      if (targets.length <= 1 && giftMessage !== 'LEARN_MODE') return null; 
      if (targets.length === 0) return null;

      return (
          <div className="flex gap-2 mb-2 overflow-x-auto custom-scrollbar pb-1">
              {targets.map(char => (
                  <button
                      key={char.name}
                      onClick={() => setRecipient(char.name)}
                      className={`flex items-center gap-1.5 px-2 py-1 rounded-full border transition-all text-[10px] font-bold uppercase shrink-0
                          ${recipient === char.name 
                              ? 'bg-pink-600 border-pink-400 text-white shadow-md' 
                              : 'bg-black/40 border-white/10 text-zinc-400 hover:border-pink-500/50'}
                      `}
                  >
                      {char.avatar ? (
                          <img src={char.avatar} alt={char.name} className="w-4 h-4 rounded-full object-cover" />
                      ) : (
                          <User size={12} />
                      )}
                      {char.name === user?.name ? "Self (Me)" : char.name}
                  </button>
              ))}
          </div>
      );
  };

  const groupedInventory: (InventoryItem | { isGroup: true, id: string, name: string, count: number, items: InventoryItem[] })[] = [];
  const skillGroups: Record<string, InventoryItem[]> = {};
  
  const preFiltered = inventory.filter(item => {
      if (activeFilter === 'ALL') return true;
      if (activeFilter === 'SKILL') return item.type === 'SKILL_CARD';
      if (activeFilter === 'USE') return item.type === 'CONSUMABLE';
      if (activeFilter === 'GEAR') return item.usageType === 'EQUIP' || item.type === 'MISC'; 
      if (activeFilter === 'GIFT') return item.type === 'GIFT';
      if (activeFilter === 'GARDEN') return item.type === 'GARDEN';
      if (activeFilter === 'OTHER') return item.type === 'KEY_ITEM' || (item.type !== 'CONSUMABLE' && item.usageType !== 'EQUIP' && item.type !== 'GIFT' && item.type !== 'GARDEN' && item.type !== 'SKILL_CARD');
      return true;
  });

  preFiltered.forEach(item => {
      if (item.type === 'SKILL_CARD') {
          const baseName = getSkillBaseName(item.name);
          if (!skillGroups[baseName]) {
              skillGroups[baseName] = [];
          }
          skillGroups[baseName].push(item);
      } else {
          groupedInventory.push(item);
      }
  });

  Object.keys(skillGroups).forEach(baseName => {
      const items = skillGroups[baseName];
      const totalCount = items.reduce((sum, i) => sum + i.quantity, 0);
      groupedInventory.unshift({
          isGroup: true,
          id: `group-${baseName}`,
          name: `Bộ Kĩ Năng: ${baseName}`,
          count: totalCount,
          items: items
      });
  });

  const displayList = groupedInventory;
  const detailList = viewingSkillGroup ? skillGroups[viewingSkillGroup] || [] : [];

  const renderItemCard = (item: InventoryItem, isDetailView: boolean) => {
        const isSkillCard = item.type === 'SKILL_CARD';
        const isEquipped = item.isEquipped;
        const cooldownText = getCooldownText(item);
        const canUse = isUsable(item);
        const isSelected = selectedIds.includes(item.id);
        const isTransferable = item.usageType !== 'INFINITE';
        const isProdigy = item.rating === 'Prodigy';
        const prodigyStyle = isProdigy ? 'border-red-500/60 bg-gradient-to-r from-red-950/60 via-purple-900/30 to-red-950/60 shadow-[0_0_20px_rgba(239,68,68,0.4),inset_0_0_10px_rgba(239,68,68,0.2)] ring-1 ring-white/10 bg-[length:200%_200%] animate-rgb-flow' : '';
        const isConsumable = item.type === 'CONSUMABLE' || item.type === 'INGREDIENT';
        const isGardenItem = item.type === 'GARDEN';

        const canSell = !isSkillCard && item.rating !== 'Prodigy';
        const sellPrice = Math.floor(item.price * 0.5);

        return (
            <div key={item.id} className={`p-3 rounded-lg border transition-all hover:bg-white/5 relative group flex flex-col gap-2 animate-in slide-in-from-bottom-2
                ${isSelected ? 'border-pink-500/50 bg-pink-900/10' : 'border-white/10 bg-white/5'}
                ${isEquipped ? 'ring-1 ring-green-500 border-green-500/50' : ''}
                ${prodigyStyle}
            `}>
                {isTransferable && (
                    <button 
                        onClick={() => toggleSelection(item.id)}
                        className={`absolute top-3 left-3 z-10 text-white/50 hover:text-pink-400 transition-colors ${isSelected ? 'text-pink-500' : ''}`}
                    >
                        {isSelected ? <CheckSquare size={18} /> : <Square size={18} />}
                    </button>
                )}

                {!isSkillCard && item.price > 0 && (
                    <div className="absolute top-2 right-2 text-[9px] font-mono font-bold text-yellow-300 flex items-center gap-1 bg-black/40 px-1.5 py-0.5 rounded border border-yellow-500/10">
                        VAL: {formatVND(sellPrice)}
                    </div>
                )}

                <div className={`flex items-center gap-4 ${isTransferable ? 'pl-8' : ''}`}>
                    <div className={`w-12 h-12 flex items-center justify-center text-3xl bg-black/20 rounded-lg shrink-0 relative ${isEquipped ? 'border border-green-500/50' : ''}`}>
                        {item.icon}
                        {item.usageType === 'INFINITE' && (
                            <div className="absolute -bottom-1 -right-1 text-white bg-blue-600 rounded-full p-0.5 border border-black shadow-sm">
                                <Infinity size={10} />
                            </div>
                        )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                            <h4 className={`font-bold text-sm ${themeColors.textMain}`}>{item.name}</h4>
                            {item.quantity > 1 && (
                                <span className="text-[9px] font-mono bg-blue-500/20 text-blue-300 px-1.5 rounded">x{item.quantity}</span>
                            )}
                            {isEquipped && (
                                <span className="text-[9px] font-bold uppercase bg-green-500/20 text-green-400 px-1.5 rounded border border-green-500/30">Equipped</span>
                            )}
                        </div>
                        <p className={`text-[10px] ${themeColors.textDim} truncate`}>{item.description}</p>
                        <div className="flex gap-2 mt-0.5">
                            <span className="text-[8px] uppercase bg-white/5 px-1.5 rounded text-gray-400">{item.type}</span>
                            {item.buffDescription && (
                                <span className="text-[9px] font-mono text-purple-400">+ {item.buffDescription}</span>
                            )}
                            {item.rating && (
                                <span className="text-[9px] font-mono text-cyan-400 border border-cyan-500/30 px-1 rounded">Rank: {item.rating}</span>
                            )}
                        </div>
                    </div>

                    <div className="flex items-center gap-1">
                        {!isGardenItem && (
                            <button 
                                onClick={() => canUse && handleUseClick(item)}
                                disabled={!canUse}
                                className={`p-2 rounded transition-colors flex flex-col items-center gap-0.5 min-w-[50px]
                                    ${item.usageType === 'EQUIP' 
                                        ? (isEquipped ? 'bg-zinc-700 text-zinc-400 hover:bg-zinc-600' : 'bg-green-600/20 hover:bg-green-600/40 text-green-400 border border-green-500/30') 
                                        : (canUse ? 'hover:bg-green-500/20 text-green-400' : 'text-zinc-500 cursor-not-allowed')
                                    }
                                    ${item.type === 'SKILL_CARD' && selectedItemForGift === item.id ? 'bg-cyan-600 text-white' : ''}
                                `}
                                title={item.usageType === 'EQUIP' ? (isEquipped ? "Unequip" : "Equip") : "Use Item"}
                            >
                                {item.type === 'SKILL_CARD' ? <BookOpen size={16} /> : item.usageType === 'EQUIP' ? (
                                    isEquipped ? <X size={16} /> : <Shield size={16} />
                                ) : isConsumable ? (
                                    <Utensils size={16} />
                                ) : (
                                    cooldownText ? <RefreshCw size={16} className="animate-spin" /> : <Sparkles size={16} />
                                )}
                                <span className="text-[8px] font-bold uppercase">
                                    {item.type === 'SKILL_CARD' ? "Learn" : item.usageType === 'EQUIP' 
                                        ? (isEquipped ? "Unequip" : "Equip") 
                                        : isConsumable ? "Eat" : (cooldownText || "Use")}
                                </span>
                            </button>
                        )}

                        {isTransferable && (
                            <button 
                                onClick={() => handleSingleGiftClick(item)}
                                className={`p-2 rounded hover:bg-pink-500/20 transition-colors flex flex-col items-center gap-0.5 ${selectedItemForGift === item.id && giftMessage !== 'LEARN_MODE' ? 'bg-pink-500/30 text-white' : 'text-pink-500'}`}
                                title="Gift One"
                            >
                                <Gift size={16} />
                                <span className="text-[8px] font-bold uppercase">Gift</span>
                            </button>
                        )}
                        
                        {canSell && isTransferable && (
                            <button 
                                onClick={() => onSell(item)}
                                className="p-2 rounded hover:bg-yellow-500/20 text-yellow-500 transition-colors flex flex-col items-center gap-0.5"
                                title={`Sell for ${formatVND(sellPrice)}`}
                            >
                                <Coins size={16} />
                                <span className="text-[8px] font-bold uppercase">Sell</span>
                            </button>
                        )}
                    </div>
                </div>
            </div>
        );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className={`w-full max-w-4xl border rounded-xl shadow-2xl flex flex-col ${themeColors.bgMain} ${themeColors.border} overflow-hidden max-h-[90vh]`}>
        
        <div className={`flex items-center justify-between p-4 border-b ${themeColors.border} ${themeColors.bgPanel} shrink-0`}>
            <div className="flex items-center gap-2 text-blue-400">
                <Briefcase size={20} />
                <h3 className="font-mono font-bold uppercase tracking-widest text-sm">Inventory Management</h3>
            </div>
            <button onClick={onClose} className={`${themeColors.textDim} hover:${themeColors.textMain} transition-colors`}><X size={18} /></button>
        </div>

        <div className={`flex border-b ${themeColors.border} ${themeColors.bgPanel} overflow-x-auto shrink-0 custom-scrollbar`}>
            {['ALL', 'SKILL', 'USE', 'GEAR', 'GIFT', 'GARDEN', 'OTHER'].map(f => (
                <button
                    key={f}
                    onClick={() => setActiveFilter(f as FilterType)}
                    className={`flex-1 min-w-[80px] py-2 text-[10px] font-mono font-bold uppercase transition-colors
                        ${activeFilter === f ? 'bg-white/10 text-white border-b-2 border-white' : 'text-zinc-500 hover:text-zinc-300 hover:bg-white/5'}
                    `}
                >
                    {f}
                </button>
            ))}
        </div>

        <div className="flex-1 flex overflow-hidden">
            
            <div className={`flex-1 overflow-y-auto custom-scrollbar p-4 flex flex-col gap-2 ${viewingSkillGroup ? 'hidden md:flex md:w-1/2 border-r border-white/10' : 'w-full'}`}>
                {displayList.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-zinc-500 gap-2 opacity-50">
                        <Package size={32} />
                        <span className="text-xs font-mono">Empty Inventory</span>
                    </div>
                ) : (
                    displayList.map((item: any) => {
                        if (item.isGroup) {
                            return (
                                <div key={item.id} className="p-3 rounded-lg border border-cyan-500/20 bg-cyan-900/10 hover:bg-cyan-900/20 transition-all cursor-pointer group" onClick={() => setViewingSkillGroup(item.name.replace('Bộ Kĩ Năng: ', ''))}>
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            <div className="w-10 h-10 rounded bg-cyan-900/30 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                                                <Layers size={18} />
                                            </div>
                                            <div>
                                                <h4 className="font-bold text-xs text-cyan-200">{item.name}</h4>
                                                <p className="text-[9px] text-cyan-500/70">{item.count} Cards Collected</p>
                                            </div>
                                        </div>
                                        <ChevronRight size={16} className="text-cyan-600 group-hover:text-cyan-400" />
                                    </div>
                                </div>
                            );
                        }
                        return renderItemCard(item, false);
                    })
                )}
            </div>

            {viewingSkillGroup && (
                <div className={`flex-1 overflow-y-auto custom-scrollbar p-4 bg-black/20 flex flex-col gap-2 ${viewingSkillGroup ? 'w-full md:w-1/2' : 'hidden'}`}>
                    <div className="flex items-center gap-2 mb-2 pb-2 border-b border-white/10 md:hidden">
                        <button onClick={() => setViewingSkillGroup(null)} className="p-1 rounded hover:bg-white/10"><ArrowLeft size={16}/></button>
                        <span className="font-bold text-xs">Back to List</span>
                    </div>
                    <h4 className="font-mono text-xs font-bold text-cyan-400 uppercase mb-2">Cards in: {viewingSkillGroup}</h4>
                    {detailList.map(item => renderItemCard(item, true))}
                </div>
            )}

        </div>

        {(selectedItemForGift || selectedIds.length > 0) && (
            <div className={`p-4 border-t ${themeColors.border} ${themeColors.bgPanel} flex flex-col gap-3 animate-in slide-in-from-bottom-2`}>
                <div className="flex justify-between items-center">
                    <span className="text-xs font-bold font-mono text-pink-400 flex items-center gap-2">
                        {giftMessage === 'LEARN_MODE' ? <BookOpen size={14} /> : <Gift size={14} />}
                        {giftMessage === 'LEARN_MODE' ? "LEARN SKILL" : selectedIds.length > 0 ? `SEND BUNDLE (${selectedIds.length})` : "SEND GIFT (PENDING)"}
                    </span>
                    <button onClick={() => { setSelectedItemForGift(null); setSelectedIds([]); setGiftMessage(''); }} className="text-zinc-500 hover:text-white"><X size={14} /></button>
                </div>

                {renderRecipientSelector()}

                <div className="flex gap-2">
                    {giftMessage !== 'LEARN_MODE' && (
                        <input 
                            type="text" 
                            value={giftMessage}
                            onChange={(e) => setGiftMessage(e.target.value)}
                            placeholder="Add a message..."
                            className="flex-1 bg-black/40 border border-white/10 rounded px-3 py-2 text-xs text-white outline-none focus:border-pink-500 transition-colors"
                        />
                    )}
                    <button 
                        onClick={confirmGift}
                        className={`px-4 py-2 rounded font-bold text-xs uppercase shadow-lg transition-all active:scale-95 flex items-center gap-2
                            ${giftMessage === 'LEARN_MODE' ? 'bg-cyan-600 hover:bg-cyan-500 text-white' : 'bg-pink-600 hover:bg-pink-500 text-white'}
                        `}
                    >
                        {giftMessage === 'LEARN_MODE' ? 'Learn Now' : <><Send size={12} /> Attach to Chat</>}
                    </button>
                </div>
            </div>
        )}

        {!selectedItemForGift && selectedIds.length === 0 && (
            <div className={`p-2 border-t ${themeColors.border} ${themeColors.bgPanel} flex justify-between items-center text-[9px] font-mono text-zinc-500`}>
                <span>Capacity: {inventory.length} items</span>
            </div>
        )}

      </div>
    </div>
  );
};

export default InventoryModal;
