
// FILE DEPRECATED - REPLACED BY ECONOMY MODAL
import React from 'react';
export default () => null;
