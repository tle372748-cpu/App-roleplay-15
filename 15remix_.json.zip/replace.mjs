import fs from 'fs';
const file = './services/aiService.ts';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(/"gemini-3-flash-preview"/g, '"gemini-3.5-flash"');
fs.writeFileSync(file, content);
