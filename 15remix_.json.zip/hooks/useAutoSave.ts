
import { useEffect, useRef } from 'react';
import { AppConfig, ChatMessage } from '../types';
import { saveConfigToIDB, saveMessagesToIDB } from '../utils/storage';

export const useAutoSave = (
    config: AppConfig, 
    messages: ChatMessage[], 
    isDataLoaded: boolean,
    onStatusChange?: (status: 'SAVING' | 'SAVED' | 'ERROR' | 'IDLE') => void
) => {
    // Refs to hold latest state for event listeners (closures)
    const configRef = useRef(config);
    const messagesRef = useRef(messages);
    const lastSavedConfigStr = useRef<string>("");
    
    // Update refs whenever state changes
    useEffect(() => {
        configRef.current = config;
    }, [config]);

    useEffect(() => {
        messagesRef.current = messages;
    }, [messages]);

    // 1. CONFIG SAVER: Interval (Every 5 seconds)
    // Only saves if data actually changed to save performance/disk writes
    useEffect(() => {
        if (!isDataLoaded) return;

        const intervalId = setInterval(async () => {
            try {
                // Safely convert to string to prevent circular references breaking it 
                // and to do exact structural comparison
                const safeConfig = JSON.parse(JSON.stringify(configRef.current));
                const currentStr = JSON.stringify(safeConfig);
                
                if (currentStr !== lastSavedConfigStr.current) {
                    if (onStatusChange) onStatusChange('SAVING');
                    await saveConfigToIDB(safeConfig);
                    lastSavedConfigStr.current = currentStr;
                    if (onStatusChange) {
                        onStatusChange('SAVED');
                        setTimeout(() => onStatusChange('IDLE'), 2000);
                    }
                }
            } catch (e: any) {
                console.error("AutoSave Config Error (Circular/Clone):", e);
                if (onStatusChange) onStatusChange('ERROR');
            }
        }, 5000); // 5 Seconds Interval

        return () => clearInterval(intervalId);
    }, [isDataLoaded, onStatusChange]);

    // 2. MESSAGE SAVER: Immediate on Change
    // Whenever the messages array length changes (new msg added)
    useEffect(() => {
        if (!isDataLoaded) return;

        const saveNow = async () => {
            try {
                if (onStatusChange) onStatusChange('SAVING');
                // Strip non-cloneable elements safely
                const safeMessages = JSON.parse(JSON.stringify(messages));
                await saveMessagesToIDB(safeMessages);
                if (onStatusChange) {
                    onStatusChange('SAVED');
                    setTimeout(() => onStatusChange('IDLE'), 2000);
                }
            } catch (e: any) {
                console.error("AutoSave Message Error (Circular/Clone):", e);
                if (onStatusChange) onStatusChange('ERROR');
            }
        };

        saveNow();
    }, [messages, isDataLoaded, onStatusChange]);

    // 3. EMERGENCY SAVER: On Exit / Hide / Blur
    useEffect(() => {
        const handleEmergencySave = () => {
            if (!isDataLoaded) return;
            // Use the REF values to ensure we capture the absolute latest state
            // even if the component is frozen/unmounting. Use safe cloning.
            try {
                const safeConfig = JSON.parse(JSON.stringify(configRef.current));
                const safeMessages = JSON.parse(JSON.stringify(messagesRef.current));
                saveConfigToIDB(safeConfig);
                saveMessagesToIDB(safeMessages);
                console.log(">> Emergency Save Triggered (Visibility/Unload)");
            } catch (e) {
                console.error("Emergency save error:", e);
            }
        };

        // 'visibilitychange' covers tab switching and minimizing on mobile
        document.addEventListener("visibilitychange", handleEmergencySave);
        
        // 'pagehide' covers closing the tab/browser (better than beforeunload for modern browsers)
        window.addEventListener("pagehide", handleEmergencySave);

        return () => {
            document.removeEventListener("visibilitychange", handleEmergencySave);
            window.removeEventListener("pagehide", handleEmergencySave);
        };
    }, [isDataLoaded]);
};
