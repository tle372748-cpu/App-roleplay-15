
import React from 'react';

export enum Kernel {
  NM_PLUS = "NM_PLUS",
  SE_PLUS = "SE_PLUS",
  SE_PRO = "SE_PRO",
  SM_PLUS = "SM_PLUS",
  SE_ULTRA = "SE_ULTRA",
  SE_DARK = "SE_DARK",
  NM_ZENITH = "NM_ZENITH",
  NM_ARCHIVE = "NM_ARCHIVE",
  CLAUDE_OPUS = "CLAUDE_OPUS",
  CLAUDE_SONNET = "CLAUDE_SONNET" // NEW KERNEL: GOD TIER LITERATURE
}

export enum AIModel {
  GEMINI_3_1_PRO = "gemini-3.1-pro-preview",
  GEMINI_3_FLASH = "gemini-3.5-flash",
  GEMINI_3_PRO = "gemini-3-pro-preview",
  GEMINI_2_5_FLASH = "gemini-flash-latest",
  GEMINI_2_5_PRO = "gemini-2.5-pro"
}

export enum CoreMode {
  HUMAN = "HUMAN",
  CRUEL = "CRUEL",
  CARNAL = "CARNAL",
  SOFT = "SOFT",
  HEALING = "HEALING",
  COMEDY = "COMEDY",
  OMNIVERSE = "OMNIVERSE",
  NOIR = "NOIR",
  HORROR = "HORROR",
  MYSTERY = "MYSTERY",
  SCHOOL_LIFE = "SCHOOL_LIFE",
  WAR = "WAR"
}

export enum Relationship {
  STRANGERS = "STRANGERS",
  ESTABLISHED = "ESTABLISHED",
  ENEMIES = "ENEMIES",
  SPARK = "SPARK",
  HAREM = "HAREM",
  MASTER_SERVANT = "MASTER_SERVANT",
  BEST_FRIENDS = "BEST_FRIENDS",
  EXES = "EXES",
  FAMILY = "FAMILY"
}

export enum WorldSetting {
  MODERN = "MODERN",
  CYBERPUNK = "CYBERPUNK",
  WUXIA = "WUXIA",
  FANTASY = "FANTASY",
  DYSTOPIA = "DYSTOPIA",
  STEAMPUNK = "STEAMPUNK",
  APOCALYPSE = "APOCALYPSE",
  ISEKAI = "ISEKAI",
  VICTORIAN = "VICTORIAN",
  SPACE_OPERA = "SPACE_OPERA",
  // NEW WORLDS
  ABO = "ABO",
  MAFIA = "MAFIA",
  CULTIVATION = "CULTIVATION",
  ELDRITCH = "ELDRITCH",
  DUNGEON = "DUNGEON",
  ECCHI_SCHOOL = "ECCHI_SCHOOL"
}

export enum CultureOS {
  NAM_HON = "NAM_HON",
  OCCIDENTALIS = "OCCIDENTALIS"
}

export enum NarrativeLength {
  CHAT = "CHAT",
  SHORT_STORY = "SHORT_STORY",
  NOVELLA = "NOVELLA",
  NOVEL = "NOVEL",
  EPIC = "EPIC",
  LONG = "LONG"
}

export enum Perspective {
  FIRST = "FIRST",
  SECOND = "SECOND",
  THIRD = "THIRD",
  THIRD_LIMITED = "THIRD_LIMITED",
  THIRD_OMNISCIENT = "THIRD_OMNISCIENT",
  CINEMATIC = "CINEMATIC"
}

export enum Mindset {
  TELEPATHIC = "TELEPATHIC",
  OBSERVER = "OBSERVER",
  ANALYTICAL = "ANALYTICAL",
  INTERNAL = "INTERNAL",
  NARRATOR = "NARRATOR"
}

export enum NarrativeTone {
  SWEET = "SWEET",
  CASUAL = "CASUAL",
  BRUTAL = "BRUTAL",
  SENSUAL = "SENSUAL",
  LEWD = "LEWD",
  OBSCENE = "OBSCENE",
  PSYCHOLOGICAL = "PSYCHOLOGICAL",
  MELANCHOLIC = "MELANCHOLIC",
  MANIC = "MANIC",
  DREAMY = "DREAMY",
  SARCASTIC = "SARCASTIC",
  EDUCATIONAL = "EDUCATIONAL",
  MYSTERIOUS = "MYSTERIOUS",
  HOPEFUL = "HOPEFUL"
}

export enum Difficulty {
  SANDBOX = "SANDBOX",
  CINEMATIC = "CINEMATIC",
  REALISM = "REALISM",
  SURVIVAL = "SURVIVAL",
  HARDCORE = "HARDCORE",
  NIGHTMARE = "NIGHTMARE"
}

export enum DisplayMode {
  IMMERSIVE = "IMMERSIVE",
  ANALYTIC = "ANALYTIC"
}

export enum Physics {
  STANDARD = "STANDARD",
  VISCERAL = "VISCERAL"
}

export enum Tempo {
  REAL_TIME = "REAL_TIME",
  CINEMATIC = "CINEMATIC",
  FAST_PACED = "FAST_PACED",
  SLOW_BURN = "SLOW_BURN"
}

export enum Entropy {
  LOW = "LOW",
  STANDARD = "STANDARD",
  HIGH = "HIGH",
  MAYHEM = "MAYHEM"
}

export enum SensoryLOD {
  LOW = "LOW",
  BALANCED = "BALANCED",
  HIGH = "HIGH",
  EXTREME = "EXTREME"
}

export enum Psyche {
  STABLE = "STABLE",
  UNSTABLE = "UNSTABLE",
  BROKEN = "BROKEN",
  MANIC = "MANIC"
}

export enum Theme {
  CLASSIC = "CLASSIC",
  TERMINAL = "TERMINAL",
  CUTE = "CUTE",
  GOTHIC = "GOTHIC",
  MINIMALIST = "MINIMALIST",
  VAPORWAVE = "VAPORWAVE",
  NATURE = "NATURE",
  MIDNIGHT_BLUE = "MIDNIGHT_BLUE",
  COFFEE = "COFFEE",
  DISTINCTIVE = "DISTINCTIVE",
  OVERFLOWEY = "OVERFLOWEY",
  SPIDEY = "SPIDEY",
  SYNTHWAVE = "SYNTHWAVE",
  DRACULA = "DRACULA",
  NORD = "NORD",
  MONOKAI = "MONOKAI",
  SAKURA = "SAKURA",
  SOLARIZED = "SOLARIZED",
  CUSTOM = "CUSTOM"
}

export interface VisualFeature {
  location: string;
  description: string;
}

export interface PhysicalAttributes {
  height?: number;
  weight?: number;
  muscle?: number;
  fat?: number;
  beauty?: number;
  sensitivity?: number;
  measurements?: { bust: number; waist: number; hips: number; cup: string };
  genitals?: { depth?: number; length?: number; girth?: number; wetness?: number; traits?: string[] };
  pregnancy?: { isPregnant: boolean; weeks: number; isVisible: boolean };
  fluids?: { lactation?: boolean; capacity?: number; flowMode?: string; valve?: string; scent?: string };
  rear?: { depth?: number; tightness?: number };
  grooming?: { style?: string };
  visuals?: {
    skinTone?: string;
    hairColor?: string;
    hairStyle?: string;
    eyeColor?: string;
    bodyType?: string;
    bodyFeatures?: VisualFeature[];
    tattoos?: VisualFeature[];
    scars?: VisualFeature[];
  };
}

export interface WardrobeItem {
  slot: 'HEAD' | 'EYES' | 'NECK' | 'TOP' | 'OUTER' | 'BOTTOM' | 'LEGS' | 'FEET' | 'ACC' | 'HELD';
  name: string;
  description: string;
  color?: string;
}

export interface Wardrobe {
  styleTag: string;
  items: WardrobeItem[];
}

export interface Keybind {
  id: string;
  trigger: string;
  effect: string;
  isActive: boolean;
}

export interface EroZone {
  id: string;
  name: string;
  sensitivity: number;
  reaction: string;
}

export interface BioRhythm {
  phase: 'NORMAL' | 'OVULATION' | 'DEPRESSIVE' | 'HYPER' | 'ESTRUS';
  day: number;
  fertility: number;
  libidoModifier: number;
}

export interface VocalSettings {
  moanPattern: string;
  speechImpediment: string;
  forbiddenWords: string[];
}

export interface HeavyAsset {
  id: string;
  name: string;
  description: string;
  value: number;
  type: 'REAL_ESTATE' | 'BUSINESS' | 'VEHICLE' | 'CONTRACT' | 'TITLE' | 'OTHER';
  icon: string;
}

export interface DialoguePatterns {
  frequency?: string;
  tone?: string;
  style?: string;
}

export interface CardData {
  name: string;
  aliases?: string[];
  role?: string;
  age?: string;
  gender?: string;
  pronouns?: string;
  height?: string;
  description?: string;
  traits?: string[];
  outfitDescription?: string;
  originalOutfitDescription?: string;
  outfitLocked?: boolean;
  physical?: PhysicalAttributes;
  dialoguePatterns?: DialoguePatterns;
  status?: {
    hp?: string;
    stress?: string;
    arousal?: string;
    secret?: string;
    logicEmotion?: string;
    introExtro?: string;
    subDom?: string;
    alignment?: string;
    speechStyle?: string;
    obsessions?: string;
    jealousy?: string;
    vulgarity?: string;
  };
  phone?: {
    model?: string;
    battery?: number;
    wallpaper?: string;
    bankBalance?: string;
    messages?: any[];
    history?: any[];
  };
  diary?: { date: string; title: string; content: string }[];
  hiddenMemories?: string[];
  wardrobe?: Wardrobe;
  keybinds?: Keybind[];
  eroMap?: EroZone[];
  bioRhythm?: BioRhythm;
  vocalSettings?: VocalSettings;
  assets?: HeavyAsset[];
  avatar?: string;
  rawContent?: string;
  wealthClass?: string;
  nativeLanguage?: string;
  isAutoGenerated?: boolean;
}

export interface InventoryItem {
  id: string;
  name: string;
  description: string;
  price: number;
  quantity: number;
  icon: string | React.ReactNode;
  type: string;
  usageType?: string;
  isEquipped?: boolean;
  buffDescription?: string;
  rating?: string;
  stars?: number;
  fusionCount?: number;
  source?: string;
  cooldown?: number;
  lastUsed?: number;
}

export interface ShopItem {
  id: string;
  name: string;
  price: number;
  description: string;
  icon: string | React.ReactNode;
  type?: string;
  usageType?: string;
  sold?: boolean;
  rating?: string;
  stars?: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  type: 'MSG_COUNT' | 'GOLD_HOARD' | 'CHAR_COUNT' | 'ITEM_COUNT' | 'EQUIP_COUNT' | 'LONG_MSG' | 'ACTION_MSG';
  targetValue: number;
  currentValue: number;
  isUnlocked: boolean;
  reward: {
    gold: number;
    nano?: number;
    qPulls?: number;
    qePulls?: number;
    item?: InventoryItem;
    items?: InventoryItem[];
  };
}

export interface GameStats {
  level: number;
  exp: number;
  maxExp: number;
  hp: number;
  maxHp: number;
  mp: number;
  maxMp: number;
  sanity: number;
  gold: number;
  nano?: number;
  qPulls?: number;
  qePulls?: number;
  messagesSent: number;
  longMessagesCount?: number;
  actionMessagesCount?: number;
  class?: string;
  investmentHistory?: number[];
  pickpocketCooldowns?: Record<string, number>;
  pickpocketStats?: Record<string, { attempts: number; penalties: number }>;
  assets?: HeavyAsset[];
  achievements?: Achievement[];
  equippedItemCount?: number;
}

export type PlantType = 'carrot' | 'tomato' | 'rose' | 'sunflower' | 'wheat' | 'orchid' | 'jade' | 'goldtree' | 'ancient' | 'divine';
export type WeatherType = 'SUN' | 'RAIN' | 'WIND' | 'SNOW' | 'ACID' | 'POLLEN' | 'METEOR' | 'FOSSIL' | 'ZOMBIE' | 'HOLY' | 'ANCIENT';

export interface GardenPlot {
  id: number;
  plantType: PlantType | null;
  growthStage: number;
  isWatered: boolean;
  tier: number;
  buffs?: { fertilizer?: boolean; autoWater?: boolean; trap?: boolean };
  mutations?: string[];
}

export interface PetState {
  name: string;
  type: string;
  level: number;
  exp: number;
  stats: {
    hunger: number;
    affection: number;
    energy: number;
  };
  lastInteraction: number;
}

export interface MusicTrack {
  id: string;
  title: string;
  url: string;
  isLocal?: boolean;
}

export interface LiveComment {
  id: string;
  user: string;
  content: string;
  type: 'CHAT' | 'DONATE' | 'GIFT';
  value?: number | string;
}

export interface LiveState {
  comments: LiveComment[];
  earnings: number;
  persona: string;
}

export interface ToyState {
  isEnabled: boolean;
  intensity: number;
  mode: 'CONSTANT' | 'PULSE' | 'WAVE' | 'RANDOM' | 'EARTHQUAKE';
  battery: number;
  targetName: string | null;
  toyType: 'VIBRATOR' | 'DILDO' | 'ANAL_BEADS' | 'NIPPLE_CLAMPS' | 'PUMP' | 'MACHINE';
  zones: ('MOUTH' | 'BREAST' | 'PUSSY' | 'ANAL')[];
}

export interface UserAura {
  type: 'NONE' | 'DOMINANCE' | 'ALLURE' | 'TERROR' | 'SAINT' | 'GHOST';
  intensity: number;
  isActive: boolean;
}

export interface SoulContract {
  clauses: string[];
  isSealed: boolean;
  signatory: string;
  dateSigned: string;
}

export interface TimelineNode {
  id: string;
  title: string;
  content: string;
  date?: string;
  position: { x: number; y: number };
  connections: string[];
  connectionLabels?: Record<string, string>;
  type: 'TIMELINE' | 'RELATION';
}

export interface HistoryCard {
  id: string;
  name: string;
  content: string;
  dateAdded: number;
  sourceType: 'FILE' | 'EXPORT_JSON' | 'MANUAL' | 'AI_EXTRACT';
}

export interface ActiveEventCard {
    id: string;
    turnsRemaining: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system' | 'nano_quasar';
  content: string;
  timestamp: number;
  versions?: string[];
  currentVersionIndex?: number;
  feedback?: 'LIKE' | 'DISLIKE';
  metadata?: any;
  sticker?: { url: string };
  style?: any;
  isHidden?: boolean;
}

export interface Biases {
  lewdness: number; // 0-4
  cruelness: number; // 0-4
  flawless: number; // 0-4
  softness: number; // 0-4
  love: number; // 0-4
  sexualNarrative?: number;
  disabledBias?: number; // 2 (Normal)
  sizeGap?: number; // 0
}

export interface SafetySettings {
    harassment: number; // 0 (None) - 3 (Everything)
    hateSpeech: number;
    sexuallyExplicit: number;
    dangerousContent: number;
}

export interface CalendarNote {
  id: string;
  date: string;
  type: 'NOTE' | 'STICKER' | 'DRAWING' | 'MARKER';
  content: string;
  position: { x: number; y: number }; // Percent
  size?: number; // Scale
  rotation?: number; // Deg
  path?: string; // For drawings (SVG Path)
  style?: {
      color?: string;
      fontFamily?: string;
      fontSize?: number;
      strokeWidth?: number;
  };
}

export interface CharacterSkillProfile {
  name: string;
  skills: { 
    name: string; 
    rating: string; 
    isCard?: boolean; 
    icon?: string; 
    color?: string; 
    visuals?: {
      bg: string;
      texture?: string;
      border: string;
      text?: string;
      ratingColor?: string;
      complexityColor?: string;
      animation?: string;
      animSpeed?: number;
    };
  }[];
}

export interface PhoneContent {
    theme: {
        wallpaperPrompt: string;
        iconStyle?: string;
        colors: {
            background: string;
            text: string;
            accent?: string;
            appIcon?: string;
        };
        fontFamily: string;
    };
    notifications: string[];
    recentNotes: { title: string; content: string; date: string }[];
    recentTransactions: { merchant: string; amount: string; date: string }[];
    installedApps: string[];
}

export interface SocialPost {
    id: string;
    authorName: string;
    avatar?: string;
    timestamp: string;
    content: string;
    likes: number;
    isLiked: boolean;
    comments: { user: string; text: string }[];
    hashtags: string[];
    proposedCharacter?: any;
}

export interface ApiSlot {
    id: string;
    name: string;
    key: string;
}

export interface VectorMemoryItem {
    id: string;
    keys: string[]; // Triggers (comma sep)
    memory: string; // The memory content
    scope?: 'GLOBAL' | string; // Global or Specific Char ID
    isActive: boolean;
    activationCount?: number;
}

export interface VoiceSettings {
    narratorVoice: string; // 'Puck', 'Kore', etc.
    userVoice: string;
    characterMap: Record<string, string>; // { "Alice": "Kore" }
    stylePrompts: Record<string, string>; // { "Alice": "Softly", "Narrator": "Neutral" }
}

export interface CharacterPromptConfig {
    speechStyle?: string; // Cách nói
    actionStyle?: string; // Cách hành động
    thoughtStyle?: string; // Cách suy nghĩ
    problemSolving?: string; // Cách nhìn nhận vấn đề
    worldView?: string; // Cách nhìn thế giới
    whisperStyle?: string; // Cách thủ thỉ
}

export interface ThemeOverlay {
  id: string;
  src: string;
  x: number; // percentage 0-100
  y: number; // percentage 0-100
  scale: number;
  rotation: number; // degrees
  layer: 'background' | 'foreground';
}

export interface DirectorPreferences {
  enabled: boolean;
  elements: {
    id: string;
    label: string;
    weight: number;
    order: number;
  }[];
}

export interface AppConfig {
  contextScanInterval?: number;
  contextScanLength?: number;
  directorPreferences?: DirectorPreferences;
  overlays?: ThemeOverlay[];
  kernel: Kernel;
  model: AIModel;
  coreMode: CoreMode[];
  relationship: Relationship[];
  world: WorldSetting[];
  culture: CultureOS;
  length: NarrativeLength;
  perspective: Perspective;
  mindset: Mindset;
  narrativeTone: NarrativeTone;
  difficulty: Difficulty;
  displayMode: DisplayMode;
  physics: Physics;
  activeModules: string[];
  tempo: Tempo;
  entropy: Entropy;
  sensory: SensoryLOD;
  psyche: Psyche;
  biases: Biases;
  safety: SafetySettings;
  burningCheese: number;
  temperature: number;
  topP: number;
  topK: number;
  frequencyPenalty: number;
  presencePenalty: number;
  proseDensity: number;
  logicalAdherence: number;
  aceEater: boolean;
  ontologicalShield: boolean;
  secretAgeChanger: boolean;
  aiSpeakForUser: number;
  aiProactivity: number;
  aiTimeSkip: number;
  agencyModes: string[];
  showInternalLog: boolean;
  betaFeatures: string[];
  controlFlags: string[];
  theFeatures: string[];
  
  userCard: CardData | null;
  characterCards: CardData[];
  loreItems: { id: string; name: string; content: string }[];
  scenario: string | null;
  historyCards: HistoryCard[];
  autokiuc: string;
  autokiucLastTimestamp: number;
  
  customSystemInstruction: string;
  systemInstructionName: string;
  themedCommandsInstruction: string;
  
  theme: Theme;
  customBackground: string | null;
  backgroundGradient?: string;
  currentMessageStyle?: any;
  
  flipCardStyle?: string;
  flipCardColors?: { front: string; back: string; text: string; border: string };
  userBubbleTheme?: string;
  charBubbleTheme?: string;
  userBubbleColor?: string;
  charBubbleColor?: string;
  
  userTextColor?: string;
  charTextColor?: string;
  
  userBubbleOpacity?: number;
  charBubbleOpacity?: number;
  profileEffect?: string;
  fontFamily: string;
  fontSize: number;
  
  autoExportInterval: number;
  
  gameStats?: GameStats;
  garden?: {
    plots: GardenPlot[];
    exp: number;
    inventory: Record<PlantType, number>;
    seeds: Record<PlantType, number>;
    interactionCooldowns: { water: number[], trample: number[], steal?: number[] };
    weather: WeatherType;
    weatherTimer: number;
  };
  musicPlayer?: {
    playlist: MusicTrack[];
    currentIndex: number;
    isPlaying: boolean;
    isLooping: boolean;
    volume: number;
    isMinimized: boolean;
  };
  liveState?: LiveState;
  toyState?: ToyState;
  inventory?: InventoryItem[];
  shopItems?: ShopItem[];
  lastShopContextId?: string;
  skillBookData?: CharacterSkillProfile[];
  activeEventCards?: ActiveEventCard[];
  stickers?: { id: string, url: string }[];
  timelineData?: TimelineNode[];
  relationData?: TimelineNode[];
  pet?: PetState | null;
  messengerConfig?: {
    enabled: boolean;
    tone: string;
    typingSpeed: number;
    allowEmoji: boolean;
    nudgeEnabled: boolean;
    maxBurst: number;
  };
  userAura?: UserAura;
  soulContract?: SoulContract;
  merchantState?: {
      lastRefresh: number;
      stock: ShopItem[];
      refreshCount: number;
  };
  customThemeColors?: { bgMain: string, bgPanel: string, accent: string };
  calendar?: {
      currentDate: string;
      notes: CalendarNote[];
  };
  // API VAULT
  apiSlots: ApiSlot[];
  activeApiKey?: string;
  
  // VECTOR MEMORY LITE
  vectorDb: VectorMemoryItem[];

  // VOICE OVER
  voiceConfig?: VoiceSettings;

  // PROMPT CUSTOMIZATION
  globalWorldPrompt?: string;
  characterCustomPrompts?: Record<number, CharacterPromptConfig>; // Keyed by char index
  styleReference?: string; // <--- ADDED: Văn Mẫu (Few-Shot Style)

  // CHRONOS SYSTEM
  simulationTimestamp?: number; // Current game time

  // LOCATION TRACKER
  currentLocation?: string;
  locationDescription?: string;
  currentTime?: string;
  currentWeather?: string;
  locationScannedTimestamp?: number;
}

export type CharacterRole = 'MAIN' | 'SIDE' | 'BACKGROUND';

export interface ConfigPreset {
  id: string;
  name: string;
  description: string;
  config: Partial<AppConfig>;
  color: string;
}

export interface SaveSlotData {
    id: string;
    timestamp: number;
    label: string;
    summary: string;
    data: {
        config: Partial<AppConfig>;
        messages: ChatMessage[];
    };
}
