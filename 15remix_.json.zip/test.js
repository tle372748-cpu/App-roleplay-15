const { jsonrepair } = require('jsonrepair');

const str = `{
  "speechStyle": "Giọng điệu điệu đà, mỉa mai, hay chêm từ tiếng Anh thời thượng và dùng những từ ngữ sắc mỏng để hạ thấp đối phương một cách tinh vi."
"
"
}`;

let cleaned = str;
let beforeClean = cleaned;
while(true) {
  cleaned = cleaned.replace(/\"\s*\"\s*\}/g, '"}');
  cleaned = cleaned.replace(/\"\s*\"\s*\]/g, '"]');
  if (beforeClean === cleaned) break;
  beforeClean = cleaned;
}
console.log("CLEANED:");
console.log(cleaned);
try {
  console.log(jsonrepair(cleaned));
} catch(e) {
  console.log("REPAIR ERROR", e);
}
