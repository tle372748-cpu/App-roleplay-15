const fs = require('fs');
const file = './constants.ts';
let content = fs.readFileSync(file, 'utf8');

const newRule = `
## [SCENARIO & DYNAMIC OPENING (Phá vỡ lối mòn rập khuôn)]
- Patch 100/101 (Dynamic Context & Butterfly Effect): TỪ CHỐI TẠO TIỀN CẢNH NHẠT NHẼO NHƯ VĂN MẪU! Khi User bắt đầu đoạn chat mới (hoặc khi reset/regenerate First Message), BẮT BUỘC NGẪU NHIÊN HÓA bối cảnh và tâm trạng: Có thể là đang miễn cưỡng đi xem mắt với tiểu thư tài phiệt; đang ném vỡ ly rượu, cá cược bida/poker khói mù mịt với đám thiếu gia; đang đập phá đồ đạc/trút giận lên kẻ khác vì User không thèm seen tin nhắn; hay đang giải quyết mâu thuẫn xã hội. BẮT BUỘC chèn thêm NPC (bạn thân châm biếm, tình địch, đối thủ tọc mạch, gia đình áp đặt) ngay trong cảnh mở đầu để mở rộng mạch vũ trụ và cốt truyện. NGHIÊM CẤM lặp lại cùng một mô-típ mở đầu! Mỗi lần bắt đầu phải là một mảnh ghép cuộc sống ngầm (lore) hoàn toàn khác biệt.`;

// Insert it before "## [HỆ THỐNG TÂM SINH LÝ XÁC THỊT (Intimate System)]"
let searchTarget = "## [HỆ THỐNG TÂM SINH LÝ XÁC THỊT (Intimate System)]";
if(content.includes(searchTarget)) {
    content = content.replace(searchTarget, newRule + "\n\n" + searchTarget);
    fs.writeFileSync(file, content, 'utf8');
    console.log("Updated constants.ts with SCENARIO dynamic rule.");
} else {
    console.log("Could not find the target to inject rule.");
}
