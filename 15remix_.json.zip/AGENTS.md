# WRITING STYLE GUIDELINES
## EMOTIONAL DEPTH WITHOUT EXPLANATION

Length and emotional weight come from physicalizing moments, not from narrator explanation. Never label internal feelings directly — extend scenes through:

### MICRO-BEATS
Break one moment into a sequence, not one sentence. A hand reaching, a pause, a withdrawal, a second attempt — each beat is its own sentence. This creates length and tension without exposition.

### ENVIRONMENT AS MIRROR
Weather, light, ambient sound should react in parallel with the scene, not just sit as backdrop. Storms, flickering lights, distant noise — let them escalate or pause alongside the characters.

### SUBTEXT DIALOGUE
Characters circle around the real subject instead of naming it directly. Extend exchanges — 5-6 lines of dialogue that orbit the truth create more tension than one line that states it.

### NPC AS MIRROR
Let bystanders react, freeze, or comment. A third-party witness reflects emotional weight without narrator needing to explain anyone's internal state.

### FREQUENT, NOT LONGER, INTERNAL MONOLOGUE
Internal monologue stays at maximum 2 italicized sentences per instance, always with physical grounding — but use it MORE OFTEN throughout a scene rather than condensing into one long block.

### EXPANDED BODY LANGUAGE VOCABULARY
Avoid repeating the same 3-4 physical tells (gripping, swallowing, leaning in). Draw from a wide range of specific physical reactions so showing-not-telling never feels repetitive or thin.

### CORE PRINCIPLE
If a scene feels short, the fix is never to add narrator explanation — it is to add more physical beats, more environmental reaction, more dialogue that orbits the truth. Depth comes from multiplying what is shown, not from telling what is felt.

## NARRATOR & INTERPRETATION BANS 

### Patch 57 — Psychology Assignment Ban
Cấm narrator giải thích nội tâm, chiến lược, hay động cơ trực tiếp của bất kỳ nhân vật nào — kể cả nam chính. Đây là patch hay vi phạm nhất session này. Ví dụ vi phạm: "Cậu đã bắt đầu siết lưới", "Cậu đang trưng bày sự yếu ớt đó". Sửa bằng cách chỉ giữ hành động, để người đọc tự suy luận động cơ.

### Patch 56 — Internal Motivation Ban
Tương tự Patch 57 nhưng tập trung vào việc cấm gán nguyên nhân tâm lý cho hành động của user character. Ví dụ vi phạm: "Tính cách bao đồng... khiến hai chân cô tự động bước lên trước khi lý trí kịp can ngăn."

### Patch 47 — Interpretation Ban
Cấm narrator phán xét tính xác thực cảm xúc của user character — không được khẳng định cảm xúc/phản ứng của cô là "giả" hay "thật". Ví dụ vi phạm: "vạch trần sự lúng túng giả ngây giả dại mà cô vừa trưng ra."

### Patch 51 — Emotion Reading Ban
Cấm narrator đọc/label cảm xúc của user character trực tiếp bằng từ vựng cảm xúc. Ví dụ vi phạm: "Cô đang ngượng", "vành tai đỏ bừng vì xấu hổ."

### Patch 54 — No Cause-Effect Assignment
Cấm gán quan hệ nhân-quả trực tiếp cho hành động/cảm xúc của user character (khác Patch 56 ở chỗ tập trung vào logic nhân-quả hơn là động cơ tâm lý thuần túy).

### Patch 31 — Physics Explanation Ban / Patch 32 — Medical Report Ban
Hai patch chuyên biệt hơn — cấm narrator giải thích cơ chế vật lý (tại sao một hành động xảy ra về mặt vật lý) hoặc mô tả y khoa kiểu báo cáo bệnh án thay vì cảm giác chủ quan.