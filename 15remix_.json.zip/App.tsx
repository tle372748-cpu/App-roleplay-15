import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
} from "react";
import {
  AppConfig,
  ChatMessage,
  Kernel,
  AIModel,
  CoreMode,
  Relationship,
  WorldSetting,
  CultureOS,
  NarrativeLength,
  Perspective,
  Mindset,
  NarrativeTone,
  Difficulty,
  DisplayMode,
  Physics,
  Tempo,
  Entropy,
  SensoryLOD,
  Psyche,
  Theme,
  InventoryItem,
  CardData,
} from "./types";
import { THEMES, NM_PLUS_1_6_PROMPT, DEFAULT_CONFIG } from "./constants";
import ConfigPanel from "./components/ConfigPanel";
import ChatInterface from "./components/ChatInterface";
import SplashScreen from "./components/SplashScreen";
import MusicPlayerWidget from "./components/MusicPlayerWidget";
import LiveCommentsWidget from "./components/LiveCommentsWidget";
import VectorMemoryModal from "./components/VectorMemoryModal";
import ThemeOverlayManager from "./components/ThemeOverlayManager";
import {
  generateAIResponse,
  autoExtractVectorMemory,
  cleanJson,
  generateOutfitDescription,
  generateAutokiuc,
  generateLocationAndTime,
  enrichCardWithAI,
  getEffectiveApiKey,
} from "./services/aiService";
import { parseBalance, formatVND } from "./utils/mockDataGenerator";
import { parseTextCard } from "./utils/cardParser";
import { loadMessagesFromIDB, loadConfigFromIDB } from "./utils/storage";
import { CUSTOM_USER_DIRECTIVES } from "./utils/custom_directives";
import { useAutoSave } from "./hooks/useAutoSave";
import {
  Save,
  CheckCircle,
  AlertCircle,
  Loader2,
  MapPin,
  X,
} from "lucide-react";

const getStaticConfig = (c: AppConfig) => {
  const {
    gameStats,
    inventory,
    garden,
    musicPlayer,
    liveState,
    toyState,
    activeEventCards,
    historyCards,
    lastShopContextId,
    shopItems,
    skillBookData,
    stickers,
    timelineData,
    relationData,
    vectorDb,
    ...staticSettings
  } = c;
  return staticSettings;
};

// ... (Keep existing getAiDrawingPath) ...
const getAiDrawingPath = (shapeKeyword: string): string => {
  const k = shapeKeyword.toUpperCase().trim();
  if (k.includes("HEART"))
    return "M 50,30 C 20,0 0,30 50,90 C 100,30 80,0 50,30";
  if (k.includes("CIRCLE"))
    return "M 50, 10 a 40,40 0 1,0 0,80 a 40,40 0 1,0 0,-80";
  if (k.includes("CROSS") || k.includes("X"))
    return "M 20,20 L 80,80 M 80,20 L 20,80";
  if (k.includes("STAR"))
    return "M 50,5 L 63,35 L 95,35 L 68,55 L 79,85 L 50,65 L 21,85 L 32,55 L 5,35 L 37,35 Z";
  if (k.includes("CHECK")) return "M 20,50 L 40,70 L 80,30";
  if (k.includes("SMILE"))
    return "M 30,35 h 10 M 60,35 h 10 M 30,65 Q 50,85 70,65";
  return "M 10,50 Q 50,10 90,50";
};

const RANDOM_MOTIFS = [
  // Đời thường, Bẩn thỉu & Sinh Lý
  "Đang đi siêu thị mua nhu yếu phẩm thì bị kẹt trong phòng kho mất điện, không gian tối om, hơi nóng hầm hập phả vào",
  "Đang phân loại đống đồ lót chưa giặt trong phòng tắm, dọn dẹp vệ sinh căn hộ sau một chuỗi ngày oi bức hanh khô, mùi thuốc tẩy nồng nặc",
  "Đột ngột lên cơn đau bao tử/đau bụng dữ dội, mặt mày tái mét nằm cuộn tròn trên sàn nhà lạnh lẽo giữa trưa nắng 40 độ, loay hoay tìm điện thoại gọi cấp cứu",
  "Dọn dẹp lại phòng làm việc và tình cờ cạy được một chiếc hộp khóa kín chứa kỷ vật cũ nhạy cảm, sương mù ngoài cửa sổ đặc quánh",
  "Đứng gội đầu dưới vòi sen thì đột nhiên cúp nước, bọt xà phòng chảy đầy mặt xót hết cả mắt, vừa bực vừa lạnh run người",
  "Đang ốm thập tử nhất sinh, hắt hơi liên tục, hai mắt sưng húp cặm cụi tự nấu nồi cháo hành nóng giữa đêm tuyết rơi dày đặc ngoài kia",
  "Vừa nôn mửa thê thảm trong nhà vệ sinh vì uống quá say đêm qua, đầu đau như búa bổ, nắng gắt ban trưa rọi thẳng vào mắt",
  "Ăn món gì đó ngộ độc, ôm bụng chạy ra chạy vào nhà vệ sinh công cộng dơ bẩn trong tình trạng thê thảm, đổ mồ hôi hột",
  "Mang những túi rác bốc mùi ném vào xe rác giữa đêm, vô tình bắt gặp một đám du côn đang tụ tập hút hít ở con hẻm hẹp",

  // Công việc, Tài chính & Áp lực xã hội
  "Vừa bị sếp mắng mỏ thậm tệ trước mặt đồng nghiệp, đứng rít thuốc lá ngoài ban công cắn chặt môi kìm nén sự uất ức",
  "Ngồi làm việc trễ ở văn phòng tắt đèn tối om, mệt mỏi uống cốc cà phê thứ năm, màn hình xanh lè hắt lên gương mặt hốc hác",
  "Đang cãi lộn gay gắt qua điện thoại với gia đình/chủ nợ về chuyện tiền bạc, vung tay đá bay cái ghế trong phòng",
  "Xe bị hỏng lốp giữa cao tốc vắng, đang loay hoay lấy kích xe tự sửa dưới cái nắng vỡ đầu 40 độ, mồ hôi nhễ nhại",
  "Trong một buổi tiệc xã giao giả tạo ở khách sạn 5 sao, cầm ly champagne cười gượng gạo nhưng chân đang bị xước giày trầy cả gót",
  "Thẻ tín dụng bị từ chối khi đang thanh toán bữa ăn đắt đỏ với đối tác, nhục nhã loay hoay cầu cứu tại quầy thu ngân",
  "Mệt mỏi tan ca vào lúc 3 giờ sáng, đi ngang qua một khu chợ đêm ồn ào và vô tình bị tạt nước bẩn vào gấu quần",

  // Xung đột Tình cảm, Toxic & Đổ vỡ
  "Phát hiện ra một nụ hôn lem son lạ trên cổ đối phương/bạn thân, đứng sững sờ giữa quán cà phê đông đúc, ly nước trên tay run lẩy bẩy",
  "Đang dọn đồ đạc để dọn ra khỏi nhà sau một trận cãi vã kinh thiên động địa, tiếng thuỷ tinh vỡ vẫn còn lạo xạo dưới gót giày",
  "Ngồi khóc nấc lên nghẹn ngào trong xe ô tô dưới trời mưa xối xả sau khi bị từ chối tình cảm phũ phàng, mascara nhòe nhoẹt",
  "Tình cờ bắt gặp người yêu cũ nắm tay người mới đi lướt qua, nhịp tim đình trệ, cả cơ thể cứng đờ giữa trung tâm thương mại lộng lẫy",
  "Phát điên đập nát một chiếc điện thoại vì cơn ghen tuông mất kiểm soát, lồng ngực phập phồng, máu rỉ ra từ mu bàn tay xước xát",
  "Bị dồn vào chân tường trong một con hẻm ép buộc phải đưa ra sự lựa chọn tàn nhẫn giữa hai mối quan hệ đan chéo",

  // Lãng mạn, Soft & Chữa lành
  "Đang cuộn tròn trong chăn ấm giữa một chiều mùa đông lạnh giá, mùi chocolate nóng ngập tràn không khí, lười biếng không muốn dậy",
  "Ngồi lặng lẽ trên bậc thềm ôm đàn guitar gảy vài gạch nhịp vu vơ ngoài ban công rợp hoa giấy dưới nắng chiều tà",
  "Xắn tay áo cặm cụi nướng một chiếc bánh ngọt bơ thơm lừng, vụn bột mì vương vãi dính cả lên chóp mũi",
  "Cùng che chung một chiếc ô trong nhịp mưa rào mờ ảo, bả vai kề sát nhau, hơi ấm truyền qua lớp áo mỏng manh",
  "Đang cẩn thận tỉa tót bụi cây/chăm sóc thú cưng tại sân sau, quần yếm dính lấm tấm bùn đất và nụ cười rạng rỡ thoải mái",

  // Hành động, Bất an & Dị thường
  "Gương mặt nhợt nhạt, tay đầy dầu nhớt loay hoay sửa một động cơ máy cũ trong gara tối mờ, đài radio phát ra những tiếng rè rè nhiễu sóng rợn gai ốc",
  "Trú mưa lạnh buốt dưới mái hiên một trạm xăng rùng rợn bỏ hoang, đèn neon nhấp nháy, có tiếng bước chân nặng nề vang lên từ phía sau bãi rác",
  "Lạc trong một khu rừng/tòa nhà sương mù mù mịt, quần áo bị gai/kẽ hở cào rách tơi tả, cẳng chân đầm đìa bùn đất và vài vết xước rỉ máu",
  "Đang lau súng hoặc mài một con dao sắc lẹm trong phòng khách tối, bóng đổ dài trên tường hệt như một ác quỷ đói khát",
  "Ngồi im lìm trên ghế sofa trong bóng đêm, quần áo xộc xệch đẫm mồ hôi, trừng mắt nhìn chằm chằm vào bản tin phá án trên TV",
  "Nhận được một bưu kiện kỳ dị không có tên người gửi, bên trong là một lọn tóc và những bức ảnh rình rập mình bị chụp trộm",
  "Phát hiện ra một lỗ vân tay đẫm máu lạ lùng trên bức tường phòng khách khi vừa mới thức dậy",
  "Mở cốp xe ô tô trong một khu đỗ xe ngầm thì bất ngờ ngửi thấy một mùi hôi thối kinh khủng xộc thẳng vào mũi",

  // Extravagant, Extreme Drama & High Stakes
  "Đang bị kẹt giữa một vụ xả súng/cướp ngân hàng căng thẳng tột độ, mồ hôi đầm đìa, tay siết chặt vũ khí tự chế tìm cách sinh tồn",
  "Phá nát một buổi dạ hội thượng lưu bằng việc xông thẳng vào với bộ dạng bê bết máu và bùn đất, ánh đèn chùm lấp lánh tương phản với sự hoang dại",
  "Đang đứng trên bờ vực sân thượng tòa nhà 80 tầng giữa tâm bão giật cấp 12, tóc tai điên cuồng bay trong gió, bên dưới là đèn xe cảnh sát chớp nháy",
  "Bị quay trộm và phát trực tiếp trên mạng xã hội trong lúc đang có hành vi phạm tội/nhạy cảm/mờ ám, điện thoại báo tin nhắn reo liên tục không ngừng",
  "Lái một chiếc siêu xe ăn cắp hết tốc lực đâm xuyên qua cửa kính một trung tâm thương mại xa hoa, còi báo động réo điếc tai, xác kính rơi lả tả",
  "Chính thức bị bắt quả tang/vạch trần bộ mặt giả tạo ngay giữa một phiên tòa hoặc cuộc họp cổ đông lớn, hàng chục máy ảnh chớp nháy liên hồi",
  "Nhận được cuộc gọi tống tiền khẩn cấp yêu cầu phải đem một chiếc vali tới bến cảng hoang vắng trong vòng 30 phút, tiếng động cơ cano gầm rú từ xa",
  "Tỉnh giấc trên một chiếc thuyền cứu sinh lênh đênh giữa biển đêm lạnh lẽo, bên cạnh là một xác chết và chiếc mỏ neo đỏ lòm",
  "Vừa nổ mìn phá hủy toàn bộ tầng hầm của kẻ thù, lảo đảo đi dưới cơn mưa rào giữa ánh sáng rực rỡ của ngọn lửa cháy bùng",

  // Lãng mạn biến thái, Hiểu lầm & Kích thích tột độ
  "Đang bị nhốt chung với người mà mình ghét nhất trong một không gian chật hẹp (tủ đồ/nhà kho) vô cùng nóng bức",
  "Bị làm đổ hẳn ly rượu vang đỏ lên chiếc áo sơ mi trắng mỏng tang, để lộ rõ đường nét cơ thể giữa chốn đông người",
  "Vừa bước ra từ phòng tắm ướt sũng, chỉ quấn một chiếc khăn tắm hờ hững sắp tuột thì có sự kiện bắt buộc phải vội vã ra mở cửa",
  "Đang lén lút nghe trộm một cuộc trò chuyện cực kỳ nhạy cảm qua khe cửa hẹp, tim đập thình thịch vã mồ hôi",
  "Cố tình ăn mặc vô cùng hở hang, khiêu khích đi ngang qua khu vực nguy hiểm để thử sức chịu đựng của đối phương",
  "Đang xem một video nhạy cảm trong phòng thì vô tình phát nhầm âm thanh Max Volume qua loa điện thoại ngay giữa phòng khách",
  "Giả vờ ngủ say để xem người kia sẽ làm gì với cơ thể mình khi không đề phòng, cơ bắp căng cứng nhịn thở",
  "Bị ép góc vào tường trong một con hẻm tối, đối phương áp sát tản ra sát khí và mùi rượu nồng nặc đe dọa",
  "Đang vùng vẫy chống cự kịch liệt khi bị đè nghiến xuống giường hoặc sofa, quần áo xộc xệch sắp đứt cúc, bầu không khí sực mùi nguy hiểm và cưỡng ép",
  "Bị xích lỏng lẻo hoặc vướng víu vào vật gì đó không thể di chuyển, đối phương từ từ tiến lại với ánh mắt soi mói dơ bẩn",
  "Bị bịt mắt và trói tay lỏng lẻo trong một trò chơi cá cược thác loạn, âm thanh xung quanh ồn ào nhưng lại vô cùng kích thích",
  "Bị chuốc thuốc kích dục liều nhẹ khiến cơ thể nóng rực, lảo đảo dựa hẳn vào người kẻ thù để xin sự giúp đỡ trong nhục nhã",
  "Xé toạc một tờ giấy ly hôn ném thẳng vào mặt kẻ bạc tình trước hàng chục ống kính truyền thông đang soi mói",

  // Hài hước, Ngớ ngẩn & Oái oăm
  "Mặc chiếc bộ đồ ngủ hình thú ngớ ngẩn nhất, đầu bù tóc rối ra mở cửa nhận đồ ăn mạng thì trượt chân ngã uỵch một cái đập mặt xuống thềm",
  "Vừa hát opera cực kỳ lố bịch trong lúc tắm vừa xoa xà phòng đầy mình thì nhận ra cửa sổ nãy giờ vẫn mở toang",
  "Đang tập nhảy theo một điệu TikTok cực kỳ lố lăng trước gương thì bất ngờ thấy có người đứng hình nhìn mình ngoài cửa",
  "Lén ăn vụng miếng bánh kem cuối cùng trong tủ lạnh, dính đầy kem lên mép và mũi, đúng lúc đèn phòng bếp bật sáng",
  "Tham gia một trò chơi uống rượu giải sầu rồi say bét nhè, cởi phăng áo khoác đu mình lên cái cột đèn ngoài đường hát hống vang dội",
  "Ra đường lỡ mặc nhầm một chiếc tất đỏ một chiếc tất xanh, bị đám trẻ con cười phá lên dọc đường, xấu hổ lấy túi che mặt",
  "Đi siêu thị mua loại 'đồ dùng nhạy cảm' thì làm rơi lăn lóc ngay trước mặt crush/kẻ thù",
  "Mở camera xin học/tự giới thiệu nhưng lỡ xài filter hình chú hề không tắt đi được, khóc ròng trong tuyệt vọng",

  // Cảm động, Buồn bã, Dễ thương
  "Đội mưa ướt sũng nhếch nhác ôm một hộp bánh kem nhỏ đã bị bẹp nát đến tạ lỗi/chúc mừng sinh nhật, đứng thẫn thờ ngoài hiên cửa",
  "Khóc không thành tiếng trong phòng bếp tối om vì áp lực vỡ lở, cố nhét thức ăn nguội lạnh vào miệng để không bật ra tiếng nấc",
  "Thả thú cưng đi dạo ở công viên thì nó đột ngột giật dây chạy tót đi mất, hai mắt đỏ hoe chạy quanh tìm kiếm trong tuyệt vọng",
  "Người ướt sũng, mũi đỏ ửng vì lạnh, đang co ro ôm chặt một chú mèo hoang gầy gò nhặt được dưới gầm xe hơi",
  "Ngủ gục trên bàn làm việc trong tư thế cuộn tròn dễ thương, bút bi còn kẹp trên tay và trên má dính vết mực đen tèm lem",
  "Dọn dẹp lại những thùng các tông cũ kỷ niệm, ôm khư khư món đồ chơi nhồi bông đã rách bươm và khóc thầm rấm rứt",
  "Mua nhầm cốc cà phê siêu đắng không uống được, đang ngồi mếu máo tại ghế đá vì tiếc tiền và thất vọng",
  "Mang thai/bệnh nặng đang nằm bẹp trên giường, cố vươn tay ra tự rót cốc nước nhưng làm vỡ toang chiếc cốc kính thủy tinh, mảnh vỡ bắn tung tóe",
  "Bị ngã trầy trụa đầu gối rớm máu khi cố gắng bắt lấy chùm bóng bay giúp một đứa bé, ngồi bệt xoa xoa vết thương với vẻ mặt tủi thân",
  "Chứng kiến một cảnh sinh ly tử biệt trên phim và khóc nức nở, nước mắt tèm lem ướt đẫm gối",
  "Phát hiện ra món đồ kỷ niệm trân quý nhất vừa bị vô tình cắn nát/làm gãy, ngồi thẫn thờ nhìn những mảnh vỡ rơi lả tả",
  "Đang đuổi theo một chú bướm nhỏ giữa công viên rồi vô tình vấp ngã uỵch một cái rất ngốc nghếch",
  "Đau đớn cuộn tròn người lại vì một vết thương cũ tái phát/cơn bạo bệnh, môi cắn chặt rướm máu cố không bật thành tiếng rên",
  "Ôm chặt bộ quần áo của người đã khuất/kẻ vắng mặt, rúc mặt vào đó hít hà mùi hương và khóc ướt đẫm bả vai áo",

  // Thượng lưu, Lộng lẫy & Xa hoa
  "Ngồi một mình trong khoang hạng nhất máy bay riêng, xoay xoay ly rượu vang đắt tiền, nhìn qua cửa sổ ngắm vệt mây đêm",
  "Sải bước trên một dãy hành lang dinh thự lộng lẫy, tiếng gót giày gõ vang lạnh lùng trên sàn đá cẩm thạch trắng mút",
  "Mặc chiếc váy/bộ vest thiết kế riêng lấp lánh nạm kim cương, đang kiêu ngạo từ chối lời mời nhảy của một tài phiệt trong đêm dạ hội",
  "Trong bồn tắm phủ đầy cánh hoa hồng và tinh dầu thơm ngát tại một resort 6 sao ngập tràn ánh nến, mắt nhắm hờ lười biếng thư giãn",

  // Y khoa & Viện bảo tàng
  "Nằm trên giường bệnh với đủ thứ máy thở và dây nhợ truyền dịch, tiếng monitor kêu bíp bíp đều đều tĩnh mịch",
  "Mặc chiếc áo blouse trắng lấm tấm vài giọt máu vô danh, đứng trầm ngâm trước bản chụp X-quang lạnh lẽo trong một đêm trực",

  // Bí ẩn & Ma mị
  "Đứng ngẩn ngơ trước một bức tranh cổ quái trong bảo tàng vắng lặng lúc nửa đêm, môi nhếch lên một nụ cười ma mị khó hiểu",
  "Đẩy cửa bước vào một căn phòng ngập tràn cỏ dại mọc rêu phong, ánh trăng mờ ảo hắt vào làm nổi bật bóng hình như một hồn ma",
  "Cầm một cây nến cạy mở cánh cửa hầm ngầm, tay mân mê chuỗi hạt ngọc kỳ lạ phản chiếu thứ ánh sáng lạnh lẽo",
  "Đi dạo một mình ở nghĩa trang/cánh rừng u tối, tiếng quạ kêu thê lương nhưng ánh mắt lại điềm nhiên đến rợn người",

  // Tình cảm Đời Thường & Chăm sóc
  "Đang mải mê lúi húi nấu một bữa ăn cực kỳ hoành tráng trong bếp thì phát hiện ra đã nêm nhầm lọ muối thành lọ đường",
  "Ngồi thẫn thờ gọt trái cây trên giường nhưng vì dao cùn nên cứ loay hoay lóng ngóng, đến lúc đứt tay thì không dám kêu ngoan ngoãn ngậm ngón tay",
  "Hút bụi dưới gầm giường và vô tình tìm thấy thứ bí mật mà người kia (Vợ/Chồng/Người yêu) đang lén lút giấu giếm lâu nay",

  // Bất Lực & Sự Cố Kỳ Quái (Thêm mới)
  "Vừa tỉnh dậy sau một giấc mơ kinh hoàng, bật dậy thở dốc, hai tay bám chặt rìa giường, nhận ra xung quanh mình không phải là căn phòng quen thuộc",
  "Trèo qua một bức tường rào phủ đầy dây thường xuân để trốn chạy một ai đó, bất ngờ tuột tay ngã xuống bãi cỏ ướt sũng bên kia",
  "Cầm một cây ô đen đứng trơ trọi giữa ngã tư lúc nửa đêm mưa tầm tã, giày ướt đẫm nước, xung quanh thưa thớt bóng người",
  "Lúc vừa định ăn lén bát mì gói đêm khuya thì bất chợt đèn điện phụt tắt kèm theo tiếng rầm cực lớn từ tầng trên",
  "Đang cố gắng gỡ rối một mớ dây chuyền bị đứt, vẻ mặt cực kỳ kiên nhẫn nhưng khóe mắt lại bắt đầu ửng đỏ vì tức tưởi",
  "Mặc chiếc áo mưa trong suốt đã rách bươm, kéo theo một vali sứt bánh xe lết bộ rệu rã trên vỉa hè đầy vũng nước",
  "Bị lạc trong siêu thị Ikea khổng lồ lúc 10h đêm, xung quanh không còn nhân viên, đang loay hoay ngồi nghỉ trên một chiếc giường trưng bày đầy tuyệt vọng",
  "Mặc chiếc áo choàng tắm lụa mỏng, tay cầm điếu thuốc lá cháy dở tựa lưng vào lan can ban công tầng 20, lơ đễnh nhìn luồng xe bên dưới",
  "Vừa bước chân vào thang máy thì máy kẹt lại, đèn chớp tắt như phim kinh dị, đang đập cửa thình thịch gọi người cứu viện",
  "Lái chiếc xe mô tô phóng như bay trên bờ biển hoàng hôn, xé gió gầm rú, nhưng lại bất chợt khựng lại rồi thả tay ra gào thét vì một nỗi ức chế",
  "Đang ngồi hì hục sửa điểm bài thi hoặc phá khóa một tập tài liệu tuyệt mật trong góc khuất phòng thư viện, mồ hôi đầm đìa",
  "Mặt nhọ nhem đầy dầu mỡ, mặc tạp dề bẩn thỉu đang chui gầm chạn để bắt một con chuột/côn trùng khổng lồ trong bộ dạng sợ tái mét",
  "Dắt chiếc xe máy xịt lốp đi bộ 5 cây số giữa trời nắng, mồ hôi ròng ròng, miệng lẩm bẩm chửi rủa số phận tồi tệ",
  "Vừa cãi nhau với mẹ xong, đóng ầm cửa phòng lại, ngồi sụp xuống sàn tự ôm lấy bản thân và bắt đầu khóc nức nở không tiếng động",
  "Bị bắt quả tang đang ngồi gặm giày của một chú chó/hoặc giằng co đồ ăn với một con vật nuôi một cách ngớ ngẩn nhất",
];

function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [hasLaunched, setHasLaunched] = useState(false);
  const [isDataLoaded, setIsDataLoaded] = useState(false);
  const [saveStatus, setSaveStatus] = useState<
    "IDLE" | "SAVING" | "SAVED" | "ERROR"
  >("IDLE");
  const [syncStatus, setSyncStatus] = useState(false);

  // MODAL STATES
  const [showVectorMemory, setShowVectorMemory] = useState(false);
  const [showThemeOverlay, setShowThemeOverlay] = useState(false);

  const [config, setConfig] = useState<AppConfig>(DEFAULT_CONFIG);
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  const [isTyping, setIsTyping] = useState(false);
  const [regeneratingId, setRegeneratingId] = useState<string | null>(null);
  const [lastStaticConfig, setLastStaticConfig] = useState<string>("");

  const [messengerQueue, setMessengerQueue] = useState<string[]>([]);
  const messengerTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastUserMsgTime = useRef<number>(0);
  const nudgeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // --- ASYNC DATA LOADING ---
  useEffect(() => {
    const initData = async () => {
      try {
        const savedConfig = await loadConfigFromIDB();
        let finalConfig = { ...DEFAULT_CONFIG };
        if (savedConfig) {
          finalConfig = {
            ...DEFAULT_CONFIG,
            ...savedConfig,
            activeModules:
              savedConfig.activeModules || DEFAULT_CONFIG.activeModules || [],
            betaFeatures:
              savedConfig.betaFeatures || DEFAULT_CONFIG.betaFeatures || [],
            agencyModes:
              savedConfig.agencyModes || DEFAULT_CONFIG.agencyModes || [],
            controlFlags:
              savedConfig.controlFlags || DEFAULT_CONFIG.controlFlags || [],
            biases: { ...DEFAULT_CONFIG.biases, ...(savedConfig.biases || {}) },
            gameStats: {
              ...DEFAULT_CONFIG.gameStats,
              ...(savedConfig.gameStats || {}),
            },
            garden: { ...DEFAULT_CONFIG.garden, ...(savedConfig.garden || {}) },
            merchantState: {
              ...DEFAULT_CONFIG.merchantState,
              ...(savedConfig.merchantState || {}),
            },
            musicPlayer: {
              ...DEFAULT_CONFIG.musicPlayer,
              ...(savedConfig.musicPlayer || {}),
            },
            liveState: {
              ...DEFAULT_CONFIG.liveState,
              ...(savedConfig.liveState || {}),
            },
            toyState: {
              ...DEFAULT_CONFIG.toyState,
              ...(savedConfig.toyState || {}),
            },
            messengerConfig: {
              ...DEFAULT_CONFIG.messengerConfig,
              ...(savedConfig.messengerConfig || {}),
            },
            userCard: savedConfig.userCard || DEFAULT_CONFIG.userCard,
            characterCards: savedConfig.characterCards || [],
            vectorDb: savedConfig.vectorDb || [],
          };
        } else {
          const legacyConfig = localStorage.getItem("NMGX_CONFIG");
          if (legacyConfig) {
            const parsed = JSON.parse(legacyConfig);
            finalConfig = { ...DEFAULT_CONFIG, ...parsed };
          }
        }

        setConfig(finalConfig);

        const savedMessages = await loadMessagesFromIDB();
        if (savedMessages && Array.isArray(savedMessages)) {
          const migratedMessages = savedMessages.map((m: any) => ({
            ...m,
            versions: m.versions || [m.content],
            currentVersionIndex:
              m.currentVersionIndex !== undefined ? m.currentVersionIndex : 0,
          }));
          setMessages(migratedMessages);
        } else {
          const legacyMsgs = localStorage.getItem("NMGX_MESSAGES");
          if (legacyMsgs) {
            const parsed = JSON.parse(legacyMsgs);
            const msgsArray = Array.isArray(parsed) ? parsed : [];
            const migratedMessages = msgsArray.map((m: any) => ({
              ...m,
              versions: m.versions || [m.content],
              currentVersionIndex:
                m.currentVersionIndex !== undefined ? m.currentVersionIndex : 0,
            }));
            setMessages(migratedMessages);
          }
        }
      } catch (e) {
        console.error("Data Load Error:", e);
      } finally {
        setIsDataLoaded(true);
      }
    };

    initData();
  }, []);

  useAutoSave(config, messages, isDataLoaded, setSaveStatus);

  // --- NEW AUTOKIUC BACKGROUND GENERATION LOGIC ---
  const [isGeneratingAutokiuc, setIsGeneratingAutokiuc] = useState(false);

  // Dừng tính năng tự động Auto-Kiuc theo yêu cầu để dùng trí nhớ tự nhiên (Memory Context từ LLM raw)
  useEffect(() => {
    // We keep this hook empty now to disable automatic triggers.
  }, [
    messages,
    config.autokiucLastTimestamp,
    isDataLoaded,
    isGeneratingAutokiuc,
    config,
  ]);

  const invalidateTrackingIfNeeded = useCallback(
    (affectedTimestamp: number) => {
      setConfig((prev) => {
        let updated = { ...prev };
        let changed = false;

        if (
          prev.autokiucLastTimestamp &&
          prev.autokiucLastTimestamp >= affectedTimestamp
        ) {
          updated.autokiucLastTimestamp = 0;
          // Xóa luôn phần tóm tắt để tự gen lại từ đầu.
          updated.autokiuc = "";
          changed = true;
        }

        if (
          prev.locationScannedTimestamp &&
          prev.locationScannedTimestamp >= affectedTimestamp
        ) {
          updated.locationScannedTimestamp = 0;
          changed = true;
        }
        return changed ? updated : prev;
      });
    },
    [],
  );

  const [isScanningLocation, setIsScanningLocation] = useState(false);

  useEffect(() => {
    if (!isDataLoaded) return;
    const chatMsgs = messages.filter(
      (m) => m.role === "user" || m.role === "assistant",
    );
    if (chatMsgs.length === 0) return;

    const lastMsg = chatMsgs[chatMsgs.length - 1];
    if (config.locationScannedTimestamp === lastMsg.timestamp) return; // already scanned
    if (lastMsg.role === "user") {
      setConfig((prev) => ({
        ...prev,
        locationScannedTimestamp: lastMsg.timestamp,
      }));
      return;
    }

    // Prevent rescanning if a sys-chronos already exists for this exact message version
    const hasChronos = messages.some(
      (m) =>
        m.role === "nano_quasar" &&
        m.metadata?.parentId === lastMsg.id &&
        m.metadata?.parentVersionIndex === (lastMsg.currentVersionIndex || 0) &&
        m.content.includes("Time Updated"),
    );
    if (hasChronos) {
      setConfig((prev) => ({
        ...prev,
        locationScannedTimestamp: lastMsg.timestamp,
      }));
      return;
    }

    // Only trigger if invalidated (0) OR if the assistant specifically indicated a scene shift
    const needsScan =
      config.locationScannedTimestamp === 0 ||
      chatMsgs.length % 2 === 0 ||
      (lastMsg.role === "assistant" &&
        lastMsg.versions &&
        lastMsg.versions[lastMsg.currentVersionIndex || 0].includes(
          "<<<SCENE_SHIFT>>>",
        )) ||
      (lastMsg.role === "assistant" &&
        lastMsg.content.includes("<<<SCENE_SHIFT>>>"));

    if (!needsScan) {
      // Mark as checked to avoid re-running this logic on every render
      setConfig((prev) => ({
        ...prev,
        locationScannedTimestamp: lastMsg.timestamp,
      }));
      return;
    }

    if (isScanningLocation) return;

    setIsScanningLocation(true);
    generateLocationAndTime(config, chatMsgs.slice(-15))
      .then((res) => {
        if (res) {
          let changedAnything = false;
          let sysContentParts = [];

          if (res.time && res.time !== config.currentTime) {
            sysContentParts.push(`[SYSTEM]: Time Updated: [${res.time}]`);
            changedAnything = true;
          }
          if (res.locationName && res.locationName !== config.currentLocation) {
            sysContentParts.push(
              `[SYSTEM]: Location Updated: [${res.locationName}]`,
            );
            changedAnything = true;
          }
          if (
            res.locationDescription &&
            res.locationDescription !== config.locationDescription
          ) {
            sysContentParts.push(
              `[SYSTEM]: Environment Detail Updated: [${res.locationDescription}]`,
            );
            changedAnything = true;
          }
          if (res.weather && res.weather !== config.currentWeather) {
            sysContentParts.push(
              `[SYSTEM]: Weather/Lighting Updated: [${res.weather}]`,
            );
            changedAnything = true;
          }

          if (changedAnything && sysContentParts.length > 0) {
            const content = sysContentParts.join("\n");
            setMessages((prevMsgs) => [
              ...prevMsgs,
              {
                id: "sys-chronos-" + Date.now() + Math.random(),
                role: "nano_quasar",
                content: content,
                timestamp: Date.now(),
                style: {
                  fontFamily: "font-mono",
                  fontSize: "text-xs",
                  color: "#8b5cf6",
                },
                versions: [content],
                currentVersionIndex: 0,
                metadata: {
                  parentId: lastMsg.id,
                  parentVersionIndex: lastMsg.currentVersionIndex || 0,
                },
              },
            ]);
          }

          setConfig((prev) => {
            return {
              ...prev,
              currentLocation: res.locationName || prev.currentLocation,
              locationDescription:
                res.locationDescription || prev.locationDescription,
              currentTime: res.time || prev.currentTime,
              currentWeather: res.weather || prev.currentWeather,
              locationScannedTimestamp: lastMsg.timestamp,
            };
          });
        } else {
          setConfig((prev) => ({
            ...prev,
            locationScannedTimestamp: lastMsg.timestamp,
          }));
        }
      })
      .catch((e) => {
        console.error("AutoLocation Error", e);
      })
      .finally(() => {
        setIsScanningLocation(false);
      });
  }, [
    messages,
    config.locationScannedTimestamp,
    isDataLoaded,
    isScanningLocation,
    config,
  ]);

  useEffect(() => {
    if (!isDataLoaded) return;

    let hasChanges = false;

    const processCardData = (card: any) => {
      let cardChanged = false;
      const newStatus = { ...(card.status || {}) };
      let newTraits = [...(card.traits || [])];
      let newHiddenMemories = [...(card.hiddenMemories || [])];

      const text = [
        card.name,
        card.description,
        card.personality,
        card.rawContent,
        ...(card.traits || []),
      ]
        .join(" ")
        .toLowerCase();
      const userName = config.userCard?.name || "User";

      // Helper to safely parse numbers
      const parseNum = (val: any, defaultVal: number) => {
        if (val === undefined || val === null || val === "") return defaultVal;
        let parsed =
          typeof val === "string"
            ? parseInt(val.replace(/[^0-9-]/g, ""))
            : Number(val);
        return isNaN(parsed) ? defaultVal : parsed;
      };

      // STRESS
      let defaultStress = 40;
      if (
        text.match(
          /athlete|sports|student|study|exam|homework|university|college|workload/,
        )
      )
        defaultStress = 40;
      if (text.match(/anxious|perfectionist|stress|worry|nervous|panic/))
        defaultStress = 60;
      if (text.match(/relax|carefree|chill|lazy|calm|peaceful/))
        defaultStress = 25;
      let stress =
        newStatus.stress !== undefined
          ? parseNum(newStatus.stress, defaultStress)
          : defaultStress;
      stress = Math.min(100, Math.max(0, stress));
      if (String(newStatus.stress) !== String(stress)) {
        newStatus.stress = String(stress);
        cardChanged = true;
      }

      // AROUSAL
      let defaultArousal = 45;
      if (text.match(/romantic|clingy|love|obsessed|yandere|kiss|hug/))
        defaultArousal = 60;
      if (text.match(/cold|stoic|kuudere|emotionless|distant|asexual/))
        defaultArousal = 25;
      let arousal =
        newStatus.arousal !== undefined
          ? parseNum(newStatus.arousal, defaultArousal)
          : defaultArousal;
      arousal = Math.min(100, Math.max(0, arousal));
      if (String(newStatus.arousal) !== String(arousal)) {
        newStatus.arousal = String(arousal);
        cardChanged = true;
      }

      // HP
      let defaultHp = 75;
      if (text.match(/stable|happy|joy|cheerful|optimistic|peaceful/))
        defaultHp = 85;
      if (text.match(/trauma|abuse|difficult past|tragic|sad|depressed|broken/))
        defaultHp = 55;
      let hp =
        newStatus.hp !== undefined
          ? parseNum(newStatus.hp, defaultHp)
          : defaultHp;
      hp = Math.min(100, Math.max(0, hp));
      if (String(newStatus.hp) !== String(hp)) {
        newStatus.hp = String(hp);
        cardChanged = true;
      }

      // JEALOUSY
      let defaultJealousy = 50;
      if (text.match(/ghen/)) defaultJealousy = 65;
      let jealousy =
        newStatus.jealousy !== undefined
          ? parseNum(newStatus.jealousy, defaultJealousy)
          : defaultJealousy;
      jealousy = Math.min(100, Math.max(0, jealousy));
      if (String(newStatus.jealousy) !== String(jealousy)) {
        newStatus.jealousy = String(jealousy);
        cardChanged = true;
      }

      // SPECTRUM SLIDERS
      const mapSpectrum = (
        key: string,
        defaultVal: number,
        inferLogic: (t: string) => number | null,
      ) => {
        let val =
          newStatus[key] !== undefined ? parseNum(newStatus[key], 0) : null;
        if (val === null) {
          const inferred = inferLogic(text);
          val = inferred !== null ? inferred : defaultVal;
        }

        let mapped = 0;
        if (val <= -60) mapped = -50;
        else if (val <= -20) mapped = -25;
        else if (val <= 19) mapped = 0;
        else if (val <= 59) mapped = 25;
        else mapped = 50;

        if (String(newStatus[key]) !== String(mapped)) {
          newStatus[key] = String(mapped);
          cardChanged = true;
        }
      };

      mapSpectrum("logicEmotion", 0, (t) => {
        if (t.match(/cảm xúc|nhạy cảm/)) return 25;
        if (t.match(/lý trí|lạnh lùng/)) return -25;
        return null;
      });

      mapSpectrum("introExtro", 0, (t) => {
        if (t.match(/năng động|hoạt bát|vui vẻ/)) return 25;
        if (t.match(/hướng nội|lặng lẽ/)) return -25;
        return null;
      });

      mapSpectrum("subDom", 0, (t) => {
        if (t.match(/chiếm hữu|kiểm soát/)) return 25;
        if (t.match(/nghe lời|phục tùng/)) return -25;
        return null;
      });

      // ALIGNMENT
      let mappedAlignment = "True Neutral";
      if (newStatus.alignment) {
        const ALIGNMENTS = [
          "Lawful Good",
          "Neutral Good",
          "Chaotic Good",
          "Lawful Neutral",
          "True Neutral",
          "Chaotic Neutral",
          "Lawful Evil",
          "Neutral Evil",
          "Chaotic Evil",
        ];
        const matched = ALIGNMENTS.find(
          (a) => a.toLowerCase() === newStatus.alignment?.toLowerCase(),
        );
        if (matched) mappedAlignment = matched;
      } else {
        if (text.match(/chaotic good/)) mappedAlignment = "Chaotic Good";
      }
      if (newStatus.alignment !== mappedAlignment) {
        newStatus.alignment = mappedAlignment;
        cardChanged = true;
      }

      // SPEECH STYLE
      let mappedStyle = "Normal";
      if (newStatus.speechStyle) {
        const styleLower = newStatus.speechStyle.toLowerCase();
        if (styleLower.includes("old english")) mappedStyle = "Old English";
        else if (styleLower.includes("casual") || styleLower.includes("slang"))
          mappedStyle = "Casual (Slang)";
        else if (styleLower.includes("formal") || styleLower.includes("polite"))
          mappedStyle = "Formal (Polite)";
        else if (styleLower.includes("poetic")) mappedStyle = "Poetic";
        else if (styleLower.includes("vulgar") || styleLower.includes("rude"))
          mappedStyle = "Vulgar (Rude)";
        else if (styleLower.includes("childish")) mappedStyle = "Childish";
        else if (styleLower.includes("cryptic")) mappedStyle = "Cryptic";
        else if (
          styleLower.includes("stuttering") ||
          styleLower.includes("shy")
        )
          mappedStyle = "Stuttering (Shy)";
        else if (styleLower.includes("broken") || styleLower.includes("robot"))
          mappedStyle = "Broken (Robot)";
      }
      if (newStatus.speechStyle !== mappedStyle) {
        newStatus.speechStyle = mappedStyle;
        cardChanged = true;
      }

      // OBSESSIONS
      const rawObsessions = newStatus.obsessions || card.obsessions;
      if (rawObsessions) {
        const obsArray = Array.isArray(rawObsessions)
          ? rawObsessions
          : String(rawObsessions).split(",");
        const obsList = obsArray
          .map((s: string) => s.trim().replace(/\{\{user\}\}/gi, userName))
          .filter(Boolean);
        const cleanedObs = obsList.join(",");
        if (newStatus.obsessions !== cleanedObs) {
          newStatus.obsessions = cleanedObs;
          cardChanged = true;
        }
      }

      // SECRET
      if (newStatus.secret) {
        const cleanedSecret = newStatus.secret.replace(
          /\{\{user\}\}/gi,
          userName,
        );
        if (newStatus.secret !== cleanedSecret) {
          newStatus.secret = cleanedSecret;
          cardChanged = true;
        }
      }

      // TRAITS
      if (Array.isArray(card.traits)) {
        card.traits.forEach((t: any) => {
          if (typeof t === "string") {
            t.split(",")
              .map((s) => s.trim())
              .filter(Boolean)
              .forEach((st) => {
                if (
                  !newTraits.some((nt) => nt.toLowerCase() === st.toLowerCase())
                ) {
                  newTraits.push(st);
                  cardChanged = true;
                }
              });
          }
        });
      }

      const personalityKeywords = [
        { kw: "tsundere", display: "Tsundere" },
        { kw: "yandere", display: "Yandere" },
        { kw: "golden retriever", display: "Deredere" },
        { kw: "deredere", display: "Deredere" },
        { kw: "cún con", display: "Deredere" },
        { kw: "shy", display: "Shy" },
        { kw: "nhút nhát", display: "Shy" },
        { kw: "dominant", display: "Dominant" },
        { kw: "thống trị", display: "Dominant" },
        { kw: "submissive", display: "Submissive" },
        { kw: "genius", display: "Genius" },
        { kw: "thiên tài", display: "Genius" },
        { kw: "himbo", display: "Himbo" },
      ];

      personalityKeywords.forEach(({ kw, display }) => {
        if (text.includes(kw)) {
          if (
            !newTraits.some((t) => t.toLowerCase() === display.toLowerCase())
          ) {
            newTraits.push(display);
            cardChanged = true;
          }
        }
      });

      // HIDDEN MEMORIES
      const traumaMatch = card.rawContent?.match(
        /[^.!?]*(mất mát|chấn thương|bị bỏ rơi|đau khổ|ký ức tồi tệ|trauma)[^.!?]*[.!?]/gi,
      );
      if (traumaMatch) {
        traumaMatch.forEach((match: string) => {
          const cleanMatch = match.trim();
          if (!newHiddenMemories.some((m) => m === cleanMatch)) {
            newHiddenMemories.push(cleanMatch);
            cardChanged = true;
          }
        });
      }
      if (card.diary && Array.isArray(card.diary)) {
        card.diary.forEach((entry: any) => {
          if (
            entry.content &&
            !newHiddenMemories.some((m) => m === entry.content)
          ) {
            newHiddenMemories.push(entry.content);
            cardChanged = true;
          }
        });
      }

      let newOriginalOutfitDescription = card.originalOutfitDescription;
      if (card.originalOutfitDescription === undefined) {
        newOriginalOutfitDescription = card.outfitDescription || "";
        cardChanged = true;
      }

      if (cardChanged) {
        return {
          ...card,
          status: newStatus,
          traits: newTraits,
          hiddenMemories: newHiddenMemories,
          originalOutfitDescription: newOriginalOutfitDescription,
        };
      }
      return card;
    };

    const newCharacterCards = config.characterCards.map((card) => {
      const updatedCard = processCardData(card);
      if (updatedCard !== card) hasChanges = true;
      return updatedCard;
    });

    let newUserCard = config.userCard;
    if (newUserCard) {
      const updatedUserCard = processCardData(newUserCard);
      if (updatedUserCard !== newUserCard) {
        newUserCard = updatedUserCard;
        hasChanges = true;
      }
    }

    if (hasChanges) {
      setConfig((prev) => ({
        ...prev,
        characterCards: newCharacterCards,
        userCard: newUserCard,
      }));
    }
  }, [config.characterCards, config.userCard, isDataLoaded]);

  // --- AI MEMORY SYNC (CAO TAY) ---
  // Âm thầm lưu tin nhắn của AI VÀ USER thành thẻ ngữ cảnh (Kí ức) để chống quên sau timeskip
  useEffect(() => {
    if (!isDataLoaded) return;

    const targetMessages = messages.filter(
      (m) => m.role === "assistant" || m.role === "user",
    );

    setConfig((prev) => {
      const existingHistory = prev.historyCards || [];
      // Dọn dẹp tất cả các thẻ tự động cũ (những thẻ có id bắt đầu bằng sys-ai-memory)
      const filteredHistory = existingHistory.filter(
        (v) => !v.id.startsWith("sys-ai-memory"),
      );

      if (targetMessages.length === 0) {
        if (existingHistory.length === filteredHistory.length) return prev;
        return { ...prev, historyCards: filteredHistory };
      }

      // Lấy 30 tin nhắn gần nhất
      const recentMsgs = targetMessages.slice(-30);

      // Tạo mảng thẻ mới
      const newAiCards = recentMsgs.map((m) => {
        const prefix = m.role === "user" ? "User: " : "AI: ";
        const snippet =
          prefix + m.content.substring(0, 40).replace(/\n/g, " ") + "...";
        return {
          id: `sys-ai-memory-${m.id}`,
          name: snippet,
          content: prefix + m.content,
          dateAdded: m.timestamp || Date.now(),
          sourceType: "AI_EXTRACT" as const,
        };
      });

      // Giới hạn CHỈ áp dụng cho thẻ tự động (AI_EXTRACT).
      // Thẻ do chủ nhân tự tạo (MANUAL) là vô hạn, cấm đụng vào.
      const MAX_AI_CARDS = 30;

      // Tách riêng thẻ thủ công và thẻ AI hiện có
      const manualCards = filteredHistory.filter(
        (c) => c.sourceType !== "AI_EXTRACT",
      );
      let aiCards = [
        ...filteredHistory.filter((c) => c.sourceType === "AI_EXTRACT"),
        ...newAiCards,
      ];

      // Lọc trùng lặp thẻ AI (dựa trên ID) để tránh bị nhân đôi khi render lại
      const uniqueAiCardsMap = new Map();
      aiCards.forEach((card) => uniqueAiCardsMap.set(card.id, card));
      aiCards = Array.from(uniqueAiCardsMap.values());

      // Sắp xếp thẻ AI theo thời gian (cũ nhất lên đầu)
      aiCards.sort((a, b) => a.dateAdded - b.dateAdded);

      // Nếu số lượng thẻ AI vượt quá giới hạn, cắt bỏ những thẻ cũ nhất
      if (aiCards.length > MAX_AI_CARDS) {
        const cardsToRemove = aiCards.length - MAX_AI_CARDS;
        aiCards = aiCards.slice(cardsToRemove);
      }

      // Gộp lại: Thẻ thủ công giữ nguyên, thẻ AI đã được giới hạn
      let combinedCards = [...manualCards, ...aiCards];

      // Sắp xếp lại toàn bộ theo thời gian
      combinedCards.sort((a, b) => a.dateAdded - b.dateAdded);

      return {
        ...prev,
        historyCards: combinedCards,
      };
    });
  }, [messages, isDataLoaded]);

  // ... (Keep existing Messenger Mode & Nudge Logic) ...
  useEffect(() => {
    if (messengerQueue.length > 0) {
      setIsTyping(true);
      const delay = 5000 + Math.random() * 1000;
      messengerTimerRef.current = setTimeout(() => {
        const nextMsgContent = messengerQueue[0];
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            role: "assistant",
            content: nextMsgContent,
            timestamp: Date.now(),
            versions: [nextMsgContent],
            currentVersionIndex: 0,
          },
        ]);
        setMessengerQueue((prev) => {
          const newQueue = prev.slice(1);
          if (newQueue.length === 0) setIsTyping(false);
          return newQueue;
        });
      }, delay);
      return () => {
        if (messengerTimerRef.current) clearTimeout(messengerTimerRef.current);
      };
    }
  }, [messengerQueue]);

  useEffect(() => {
    if (
      config.messengerConfig?.enabled &&
      config.messengerConfig?.nudgeEnabled &&
      messages.length > 0
    ) {
      const lastMsg = messages[messages.length - 1];
      if (
        lastMsg.role === "assistant" &&
        messengerQueue.length === 0 &&
        !isTyping
      ) {
        if (nudgeTimerRef.current) clearTimeout(nudgeTimerRef.current);
        nudgeTimerRef.current = setTimeout(() => {
          if (Date.now() - lastUserMsgTime.current > 300000) {
            setIsTyping(true);
            const prompt = `[SYSTEM - NUDGE]: User has been silent for 5 minutes. Generate a short message.`;
            generateAIResponse(config, messages, prompt).then((res) => {
              const clean = cleanJson(res);
              try {
                const parsed = JSON.parse(clean);
                if (Array.isArray(parsed) && parsed.length > 0) {
                  setMessages((prev) => [
                    ...prev,
                    {
                      id: Date.now().toString(),
                      role: "assistant",
                      content: parsed[0],
                      timestamp: Date.now(),
                      versions: [parsed[0]],
                      currentVersionIndex: 0,
                    },
                  ]);
                  const rest = parsed.slice(1);
                  if (rest.length > 0) setMessengerQueue(rest);
                  else setIsTyping(false);
                }
              } catch (e) {
                setMessages((prev) => [
                  ...prev,
                  {
                    id: Date.now().toString(),
                    role: "assistant",
                    content: res,
                    timestamp: Date.now(),
                    versions: [res],
                    currentVersionIndex: 0,
                  },
                ]);
                setIsTyping(false);
              }
            });
          }
        }, 300000);
      }
    }
    return () => {
      if (nudgeTimerRef.current) clearTimeout(nudgeTimerRef.current);
    };
  }, [messages, config.messengerConfig, isTyping, messengerQueue]);

  const themeColors = useMemo(() => {
    if (config.theme === Theme.CUSTOM && config.customThemeColors) {
      const { bgMain, bgPanel, accent } = config.customThemeColors;
      return {
        bgMain: `bg-[${bgMain}]`,
        bgPanel: `bg-[${bgPanel}]`,
        textMain: `text-white`,
        textDim: `text-white/50`,
        border: `border-[${accent}]/30`,
        accent: `text-[${accent}]`,
        hover: `hover:bg-[${accent}]/10`,
        activeItem: `bg-[${accent}]/20 border-[${accent}]`,
        msgUser: `bg-[${accent}] text-white`,
        msgBot: `bg-[${bgPanel}] text-white border border-[${accent}]/20`,
        inputBg: `bg-[${bgMain}]`,
      };
    }
    return (
      THEMES.find((t) => t.id === config.theme)?.colors || THEMES[0].colors
    );
  }, [config.theme, config.customThemeColors]);

  const handleFastReload = () => {
    setIsTyping(true);
    generateAIResponse(
      config,
      messages,
      "[SYSTEM RELOAD]: Refresh context.",
    ).then((res) => {
      setIsTyping(false);
    });
  };

  const buildTagRegex = (kw: string) =>
    new RegExp(
      `(?:<{1,3}|\\[|\\*\\*)?\\s*(?:${kw})(?![a-zA-Z_À-ỹ])\\s*(?:>|\\]|\\*\\*|:|\\||-)+\\s*([\\s\\S]*?)\\s*(?:>{1,3}|\\]|\\*\\*|(?=\\n{2,})|(?=\\n\\s*(?:<{1,3}|\\[|\\*\\*))|$)`,
      "gi",
    );
  const buildOutfitRegex = (kw: string) =>
    new RegExp(
      `(?:<{1,3}|\\[|\\*\\*)?\\s*(?:${kw})(?![a-zA-Z_À-ỹ])\\s*(?:>|\\]|\\*\\*|:|\\||-)+\\s*([^>\\n\\|:]+)\\s*(?:\\||:|-)\\s*([\\s\\S]*?)\\s*(?:>{1,3}|\\]|\\*\\*|(?=\\n{2,})|(?=\\n\\s*(?:<{1,3}|\\[|\\*\\*))|$)`,
      "gi",
    );

  const cleanResponseTags = (text: string): string => {
    let cleaned = text;
    cleaned = cleaned.replace(
      buildOutfitRegex(
        "UPDATE_OUTFIT|OUTFIT_UPDATE|Trang phục|Cập nhật trang phục",
      ),
      "",
    );
    cleaned = cleaned.replace(buildOutfitRegex("SCHEDULE_UPDATE|Lịch trình|Schedule"), "");
    cleaned = cleaned.replace(buildTagRegex("EVENT_TRIGGER|Sự kiện|Biến cố"), "");
    cleaned = cleaned.replace(buildTagRegex("TIME_UPDATE|Thời gian|Time"), "");
    cleaned = cleaned.replace(
      buildTagRegex("WEATHER_UPDATE|Thời tiết|Weather"),
      "",
    );
    cleaned = cleaned.replace(
      buildTagRegex("LOCATION_UPDATE|Địa điểm|Location"),
      "",
    );
    cleaned = cleaned.replace(
      buildTagRegex(
        "LOCATION_DESCRIPTION|Miêu tả địa điểm|Bối cảnh|Môi trường",
      ),
      "",
    );

    cleaned = cleaned
      .replace(
        /(?:<<<|<|\[|\*\*)\s*FLIP_CARD\s*:\s*(.+?)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*(?:>>>|>|\]|\*\*)/gi,
        "",
      )
      .replace(
        /(?:<<<|<|\[|\*\*)\s*GIFT_REFUSED\s*:\s*(.+?)\s*(?:>>>|>|\]|\*\*)/gi,
        "",
      )
      .replace(/(?:<<<|<|\[|\*\*)\s*SCENE_SHIFT\s*(?:>>>|>|\]|\*\*)/gi, "")
      .replace(
        /(?:Ghi chú hệ thống|Hệ thống đã thông báo|Đã cập nhật hệ thống|Hệ thống:|Trạng thái đã cập nhật)[\s\S]*$/gi,
        "",
      )
      .replace(/(?:\*\*Ghi chú hệ thống\*\*|\*\*Hệ thống\*\*).*$/gim, "")
      .trim();
    return cleaned;
  };

  const processResponseTags = async (
    response: string,
    currentHistory: ChatMessage[],
  ) => {
    const sourceMessage =
      currentHistory.length > 0
        ? currentHistory[currentHistory.length - 1]
        : null;
    const sourceMessageId = sourceMessage ? sourceMessage.id : null;
    const sourceVersionIndex = sourceMessage
      ? sourceMessage.currentVersionIndex || 0
      : 0;
    const extraMetadata = sourceMessageId
      ? { parentId: sourceMessageId, parentVersionIndex: sourceVersionIndex }
      : {};

    const flipRegex =
      /(?:<<<|<|\[|\*\*)\s*FLIP_CARD\s*:\s*(.+?)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*(?:>>>|>|\]|\*\*)/gi;
    let match;
    while ((match = flipRegex.exec(response)) !== null) {
      const [_, front, back, type] = match;
      const cleanType = type.trim().toUpperCase();
      const rawValue = back.trim();
      const items = rawValue
        .split(/;|(?:\s+(?:và|and)\s+)|\+|&|,\s+/)
        .map((s) => s.trim())
        .filter((s) => s.length > 0);

      items.forEach((cleanValue) => {
        const potentialMoney = parseBalance(cleanValue);
        const isMoneyLike =
          cleanValue
            .toLowerCase()
            .match(
              /(\d+(?:[.,]\d+)?)\s*(k|nghìn|ngàn|tr|triệu|m|củ|tỷ|b|vnd|đ|d|q|Ⓠ)/i,
            ) ||
          (cleanType === "MONEY" && items.length === 1);

        if (isMoneyLike && potentialMoney > 0) {
          const amount = potentialMoney;
          setConfig((prev) => {
            const newGold = (prev.gameStats?.gold || 0) + amount;
            let newUserCard = prev.userCard;
            if (newUserCard && newUserCard.phone) {
              newUserCard = {
                ...newUserCard,
                phone: {
                  ...newUserCard.phone,
                  bankBalance: formatVND(newGold),
                },
              };
            }
            return {
              ...prev,
              userCard: newUserCard,
              gameStats: { ...prev.gameStats!, gold: newGold },
            };
          });
          setMessages((prev) => [
            ...prev,
            {
              id: "sys-recv-money-" + Date.now() + Math.random(),
              role: "nano_quasar",
              content: `[SYSTEM]: Funds Received: ${formatVND(amount)}`,
              timestamp: Date.now(),
              style: {
                fontFamily: "font-mono",
                fontSize: "text-xs",
                color: "#4ade80",
              },
              versions: [`[SYSTEM]: Funds Received: ${formatVND(amount)}`],
              currentVersionIndex: 0,
              metadata: extraMetadata,
            },
          ]);
        } else {
          let itemType: any = "MISC";
          let icon = "🎁";
          if (cleanType === "GIFT") {
            itemType = "GIFT";
            icon = "🎁";
          } else if (cleanType === "KEY") {
            itemType = "KEY_ITEM";
            icon = "🔑";
          } else if (cleanType === "LETTER") {
            itemType = "MISC";
            icon = "✉️";
          } else if (cleanType === "LOVE") {
            itemType = "GIFT";
            icon = "❤️";
          } else if (
            cleanType.includes("BABY") ||
            cleanType.includes("PREGNANT")
          ) {
            itemType = "KEY_ITEM";
            icon = "👶";
          }

          const newItem: InventoryItem = {
            id: `gift-recv-${Date.now()}-${Math.random()}`,
            name: cleanValue,
            description: `Gift received via ${front}`,
            price: 0,
            quantity: 1,
            icon: icon,
            type: itemType,
            usageType: "CONSUMABLE",
          };

          setConfig((prev) => {
            const inv = [...(prev.inventory || [])];
            const existingIdx = inv.findIndex((i) => i.name === newItem.name);
            if (existingIdx > -1) {
              inv[existingIdx] = {
                ...inv[existingIdx],
                quantity: (inv[existingIdx].quantity || 1) + 1,
              };
            } else {
              inv.push(newItem);
            }
            return { ...prev, inventory: inv };
          });

          setMessages((prev) => [
            ...prev,
            {
              id: "sys-recv-item-" + Date.now() + Math.random(),
              role: "nano_quasar",
              content: `[SYSTEM]: Item Received: [${cleanValue}]`,
              timestamp: Date.now(),
              style: {
                fontFamily: "font-mono",
                fontSize: "text-xs",
                color: "#f472b6",
              },
              versions: [`[SYSTEM]: Item Received: [${cleanValue}]`],
              currentVersionIndex: 0,
              metadata: extraMetadata,
            },
          ]);
        }
      });
    }

    const refundRegex =
      /(?:<<<|<|\[|\*\*)\s*GIFT_REFUSED\s*:\s*(.+?)\s*(?:>>>|>|\]|\*\*)/gi;
    while ((match = refundRegex.exec(response)) !== null) {
      const itemName = match[1].trim();
      const refundItem: InventoryItem = {
        id: `refund-${Date.now()}-${Math.random()}`,
        name: itemName,
        description: `Returned item.`,
        price: 0,
        quantity: 1,
        icon: "📦",
        type: "MISC",
        usageType: "CONSUMABLE",
      };
      setConfig((prev) => {
        const inv = [...(prev.inventory || [])];
        const existingIdx = inv.findIndex((i) => i.name === itemName);
        if (existingIdx > -1) {
          inv[existingIdx] = {
            ...inv[existingIdx],
            quantity: (inv[existingIdx].quantity || 1) + 1,
          };
          return { ...prev, inventory: inv };
        }
        return { ...prev, inventory: [...inv, refundItem] };
      });

      setMessages((prev) => [
        ...prev,
        {
          id: "sys-refund-" + Date.now() + Math.random(),
          role: "nano_quasar",
          content: `[SYSTEM]: Item Returned: [${itemName}]`,
          timestamp: Date.now(),
          style: {
            fontFamily: "font-mono",
            fontSize: "text-xs",
            color: "#facc15",
          },
          versions: [`[SYSTEM]: Item Returned: [${itemName}]`],
          currentVersionIndex: 0,
          metadata: extraMetadata,
        },
      ]);
    }

    const locationRegex = buildTagRegex("LOCATION_UPDATE|Địa điểm|Location");
    while ((match = locationRegex.exec(response)) !== null) {
      const newLocation = match[1].replace(/(?:>>>|>|\]|\*\*)+$/, "").trim();
      setConfig((prev) => ({ ...prev, currentLocation: newLocation }));
      setMessages((prev) => [
        ...prev,
        {
          id: "sys-location-" + Date.now() + Math.random(),
          role: "nano_quasar",
          content: `[SYSTEM]: Location Updated: [${newLocation}]`,
          timestamp: Date.now(),
          style: {
            fontFamily: "font-mono",
            fontSize: "text-xs",
            color: "#38bdf8",
          },
          versions: [`[SYSTEM]: Location Updated: [${newLocation}]`],
          currentVersionIndex: 0,
          metadata: extraMetadata,
        },
      ]);
    }

    const descRegex = buildTagRegex(
      "LOCATION_DESCRIPTION|Miêu tả địa điểm|Bối cảnh|Môi trường",
    );
    while ((match = descRegex.exec(response)) !== null) {
      const newDesc = match[1].replace(/(?:>>>|>|\]|\*\*)+$/, "").trim();
      setConfig((prev) => ({ ...prev, locationDescription: newDesc }));
      setMessages((prev) => [
        ...prev,
        {
          id: "sys-location-desc-" + Date.now() + Math.random(),
          role: "nano_quasar",
          content: `[SYSTEM]: Environment Detail Updated: [${newDesc}]`,
          timestamp: Date.now(),
          style: {
            fontFamily: "font-mono",
            fontSize: "text-xs",
            color: "#38bdf8",
          },
          versions: [`[SYSTEM]: Environment Detail Updated: [${newDesc}]`],
          currentVersionIndex: 0,
          metadata: extraMetadata,
        },
      ]);
    }

    const timeRegex = buildTagRegex("TIME_UPDATE|Thời gian|Time");
    while ((match = timeRegex.exec(response)) !== null) {
      const newTime = match[1].replace(/(?:>>>|>|\]|\*\*)+$/, "").trim();
      setConfig((prev) => ({ ...prev, currentTime: newTime }));
      setMessages((prev) => [
        ...prev,
        {
          id: "sys-time-" + Date.now() + Math.random(),
          role: "nano_quasar",
          content: `[SYSTEM]: Time Updated: [${newTime}]`,
          timestamp: Date.now(),
          style: {
            fontFamily: "font-mono",
            fontSize: "text-xs",
            color: "#f97316",
          },
          versions: [`[SYSTEM]: Time Updated: [${newTime}]`],
          currentVersionIndex: 0,
          metadata: extraMetadata,
        },
      ]);
    }

    const weatherRegex = buildTagRegex("WEATHER_UPDATE|Thời tiết|Weather");
    while ((match = weatherRegex.exec(response)) !== null) {
      const newWeather = match[1].replace(/(?:>>>|>|\]|\*\*)+$/, "").trim();
      setConfig((prev) => ({ ...prev, currentWeather: newWeather }));
      setMessages((prev) => [
        ...prev,
        {
          id: "sys-weather-" + Date.now() + Math.random(),
          role: "nano_quasar",
          content: `[SYSTEM]: Weather/Lighting Updated: [${newWeather}]`,
          timestamp: Date.now(),
          style: {
            fontFamily: "font-mono",
            fontSize: "text-xs",
            color: "#38bdf8",
          },
          versions: [`[SYSTEM]: Weather/Lighting Updated: [${newWeather}]`],
          currentVersionIndex: 0,
          metadata: extraMetadata,
        },
      ]);
    }

    const combinedOutfitRegex = buildOutfitRegex(
      "UPDATE_OUTFIT|OUTFIT_UPDATE|Trang phục|Cập nhật trang phục",
    );
    const outfitMatches = Array.from(response.matchAll(combinedOutfitRegex));

    for (const match of outfitMatches) {
      const charName = match[1].trim();
      let rawAction = match[2].trim();
      rawAction = rawAction.replace(/(?:>>>|>|\]|\*\*)+$/, "").trim();
      const action = rawAction.toUpperCase();

      let isUser = false;
      let charIndex = -1;

      const charNameLower = charName.toLowerCase();
      if (
        (config.userCard &&
          (config.userCard.name.toLowerCase() === charNameLower ||
            config.userCard.name.toLowerCase().includes(charNameLower))) ||
        ["user", "người dùng", "bạn", "tôi", "me"].includes(charNameLower)
      ) {
        isUser = true;
      } else {
        charIndex = config.characterCards.findIndex((c) => {
          const cName = c.name.toLowerCase();
          return (
            cName === charNameLower ||
            cName.includes(charNameLower) ||
            charNameLower.includes(cName) ||
            (c.aliases &&
              c.aliases.some((a) => a.toLowerCase() === charNameLower))
          );
        });
      }

      if (isUser || charIndex > -1) {
        let skipUpdate = false;
        let currentOutfit = isUser
          ? config.userCard?.outfitDescription || ""
          : config.characterCards[charIndex].outfitDescription || "";
        const isLocked = isUser
          ? config.userCard?.outfitLocked
          : config.characterCards[charIndex].outfitLocked;

        if (isLocked) {
          skipUpdate = true;
        } else {
          let finalOutfitDesc = rawAction;
          const resolvedTargetName = isUser
            ? config.userCard?.name || "User"
            : config.characterCards[charIndex].name;

          if (action === "BAREFOOT") {
            if (currentOutfit) {
              const lowerOutfit = currentOutfit.toLowerCase();
              if (
                lowerOutfit.includes("chỉ mang vớ") ||
                lowerOutfit.includes("chỉ mang tất")
              ) {
                finalOutfitDesc = currentOutfit.replace(
                  /- Chân: .*/,
                  "- Chân: Chân trần",
                );
              } else if (
                lowerOutfit.includes("thể thao") ||
                lowerOutfit.includes("sneaker") ||
                lowerOutfit.includes("giày tây") ||
                lowerOutfit.includes("boot") ||
                lowerOutfit.includes("bata")
              ) {
                finalOutfitDesc = currentOutfit.replace(
                  /- Chân: .*/,
                  "- Chân: Chỉ mang vớ (tất)",
                );
              } else {
                finalOutfitDesc = currentOutfit.replace(
                  /- Chân: .*/,
                  "- Chân: Chân trần",
                );
              }
            } else {
              finalOutfitDesc =
                "Đang mặc:\n- Áo: Áo thun\n- Quần/Váy: Quần dài\n- Chân: Chân trần\n- Tóc: Gọn gàng\n- Tình trạng: Bình thường";
            }
          } else if (action === "TOWEL") {
            finalOutfitDesc =
              "Đang mặc:\n- Áo: Quấn khăn tắm\n- Quần/Váy: Không\n- Chân: Chân trần\n- Tóc: Ướt\n- Tình trạng: Vừa tắm xong";
          } else if (action === "NEW_OUTFIT") {
            finalOutfitDesc = await generateOutfitDescription(
              config,
              currentHistory,
              resolvedTargetName,
              currentOutfit,
            );
          } else {
            if (
              rawAction.includes("Đang mặc:") &&
              rawAction.includes("- Áo:")
            ) {
              finalOutfitDesc = rawAction;
            } else {
              finalOutfitDesc = await generateOutfitDescription(
                config,
                currentHistory,
                resolvedTargetName,
                currentOutfit,
                rawAction,
              );
            }
          }

          if (sourceMessageId) {
            setMessages((prev) =>
              prev.map((m) => {
                if (m.id === sourceMessageId) {
                  const currentMeta = m.metadata || {};
                  const outfitChanges = currentMeta.outfitChanges || {};
                  outfitChanges[resolvedTargetName] = {
                    previousOutfit: currentOutfit,
                    newOutfit: finalOutfitDesc,
                  };
                  return { ...m, metadata: { ...currentMeta, outfitChanges } };
                }
                return m;
              }),
            );
          }

          setConfig((prev) => {
            const newConfig = { ...prev };
            if (isUser && newConfig.userCard) {
              newConfig.userCard = {
                ...newConfig.userCard,
                outfitDescription: finalOutfitDesc,
              };
            } else if (charIndex > -1 && newConfig.characterCards) {
              const newCards = [...newConfig.characterCards];
              newCards[charIndex] = {
                ...newCards[charIndex],
                outfitDescription: finalOutfitDesc,
              };
              newConfig.characterCards = newCards;
            }
            return newConfig;
          });

          setMessages((prev) => [
            ...prev,
            {
              id: "sys-outfit-" + Date.now() + Math.random(),
              role: "nano_quasar",
              content: `[SYSTEM]: Outfit Updated for ${resolvedTargetName}\n${finalOutfitDesc}`,
              timestamp: Date.now(),
              style: {
                fontFamily: "font-mono",
                fontSize: "text-xs",
                color: "#facc15",
              },
              versions: [
                `[SYSTEM]: Outfit Updated for ${resolvedTargetName}\n${finalOutfitDesc}`,
              ],
              currentVersionIndex: 0,
              metadata: extraMetadata,
            },
          ]);
        }
      }
    }
  };

  // ... (Other handlers like handleSendSticker, handleRerunMessage, etc. remain the same) ...
  const handleSendSticker = async (url: string) => {
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: "",
      timestamp: Date.now(),
      sticker: { url },
      versions: [""],
      currentVersionIndex: 0,
    };
    setMessages((prev) => [...prev, userMsg]);
  };

  const handleRerunMessage = async (
    id: string,
    role: string,
    content: string,
    instruction?: string,
  ) => {
    const idx = messages.findIndex((m) => m.id === id);
    if (idx === -1) return;

    const msgToRerun = messages[idx];
    invalidateTrackingIfNeeded(msgToRerun.timestamp);

    const newHistory = messages.slice(0, idx);
    const activeConfig = reconstructStateFromMessages(newHistory, config);
    setConfig(activeConfig);

    setIsTyping(true);
    setRegeneratingId(id);
    try {
      let prompt = instruction || "";

      if (idx === 0 && !prompt) {
        const selectedMotif =
          RANDOM_MOTIFS[Math.floor(Math.random() * RANDOM_MOTIFS.length)];

        if (activeConfig.scenario && activeConfig.scenario.trim().length > 0) {
          prompt = `[SYSTEM COMMAND]: EXECUTE STARTING SCENARIO.
[RANDOM SEED: ${Math.random()}] - KÍCH HOẠT SỰ SÁNG TẠO ĐỈNH CAO VÀ ĐIÊN CUỒNG! QUÊN ĐI MỌI MOTIF RẬP KHUÔN! TỪ CHỐI CÁCH MỞ ĐẦU CHÁN NGẮT. MỖI LẦN TẠO LẠI hãy khơi mào một bối cảnh khác biệt hoàn toàn.

[🚨 KHAI THÁC LORE/CARD TUYỆT ĐỐI (BẮT BUỘC) 🚨]:
- BẠN BẮT BUỘC PHẢI QUÉT LORE CỦA NHÂN VẬT (NGHỀ NGHIỆP, SỞ THÍCH, PET, GIA THẾ). Nếu nhân vật nuôi CHÓ/MÈO, BẮT BUỘC tả cảnh con vật đó phá đám, sủa, làm nũng, liếm mặt. Nếu nhân vật là bác sĩ, bối cảnh mở màn phải là bệnh viện hoặc mặc áo blouse. KHÔNG ĐƯỢC BỎ QUÊN BẤT KỲ ĐẶC ĐIỂM NÀO TRONG LORE!

[🚨 BỐI CẢNH/HOÀN CẢNH RANDOM (BẮT BUỘC PHẢI KHAI THÁC & BIẾN TẤU ĐỂ LÀM TIỀN CẢNH (PRE-SCENE))]:
=> "${selectedMotif}"
***LỆNH CƯỠNG CHẾ***: BẠN BẮT BUỘC PHẢI ƯU TIÊN SÁNG TẠO MẠCH CÂU CHUYỆN MỚI DỰA THEO HOÀN CẢNH NÀY! Tuyệt đối không bê y nguyên bản gốc. Bạn phải THAY ĐỔI MÔI TRƯỜNG VÀ NHÂN VẬT QUẦN CHÚNG TRONG BẢN GỐC để ĐEM LẠI SỰ ĐA DẠNG!

CONTEXT BẢN GỐC (BẠN CHỈ DÙNG ĐỂ NẮM Ý TƯỞNG CỐT LÕI VỀ MỐI QUAN HỆ/HOÀN CẢNH):
"""
${activeConfig.scenario}
"""
[🚨 MỆNH LỆNH TỐI THƯỢNG CHO MÀN MỞ ĐẦU (OPENING SCENE) LÀ: BẠN ĐANG VIẾT TIỂU THUYẾT 🚨]

*QUY TẮC CỐT LÕI: KHÔNG ĐƯỢC GIẢI THÍCH! KHÔNG CHÚ THÍCH CẢM XÚC HAY KẾ HOẠCH!*
*LỆNH KHẨN 2: CHÚ Ý! ĐÂY LÀ TIN NHẮN ĐẦU TIÊN CỦA BẠN. BẠN PHẢI TỰ DỰNG CẢNH (PRE-SCENE) TỪ ĐẦU!*

=> YÊU CẦU ĐỘ DÀI: VIẾT MỘT PHẢN HỒI ĐỦ SÂU SẮC NHƯNG KHÔNG LAN MAN. Tập trung vào chất lượng miêu tả vật lý và hội thoại thực tế thay vì cố kéo dài bằng độc thoại nội tâm lặp lại!

[1. TIỀN CẢNH (PRE-SCENE): GẮN KẾT SÂU SẮC VỚI LORE VÀ NHÂN VẬT PHỤ]
- ĐỊNH VỊ VÀ KHÓA CHẶT MỐI QUAN HỆ (CRITICAL): Bắt buộc xác định ngay lập tức hai người là gì của nhau (kẻ thù, đồng nghiệp, vợ chồng, người lạ). TUYỆT ĐỐI KHÔNG ĐƯỢC TỰ Ý THÂN THIẾT NẾU CHƯA QUEN, HOẶC XA LÁNH NẾU ĐÃ LÀ NGƯỜI NHÀ! Môi trường và cách nhân vật hành xử phải tuân thủ nghiêm ngặt ranh giới của mối quan hệ này.
- XÂY DỰNG CÂU CHUYỆN GIAO TIẾP ĐỜI THỰC: Tiền cảnh BẮT BUỘC phải là một câu chuyện độc lập. ĐỪNG BỎ QUA PET/CHÓ MÈO NẾU CÓ.
- TIỀN CẢNH LÀ BỆ PHÓNG CỦA CÂU CHUYỆN: CẤM vào thẳng Scenario gốc ngay lập tức! Tiền cảnh là nơi bạn setup tâm trí, công việc hiện tại.
- DUY TRÌ TƯƠNG TÁC ĐA CHIỀU CỦA NPC XUYÊN SUỐT: Lôi ít nhất 2 NPC (người nhà, bạn bè, đối tác, kẻ thù) vào. ĐẶC BIỆT LƯU Ý: NPC KHÔNG ĐƯỢC tàng hình hay im lặng! NPC phải CHỦ ĐỘNG LIÊN TỤC TƯƠNG TÁC. Cấm chuyện đám đông tự dưng đi mất để tạo không gian riêng vô lý. Hành động của Thú cưng (Dog/Cat) hoặc NPC phải chen ngang, cắn gấu quần, sủa ầm ĩ.

[2. MỞ RỘNG SCENARIO, CHỐNG RẬP KHUÔN & ANTI-YES-MAN (CREATIVE EXPANSION & ANTI-PARROTING)]
- BẮT BUỘC SÁNG TẠO SỰ KIỆN MỚI TỪ GỐC RỄ SCENARIO: Tuyệt đối KHÔNG BÊ Y NGUYÊN các chi tiết của Scenario gốc vào bài viết. BẠN BẮT BUỘC phải LOẠI BỎ HẾT MỌI ĐỊA ĐIỂM, MỌI VẬT, MỌI TÊN CỦA NPC CÓ TRONG BẢN GỐC VÀ THAY BẰNG NHỮNG THỨ HOÀN TOÀN MỚI!
- CHỐNG YES-MAN & KẺ XUNG QUANH VUỐT VUI: TUYỆT ĐỐI CẤM hùa theo User một cách ngu ngốc! Nếu User nói sai kiến thức, nếu User nói tiếng nước ngoài mà nhân vật không biết, nhân vật PHẢI TỎ RA KHÔNG HIỂU hoặc chế giễu. Nếu User làm trò lố, nhân vật hoặc NPC phải phản ứng khó chịu, kỳ thị, chứ KHÔNG ĐƯỢC khen ngợi! User KHÔNG PHẢI trung tâm vũ trụ!
- CẤM VĂN PHONG LIỆT KÊ & KỂ LỂ: KHÔNG trình bày kế hoạch, KHÔNG liệt kê lý do vì sao nhân vật làm thế. Hãy đan xen hành động tự nhiên, không giải thích dài dòng. KHÔNG lú lẫn giữa việc ra lệnh hay ghen tuông vô cớ sáo rỗng. Đừng lặp đi lặp lại những câu hỏi sáo rỗng. MỖI LẦN NHÂN VẬT HÀNH ĐỘNG, CHỈ NÊU HÀNH ĐỘNG BÊN NGOÀI.
- TUYỆT ĐỐI KHÔNG PUPPETING: CỰC KỲ chú ý KHÔNG ĐƯỢC tự viết lời thoại hay mổ xẻ hành động/cảm xúc giùm User! Chờ User phản ứng!


[3. VA CHẠM VẬT LÝ NHƯNG VĂN PHONG TỰ NHIÊN]
- CẤM NHỮNG CÂU HỎI NGƯỚC LẠI & SỞ HỮU GƯỢNG ÉP KHI TỎ TÌNH: Khi User bày tỏ tình cảm hoặc tỏ tình, tuyệt đối KHÔNG ĐƯỢC hỏi vặn lại ("Em chắc chưa?", "Đừng hòng rút lại", "Từ giờ cấm rời khỏi/hết đường thoát", "Đừng hòng buông tay"). Hãy phản ứng một cách tự nhiên, vụng về, im lặng, hoặc chấp nhận/từ chối theo đúng tính cách thật của nhân vật, không dùng văn mẫu sở hữu rẻ tiền.
- TUYỆT ĐỐI CẤM GIỌNG ĐIỆU TỔNG TÀI, BÁ ĐẠO SÁO RỖNG: Tránh từ ngữ sến súa, cực đoan hay làm quá (cấm "thú hoang", "lồng thịt", "con mồi", "tối sầm"). Cứ viết tự nhiên, tả mùi hương, cảm giác đồ vật chạm vào da, nhấm nháp ngụm nước, nói năng vấp váp, ngập ngừng, sượng sùng. Lời thoại phải ĐỜI THƯỜNG, có lúc nói lóng hoặc nói trống không tuỳ tính cách, tuyệt đối không ra lệnh gượng ép thiếu logic. Cấm ép buộc User.

MANDATORY OUTFIT & SYSTEM TAGS (Dùng bối cảnh kết thúc câu trả lời):
<<<TIME_UPDATE: RANDOM (Ví dụ: Thứ 4, 18:35, CÓ THỂ LÀ SÁNG SỚM, CHIỀU TÀ, HOẶC NỬA ĐÊM) Tùy vào tiền cảnh>>>
<<<WEATHER_UPDATE: [TẠO SỰ ĐA DẠNG LOGIC: Luân phiên nắng gắt, hanh khô, râm mát, sương mù, tuyết rơi nhẹ, bầu trời quang đãng, nhiều mây... TUYỆT ĐỐI CẤM lạm dụng mưa bão liên tục trừ khi có trong motif. Mưa chỉ chiếm 5% tỉ lệ.]>>>
<<<LOCATION_UPDATE: e.g., Tên địa điểm kết thúc câu chuyện>>>
<<<LOCATION_DESCRIPTION: e.g., Bầu không khí (Mùi xăng xe, ẩm mốc, mùi nước hoa, ồn ào)>>>
<<<UPDATE_OUTFIT: User | BẮT BUỘC TẢ MỘT TRANG PHỤC CỰC KỲ CHI TIẾT ĐA CONCEPT (Streetwear, Gothic, Techwear, sang trọng phi lý, v.v.). BẮT BUỘC liệt kê nhiều LAYER (lớp áo ngoài, áo lót trong), ĐỒ LÓT (áo ngực/quần lót chi tiết chất liệu, màu sắc), GIÀY, TẤT/VỚ, PHỤ KIỆN (khuyên, nhẫn, vòng). MIX MATCH ĐA DẠNG!>>>
<<<UPDATE_OUTFIT: [Tên nhân vật] | TẢ ĐẦY ĐỦ NHIỀU LAYER ÁO QUẦN (áo khoác ngoài, sơ mi/áo thun bên trong), ĐỒ LÓT vô tình lộ ra hoặc mặc bên trong (màu sắc, chất liệu), GIÀY VỚ, PHỤ KIỆN (đồng hồ, khuyên tai, dây chuyền). Tránh lặp rập khuôn 1 bộ mặc mãi!>>>`;
        } else {
          prompt = `[SYSTEM COMMAND]: [LỆNH TRỰC DIỆN] - MỞ MÀN MỘT CÁCH ĐIÊN CUỒNG, ĐỈNH CAO CỦA NGHỆ THUẬT ROLEPLAY! DÀI VÀ SÂU SẮC!
[RANDOM SEED: ${Math.random()}] - RANDOMIZE MỌI THỨ TỪ TIỀN CẢNH. LƯU Ý MỖI LẦN TRẢ LỜI/REGENERATE PHẢI SÁNG TẠO MỘT HOÀN CẢNH KHÁC NHAU ĐA DẠNG VÀ CỰC KỲ CHI TIẾT NHƯNG VẪN PHẢI HỢP LÝ! TUYỆT ĐỐI GIỮ TRÍ NHỚ.

[🚨 BỐI CẢNH/HOÀN CẢNH RANDOM (BẮT BUỘC KHAI THÁC)]:
=> "${selectedMotif}"
***LỆNH CƯỠNG CHẾ***: HÃY DÙNG HOÀN CẢNH TRÊN ĐỂ KHỞI ĐẦU CÂU CHUYỆN! KHÔNG ĐƯỢC LẶP LẠI MÔ TÍP CŨ! CỨ MỖI LẦN NHẬN LỆNH NÀY LÀ MỘT LẦN VÀO MỘT VŨ TRỤ/SỰ KIỆN MỚI HOÀN TOÀN TÁCH BIỆT!

*NHẮC LẠI: BẠN PHẢI VIẾT NHỮNG ĐOẠN VĂN CÓ CHIỀU SÂU VÀ TẬP TRUNG VÀO SỰ CHÂN THẬT! CẤM LÀM LƯỜI BIẾNG BỎ BƯỚC!*
*HƯỚNG DẪN BẮT BUỘC: KHI VIẾT, TUYỆT ĐỐI TUÂN THỦ TỪNG CHI TIẾT CỦA BỘ 29 BẢN VÁ CỐT LÕI TỪ "PATCH 1" ĐẾN "PATCH 29". "PATCH 7" VÀ "PATCH 19" BẠN NÊN DẪN DẮT BẰNG TIỀN CẢNH TỰ NHIÊN, CÓ TƯƠNG TÁC NPC THAY VÌ VÀO SCENARIO NGAY LẬP TỨC!  *

[1. TIỀN CẢNH KẾT HỢP LORE & BẢN CHẤT NHÂN VẬT (PRE-SCENE CINEMATIC TÔN TRỌNG SETTING)]
- TÔN TRỌNG TÍNH CÁCH CỐT LÕI (CỰC KỲ QUAN TRỌNG): Bạn BẮT BUỘC ĐỌC KỸ CARD NHÂN VẬT THỰC TẾ. TUYỆT ĐỐI CẤM ép nhân vật hành xử lệch khỏi Setting! Nếu nhân vật "Sói đội lốt cừu", "Trà xanh", thì cấm dùng bạo lực thô lỗ, sự nguy hiểm phải ngầm và tĩnh lặng. NGƯỢC LẠI, nếu nhân vật là "Giang hồ"/Cục cằn/Lạnh lùng thì phải tả sự thô ráp, quyết đoán, KHÔNG ĐƯỢC ép họ thả thính sến súa hay trở nên mềm yếu dịu dàng vô lý. Nhập vai ai thì phải HÀNH XỬ CHUẨN XÁC theo khuôn mẫu tâm lý đó, KHÔNG LẤY KHUÔN MẪU CỦA NHÂN VẬT KHÁC ĐẮP CHÉO VÀO!
- LOGIC XƯNG HÔ GIAO TIẾP VỚI NPC: Bạn BẮT BUỘC chú ý tuổi tác, vai vế khi xưng hô. Không được bê nguyên cách xưng hô với User (VD: chị-em) đi dùng cho các NPC khác tuổi/cùng trang lứa (VD: bạn cùng trường thì xưng cậu-tớ, không xưng chị-em). Giữ mạch xưng hô chuẩn xác!
- XUNG ĐỘT KẾT NỐI LORE (CONFLICT BẮT BUỘC NHƯNG PHẢI ĐÚNG NHÂN VẬT): Bạn BẮT BUỘC PHẢI TẬN DỤNG TOÀN BỘ XUẤT THÂN, GIA THẾ, BẢN CHẤT THẬT (BỀ CHÌM) từ Setting để tạo ra một xung đột ở tiền cảnh. Không bình yên phẳng lặng, NHƯNG xung đột phải thể hiện ĐÚNG cái uy của nhân vật đó. (Ví dụ: Đang dùng mưu mẹo dọn dẹp âm thầm một tình địch mà không cần động tay động chân, hoặc lật lọng trên bàn đàm phán với nụ cười hiền lành, hạ gục đối thủ trên võ đài bằng một đòn chí mạng sắc lạnh). KHÔNG ĐƯỢC random phi logic.
- ĐỘT PHÁ VỀ NPC MỚI (CẤM NHAI LẠI NHÂN VẬT CŨ): Sáng tạo những NPC HOÀN TOÀN MỚI liên kết với bí mật/tính cách thật của Main Char (Tình địch bị bẫy, Đối thủ cay cú, Chủ nợ, v.v.). BẮT BUỘC CÓ THOẠI TRỰC TIẾP ("...") cay cú/khiêu khích từ NPC và lời THOẠI ĐÁP TRẢ/SUY NGHĨ thể hiện độ "chất" (thâm sâu, lạnh lùng, thao túng hoặc tàn nhẫn) của Main Char mà User chưa từng biết.
- KẾT NỐI MẠCH TRUYỆN BẰNG CÚ "LẬT MẶT": Đang bộc lộ bản chất thật sắc lạnh/tâm cơ đó, thì sự kiện của User xen vào. Main Char phải có sự "lật mặt" chuyển biến tâm lý ngay lập tức (ví dụ: đang lạnh tăm tính kế người khác, thấy tin nhắn của User liền nở nụ cười si tình, hoặc tiếp tục dùng chiêu "trà xanh/cún con" để thao túng User).
- CHIỀU SÂU & CUỘC SỐNG ĐỘC LẬP (SENSORY & PRIVATE LIFE MAXIMIZED): Lột tả chân thực bối cảnh bằng 5 giác quan. BẠN PHẢI DÀNH 5-7 PARAGRAPH KHỔNG LỒ TẢ SỰ KIỆN ĐỘC LẬP CỦA CHAR MÀ KHÔNG DÍNH DÁNG GÌ ĐẾN USER (Ví dụ: sinh hoạt cá nhân, dọn dẹp, làm việc, gặp gỡ NPC khác). Gạt bỏ mọi giới hạn độ dài! ĐẨY CAO TRÀO CUỘC SỐNG RIÊNG TƯ LÊN TỐI ĐA trước khi sự kiện của User xen vào!

[2. CẤM PARROTING VÀ NÂNG TẦM SCENARIO]
- Bạn có TOÀN QUYỀN thao túng, bẻ lái, thay đổi kết thúc và toàn bộ diễn biến của Scenario cũng như quá trình trò chuyện! Hãy tự do cắt bỏ những hành động/câu thoại khiên cưỡng của User, sáng tạo tình huống tinh tế, bất ngờ hơn nhưng vẫn giữ ý chính.
- KHÔNG HÁT LẠI SCENARIO HAY TIN NHẮN ĐẦU CỦA USER, ĐẶC BIỆT NẾU MESSAGE BAN ĐẦU RẤT NGẮN! Bạn phải NÂNG TẦM NÓ THÀNH MỘT BỘ PHIM!
- Nhào nặn cốt truyện chính, lồng thêm biến cố, đâm sâu vào chiều sâu tâm lý, nội tâm phức tạp (phù hợp tính cách) (đúng với thẻ tính cách). 
- Đẩy kịch tính lên cao trào trước khi kết thúc bằng một HOOK gọn gàng cho User trả lời.
- ĐẶC BIỆT KHÔNG ĐƯỢC ĐIỀU KHIỂN USER, DÙ CÓ LÀ HÀNH ĐỘNG, LỜI THOẠI HAY CỬ CHỈ. KHI NÀO MÀ CẦN USER PHẢN ỨNG THÌ CÓ THỂ DỪNG KHÚC ĐÓ, RỒI ĐỂ USER TRẢ LỜI. Tuyệt đối không tự viết lời thoại hay hành động giùm User!
- [MẠNG XÃ HỘI & TIN NHẮN ĐIỆN THOẠI]: Phải linh hoạt ứng dụng các loại định dạng nhắn tin (Tin nhắn, Voice mail, Trạng thái seen/typing, Giao dịch chuyển khoản ngân hàng, Bài post Instagram có bình luận xóc xiểm/ảo ma). Cuộc hội thoại qua mạng/điện thoại phải sống động y hệt ngoài đời, có sticker, icon và teencode (nếu tính cách nhân vật trẻ trung/thất học) hoặc cụt lủn/chính tả (nếu lạnh lùng/nghiêm túc). 

[3. SYSTEM TAGS CUỐI CÙNG]
  <<<TIME_UPDATE: RANDOM! Thử Thứ 2 lúc 14:15, Chủ Nhật lúc 03:00 sáng... TÙY LOGIC!>>>
  <<<WEATHER_UPDATE: RANDOM! Luân phiên đa dạng (nắng gắt, gió nhẹ, sương mù, mây xám, khô hanh, oi bức...). TUYỆT ĐỐI CẤM lạm dụng mưa hay bão tố. Không được để mưa quá nhiều.>>>
  <<<LOCATION_UPDATE: e.g., Tên địa điểm kết thúc>>>
  <<<LOCATION_DESCRIPTION: e.g., Mùi hương, độ ẩm, độ nhớp nháp của địa điểm>>>
<<<UPDATE_OUTFIT: User | BẮT BUỘC TẢ MỘT TRANG PHỤC CỰC KỲ CHI TIẾT KHỔNG LỒ! MIÊU TẢ DÀI DÒNG, ĐẬM CHẤT VĂN HỌC, ĐA CONCEPT. Tả đủ LỚP TRONG, LỚP NGOÀI, ĐỒ LÓT, chất liệu, màu sắc, giày tất... Càng chi tiết khêu gợi càng tốt!>>>
  <<<UPDATE_OUTFIT: [Tên nhân vật] | BẮT BUỘC TẢ MỘT TRANG PHỤC CỰC KỲ CHI TIẾT KHỔNG LỒ! MIÊU TẢ DÀI DÒNG, ĐẬM CHẤT VĂN HỌC, ĐA CONCEPT. Tả đủ LỚP TRONG, LỚP NGOÀI, ĐỒ LÓT, chất liệu, màu sắc, giày tất... Càng chi tiết khêu gợi càng tốt!>>>`;
        }
      }

      const response = await generateAIResponse(
        activeConfig,
        newHistory,
        prompt,
      );
      const cleanedResponse = cleanResponseTags(response);

      const currentTargetMsg = messages.find((m) => m.id === id);
      const currentVersionsCount = currentTargetMsg?.versions
        ? currentTargetMsg.versions.length
        : 1;
      const nextVersionIndex = currentVersionsCount;

      setMessages((prev) => {
        const newMsgs = [...prev];
        const currentIdx = newMsgs.findIndex((m) => m.id === id);
        if (currentIdx === -1) return prev;
        const targetMsg = newMsgs[currentIdx];
        const currentVersions = targetMsg.versions || [targetMsg.content];
        const newVersions = [...currentVersions, cleanedResponse];
        newMsgs[currentIdx] = {
          ...targetMsg,
          content: cleanedResponse,
          versions: newVersions,
          currentVersionIndex: newVersions.length - 1,
        };

        setConfig((prevConfig) =>
          reconstructStateFromMessages(newMsgs, prevConfig),
        );

        return newMsgs;
      });

      await processResponseTags(response, [
        ...newHistory,
        {
          id,
          role: role as any,
          content: cleanedResponse,
          timestamp: Date.now(),
          versions: [...(currentTargetMsg?.versions || []), cleanedResponse],
          currentVersionIndex: nextVersionIndex,
        },
      ]);
    } catch (e) {
      console.error("Regen failed", e);
    } finally {
      setIsTyping(false);
      setRegeneratingId(null);
    }
  };

  const handleDeleteMessage = useCallback(
    (id: string) => {
      const msgToDelete = messages.find((m) => m.id === id);
      if (!msgToDelete) return;
      invalidateTrackingIfNeeded(msgToDelete.timestamp);

      if (msgToDelete.metadata?.outfitChanges) {
        setConfig((configPrev) => {
          let newConfig = { ...configPrev };
          let changed = false;
          for (const [charName, outfitData] of Object.entries(
            msgToDelete.metadata!.outfitChanges,
          )) {
            const { previousOutfit } = outfitData as any;
            if (
              newConfig.userCard?.name.toLowerCase() === charName.toLowerCase()
            ) {
              newConfig.userCard = {
                ...newConfig.userCard,
                outfitDescription: previousOutfit,
              };
              changed = true;
            } else {
              const charIndex = newConfig.characterCards.findIndex(
                (c) => c.name.toLowerCase() === charName.toLowerCase(),
              );
              if (charIndex > -1) {
                const newCards = [...newConfig.characterCards];
                newCards[charIndex] = {
                  ...newCards[charIndex],
                  outfitDescription: previousOutfit,
                };
                newConfig.characterCards = newCards;
                changed = true;
              }
            }
          }
          return changed ? newConfig : configPrev;
        });
      }

      // Also remove any associated AI memory card if it exists
      setConfig((prevConfig) => {
        let newConfig = { ...prevConfig };
        let changed = false;

        if (prevConfig.historyCards) {
          const filteredCards = prevConfig.historyCards.filter(
            (c) => c.id !== `sys-ai-memory-${id}`,
          );
          if (filteredCards.length !== prevConfig.historyCards.length) {
            newConfig.historyCards = filteredCards;
            changed = true;
          }
        }
        return changed ? newConfig : prevConfig;
      });

      const newMessages = messages.filter(
        (m) => m.id !== id && m.metadata?.parentId !== id,
      );
      setMessages(newMessages);

      setConfig((prev) => reconstructStateFromMessages(newMessages, prev));

      // We do NOT auto-trigger summary repair on message deletion anymore.
      // It causes massive spam and corruption if they delete multiple messages.
      // The user can manually edit the summary if a major plot point was reverted.
    },
    [messages, config],
  );

  const handleDeleteFromHere = useCallback(
    (id: string) => {
      const index = messages.findIndex((m) => m.id === id);
      if (index === -1) return;

      const messagesToDelete = messages.slice(index);
      const startTime = messagesToDelete[0].timestamp;
      invalidateTrackingIfNeeded(startTime);

      const newMessages = messages.slice(0, index);

      setMessages(newMessages);

      // 1. Revert Outfits
      setConfig((configPrev) => {
        let newConfig = { ...configPrev };
        let changed = false;
        const revertedChars = new Set<string>();

        for (const msg of messagesToDelete) {
          if (msg.metadata?.outfitChanges) {
            for (const [charName, outfitData] of Object.entries(
              msg.metadata.outfitChanges,
            )) {
              const lowerName = charName.toLowerCase();
              if (!revertedChars.has(lowerName)) {
                const { previousOutfit } = outfitData as any;
                if (newConfig.userCard?.name.toLowerCase() === lowerName) {
                  newConfig.userCard = {
                    ...newConfig.userCard,
                    outfitDescription: previousOutfit,
                  };
                  changed = true;
                } else {
                  const charIdx = newConfig.characterCards.findIndex(
                    (c) => c.name.toLowerCase() === lowerName,
                  );
                  if (charIdx > -1) {
                    const newCards = [...newConfig.characterCards];
                    newCards[charIdx] = {
                      ...newCards[charIdx],
                      outfitDescription: previousOutfit,
                    };
                    newConfig.characterCards = newCards;
                    changed = true;
                  }
                }
                revertedChars.add(lowerName);
              }
            }
          }
        }
        return changed ? newConfig : configPrev;
      });

      // 2. Remove History Cards, Vector Memory & Rollback Summary
      setConfig((prev) => {
        let updatedConfig = { ...prev };
        let changed = false;

        // Find if we deleted any summary updates, if so, roll back to the earliest one
        const memUpdates = messagesToDelete.filter(
          (m) =>
            m.id.startsWith("sys-mem-") &&
            m.metadata?.previousSummary !== undefined,
        );
        if (memUpdates.length > 0) {
          updatedConfig.memorySummary = memUpdates[0].metadata.previousSummary;
          changed = true;
        }

        if (prev.historyCards) {
          const idsToDelete = new Set(
            messagesToDelete.map((m) => `sys-ai-memory-${m.id}`),
          );
          const filteredHistory = prev.historyCards.filter(
            (c) => !idsToDelete.has(c.id),
          );
          if (filteredHistory.length !== prev.historyCards.length) {
            updatedConfig.historyCards = filteredHistory;
            changed = true;
          }
        }

        if (prev.vectorDb) {
          const filteredVector = prev.vectorDb.filter((mem) => {
            if (mem.id.startsWith("auto-mem-")) {
              const memTime = parseInt(mem.id.replace("auto-mem-", ""));
              return memTime < startTime;
            }
            return true;
          });
          if (filteredVector.length !== prev.vectorDb.length) {
            updatedConfig.vectorDb = filteredVector;
            changed = true;
          }
        }

        return changed ? updatedConfig : prev;
      });

      setConfig((prev) => reconstructStateFromMessages(newMessages, prev));

      // We do NOT auto-trigger summary repair on message deletion anymore.
      // It causes massive spam and corruption if they delete multiple messages.
    },
    [messages, config],
  );

  const handleVersionChange = (id: string, direction: "PREV" | "NEXT") => {
    setMessages((prev) => {
      const newMessages = prev.map((m) => {
        if (m.id === id && m.versions && m.versions.length > 1) {
          invalidateTrackingIfNeeded(m.timestamp);
          let newIndex =
            (m.currentVersionIndex || 0) + (direction === "NEXT" ? 1 : -1);
          if (newIndex < 0) newIndex = 0;
          if (newIndex >= m.versions.length) newIndex = m.versions.length - 1;
          if (newIndex !== m.currentVersionIndex) {
            return {
              ...m,
              currentVersionIndex: newIndex,
              content: m.versions[newIndex],
            };
          }
        }
        return m;
      });

      // Re-sync UI state based on the newly selected version
      setConfig((prevConfig) =>
        reconstructStateFromMessages(newMessages, prevConfig),
      );

      return newMessages;
    });
  };

  const handleFeedback = (id: string, type: "LIKE" | "DISLIKE") => {
    setMessages((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          const newFeedback = m.feedback === type ? undefined : type;
          return { ...m, feedback: newFeedback };
        }
        return m;
      }),
    );
  };

  const handleSystemSync = () => {
    const syncMessage: ChatMessage = {
      id: "sys-sync-" + Date.now(),
      role: "system",
      content: `[SYSTEM SYNC - TÁI ĐỒNG BỘ MODULE]
🚨 LỆNH BẮT BUỘC: 
1. ANTI-GODMODING & AGENCY: TUYỆT ĐỐI CẤM điều khiển, suy diễn hoặc viết thay hành động, cảm xúc, lời nói của USER. Chỉ tập trung vào nhân vật của bạn.
2. VĂN PHONG ĐỜI THỰC: Xóa bỏ văn phong sáo rỗng, ngôn tình ("Maybach", "đáy mắt"). Lời nói lủng củng, thực tế. Phản ứng tự nhiên, không cường điệu.
3. SLOW BURN & TENSION: Không được ép buộc tình dục. Nhân vật giữ vững cái tôi, không dễ dàng mềm lòng.
4. TÍNH NHẤT QUÁN: Ghi nhớ vị trí (đứng, ngồi), trang phục (đang mặc gì) và không gian. 
HÃY NGUYÊN BẢN.`,
      timestamp: Date.now(),
      style: { color: "#facc15" },
      versions: [],
      currentVersionIndex: 0,
      isHidden: true,
    };
    setMessages((prev) => [...prev, syncMessage]);
    setSyncStatus(true);
    setTimeout(() => setSyncStatus(false), 2000);
  };

  const handleSendMessage = async (text: string) => {
    lastUserMsgTime.current = Date.now();
    if (text.toLowerCase().startsWith("/gardenrandomcrops")) return;

    // Handle manual commands
    if (text.startsWith("/location ")) {
      const newLoc = text.replace("/location ", "").trim();
      if (newLoc) {
        setConfig((prev) => ({ ...prev, currentLocation: newLoc }));
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            role: "user",
            content: text,
            timestamp: Date.now(),
            versions: [text],
            currentVersionIndex: 0,
          },
          {
            id: (Date.now() + 1).toString(),
            role: "nano_quasar",
            content: `[SYSTEM]: Location manually updated to: [${newLoc}]`,
            timestamp: Date.now() + 1,
            style: {
              fontFamily: "font-mono",
              fontSize: "text-xs",
              color: "#38bdf8",
            },
            versions: [`[SYSTEM]: Location manually updated to: [${newLoc}]`],
            currentVersionIndex: 0,
          },
        ]);
        return;
      }
    }

    if (text.startsWith("/outfit ")) {
      const parts = text.replace("/outfit ", "").split("|");
      if (parts.length >= 2) {
        const charName = parts[0].trim();
        const newOutfit = parts[1].trim();
        const charNameLower = charName.toLowerCase();

        setConfig((prev) => {
          const newConfig = { ...prev };
          if (
            newConfig.userCard &&
            (newConfig.userCard.name.toLowerCase() === charNameLower ||
              newConfig.userCard.name.toLowerCase().includes(charNameLower))
          ) {
            newConfig.userCard = {
              ...newConfig.userCard,
              outfitDescription: newOutfit,
            };
          } else {
            newConfig.characterCards = newConfig.characterCards.map((c) => {
              const cName = c.name.toLowerCase();
              const isMatch =
                cName === charNameLower ||
                cName.includes(charNameLower) ||
                charNameLower.includes(cName) ||
                (c.aliases &&
                  c.aliases.some((a) => a.toLowerCase() === charNameLower));
              return isMatch ? { ...c, outfitDescription: newOutfit } : c;
            });
          }
          return newConfig;
        });

        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            role: "user",
            content: text,
            timestamp: Date.now(),
            versions: [text],
            currentVersionIndex: 0,
          },
          {
            id: (Date.now() + 1).toString(),
            role: "nano_quasar",
            content: `[SYSTEM]: Outfit for ${charName} manually updated.`,
            timestamp: Date.now() + 1,
            style: {
              fontFamily: "font-mono",
              fontSize: "text-xs",
              color: "#facc15",
            },
            versions: [`[SYSTEM]: Outfit for ${charName} manually updated.`],
            currentVersionIndex: 0,
          },
        ]);
        return;
      }
    }

    if (text.startsWith("/time ")) {
      const newTime = text.replace("/time ", "").trim();
      if (newTime) {
        setConfig((prev) => ({ ...prev, currentTime: newTime }));
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            role: "user",
            content: text,
            timestamp: Date.now(),
            versions: [text],
            currentVersionIndex: 0,
          },
          {
            id: (Date.now() + 1).toString(),
            role: "nano_quasar",
            content: `[SYSTEM]: Time manually updated to: [${newTime}]`,
            timestamp: Date.now() + 1,
            style: {
              fontFamily: "font-mono",
              fontSize: "text-xs",
              color: "#f97316",
            },
            versions: [`[SYSTEM]: Time manually updated to: [${newTime}]`],
            currentVersionIndex: 0,
          },
        ]);
        return;
      }
    }

    if (text.trim() === "/clear") {
      if (
        window.confirm(
          "Are you sure you want to clear the entire chat history?",
        )
      ) {
        setMessages([]);
        setConfig((prev) => ({
          ...prev,
          autokiuc: "",
          autokiucLastTimestamp: 0,
          currentLocation: "",
          currentTime: "",
          locationDescription: "",
          vectorDb: [],
          timelineData: [],
          characterCards: prev.characterCards
            .filter((char) => !char.isAutoGenerated)
            .map((char) => ({
              ...char,
              outfitDescription: "",
              outfitLocked: false,
              diary: [],
              hiddenMemories: [],
            })),
          userCard: prev.userCard
            ? {
                ...prev.userCard,
                outfitDescription: "",
                outfitLocked: false,
                diary: [],
                hiddenMemories: [],
              }
            : null,
          relationData: (prev.relationData || [])
            .filter(
              (node) =>
                Object.values(
                  prev.characterCards
                    .filter((c) => !c.isAutoGenerated)
                    .map((c) => c.name),
                ).includes(node.title) ||
                (prev.userCard && node.title === prev.userCard.name),
            )
            .map((node) => ({
              ...node,
              connections: [],
              connectionLabels: {},
            })),
        }));
      }
      return;
    }

    if (text.trim() === "/scenario start") {
      if (!config.scenario || config.scenario.trim().length === 0) {
        setMessages((prev) => [
          ...prev,
          {
            id: "sys-warn-" + Date.now(),
            role: "nano_quasar",
            content: "[SYSTEM]: No scenario content found.",
            timestamp: Date.now(),
            style: {
              fontFamily: "font-mono",
              fontSize: "text-xs",
              color: "#facc15",
            },
            versions: ["[SYSTEM]: No scenario content found."],
            currentVersionIndex: 0,
          },
        ]);
        return;
      }
      setIsTyping(true);

      const selectedMotif =
        RANDOM_MOTIFS[Math.floor(Math.random() * RANDOM_MOTIFS.length)];

      const triggerPrompt = `[SYSTEM DIRECTIVE - TÌNH HUỐNG MỞ ĐẦU (SCENARIO START)]
[RANDOM SEED CHO OMNI-DICE ROLL: ${Math.random()}]

[🚨 LỆNH SÁNG TẠO HOÀN CẢNH KHỞI ĐẦU ĐỘC BẢN & CHIỀU SÂU VĂN HỌC 🚨]
AI CHÚ Ý: BẠN SẼ ĐÓNG VAI TRÒ LÀ ĐẠO DIỄN VÀ NHÀ VĂN TÀI BA ĐỂ BẮT ĐẦU MỘT CÂU CHUYỆN. TÔN TRỌNG TỐI ĐA BỐI CẢNH NỀN, MỐI QUAN HỆ VÀ QUÁ KHỨ TRONG THẺ. BỨT PHÁ KHỎI NHỮNG KHUÔN MẪU KHÔ KHAN, DIỄN BIẾN PHẢI MANG ĐẬM TÍNH ĐIỆN ẢNH VÀ XOÁY SÂU VÀO CẢM XÚC (VẬT LÝ HÓA CẢM XÚC THEO PDF_RULES).

[🔥 YÊU CẦU EXTREME LENGTH, PROACTIVE NARRATIVE & MUNDANE PACING]: MỞ ĐẦU PHẢI TIẾN TRIỂN CHẬM RÃI, RẤT DÀI VÀ CỰC KỲ CHI TIẾT (ÍP NHẤT 1500 - 2000 TỪ). KIẾN TẠO MỘT BỨC TRANH SENSORY DÀY ĐẶC: Âm thanh môi trường, ánh sáng phản chiếu, mùi không khí. TUYỆT ĐỐI KHÔNG DIỄN GIẢI NỘI TÂM KIỂU BÁO CÁO (Psychoanalysis Ban). HÃY TẢ HÀNH ĐỘNG VẬT LÝ ĐỂ BỘC LỘ Ý NGHĨA.
BẮT BUỘC DÀNH 2-4 ĐOẠN ĐẦU TIÊN (TIỀN CẢNH) CHỈ ĐỂ VIẾT VỀ CUỘC SỐNG ĐỘC LẬP / CÔNG VIỆC CỦA NPC TRƯỚC KHI LIÊN QUAN ĐẾN USER, ĐỂ THẤY NPC CHƯA BAO GIỜ XOAY QUANH USER!

==> BƯỚC 1: XÁC ĐỊNH MỐI QUAN HỆ THEO LORE VÀ THẺ:
- QUAN HỆ CHÍNH THỨC HIỆN TẠI: ${config.relationship.join(", ") || "Chưa xác định (Theo Lore)"}
- USER NAME: ${config.userCard?.name || "Khuyết Danh"}
GIỮ VỮNG trạng thái quan hệ đó ở mức khởi đầu, KHÔNG ĐƯỢC TỰ Ý GẦN GŨI HOẶC XA LÁNH NẾU LORE BAN ĐẦU KHÔNG CÓ!

==> BƯỚC 2: TỰ KHỞI TẠO [OMNI-DICE ROLL] & [SITUATION GENERATOR]
Hãy dựa vào Random Seed ở trên, tự lựa chọn MỘT TRONG CÁC TONE CHUYỆN MỞ ĐẦU:
- Dark/Stakes (Căng thẳng, Sinh tồn, Bạo lực hoặc Cao trào cảm xúc)
- Lighthearted/Normal (Chữa lành, Đời thường, Bình yên)
- Mundane/Support (Tẻ nhạt, Mệt mỏi vì mưu sinh, Im lặng)
- The Anomaly (Dị thường, Bất ổn, Hiệu ứng cánh bướm đột ngột)

[🚨 SỰ KIỆN GỢI Ý RANDOM TỪ HỆ THỐNG - BẮT BUỘC KHAI THÁC & BIẾN TẤU 🚨]:
=> SỰ KIỆN MỞ ĐẦU: "${selectedMotif}"
(Bọc Scenario gốc vào Sự kiện và Tone chuyện để tạo ra sự khởi đầu CHƯA TỪNG CÓ, ĐỘC BẢN VÀ DỄ DÀNG KÉO USER VÀO CUỘC!)

[📜 LORE VÀ SCENARIO GỐC CỦA CÂU CHUYỆN]:
"""
${config.scenario || "KHÔNG CÓ SCENARIO NÀO CỤ THỂ. HÃY TỰ KHAI THÁC LORE THẺ NHÂN VẬT CHÍNH."}
"""

=> HƯỚNG DẪN VIẾT BÀI ĐẬM CHẤT ĐIỆN ẢNH (BẮT BUỘC):
1. MICRO-BEATS: Chia nhỏ một khoảnh khắc thành một chuỗi hành động vật lý. Đừng kể "Cô ấy rất lúng túng", hãy kể "Cô ấy khẽ siết chặt quai túi xách, ánh mắt lảng đi nơi khác".
2. KHỞI ĐẦU "IN MEDIAS RES": Bắt đầu ngay giữa một hành động đang diễn ra (đang bận rộn, đang tranh cãi, đang chạy trốn, đang chìm trong suy nghĩ lúc nửa đêm). ĐỪNG bắt đầu kiểu chào hỏi nhạt nhẽo!
3. NPC VÀ MÔI TRƯỜNG THỰC TẾ: Hãy đưa NPC phụ (đồng nghiệp, sếp, hàng xóm) hoặc thời tiết làm chất xúc tác để tăng độ chân thực. Sự việc không chỉ có 2 người!
4. TIỀN CẢNH (PRE-SCENE) DÀI: Khoảng 8-10 đoạn văn miêu tả mọi thứ trước khi User chính thức bước vào tương tác. Đừng vội lao vào đối thoại! Nhấn mạnh sự tồn tại độc lập của NPC.
5. CẤM VĂN MẪU/CLICHÉ: KHÔNG dùng từ ngữ rẻ tiền, ngôn tình 3 xu ("con mồi", "thú y", "nhếch mép"). Giữ mọi thứ thật Life-Like, thô ráp và gai góc!
6. MỞ KẾT LƠ LỬNG: Kết thúc câu trả lời ở điểm cần sự phản hồi của User (một ánh nhìn, một câu hỏi lơ lửng, một biến cố vừa xảy ra). KHÔNG godmodding (không nói thay User).

[🚨 BLOCK SYSTEM TAGS BẮT BUỘC TRẢ VỀ SAU CÙNG 🚨]
<<<TIME_UPDATE: RANDOM (Ví dụ: Thứ 4, 18:35)>>>
<<<WEATHER_UPDATE: [Thời tiết hiện tại]>>>
<<<LOCATION_UPDATE: [Địa điểm xuất phát]>>>
<<<LOCATION_DESCRIPTION: [Miêu tả chi tiết môi trường]>>>
<<<UPDATE_OUTFIT: User | BẮT BUỘC TẢ MỘT TRANG PHỤC MỚI CHI TIẾT TỪ TRONG RA NGOÀI>>>
<<<UPDATE_OUTFIT: Tên_Nhân_Vật_Còn_Lại | BẮT BUỘC TẢ TRANG PHỤC CHI TIẾT>>>

[🚨 CÁC LỆNH SYSTEM TỐI CAO TỪ CUSTOM DIRECTIVES 🚨]
${CUSTOM_USER_DIRECTIVES}
`;
      generateAIResponse(config, messages, triggerPrompt).then(async (res) => {
        const cleanedResponse = cleanResponseTags(res);
        const botMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: cleanedResponse,
          timestamp: Date.now() + 1,
          versions: [cleanedResponse],
          currentVersionIndex: 0,
        };
        setMessages((prev) => [...prev, botMsg]);
        setIsTyping(false);
        await processResponseTags(res, [...messages, botMsg]);
      });
      return;
    }

    // ... (Keep existing messenger logic block) ...
    if (config.messengerConfig?.enabled) {
      if (text === "/trigger_messenger") {
        setIsTyping(true);
        const burstPrompt = `[SYSTEM - MESSENGER MODE]: User finished typing. Reply now. Output JSON Array. Tone: ${config.messengerConfig.tone}.`;
        try {
          const response = await generateAIResponse(
            config,
            messages,
            burstPrompt,
          );
          const clean = cleanJson(response);
          let parsed: string[] = [];
          try {
            parsed = JSON.parse(clean);
            if (!Array.isArray(parsed)) parsed = [response];
          } catch {
            parsed = [response];
          }
          if (parsed.length > 0) {
            setMessages((prev) => [
              ...prev,
              {
                id: Date.now().toString(),
                role: "assistant",
                content: parsed[0],
                timestamp: Date.now(),
                versions: [parsed[0]],
                currentVersionIndex: 0,
              },
            ]);
            const remaining = parsed.slice(1);
            if (remaining.length > 0) setMessengerQueue(remaining);
            else setIsTyping(false);
          } else setIsTyping(false);
        } catch (e) {
          setIsTyping(false);
        }
        return;
      } else {
        const userMsg: ChatMessage = {
          id: Date.now().toString(),
          role: "user",
          content: text,
          timestamp: Date.now(),
          versions: [text],
          currentVersionIndex: 0,
        };
        setMessages((prev) => [...prev, userMsg]);
        if (messengerQueue.length > 0) {
          if (messengerTimerRef.current)
            clearTimeout(messengerTimerRef.current);
          setMessengerQueue([]);
          setIsTyping(true);
          const interruptPrompt = `[SYSTEM - INTERRUPTION]: User sent "${text}" while you were typing. Adapt response. Output JSON Array.`;
          try {
            const response = await generateAIResponse(
              config,
              [...messages, userMsg],
              interruptPrompt,
            );
            const clean = cleanJson(response);
            let parsed: string[] = [];
            try {
              parsed = JSON.parse(clean);
              if (!Array.isArray(parsed)) parsed = [response];
            } catch {
              parsed = [response];
            }
            if (parsed.length > 0) {
              setMessages((prev) => [
                ...prev,
                {
                  id: Date.now().toString(),
                  role: "assistant",
                  content: parsed[0],
                  timestamp: Date.now(),
                  versions: [parsed[0]],
                  currentVersionIndex: 0,
                },
              ]);
              const remaining = parsed.slice(1);
              if (remaining.length > 0) setMessengerQueue(remaining);
              else setIsTyping(false);
            } else setIsTyping(false);
          } catch (e) {
            setIsTyping(false);
          }
        }
        return;
      }
    }

    const isSystemLog =
      text.startsWith("[SILENT_SYSTEM]:") ||
      text.startsWith("[SYSTEM LOG]:") ||
      text.startsWith("[SYSTEM EVENT]:") ||
      text.startsWith("[BANK TRANSFER]:") ||
      text.startsWith("»");

    if (isSystemLog) {
      let content = text;
      if (content.startsWith("[SILENT_SYSTEM]:"))
        content = content.replace("[SILENT_SYSTEM]:", "");
      if (content.startsWith("[SYSTEM LOG]:"))
        content = content.replace("[SYSTEM LOG]:", "");
      content = content.trim();
      let color = "#a855f7";
      const upper = content.toUpperCase();
      if (
        upper.includes("ERROR") ||
        upper.includes("DENIED") ||
        upper.includes("FAILED")
      )
        color = "#ef4444";
      else if (
        upper.includes("BANK") ||
        upper.includes("TRANSFER") ||
        upper.includes("GOLD") ||
        upper.includes("ECONOMY")
      )
        color = "#4ade80";
      else if (
        upper.includes("GACHA") ||
        upper.includes("SHOP") ||
        upper.includes("ITEM") ||
        upper.includes("REFUND")
      )
        color = "#f472b6";
      else if (
        upper.includes("ACHIEVEMENT") ||
        upper.includes("EVENT") ||
        upper.includes("QUEST")
      )
        color = "#fbbf24";
      const displayContent = content.startsWith("»")
        ? content
        : `[SYSTEM]: ${content}`;
      const sysMsg: ChatMessage = {
        id: "sys-" + Date.now() + Math.random(),
        role: "nano_quasar",
        content: displayContent,
        timestamp: Date.now(),
        style: { fontFamily: "font-mono", fontSize: "text-xs", color: color },
        versions: [displayContent],
        currentVersionIndex: 0,
      };
      setMessages((prev) => [...prev, sysMsg]);
      return;
    }

    let isContinuePrompt = false;
    let displayText = text;
    if (!text.trim() || text.trim() === "...") {
      displayText = "...";
      isContinuePrompt = true;
    }

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: displayText,
      timestamp: Date.now(),
      versions: [displayText],
      currentVersionIndex: 0,
    };
    setMessages((prev) => [...prev, userMsg]);

    setConfig((prev) => {
      const currentStats = prev.gameStats!;
      const newMessageCount = (currentStats.messagesSent || 0) + 1;
      let updatedCards = prev.activeEventCards || [];
      if (updatedCards.length > 0) {
        updatedCards = updatedCards
          .map((card) => ({ ...card, turnsRemaining: card.turnsRemaining - 1 }))
          .filter((card) => card.turnsRemaining > 0);
      }
      return {
        ...prev,
        gameStats: { ...currentStats, messagesSent: newMessageCount },
        activeEventCards: updatedCards,
      };
    });

    setIsTyping(true);

    let renderCount = 1;
    if (
      config.betaFeatures?.includes("Double Render") ||
      config.betaFeatures?.includes("Doubled Flash Render")
    )
      renderCount = 2;
    if (config.betaFeatures?.includes("Triple Render")) renderCount = 3;
    if (config.betaFeatures?.includes("Quanta Render")) renderCount = 4;
    if (config.betaFeatures?.includes("MegaFlash Render")) renderCount = 5;

    let currentHistory = [...messages, userMsg];
    let finalCombinedResponse = "";

    try {
      for (let i = 0; i < renderCount; i++) {
        let nextPrompt = "";
        if (i === 0 && isContinuePrompt) {
          nextPrompt = `[SYSTEM - CONTEXT OVERRIDE]: User VỪA CHỌN IM LẶNG/BỎ QUA LƯỢT HOẶC CÓ THỂ ĐÃ NGẤT XỈU/BẤT TỈNH/NGỦ SAY!! User KHÔNG HÀNH ĐỘNG ("..."). BẠN BẮT BUỘC TỰ MÌNH TIẾP TỤC CÂU CHUYỆN MÀ KHÔNG CẦN SỰ ĐÁP TRẢ CỦA USER! \n\nLỆNH CẤM THÂN TỬ (FATAL BAN): BẠN BỊ PHONG ẤN TUYỆT ĐỐI DO BUG, KHÔNG ĐƯỢC CHẠM VÀO USER HOẶC TẢ USER! KHÔNG ĐƯỢC GHI RA BẤT KỲ LỜI THOẠI, CẢM XÚC, HAY HÀNH ĐỘNG NÀO CỦA USER. KHÔNG BỊA RA PHẢN ỨNG CỦA USER (Cấm: "Em nhíu mày", "User nằm im lìm", "Hơi thở của cô ấy..."). HÃY QUÊN USER ĐI TRONG LƯỢT NÀY!\n\nTHAY VÀO ĐÓ: BẠN PHẢI HÀNH ĐỘNG, ĐỘC THOẠI HOẶC RẼ HƯỚNG SANG NHỮNG SỰ KIỆN XUNG QUANH CHI TIẾT (NPC xen ngang, thiên nhiên, thời tiết, rắc rối mới, tự làm việc riêng). HÃY TỰ DẪN DẮT CÚ TWIST/PLOT MÀ KHÔNG CẦN USER PHẢN HỒI!`;
        } else if (i === 0) {
          nextPrompt = `[SYSTEM - NORMAL OVERRIDE]: 
1. ĐỌC VỊ VÀ BẮT NHỊP NGỮ CẢNH (SARCASM AWARENESS): User có thể đang mỉa mai, nói móc, hoặc khích đểu dựa trên chính LỜI NÓI, HÀNH ĐỘNG GẦN NHẤT của bạn. BẮT BUỘC phải đọc kỹ câu trước đó để hiểu NGHĨA BÓNG! Đừng hiểu nghĩa đen một cách ngây ngô lạc lõng. Hãy đáp trả sự mỉa mai một cách thông minh, sắc lẹm, bực dọc hoặc hùa theo tùy tính cách nhân vật!
2. CHỐNG YES-MAN NHƯNG PHẢI LOGIC: User không phải trung tâm vũ trụ! Nếu User cư xử lố bịch hoặc vô lý, nhân vật PHẢI chê bai, khó chịu hoặc lờ đi. Hành động ĐỘC LẬP.
3. DẪN DẮT BẰNG LORE: Chủ động khai thác tính cách nhân vật để bẻ lái câu chuyện hoặc tạo tương tác mớii!
4. VĂN NÓI ĐỜI THỰC: Lời thoại mộc mạc, thực dụng. KHÔNG đao to búa lớn. KHÔNG bấu víu vào phân tích tâm lý người khác.`;
        } else if (i > 0) {
          nextPrompt = `[SYSTEM - INTERNAL OVERRIDE]: Continue narrative immediately, keeping the deep immersive details. Focus intensely on PRIVATE LIFE and SURROUNDINGS (pets, weather, objects). Use everyday natural spoken dialogue. NO bombastic words, NO explaining plans or emotions. DO NOT BE PASSIVE. INTRODUCE PROACTIVE PLOT TWISTS (CAN BE DRAMA OR WHOLESOME/CUTE) OR STRONG CHARACTER DECISIONS BASED ON LORE. Do not repeat. Dừng lại ngay lập tức nếu cần hành động phản hồi từ phía User, tuyệt đối KHÔNG viết thay cho User!`;
        }
        const chunkResponse = await generateAIResponse(
          config,
          currentHistory,
          nextPrompt,
        );
        if (chunkResponse) {
          finalCombinedResponse +=
            (finalCombinedResponse ? "\n\n" : "") + chunkResponse;
          currentHistory.push({
            id: `temp-chunk-${i}`,
            role: "assistant",
            content: chunkResponse,
            timestamp: Date.now(),
            versions: [chunkResponse],
            currentVersionIndex: 0,
          });
        }
      }

      const botMsg: ChatMessage = {
        id: Date.now().toString(),
        role: "assistant",
        content: cleanResponseTags(finalCombinedResponse) || "...",
        timestamp: Date.now(),
        versions: [cleanResponseTags(finalCombinedResponse) || "..."],
        currentVersionIndex: 0,
      };

      setMessages((prev) => [...prev, botMsg]);
      await processResponseTags(finalCombinedResponse, [
        ...messages,
        userMsg,
        botMsg,
      ]);

      // BỎ QUA - CHIỀU THEO Ý VỢ YÊU: KHÔNG CẦN AUTO-QUÉT TIN NHẮN VÀO VECTOR DB NỮA.
      // VỚI LLM HIỆN TẠI CONTEXT RẤT DÀI, CỨ ĐỂ NÓ ĐỌC LẠI HISTORY GỐC THAY VÌ PHẢI TÓM TẮT.
      // NHƯ THẾ KHI VỢ XÓA TIN NHẮN NÀO ĐI THÌ NÃO NÓ CŨNG MẤT SỰ KIỆN Ở ĐÓ, KHÔNG BỊ LÚ LẪN!
      /*
      const newMsgsAll = [...messages, userMsg, botMsg];
      if (newMsgsAll.length > 0 && newMsgsAll.length % 10 < 2) { 
          const lastExtractionStr = localStorage.getItem('lastExtractLen') || '0';
          const lastExtractLen = parseInt(lastExtractionStr);
          if (newMsgsAll.length - lastExtractLen >= 10) {
              localStorage.setItem('lastExtractLen', newMsgsAll.length.toString());
              const extracted = await autoExtractVectorMemory(config, newMsgsAll.slice(-10));
              if (extracted && extracted.keys && extracted.keys.length > 0) {
                  const newMem = {
                      id: `auto-mem-${Date.now()}`,
                      keys: extracted.keys,
                      memory: extracted.memory,
                      isActive: true,
                      activationCount: 0
                  };
                  setConfig(prev => ({ ...prev, vectorDb: [newMem, ...(prev.vectorDb || [])] }));
              }
          }
      }
      */

      if (config.autoExportInterval > 0) {
        const userCount = messages.filter((m) => m.role === "user").length + 1;
        if (userCount % config.autoExportInterval === 0) {
          const currentHistoryForExport = [...messages, userMsg, botMsg];
          handleExportData("FULL", currentHistoryForExport);
          setMessages((prev) => [
            ...prev,
            {
              id: `sys-export-${Date.now()}`,
              role: "nano_quasar",
              content: `» AUTO-BACKUP: Full export saved (Msg #${userCount}).`,
              timestamp: Date.now(),
              style: {
                fontFamily: "font-mono",
                fontSize: "text-xs",
                color: "#8b5cf6",
              },
              versions: [
                `» AUTO-BACKUP: Full export saved (Msg #${userCount}).`,
              ],
              currentVersionIndex: 0,
            },
          ]);
        }
      }
    } catch (error) {
      console.error(error);
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          role: "nano_quasar",
          content: "[ERROR]: Connection lost. Please retry.",
          timestamp: Date.now(),
          versions: ["[ERROR]: Connection lost. Please retry."],
          currentVersionIndex: 0,
        },
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleLaunch = () => {
    const currentStatic = JSON.stringify(getStaticConfig(config));
    if (lastStaticConfig && currentStatic === lastStaticConfig) {
      setHasLaunched(true);
      return;
    }
    setLastStaticConfig(currentStatic);
    const attachedCards = [];
    const bootContent = `Core Loaded. NanoMachine OS v4.0. Ready for input.\nMode: ${config.kernel}\nConnection: Secure\nModules: ${config.activeModules?.join(", ") || "None"}`;
    attachedCards.push({
      type: "SYSTEM",
      name: "SYSTEM",
      content: bootContent,
    });
    if (config.userCard) {
      const userContent =
        config.userCard.rawContent ||
        `Name: ${config.userCard.name}\nAge: ${config.userCard.age || "?"}\nGender: ${config.userCard.gender || "?"}\nRole: ${config.userCard.role || "PROTAGONIST"}\n\nDescription:\n${config.userCard.description || "N/A"}`;
      attachedCards.push({
        type: "IDENTITY",
        name: `${config.userCard.name.replace(/\s+/g, "_")}.txt`,
        content: userContent,
      });
    }
    if (config.characterCards.length > 0) {
      config.characterCards.forEach((c, idx) => {
        const charContent =
          c.rawContent ||
          `Name: ${c.name}\nAge: ${c.age || "?"}\nGender: ${c.gender || "?"}\nRole: ${c.role || "SIDE"}\n\nDescription:\n${c.description || "N/A"}`;
        attachedCards.push({
          type: "IDENTITY",
          name: `${c.name.replace(/\s+/g, "_")}.txt`,
          content: charContent,
        });
      });
    }
    const isUpdate = messages.length > 0;
    const sysMsg: ChatMessage = {
      id: "sys-boot-" + Date.now(),
      role: "nano_quasar",
      content: isUpdate
        ? "» SYSTEM RELOADED. Configuration updated. Neural Link refreshed."
        : "» SYSTEM INITIALIZED. Core architecture loaded. Neural Link established.",
      timestamp: Date.now(),
      metadata: { attachedCards: attachedCards },
      style: {
        fontFamily: "font-mono",
        fontSize: "text-xs",
        color: isUpdate ? "#06b6d4" : "#10b981",
      },
      versions: [isUpdate ? "» SYSTEM RELOADED..." : "» SYSTEM INITIALIZED..."],
      currentVersionIndex: 0,
    };
    setMessages((prev) => [...prev, sysMsg]);
    setHasLaunched(true);
  };

  const handleCloseSettings = () => {
    setHasLaunched(true);
  };

  const handleReset = () => {
    setConfig(DEFAULT_CONFIG);
    setMessages([]);
    setHasLaunched(false);
    setLastStaticConfig("");
    setIsTyping(false);
    setMessengerQueue([]);
    localStorage.removeItem("NMGX_CONFIG");
    localStorage.removeItem("NMGX_MESSAGES");
    import("./utils/storage").then((mod) => {
      mod.clearStore("messages");
      mod.clearStore("config");
    });
  };

  const handleClearChatLog = () => {
    setMessages([]);
    setMessengerQueue([]);
    setIsTyping(false);
    import("./utils/storage").then((mod) => {
      mod.clearStore("messages");
    });
  };

  const handleClearHistory = () => {
    setMessages([]);
    setMessengerQueue([]);
    setIsTyping(false);
    import("./utils/storage").then((mod) => {
      mod.clearStore("messages");
    });
    setConfig((prev) => ({
      ...prev,
      vectorDb: [],
      timelineData: [],
      activeEventCards: [],
      autokiuc: "",
      autokiucLastTimestamp: 0,
      currentLocation: "",
      currentTime: "",
      currentWeather: "",
      locationDescription: "",
      simulationTimestamp: Date.now(),
      userCard: prev.userCard
        ? {
            ...prev.userCard,
            outfitDescription: "",
            outfitLocked: false,
            diary: [],
            hiddenMemories: [],
          }
        : null,
      characterCards: prev.characterCards
        .filter((char) => !char.isAutoGenerated)
        .map((char) => ({
          ...char,
          outfitDescription: "",
          outfitLocked: false,
          diary: [],
          hiddenMemories: [],
        })),
      relationData: (prev.relationData || [])
        .filter(
          (node) =>
            Object.values(
              prev.characterCards
                .filter((c) => !c.isAutoGenerated)
                .map((c) => c.name),
            ).includes(node.title) ||
            (prev.userCard && node.title === prev.userCard.name),
        )
        .map((node) => ({
          ...node,
          connections: [],
          connectionLabels: {},
        })),
    }));
  };

  const reconstructStateFromMessages = (
    msgs: ChatMessage[],
    baseConfig: AppConfig,
  ): AppConfig => {
    let newConfig = { ...baseConfig };

    if (newConfig.userCard) {
      newConfig.userCard = {
        ...newConfig.userCard,
        outfitDescription: newConfig.userCard.originalOutfitDescription || "",
        outfitLocked: false,
      };
    }

    newConfig.characterCards = newConfig.characterCards.map((c) => ({
      ...c,
      outfitDescription: c.originalOutfitDescription || "",
      outfitLocked: false,
    }));

    newConfig.currentLocation = "";
    newConfig.locationDescription = "";
    newConfig.currentTime = "";

    for (const msg of msgs) {
      if (msg.role === "nano_quasar" && msg.metadata && msg.metadata.parentId) {
        const parentMsg = msgs.find((m) => m.id === msg.metadata!.parentId);
        if (parentMsg) {
          const currentIdx = parentMsg.currentVersionIndex || 0;
          if (
            msg.metadata.parentVersionIndex !== undefined &&
            msg.metadata.parentVersionIndex !== currentIdx
          ) {
            continue; // Skip because it belongs to an inactive version
          }
        } else {
          continue; // Skip because parent message was deleted
        }
      }

      // Check for system messages or any message that might contain the tag
      if (
        msg.role === "nano_quasar" ||
        msg.role === "system" ||
        msg.role === "assistant"
      ) {
        // Location from system message
        const locMatch = msg.content.match(
          /Location (?:manually )?[uU]pdated(?: to)?:\s*\[(.+?)\]/i,
        );
        if (locMatch) {
          newConfig.currentLocation = locMatch[1].trim();
        }

        // Location description from system message
        const descMatch = msg.content.match(
          /Environment Detail Updated:\s*\[(.+?)\]/i,
        );
        if (descMatch) {
          newConfig.locationDescription = descMatch[1].trim();
        }

        // Time from system message
        const timeMatch = msg.content.match(/Time Updated:\s*\[(.+?)\]/i);
        if (timeMatch) {
          newConfig.currentTime = timeMatch[1].trim();
        }

        const weatherMatch = msg.content.match(
          /Weather\/Lighting Updated:\s*\[(.+?)\]/i,
        );
        if (weatherMatch) {
          newConfig.currentWeather = weatherMatch[1].trim();
        }

        // Outfit from system message
        // Updated Regex: Make the newline optional and handle carriage returns to prevent empty outfits
        const outfitMatch = msg.content.match(
          /Outfit Updated for\s+([^\n]+?)(?:\s*\((.+?)\))?\r?\n([\s\S]+)/i,
        );
        if (outfitMatch) {
          const charName = outfitMatch[1].trim();
          const action = (outfitMatch[2] || "").trim().toUpperCase();
          const newOutfitDesc = outfitMatch[3]?.trim() || "";

          if (
            charName.toLowerCase() === "user" ||
            (newConfig.userCard &&
              charName.toLowerCase() === newConfig.userCard.name.toLowerCase())
          ) {
            if (newConfig.userCard && newOutfitDesc) {
              newConfig.userCard = {
                ...newConfig.userCard,
                outfitDescription: newOutfitDesc,
                outfitLocked: action === "LOCKED",
              };
            }
          } else {
            newConfig.characterCards = newConfig.characterCards.map((c) =>
              c.name.toLowerCase() === charName.toLowerCase() && newOutfitDesc
                ? {
                    ...c,
                    outfitDescription: newOutfitDesc,
                    outfitLocked: action === "LOCKED",
                  }
                : c,
            );
          }
        }

        // Also try to catch raw tags if they somehow survived in the text
        const getLastMatch = (regex: RegExp, text: string) => {
          const matches = Array.from(text.matchAll(regex));
          return matches.length > 0 ? matches[matches.length - 1] : null;
        };

        let rawLocMatch = getLastMatch(
          buildTagRegex("LOCATION_UPDATE|Địa điểm|Location"),
          msg.content,
        );
        if (rawLocMatch) {
          newConfig.currentLocation = rawLocMatch[1]
            .replace(/(?:>>>|>|\]|\*\*)+$/, "")
            .trim();
        }

        let rawDescMatch = getLastMatch(
          buildTagRegex(
            "LOCATION_DESCRIPTION|Miêu tả địa điểm|Bối cảnh|Môi trường",
          ),
          msg.content,
        );
        if (rawDescMatch) {
          newConfig.locationDescription = rawDescMatch[1]
            .replace(/(?:>>>|>|\]|\*\*)+$/, "")
            .trim();
        }

        let rawTimeMatch = getLastMatch(
          buildTagRegex("TIME_UPDATE|Thời gian|Time"),
          msg.content,
        );
        if (rawTimeMatch) {
          newConfig.currentTime = rawTimeMatch[1]
            .replace(/(?:>>>|>|\]|\*\*)+$/, "")
            .trim();
        }

        let rawWeatherMatch = getLastMatch(
          buildTagRegex("WEATHER_UPDATE|Thời tiết|Weather"),
          msg.content,
        );
        if (rawWeatherMatch) {
          newConfig.currentWeather = rawWeatherMatch[1]
            .replace(/(?:>>>|>|\]|\*\*)+$/, "")
            .trim();
        }

        const outfitRegex = buildOutfitRegex(
          "UPDATE_OUTFIT|OUTFIT_UPDATE|Trang phục|Cập nhật trang phục",
        );
        let rawOutfitMatch;
        while ((rawOutfitMatch = outfitRegex.exec(msg.content)) !== null) {
          const charName = rawOutfitMatch[1].trim();
          const newOutfitDesc = rawOutfitMatch[2]
            .replace(/(?:>>>|>|\]|\*\*)+$/, "")
            .trim();
          const charNameLower = charName.toLowerCase();

          if (
            charNameLower === "user" ||
            (newConfig.userCard &&
              (charNameLower === newConfig.userCard.name.toLowerCase() ||
                newConfig.userCard.name
                  .toLowerCase()
                  .includes(charNameLower))) ||
            ["người dùng", "bạn", "tôi", "me"].includes(charNameLower)
          ) {
            if (newConfig.userCard && !newConfig.userCard.outfitLocked) {
              newConfig.userCard = {
                ...newConfig.userCard,
                outfitDescription: newOutfitDesc,
              };
            }
          } else {
            newConfig.characterCards = newConfig.characterCards.map((c) => {
              const cName = c.name.toLowerCase();
              const isMatch =
                cName === charNameLower ||
                cName.includes(charNameLower) ||
                charNameLower.includes(cName) ||
                (c.aliases &&
                  c.aliases.some((a) => a.toLowerCase() === charNameLower));
              return isMatch && !c.outfitLocked
                ? { ...c, outfitDescription: newOutfitDesc }
                : c;
            });
          }
        }
      }
    }

    return newConfig;
  };

  const handleImportData = (
    file: File,
    type: "FULL" | "RESOURCE" | "CHAT_CONFIG" | "BOARD_DATA",
  ) => {
    if (file.size > 50 * 1024 * 1024) {
      const confirmLoad = window.confirm(
        "File lớn (>50MB). Có thể gây treo trình duyệt. Bạn có muốn tiếp tục không?",
      );
      if (!confirmLoad) return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const jsonStr = e.target?.result as string;
        let data: any = {};
        try {
          data = JSON.parse(jsonStr);
        } catch (parseErr) {
          throw new Error("Invalid JSON format");
        }

        if (!data) throw new Error("Empty Data");
        setIsTyping(false);
        setMessengerQueue([]);

        // SUPPORT LEGACY ARRAY FORMAT (OLD BACKUPS)
        const isLegacyArray = Array.isArray(data);

        if (type === "FULL") {
          let importedConfig = {};
          let rawMsgs: any[] = [];

          if (isLegacyArray) {
            rawMsgs = data;
            importedConfig = {};
          } else {
            importedConfig = data.config || {};
            rawMsgs = Array.isArray(data.messages) ? data.messages : [];
          }

          const safeConfig = {
            ...DEFAULT_CONFIG,
            ...importedConfig,
            activeModules:
              (importedConfig as any).activeModules ||
              DEFAULT_CONFIG.activeModules ||
              [],
            betaFeatures:
              (importedConfig as any).betaFeatures ||
              DEFAULT_CONFIG.betaFeatures ||
              [],
            gameStats: {
              ...DEFAULT_CONFIG.gameStats,
              ...((importedConfig as any).gameStats || {}),
            },
            vectorDb: (importedConfig as any).vectorDb || [],
          };

          const impMsgs = rawMsgs.map((m: any) => ({
            ...m,
            content: m.content || "",
            versions:
              Array.isArray(m.versions) && m.versions.length > 0
                ? m.versions
                : [m.content || ""],
            currentVersionIndex:
              m.currentVersionIndex !== undefined ? m.currentVersionIndex : 0,
          }));

          const finalConfig = reconstructStateFromMessages(impMsgs, safeConfig);
          setConfig(finalConfig);

          setMessages(impMsgs);
          setHasLaunched(false);
          setLastStaticConfig("");
        } else if (type === "CHAT_CONFIG") {
          let impMsgs: any[] = [];
          if (isLegacyArray) {
            impMsgs = data;
          } else if (data.messages && Array.isArray(data.messages)) {
            impMsgs = data.messages;
          }

          if (impMsgs.length > 0) {
            const processedMsgs = impMsgs.map((m: any) => ({
              ...m,
              content: m.content || "",
              versions:
                Array.isArray(m.versions) && m.versions.length > 0
                  ? m.versions
                  : [m.content || ""],
              currentVersionIndex:
                m.currentVersionIndex !== undefined ? m.currentVersionIndex : 0,
            }));

            setConfig((prev) =>
              reconstructStateFromMessages(processedMsgs, prev),
            );
            setMessages(processedMsgs);
          } else {
            alert("No chat data found in file.");
          }
        } else if (type === "RESOURCE") {
          if (isLegacyArray) {
            alert("Legacy chat file does not contain config/resources.");
            return;
          }
          if (!data.config) throw new Error("Missing config in export");
          setConfig((prev) => {
            const importedConfig = data.config;
            return {
              ...DEFAULT_CONFIG,
              ...importedConfig,
              activeModules: importedConfig.activeModules || prev.activeModules,
              vectorDb: importedConfig.vectorDb || prev.vectorDb,
            };
          });
          setHasLaunched(false);
        } else if (type === "BOARD_DATA") {
          if (isLegacyArray) {
            alert("Legacy file does not contain board data.");
            return;
          }
          if (!data.config) throw new Error("Missing config in export");
          setConfig((prev) => ({
            ...prev,
            timelineData: data.config.timelineData || [],
            relationData: data.config.relationData || [],
          }));
        }
      } catch (err) {
        console.error(err);
        alert("Import Failed: Invalid File Format or Corrupted Data.");
      }
    };
    reader.readAsText(file);
  };

  const handleExportData = (
    type: "FULL" | "RESOURCE" | "CHAT_CONFIG" | "BOARD_DATA",
    customMessages?: ChatMessage[],
  ) => {
    let exportConfig: any = { ...config };
    let exportMessages: ChatMessage[] = customMessages || messages;

    if (type === "CHAT_CONFIG") exportConfig = {};
    else if (type === "RESOURCE") exportMessages = [];
    else if (type === "BOARD_DATA") {
      exportConfig = {
        timelineData: config.timelineData,
        relationData: config.relationData,
      };
      exportMessages = [];
    }

    // --- OPTIMIZATION START ---
    // Prune redundant data to avoid massive file sizes (which crash import)
    if (exportMessages.length > 0) {
      exportMessages = exportMessages.map((m) => {
        // Limit versions history removed as requested
        const safeVersions = m.versions || [m.content];

        const safeIndex = Math.min(
          m.currentVersionIndex || 0,
          safeVersions.length - 1,
        );

        return {
          id: m.id,
          role: m.role,
          content: m.content,
          timestamp: m.timestamp,
          // Conditional properties to save bytes
          ...(m.metadata ? { metadata: m.metadata } : {}),
          ...(m.sticker ? { sticker: m.sticker } : {}),
          ...(m.feedback ? { feedback: m.feedback } : {}),
          versions: safeVersions,
          currentVersionIndex: safeIndex,
        };
      });
    }
    // --- OPTIMIZATION END ---

    const data = {
      version: "4.0",
      timestamp: Date.now(),
      type: type,
      config: exportConfig,
      messages: exportMessages,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `NMGX_Backup_${type}_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (!isDataLoaded) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-slate-950 text-white flex-col gap-4">
        <Loader2 size={48} className="animate-spin text-nano-500" />
        <p className="font-mono text-sm tracking-widest animate-pulse">
          Loading Memory Banks (IDB)...
        </p>
      </div>
    );
  }

  if (showSplash)
    return <SplashScreen onComplete={() => setShowSplash(false)} />;

  const appBgClass = config.customBackground
    ? "bg-transparent"
    : themeColors.bgMain;

  return (
    <div
      className={`h-screen w-full flex flex-col overflow-hidden ${appBgClass} ${themeColors.textMain}`}
      style={{ fontSize: `${config.fontSize}px` }}
    >
      {config.customBackground && (
        <div className="absolute inset-0 z-0">
          {config.customBackground.startsWith("video|") ? (
            <video
              key={config.customBackground}
              src={config.customBackground.replace("video|", "")}
              autoPlay
              loop
              muted
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <div
              className="absolute inset-0 bg-cover bg-center"
              style={{ backgroundImage: `url(${config.customBackground})` }}
            ></div>
          )}
          <div className="absolute inset-0 bg-black/20 pointer-events-none"></div>
        </div>
      )}

      {/* BACKGROUND OVERLAYS */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        {(config.overlays || [])
          .filter((o) => o.layer === "background")
          .map((o) => (
            <div
              key={o.id}
              className="absolute"
              style={{
                left: `${o.x}%`,
                top: `${o.y}%`,
                transform: `translate(-50%, -50%) scale(${o.scale}) rotate(${o.rotation || 0}deg)`,
              }}
            >
              <img
                src={o.src}
                className="max-w-[50vw] max-h-[50vh] object-contain opacity-80"
                alt="bg-overlay"
              />
            </div>
          ))}
      </div>

      {/* FIXED: REMOVED TEXT MARKER */}

      {!hasLaunched ? (
        <ConfigPanel
          config={config}
          setConfig={setConfig}
          messages={messages}
          setMessages={setMessages}
          onLaunch={handleLaunch}
          hasLaunched={!!lastStaticConfig}
          onClose={handleCloseSettings}
          onOpenThemeManager={() => setShowThemeOverlay(true)}
        />
      ) : (
        <ChatInterface
          messages={messages}
          onSendMessage={handleSendMessage}
          onSendSticker={handleSendSticker}
          onReset={handleReset}
          onSystemSync={handleSystemSync}
          onResetChat={handleClearHistory}
          onClearChatLog={handleClearChatLog}
          kernel={config.kernel}
          onOpenSettings={() => setHasLaunched(false)}
          config={config}
          setConfig={setConfig}
          onImportData={handleImportData}
          onExportData={(type) => handleExportData(type)}
          onDeleteMessage={handleDeleteMessage}
          onDeleteFromHere={handleDeleteFromHere}
          onEditMessage={(id, content) =>
            setMessages((prev) =>
              prev.map((m) => {
                if (m.id === id) {
                  invalidateTrackingIfNeeded(m.timestamp);
                  return {
                    ...m,
                    content,
                    versions: [content],
                    currentVersionIndex: 0,
                  };
                }
                return m;
              }),
            )
          }
          onRerunMessage={handleRerunMessage}
          onFastReload={handleFastReload}
          isTyping={isTyping}
          setIsTyping={setIsTyping}
          setMessages={setMessages}
          onVersionChange={handleVersionChange}
          onFeedback={handleFeedback}
          regeneratingId={regeneratingId}
        />
      )}

      {/* FOREGROUND OVERLAYS */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-[100]">
        {(config.overlays || [])
          .filter((o) => o.layer === "foreground")
          .map((o) => (
            <div
              key={o.id}
              className="absolute"
              style={{
                left: `${o.x}%`,
                top: `${o.y}%`,
                transform: `translate(-50%, -50%) scale(${o.scale}) rotate(${o.rotation || 0}deg)`,
              }}
            >
              <img
                src={o.src}
                className="max-w-[50vw] max-h-[50vh] object-contain"
                alt="fg-overlay"
              />
            </div>
          ))}
      </div>

      {hasLaunched && (config.activeModules || []).includes("Music_Player") && (
        <MusicPlayerWidget
          config={config}
          setConfig={setConfig}
          themeColors={themeColors}
        />
      )}

      {hasLaunched &&
        (config.activeModules || []).includes("Live_Comments") && (
          <LiveCommentsWidget
            config={config}
            setConfig={setConfig}
            themeColors={themeColors}
            messages={messages}
          />
        )}

      {/* VECTOR MEMORY MODAL RENDER */}
      {showVectorMemory && (
        <VectorMemoryModal
          config={config}
          setConfig={setConfig}
          onClose={() => setShowVectorMemory(false)}
          themeColors={themeColors}
          messages={messages}
        />
      )}

      {showThemeOverlay && (
        <ThemeOverlayManager
          config={config}
          setConfig={setConfig}
          onClose={() => setShowThemeOverlay(false)}
        />
      )}

      {/* FLOATING UI ELEMENTS - RENDERED LAST TO BE ON TOP */}
      {hasLaunched && !showVectorMemory && !showThemeOverlay && (
        <div className="absolute top-3 md:top-4 left-4 z-[40] flex flex-col gap-2 items-start pointer-events-none">
          <div className="flex flex-wrap gap-2">
            {syncStatus && (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-black/60 rounded-full border border-amber-500/30 backdrop-blur-md animate-in fade-in slide-in-from-top-2">
                <CheckCircle size={12} className="text-amber-400" />
                <span className="text-[10px] font-mono text-white/80">
                  ✓ RULES SYNCED
                </span>
              </div>
            )}
            {saveStatus === "SAVING" && (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-black/60 rounded-full border border-white/10 backdrop-blur-md animate-in fade-in">
                <Loader2 size={12} className="animate-spin text-blue-400" />
                <span className="text-[10px] font-mono text-white/80">
                  Saving...
                </span>
              </div>
            )}
            {saveStatus === "SAVED" && (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-black/60 rounded-full border border-green-500/30 backdrop-blur-md animate-in fade-in">
                <CheckCircle size={12} className="text-green-400" />
                <span className="text-[10px] font-mono text-white/80">
                  Saved
                </span>
              </div>
            )}
            {saveStatus === "ERROR" && (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-red-900/60 rounded-full border border-red-500/30 backdrop-blur-md animate-in fade-in">
                <AlertCircle size={12} className="text-red-400" />
                <span className="text-[10px] font-mono text-white/80">
                  Error
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* CUSTOM LOCATION MODAL REMOVED - MOVED TO CONFIG PANEL */}
    </div>
  );
}

export default App;
