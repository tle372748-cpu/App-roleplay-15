
// IndexedDB Wrapper for NanoMachineGX
// Handles massive datasets (images, long chat logs) without 5MB limit of localStorage

const DB_NAME = 'NMGX_DB_V1';
const DB_VERSION = 2; // Bumped version to force store creation
const STORE_MESSAGES = 'messages';
const STORE_CONFIG = 'config';

export const initDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = (event) => {
      console.error("IndexedDB error:", event);
      reject("Database error");
    };

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      
      // Create messages store if it doesn't exist
      if (!db.objectStoreNames.contains(STORE_MESSAGES)) {
        db.createObjectStore(STORE_MESSAGES);
      }
      
      // Create config store if it doesn't exist (Critical Fix)
      if (!db.objectStoreNames.contains(STORE_CONFIG)) {
        db.createObjectStore(STORE_CONFIG);
      }
    };

    request.onsuccess = (event) => {
      resolve((event.target as IDBOpenDBRequest).result);
    };
  });
};

export const saveToDB = async (storeName: string, key: string, data: any) => {
  try {
    const db = await initDB();
    return new Promise<void>((resolve, reject) => {
      const transaction = db.transaction([storeName], "readwrite");
      const store = transaction.objectStore(storeName);
      const request = store.put(data, key);

      request.onsuccess = () => resolve();
      request.onerror = (e) => {
          console.error(`Error saving to ${storeName}:`, e);
          reject("Save failed");
      };
    });
  } catch (e) {
      console.error("DB Init failed during save:", e);
  }
};

export const loadFromDB = async (storeName: string, key: string) => {
  try {
    const db = await initDB();
    return new Promise<any>((resolve, reject) => {
      const transaction = db.transaction([storeName], "readonly");
      const store = transaction.objectStore(storeName);
      const request = store.get(key);

      request.onsuccess = () => resolve(request.result);
      request.onerror = (e) => {
          console.error(`Error loading from ${storeName}:`, e);
          reject("Load failed");
      };
    });
  } catch (e) {
      console.error("DB Init failed during load:", e);
      return null;
  }
};

export const clearStore = async (storeName: string) => {
    try {
        const db = await initDB();
        return new Promise<void>((resolve, reject) => {
            const transaction = db.transaction([storeName], "readwrite");
            const store = transaction.objectStore(storeName);
            const request = store.clear();
            request.onsuccess = () => resolve();
            request.onerror = () => reject("Clear failed");
        });
    } catch (e) {
        console.error("DB Clear failed:", e);
    }
};

// Specific helpers
export const saveMessagesToIDB = (msgs: any[]) => saveToDB(STORE_MESSAGES, 'current_session', msgs);
export const loadMessagesFromIDB = () => loadFromDB(STORE_MESSAGES, 'current_session');

export const saveConfigToIDB = (config: any) => saveToDB(STORE_CONFIG, 'current_config', config);
export const loadConfigFromIDB = () => loadFromDB(STORE_CONFIG, 'current_config');
