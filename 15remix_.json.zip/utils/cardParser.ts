
import { CardData, CharacterRole, PhysicalAttributes } from '../types';

const DEFAULT_PHYSICAL: PhysicalAttributes = {
    height: 0, 
    weight: 0,
    muscle: 10,
    fat: 20,
    beauty: 70,
    sensitivity: 50,
    measurements: { bust: 0, waist: 0, hips: 0, cup: '?' }, 
    genitals: { depth: 0, length: 0, girth: 0, wetness: 10, traits: [] },
    pregnancy: { isPregnant: false, weeks: 0, isVisible: false }
};

export const parseTextCard = (text: string): CardData => {
  const lines = text.split('\n');
  const fullText = text; 
  
  const physical: PhysicalAttributes = JSON.parse(JSON.stringify(DEFAULT_PHYSICAL));

  const data: any = {
    name: "Unknown Identity", 
    status: {},
    phone: { messages: [], history: [] },
    diary: [],
    traits: [],
    physical: physical 
  };

  let currentSection: 'root' | 'messages' | 'diary' | 'history' = 'root';
  let nameFound = false;

  // --- AGGRESSIVE NAME HUNTING ---
  const explicitNameMatch = fullText.match(/^[\s\-\*]*(?:name|tên|tên đầy đủ|tên nhân vật|character|char|identity|họ tên|biệt danh|full name)\s*\**\s*[:=\-–]\s*\**\s*(.+)$/im);
  if (explicitNameMatch) {
      let rawName = explicitNameMatch[1].trim();
      rawName = rawName.replace(/^["'](.*)["']$/, '$1');
      rawName = rawName.replace(/\**$/, '').trim();
      rawName = rawName.replace(/[,{].*$/, '').trim();
      if (rawName.length > 0) { data.name = rawName; nameFound = true; }
  }

  if (!nameFound) {
      const wppMatch = fullText.match(/Name\s*[\(\[]\s*\"?([^")\]]+)\"?\s*[\)\]]/i);
      if (wppMatch) { data.name = wppMatch[1].trim(); nameFound = true; }
  }

  if (!nameFound) {
      const firstLine = lines.find(l => l.trim().length > 0)?.trim();
      if (firstLine) {
          const isNotKey = !firstLine.includes(':') && !firstLine.includes('=');
          const isNotBracket = !firstLine.startsWith('[') && !firstLine.startsWith('{') && !firstLine.startsWith('<');
          const isShort = firstLine.length < 50;
          if (isNotKey && isNotBracket && isShort) { data.name = firstLine; nameFound = true; }
      }
  }

  const keys: Record<string, string[]> = {
    role: ['role', 'vai trò', 'vị trí', 'loại nhân vật', 'tầm quan trọng', 'chức vụ'],
    aliases: ['aliases', 'biệt danh', 'nicknames', 'cách gọi khác', 'tên gọi khác', 'nick name', 'aka', 'biệt hiệu'],
    age: ['age', 'tuổi', 'tuoi', 'vòng đời', 'năm sinh', 'sinh năm'],
    gender: ['gender', 'giới tính', 'gioi tinh', 'sex', 'phái', 'loài', 'giống', 'hệ', 'giới'],
    pronouns: ['pronouns', 'xưng hô', 'đại từ', 'xung ho', 'address as', 'gọi là', 'cách gọi', 'vai vế', 'cách xưng hô'],
    height: ['height', 'chiều cao', 'cao', 'chieu cao', 'vóc dáng', 'thể hình', 'cm'],
    weight: ['weight', 'cân nặng', 'nặng', 'can nang', 'kg', 'lbs'],
    traits: ['traits', 'đặc điểm', 'tính cách', 'tags', 'đặc trưng', 'dac diem', 'tinh cach', 'tính nết', 'sở thích', 'thói quen', 'personality'],
    description: ['description', 'mô tả', 'ngoại hình', 'appearance', 'mo ta', 'ngoai hinh', 'tiểu sử', 'bio', 'cốt truyện', 'bối cảnh', 'tóm tắt', 'summary'],
    measurements: ['measurements', '3 vòng', 'số đo', 'bwh', 'ba vòng', 'body stats', 'chỉ số cơ thể'],
    cup: ['cup', 'cỡ ngực', 'cup size', 'bra', 'vòng 1', 'size'],
    hp: ['hp', 'máu', 'health', 'sức khỏe', 'mau', 'suc khoe', 'thể trạng', 'sinh lực'],
    stress: ['stress', 'căng thẳng', 'áp lực', 'cang thang', 'ap luc', 'tâm trí', 'tinh thần'],
    arousal: ['arousal', 'hưng phấn', 'ham muốn', 'hung phan', 'ham muon', 'dục vọng', 'kích thích', 'nhu cầu'],
    secret: ['secret', 'bí mật', 'bi mat', 'góc khuất', 'nội tâm', 'bí ẩn'],
    model: ['phone model', 'điện thoại', 'dế', 'dien thoai', 'thiết bị', 'smartphone'],
    battery: ['battery', 'pin', 'dung lượng'],
    wallpaper: ['wallpaper', 'hình nền', 'hinh nen', 'phông nền', 'ảnh nền'],
    bank: ['bank', 'ngân hàng', 'tài khoản', 'số dư', 'money', 'tiền', 'ngan hang', 'tai khoan', 'so du', 'tien', 'ví', 'túi tiền'],
    nativeLanguage: ['language', 'ngôn ngữ', 'quốc tịch', 'nationality', 'native', 'tiếng mẹ đẻ', 'ngon ngu', 'quoc tich']
  };

  const extractNum = (str: string): number | null => {
      const mMatch = str.match(/(\d+)\s*m\s*(\d+)/i);
      if (mMatch) {
          return parseInt(mMatch[1]) * 100 + parseInt(mMatch[2].padEnd(2, '0').substring(0, 2));
      }
      const match = str.match(/(\d+(\.\d+)?)/);
      return match ? parseFloat(match[0]) : null;
  };

  lines.forEach(line => {
    const trimmedLine = line.trim();
    if (!trimmedLine) return;
    const lowerLine = trimmedLine.toLowerCase();
    
    if (['messages:', 'tin nhắn:', 'tin nhan:'].some(k => lowerLine.startsWith(k))) { currentSection = 'messages'; return; }
    if (['diary:', 'nhật ký:', 'nhat ky:'].some(k => lowerLine.startsWith(k))) { currentSection = 'diary'; return; }
    if (['history:', 'lịch sử:', 'lich su:'].some(k => lowerLine.startsWith(k))) { currentSection = 'history'; return; }

    if (trimmedLine.match(/^[-*•]\s/)) {
      const content = trimmedLine.replace(/^[-*•]\s/, '').trim();
      if (currentSection === 'messages') {
        const colonIndex = content.indexOf(':');
        if (colonIndex !== -1) {
          data.phone.messages.push({
            sender: content.substring(0, colonIndex).trim(),
            content: content.substring(colonIndex + 1).trim(),
            timestamp: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' }),
            read: true
          });
        }
      } else if (currentSection === 'diary') {
        const parts = content.split('|');
        if (parts.length >= 3) {
          data.diary.push({ date: parts[0].trim(), title: parts[1].trim(), content: parts[2].trim() });
        } else {
             data.diary.push({ date: "Unknown", title: "Entry", content: content });
        }
      } else if (currentSection === 'history') {
        data.phone.history.push(content);
      }
      return;
    }

    const colonIndex = trimmedLine.indexOf(':');
    if (colonIndex !== -1) {
      const key = trimmedLine.substring(0, colonIndex).trim().toLowerCase();
      let val = trimmedLine.substring(colonIndex + 1).trim();
      
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.substring(1, val.length - 1);
      }

      if (!val) return;

      if (!nameFound && (key === 'name' || key === 'tên')) { data.name = val; nameFound = true; }
      else if (keys.aliases && keys.aliases.includes(key)) {
         data.aliases = val.split(/[,;|/]/).map(s => s.trim()).filter(s => s);
      }
      else if (keys.role.includes(key)) {
         if (val.toLowerCase().includes('main') || val.toLowerCase().includes('chính')) data.role = 'MAIN';
         else if (val.toLowerCase().includes('background') || val.toLowerCase().includes('nền')) data.role = 'BACKGROUND';
         else data.role = 'SIDE';
      }
      else if (keys.age.includes(key)) data.age = val; 
      else if (keys.gender.includes(key)) data.gender = val; 
      else if (keys.pronouns.includes(key)) data.pronouns = val; 
      else if (keys.nativeLanguage.includes(key)) data.nativeLanguage = val;
      else if (keys.traits.includes(key)) {
        const rawTraits = val.split(/[,/|]/).map(t => t.trim()).filter(t => t.length > 0);
        data.traits = [...new Set([...(data.traits || []), ...rawTraits])];
      }
      else if (keys.description.includes(key)) data.description = data.description ? data.description + "\n" + val : val;
      else if (keys.height.includes(key)) {
          const h = extractNum(val);
          if (h) data.physical.height = h < 3 ? h * 100 : h;
      }
      else if (keys.weight.includes(key)) {
          const w = extractNum(val);
          if (w) data.physical.weight = w;
      }
      else if (keys.measurements.includes(key)) {
          const nums = val.match(/(\d{2,3})/g);
          if (nums && nums.length >= 3) {
              data.physical.measurements.bust = parseInt(nums[0]);
              data.physical.measurements.waist = parseInt(nums[1]);
              data.physical.measurements.hips = parseInt(nums[2]);
          }
      }
      else if (keys.cup.includes(key)) {
          const cupMatch = val.match(/^([A-Z])/i); 
          if (cupMatch) data.physical.measurements.cup = cupMatch[1].toUpperCase();
      }
      else if (keys.hp.includes(key)) data.status.hp = val;
      else if (keys.stress.includes(key)) data.status.stress = val;
      else if (keys.arousal.includes(key)) data.status.arousal = val;
      else if (keys.secret.includes(key)) data.status.secret = val;
      else if (keys.model.includes(key)) data.phone.model = val;
      else if (keys.battery.includes(key)) data.phone.battery = parseInt(val) || 100;
      else if (keys.wallpaper.includes(key)) data.phone.wallpaper = val;
      else if (keys.bank.includes(key)) data.phone.bankBalance = val;
      else {
          // If it's an unrecognized key, append it to description so we don't lose data
          const unknownLine = `${trimmedLine.substring(0, colonIndex).trim()}: ${val}`;
          data.description = data.description ? data.description + "\n" + unknownLine : unknownLine;
      }
    } else {
      if (!data.gender) {
        if ([' nam ', ' male', 'ông ', 'anh trai'].some(c => lowerLine.includes(c))) data.gender = "Nam";
        else if ([' nữ ', ' female', 'bà ', 'chị gái'].some(c => lowerLine.includes(c))) data.gender = "Nữ";
      }
      
      // If it's not a key-value pair and not a known section header, treat it as description paragraph
      const skipStrings = ['essages:', 'iary:', 'istory:', 'name:', 'tên:'];
      if (!skipStrings.some(s => lowerLine.includes(s))) {
         data.description = data.description ? data.description + "\n" + trimmedLine : trimmedLine;
      }
    }
  });

  const lowerFullText = fullText.toLowerCase();

  // 1. Text Search Fallbacks
  if (!nameFound || data.name === "Unknown Identity") {
      const aggressiveNameMatch = fullText.match(/(?:Tên|Name|Tên đầy đủ|Họ và tên)[\s\*]*[:\-]*(?!:?)[\s\*]*([A-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪỬỮỰỲỴÝỶỸ][a-zàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]*(\s+[A-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪỬỮỰỲỴÝỶỸ][a-zàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]*)*)/i);
      if (aggressiveNameMatch && aggressiveNameMatch[1]) {
          data.name = aggressiveNameMatch[1].trim();
          nameFound = true;
      }
  }

  if (!data.physical.measurements.bust) { 
      const bwhMatch = lowerFullText.match(/(?:^|\s|[bB]|v1[:\s]?)(\d{2,3})[\s\-\/]+(?:[wW]|v2[:\s]?)?(\d{2,3})[\s\-\/]+(?:[hH]|v3[:\s]?)?(\d{2,3})(?:\s|$)/);
      if (bwhMatch) {
          data.physical.measurements.bust = parseInt(bwhMatch[1]);
          data.physical.measurements.waist = parseInt(bwhMatch[2]);
          data.physical.measurements.hips = parseInt(bwhMatch[3]);
      }
  }
  if (!data.physical.height) {
      const heightMatch = lowerFullText.match(/(?:height|cao|chiều cao)[:\s]*(?:(\d{1}\.?\d{2})\s*m(?:eters?)?|(\d{1})\s*m\s*(\d{2})|(\d{1,3}(?:\.\d+)?)\s*cm)/i);
      if (heightMatch) {
          let val = 0;
          if (heightMatch[1]) val = parseFloat(heightMatch[1]) * 100;
          else if (heightMatch[2] && heightMatch[3]) val = parseInt(heightMatch[2]) * 100 + parseInt(heightMatch[3]);
          else if (heightMatch[4]) val = parseFloat(heightMatch[4]);
          if (val > 50 && val < 300) data.physical.height = Math.round(val);
      }
  }
  if (!data.physical.weight) {
      const weightMatch = lowerFullText.match(/(?:weight|nặng|cân)[:\s]*(\d{2,3})\s*kg/i);
      if (weightMatch) {
          data.physical.weight = parseFloat(weightMatch[1]);
      }
  }
  if (data.physical.measurements.cup === '?') {
      // Regex fixed to strictly capture just the letter if followed by "cup", "size", or space/end
      const cupMatch = fullText.match(/\b([A-H])\s*[-]?\s*(?:cup|size|vòng 1)/i);
      if (cupMatch) {
          data.physical.measurements.cup = cupMatch[1].toUpperCase();
      }
  }

  if (data.physical.height) data.height = `${data.physical.height}cm`;
  if (!nameFound) data.name = "Unknown Identity";
  
  // --- PROCEDURAL GENERATION (AUTO-FILL) ---
  const genderLower = data.gender ? data.gender.toLowerCase() : "";
  // PRIORITIZE FEMALE CHECK (Check "Female" before "Male" to avoid partial match)
  const isFemale = genderLower.includes('female') || genderLower.includes('nữ') || genderLower.includes('girl') || genderLower.includes('women');
  const isMale = !isFemale && (genderLower.includes('male') || genderLower.includes('nam') || genderLower.includes('boy') || genderLower.includes('man'));

  // A. Infer Height if missing
  if (!data.physical.height) {
      if (isMale) data.physical.height = 175 + Math.floor(Math.random() * 10);
      else if (isFemale) data.physical.height = 158 + Math.floor(Math.random() * 10);
      else data.physical.height = 165;
      data.height = `${data.physical.height}cm`;
  }

  // B. Infer Weight if missing (BMI approx 20-22)
  if (!data.physical.weight) {
      const heightM = data.physical.height / 100;
      data.physical.weight = Math.round(21 * (heightM * heightM));
  }

  // C. Sanitize & Procedurally Generate Genitals/Measurements
  if (isFemale) {
      if (!data.pronouns) data.pronouns = "Em";
      
      // Force remove male parts
      data.physical.genitals.length = 0;
      
      // Infer Vagina Depth (Height-based)
      // Base: 160cm -> 12cm. Scale: +1cm per 10cm height.
      // FORCE RE-CALCULATION IF DEPTH IS ZERO (Common missing data issue)
      if (!data.physical.genitals.depth || data.physical.genitals.depth === 0) {
          const baseDepth = 12;
          const heightDiff = data.physical.height - 160;
          // Minimum depth of 8cm even if very short
          const calculatedDepth = Math.max(8, parseFloat((baseDepth + (heightDiff * 0.1)).toFixed(1)));
          data.physical.genitals.depth = calculatedDepth;
      }

      // Infer Tightness (Girth field reused for width/tightness)
      // If 0, set default tightness based on "Tiny" trait or height.
      if (!data.physical.genitals.girth || data.physical.genitals.girth === 0) {
          let tightness = 2.5; // Average 2.5cm diameter
          const traitsStr = (data.traits || []).join(' ').toLowerCase();
          
          if (traitsStr.includes('loli') || traitsStr.includes('petite') || traitsStr.includes('tight')) {
              tightness = 1.5 + Math.random(); // 1.5 - 2.5
          } else if (traitsStr.includes('milf') || traitsStr.includes('mature')) {
              tightness = 3.0 + Math.random(); // 3.0 - 4.0
          }
          data.physical.genitals.girth = parseFloat(tightness.toFixed(1));
      }

      // Infer Measurements - "TALLER = BIGGER BOOBS" LOGIC
      if (!data.physical.measurements.bust) {
          const h = data.physical.height;
          let bustRatio = 0.53; // Default (Average)
          
          if (h >= 175) bustRatio = 0.62; // Amazonian/Model (Very Large)
          else if (h >= 168) bustRatio = 0.58; // Tall (Large)
          else if (h >= 160) bustRatio = 0.54; // Average+
          else if (h < 155) bustRatio = 0.50; // Petite (Small)

          data.physical.measurements.bust = Math.round(h * bustRatio);
          data.physical.measurements.waist = Math.round(h * 0.38); 
          data.physical.measurements.hips = Math.round(h * 0.56); // Hips also scale slightly
          
          const underbust = Math.round(h * 0.43);
          const diff = data.physical.measurements.bust - underbust;
          const cups = ['AA', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
          let cupIdx = Math.floor((diff - 8) / 2.5);
          if (cupIdx < 0) cupIdx = 0;
          if (cupIdx >= cups.length) cupIdx = cups.length - 1;
          data.physical.measurements.cup = cups[cupIdx];
      }
  } 
  else if (isMale) {
      if (!data.pronouns) data.pronouns = "Anh";
      
      data.physical.genitals.depth = 0;
      data.physical.measurements.cup = '';

      // Infer Penis Size (Height-based) - LOWERED STANDARDS EDITION
      if (!data.physical.genitals.length || data.physical.genitals.length === 0) {
          const h = data.physical.height;
          let baseL = 12;
          
          if (h <= 155) {
             // RUTHLESS: < 155cm is Micro or Inverted. 
             // Range: -3 to 2.
             baseL = Math.floor(Math.random() * 6) - 3; 
             if (!data.traits.includes("Micro")) data.traits.push(baseL <= 0 ? "Inverted" : "Micro");
          } else if (h <= 162) {
             // TINY: 155-162cm. Range 2 to 5.
             baseL = 2 + Math.random() * 3;
             if (!data.traits.includes("Tiny")) data.traits.push("Tiny");
          } else if (h <= 170) {
             // SMALL: 162-170cm. Range 6 to 9.
             baseL = 6 + Math.random() * 3;
             if (!data.traits.includes("Small")) data.traits.push("Small");
          } else if (h >= 180) {
             // TALL (BUT LOWERED): Range 13 to 17.
             baseL = 13 + Math.random() * 4;
          } else {
             // AVERAGE (BUT LOWERED): Range 9 to 13.
             baseL = 9 + Math.random() * 4;
          }

          data.physical.genitals.length = parseFloat(baseL.toFixed(1));
          
          if (baseL <= 0) data.physical.genitals.girth = 0;
          else {
              // Girth scaling: Smaller penis = thinner girth
              let girthRatio = 0.75;
              if (baseL < 5) girthRatio = 0.4;
              else if (baseL < 10) girthRatio = 0.55;
              
              data.physical.genitals.girth = parseFloat((Math.max(0.5, baseL * girthRatio)).toFixed(1)); 
          }
      }
  }

  // --- PROCEDURAL MIND SCULPTING (FILL MISSING STATS) ---
  if (!data.status) data.status = {};
  
  // 1. Stress
  if (!data.status.stress) {
      data.status.stress = Math.floor(Math.random() * 20).toString(); // Default low stress
  }

  // 2. Arousal (Libido)
  if (!data.status.arousal) {
      const traitsStr = (data.traits || []).join(' ').toLowerCase();
      let baseLibido = 10;
      if (traitsStr.includes('succubus') || traitsStr.includes('nympho') || traitsStr.includes('lust')) baseLibido = 80;
      else if (traitsStr.includes('shy') || traitsStr.includes('pure')) baseLibido = 5;
      data.status.arousal = Math.floor(baseLibido + Math.random() * 10).toString();
  }

  // 3. HP
  if (!data.status.hp) data.status.hp = "100";

  // 4. Personality Spectrum (Generate if missing)
  const traitsStr = (data.traits || []).join(' ').toLowerCase();
  
  if (!data.status.logicEmotion) {
      // < 0 Logic, > 0 Emotion
      if (traitsStr.includes('smart') || traitsStr.includes('cold') || traitsStr.includes('kuudere')) data.status.logicEmotion = "-40";
      else if (traitsStr.includes('crybaby') || traitsStr.includes('emotional') || traitsStr.includes('deredere')) data.status.logicEmotion = "40";
      else data.status.logicEmotion = (Math.floor(Math.random() * 40) - 20).toString(); // -20 to 20
  }

  if (!data.status.introExtro) {
      // < 0 Intro, > 0 Extro
      if (traitsStr.includes('shy') || traitsStr.includes('quiet') || traitsStr.includes('dandere')) data.status.introExtro = "-40";
      else if (traitsStr.includes('genki') || traitsStr.includes('loud') || traitsStr.includes('gyaru')) data.status.introExtro = "40";
      else data.status.introExtro = (Math.floor(Math.random() * 40) - 20).toString();
  }

  if (!data.status.subDom) {
      // < 0 Sub, > 0 Dom
      if (traitsStr.includes('submissive') || traitsStr.includes('slave') || traitsStr.includes('pet')) data.status.subDom = "-50";
      else if (traitsStr.includes('dominant') || traitsStr.includes('queen') || traitsStr.includes('sadist')) data.status.subDom = "50";
      else data.status.subDom = (Math.floor(Math.random() * 40) - 20).toString();
  }

  // 5. Additional mental stats
  if (!data.status.alignment) {
      const alignments = ['Lawful Good', 'Neutral Good', 'Chaotic Good', 'Lawful Neutral', 'True Neutral', 'Chaotic Neutral', 'Lawful Evil', 'Neutral Evil', 'Chaotic Evil'];
      data.status.alignment = alignments[Math.floor(Math.random() * alignments.length)];
  }
  if (!data.status.speechStyle) {
      const styles = ['Formal', 'Casual', 'Slang/Street', 'Polite', 'Aggressive', 'Shy', 'Flirtatious', 'Monotone', 'Sarcastic', 'Energetic'];
      data.status.speechStyle = styles[Math.floor(Math.random() * styles.length)];
  }
  if (!data.status.obsessions) {
      data.status.obsessions = traitsStr.includes('yandere') ? 'The protagonist' : 'None';
  }
  if (!data.status.secret) {
      data.status.secret = 'Unknown';
  }

  return data as CardData;
};
