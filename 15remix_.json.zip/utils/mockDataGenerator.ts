
import { CardData } from '../types';

// --- HELPER FUNCTIONS FOR PROCEDURAL GENERATION ---

const getSignalIcon = () => {
  const signals = [" ▂▃▄", " ▂▃", " ▂", " "];
  return signals[Math.floor(Math.random() * signals.length)];
};

const getNetworkType = () => {
  return Math.random() > 0.3 ? "5G" : "LTE";
};

const getWeather = () => {
  const weathers = ["☁️ 24°C Cloudy", "☀️ 32°C Sunny", "🌧️ 19°C Rainy", "🌙 22°C Clear", "⛈️ 18°C Storm", "🌫️ 20°C Foggy", "🌪️ Windy 28°C"];
  return weathers[Math.floor(Math.random() * weathers.length)];
};

const getMusicTrack = (vibe: string) => {
  const tracks = {
    sad: ["Mưa Tầm Tã - Vũ.", "Glimpse of Us - Joji", "Tháng Tư Là Lời Nói Dối Của Em"],
    hype: ["Haru Haru (Remix)", "Waiting For You - MONO", "Cắt Đôi Nỗi Sầu"],
    chill: ["Lối Nhỏ - Đen Vâu", "Best Part - Daniel Caesar", "Em Dạo Này - Ngọt"],
    dark: ["Earned It - The Weeknd", "Under The Influence - Chris Brown", "I Was Never There"],
    default: ["Making My Way - Son Tung M-TP", "See Tình - Hoang Thuy Linh", "Ditto - NewJeans"]
  };
  const category = (Object.keys(tracks) as Array<keyof typeof tracks>)[Math.floor(Math.random() * 5)];
  const song = tracks[category][Math.floor(Math.random() * tracks[category].length)];
  return song;
};

const generateContextualNotifications = (status: any, name: string): string[] => {
  const notifs: string[] = [];
  
  if (status?.stress && (status.stress.toLowerCase().includes('high') || status.stress.toLowerCase().includes('panic'))) {
    notifs.push("🏦 [Bank]: Your Qtoken balance is critically low. Transaction declined.");
    notifs.push("⏰ [Clock]: ALARM - DEADLINE (Missed). WAKE UP!");
    notifs.push("📞 [Mom]: 5 Missed Calls. 'Ve an com ngay!'");
  }

  if (status?.hp && (status.hp.toLowerCase().includes('injured') || status.hp.toLowerCase().includes('low'))) {
    notifs.push("❤️ [Health]: Heart rate spike (140bpm). Seek medical attention immediately.");
    notifs.push("⚠️ [System]: Adrenaline levels critical.");
  }

  if (status?.arousal && (status.arousal.toLowerCase().includes('high') || status.arousal.includes('8') || status.arousal.includes('9'))) {
    notifs.push(`🔥 [Tinder]: It's a match! "BadBoy99" sent you a location...`);
    notifs.push("💬 [Zalo]: Anh ơi, tối nay rảnh không? Em qua nhé? 🍑");
  }

  if (notifs.length === 0) {
    notifs.push("📰 [News]: Traffic jam at Nguyen Hue Walking Street due to event.");
    notifs.push("🛒 [Shopee]: Your order 'Goi Om Anime' has arrived!");
    notifs.push(`✉️ [Gmail]: Weekly report for ${name} - Unread`);
    notifs.push(`🌦️ [Weather]: Rain expected in 30 minutes.`);
    notifs.push(`🎮 [Steam]: Summer Sale is live! 90% off.`);
  }

  return notifs;
};

const findCard = (target: string, userCard: CardData | null, charCards: CardData[]): CardData | null => {
    if (target === 'Self' || target === 'User' || target === 'Me') return userCard;
    if (target === 'Char' || target === 'Character' || target === 'Target') return charCards.length > 0 ? charCards[0] : null;
    const match = charCards.find(c => c.name === target);
    if (match) return match;
    const fuzzy = charCards.find(c => c.name.toLowerCase().includes(target.toLowerCase()));
    return fuzzy || null;
}

// --- CURRENCY PARSER ---
export const parseBalance = (input: string): number => {
    if (!input) return 0;
    const clean = input.toLowerCase().trim();
    
    // 1. Check for Billions (Tỷ / B)
    if (clean.includes('tỷ') || clean.includes('b')) {
        const num = parseFloat(clean.replace(/[^0-9.]/g, ''));
        return num * 1_000_000_000;
    }
    
    // 2. Check for Millions (Triệu / Tr / M / Củ)
    if (clean.includes('tr') || clean.includes('m') || clean.includes('củ')) {
        const num = parseFloat(clean.replace(/[^0-9.]/g, ''));
        return num * 1_000_000;
    }

    // 3. Check for Thousands (Nghìn / K)
    if (clean.includes('k') || clean.includes('nghìn') || clean.includes('ngàn')) {
        const num = parseFloat(clean.replace(/[^0-9.]/g, ''));
        return num * 1_000;
    }

    // 4. Standard Number (Remove non-digits)
    const rawNum = clean.replace(/[^0-9]/g, '');
    return parseInt(rawNum) || 0;
};

export const formatVND = (amount: number): string => {
    // Format as Qtoken
    const formatted = new Intl.NumberFormat('en-US').format(amount);
    return `${formatted} Ⓠ`;
};

// --- REALISM ENFORCER ---
const sanitizePhoneModel = (model: string | undefined, balance: number): string => {
    let finalModel = model || "Unknown Smartphone";
    
    // Threshold: < 50 Million VND (approx 50k Qtoken in new scale? No, sticking to high numbers for realism context)
    // Assuming 1 Qtoken = 1 VND for realism scaling in description, but displayed as Q
    if (balance < 30_000_000) {
        if (finalModel.match(/(14|15|16).*Pro.*Max/i) || finalModel.match(/S2[34].*Ultra/i) || finalModel.match(/Fold/i)) {
            const downgrades = [
                "iPhone 11 (Cracked Screen)", 
                "iPhone 12", 
                "iPhone XR (Yellow)", 
                "Samsung A54", 
                "Oppo Reno 8", 
                "Xiaomi Redmi Note 12",
                "iPhone 8 Plus (Home Button)"
            ];
            finalModel = downgrades[Math.floor(Math.random() * downgrades.length)];
        }
    }
    return finalModel;
};

// --- BANKING INTENT DETECTION ---
export const detectTransferIntent = (text: string, characters: CardData[]): { target: CardData, amount: number, direction: 'USER_TO_CHAR' | 'CHAR_TO_USER' } | null => {
    const lower = text.toLowerCase();
    const keywords = ['chuyển', 'bắn', 'gửi', 'tặng', 'cho', 'biếu', 'lì xì', 'bank', 'ck'];
    if (!keywords.some(k => lower.includes(k))) return null;

    // Regex to find amount with unit
    const amountRegex = /(\d+(?:[.,]\d+)?)\s*(k|nghìn|ngàn|tr|triệu|m|củ|tỷ|b|vnd|đ|d|q|Ⓠ)/i;
    const match = lower.match(amountRegex);
    
    if (!match) return null;
    
    const amount = parseBalance(match[0]);
    if (amount <= 0) return null;

    // Detect Direction
    // If text contains "cho tôi", "tặng tôi", "chuyển tôi", "cho mình", "vào tk tôi" -> Char to User
    const meKeywords = ['cho tôi', 'tặng tôi', 'chuyển tôi', 'cho mình', 'chuyển mình', 'vào tk tôi', 'bank tôi'];
    const isCharToUser = meKeywords.some(k => lower.includes(k));
    const direction = isCharToUser ? 'CHAR_TO_USER' : 'USER_TO_CHAR';

    // Find Target (The Character involved)
    // If USER_TO_CHAR: Target is Recipient
    // If CHAR_TO_USER: Target is Sender
    
    // 1. Exact name match
    let target = characters.find(c => lower.includes(c.name.toLowerCase()));
    
    // 2. Implicit single character
    if (!target && characters.length === 1) {
        target = characters[0];
    }

    return target ? { target, amount, direction } : null;
};

// --- ASCII FORMATTING (ULTRA WIDE = 110) ---
const WIDTH = 110;

const center = (text: string, width: number = WIDTH) => {
    const len = text.length;
    if (len >= width) return text.substring(0, width);
    const left = Math.floor((width - len) / 2);
    const right = width - len - left;
    return " ".repeat(left) + text + " ".repeat(right);
};
  
const pad = (text: string, width: number = WIDTH) => {
    if (text.length >= width) return text.substring(0, width);
    return text + " ".repeat(width - text.length);
};

const repeat = (char: string, count: number) => char.repeat(count);

// --- GENERATORS ---

export const generatePartialPhoneDisplay = (target: string, userCard: CardData | null, charCards: CardData[]) => {
  let data = findCard(target, userCard, charCards);
  if (!data && charCards.length > 0) data = charCards[0];

  const wallpaper = data?.phone?.wallpaper || "Unknown";
  const border = repeat('═', WIDTH);
  
  return `╔${border}╗
║ 🔓 UNLOCKED | 🖼️ WP: ${pad(wallpaper, WIDTH - 22)}║
║ [ MESSENGER ] - Active Session...                                                                            ║
║                                                                                                              ║
║  > Beo: "Em nho a... Hom nay troi mua to qua, a co mang ao mua khong?"                                       ║
║  > Bank: "-5,000 Ⓠ [Transfer Sent] to Nguyen Van A..."                                                       ║
║  > Mom: "Bao gio moi ve an com? Bo may dang doi day nay."                                                    ║
║  > Zalo: "Ban co 1 loi moi ket ban tu 'Ngoc Trinh'..."                                                       ║
║                                                                                                              ║
║ [ ⚠️ SIGNAL LOST - DEVICE SNATCHED AWAY / SCREEN LOCKED ]                                                    ║
╚${border}╝`;
};

export const generatePhoneDisplay = (target: string, locked: boolean = true, userCard: CardData | null, charCards: CardData[]) => {
  const now = new Date();
  const time = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
  const date = now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
  
  let data = findCard(target, userCard, charCards);
  if (!data && charCards.length > 0) data = charCards[0];

  const border = repeat('═', WIDTH);
  const line = repeat('─', WIDTH);

  if (!data) {
    return `╔${border}╗
║ ⚠️ SYSTEM ERROR: TARGET NOT FOUND                                                                            ║
╚${border}╝`;
  }

  const battery = data.phone?.battery || Math.floor(Math.random() * 100);
  const wallpaper = data.phone?.wallpaper || "Abstract Void";
  const bankStr = data.phone?.bankBalance || "0 Ⓠ";
  const balanceVal = parseBalance(bankStr);

  // REALISM CHECK: Determine Phone Model based on Wealth
  const phoneModel = sanitizePhoneModel(data.phone?.model, balanceVal);
  
  const status = data.status || {};
  const signal = getSignalIcon();
  const net = getNetworkType();
  const weather = getWeather();
  const music = getMusicTrack("default");
  const realMsgs = data.phone?.messages || [];
  const fakeNotifs = generateContextualNotifications(status, data.name);
  
  const battIcon = battery > 80 ? "🔋" : battery > 30 ? "🔋" : "🪫";
  const battColor = battery < 20 ? "🔴" : "";

  const header = `╔${border}╗
║ ${signal} ${net}                 ${center(time, 60)}                ${battColor}${battery}%${battIcon} ║
║ 📱 DEVICE: ${pad(phoneModel, WIDTH - 13)} ║
╟${line}╢`;

  if (locked) {
    return `${header}
║ 🔒 LOCKED   [FaceID: Scanning...]                                                                            ║
║                                                                                                              ║
║   ${center(date, WIDTH)} ║
║   ${center(weather, WIDTH)} ║
║                                                                                                              ║
║ 🎵 NOW PLAYING (Spotify):                                                                                    ║
║    ${pad(music, WIDTH)}║
║    ⏪  ▶️  ⏩     [AirPods Pro Connected]                                                                     ║
╟${line}╢
║ 🔔 NOTIFICATIONS CENTER                                                                                      ║
║                                                                                                              ║
${realMsgs.slice(0, 4).map(m => `║ 💬 [${pad(m.sender, 15)}]: ${pad(m.content, WIDTH - 25)}║`).join('\n') || `║ ${pad(fakeNotifs[0], WIDTH)} ║`}
║ ${fakeNotifs[1] ? pad(fakeNotifs[1], WIDTH) : pad("", WIDTH)} ║
║ ${fakeNotifs[2] ? pad(fakeNotifs[2], WIDTH) : pad("", WIDTH)} ║
║ ${fakeNotifs[3] ? pad(fakeNotifs[3], WIDTH) : pad("", WIDTH)} ║
║                                                                                                              ║
║ [ Swipe up to unlock ]                                                                                       ║
╚${border}╝`;
  }

  // UNLOCKED - TABLET VIEW
  return `${header}
║ 🔓 UNLOCKED | 🖼️ WP: ${pad(wallpaper, WIDTH - 22)}║
╟${line}╢
║ 📱 APPS GRID   [Page 1/3]                                                                                    ║
║                                                                                                              ║
║  [📞 Phone]    [💬 Mess]     [🌐 Chrome]   [📸 Cam]      [🎵 Spotify]  [🗺️ Maps]                           ║
║  [💳 QBank]    [⚙️ Settings]  [🎮 Genshin]  [📁 Files]    [🛒 Shopee]   [❤️ Tinder]                         ║
║  [🚕 Grab]     [🎬 Netflix]  [📷 Insta]    [📘 Facebk]   [🎵 TikTok]   [📝 Notes]                          ║
║                                                                                                              ║
╟${line}╢
║ 📩 LATEST MESSAGES (Unread: ${realMsgs.length})                                                                   ║
${realMsgs.length > 0 
  ? realMsgs.slice(0, 3).map(m => `║ • ${pad(m.sender, 12)}: "${pad(m.content.substring(0, 70) + '..."', 80)}║`).join('\n') 
  : `║ (No recent messages)                                                                                         ║`}
║                                                                                                              ║
╟${line}╢
║ 💳 WIDGET: QTOKEN BANK (Fast View)                                                                           ║
║ 💰 BALANCE: ${pad(bankStr, 96)} ║
║ 📉 LAST TRANS: -55,000 (Circle K - Food & Drink)                                                             ║
╟${line}╢
║ 🌐 WIDGET: CHROME TABS (Incognito Mode Active)                                                               ║
║ 1. "How to tell if he likes me..."                                                                           ║
║ 2. "Cheap flights to Bangkok..."                                                                             ║
╚${border}╝`;
};

export const generateBankDisplay = (target: string, userCard: CardData | null, charCards: CardData[]) => {
  let data = findCard(target, userCard, charCards);
  if (!data && charCards.length > 0) data = charCards[0];
  if (!data) return "⚠️ NO DATA";

  const bankBalanceStr = data.phone?.bankBalance || "0 Ⓠ";
  const name = data.name.toUpperCase();
  const displayName = name.length > 40 ? name.substring(0, 37) + "..." : name;
  const accNum = Math.floor(Math.random() * 1000000000000);
  const creditScore = Math.floor(Math.random() * (850 - 500) + 500); // 500-850

  // NEW LOGIC: Use parser to determine numeric value
  const balanceVal = parseBalance(bankBalanceStr);
  
  let status = "STANDARD";
  let cardType = "DEBIT";
  let transList: string[] = [];

  const THRESHOLD_POOR = 2_000_000;
  const THRESHOLD_AVG = 25_000_000;
  const THRESHOLD_MIDDLE = 200_000_000;
  const THRESHOLD_WEALTHY = 1_000_000_000;

  if (balanceVal < THRESHOLD_POOR) {
      status = "MEMBER / STUDENT";
      cardType = "Q-BANK BASIC";
      transList = [
          "• Today | -5,000       | Gui xe (Parking)             ",
          "• Today | -12,000      | Hao Hao (Noodles)            ",
          "• Ystdy | -20,000      | Viettel (Mobile Data)        ",
      ];
  } else if (balanceVal < THRESHOLD_AVG) {
      status = "SILVER MEMBER";
      cardType = "VISA DEBIT";
      transList = [
          "• Today | -45,000      | GrabBike (Ride)              ",
          "• Ystdy | -55,000      | Highlands (Coffee)           ",
      ];
  } else {
      status = "DIAMOND PRIORITY";
      cardType = "VISA SIGNATURE";
      transList = [
          "• Today | -150,000     | Gift Shop                    ",
          "• Ystdy | -3,000,000   | Fine Dining                  ",
      ];
  }

  const border = repeat('═', WIDTH);
  const line = repeat('─', WIDTH);

  // Graphical Card Logic
  const cardBorderTop = "╭──────────────────────────────────────────────────╮";
  const cardBorderBot = "╰──────────────────────────────────────────────────╯";
  const cardEmpty     = "│                                                  │";
  const chipLine      = "│   [|||]  )))                                     │";
  const numLine       = `│   **** **** **** ${String(accNum).slice(-4)}                        │`;
  const nameLine      = `│   ${pad(displayName, 30)}               │`;
  const typeLine      = `│   ${pad(cardType, 20)}              VALID: 12/29   │`;

  return `╔${border}╗
║ 🏦 Q-BANK / TOKEN VAULT                   [ 📶 4G | 🔋 85% ]                                                 ║
╠${border}╣
║ 💳 DIGITAL CARD PREVIEW                                                                                      ║
║                                                                                                              ║
║   ${cardBorderTop}                                                                        ║
║   ${chipLine}                                                                        ║
║   ${cardEmpty}                                                                        ║
║   ${numLine}                                                                        ║
║   ${cardEmpty}                                                                        ║
║   ${typeLine}                                                                        ║
║   ${nameLine}                                                                        ║
║   ${cardBorderBot}                                                                        ║
║                                                                                                              ║
╠${border}╣
║ 👤 CUSTOMER PROFILE                                                                                          ║
║    FULL NAME:   ${pad(displayName, 92)} ║
║    CREDIT SCR:  ${creditScore} (Very Good)  |  TIER: ${pad(status, 55)} ║
╠${border}╣
║ 💰 FINANCIAL SUMMARY (QTOKEN)                                                                                ║
║    CURRENT BALANCE:        ${pad(formatVND(balanceVal), 81)} ║
║    SAVINGS (Locked):       ${pad(formatVND(balanceVal * 0.2), 81)} ║
║    DEBT / LOANS:           0 Ⓠ                                                                               ║
╠${border}╣
║ 📉 LAST TRANSACTIONS                                                                                         ║
║ ${pad(transList[0] || "", WIDTH)} ║
║ ${pad(transList[1] || "", WIDTH)} ║
╚${border}╝`;
};

// --- NEW EXPORTS TO FIX IMPORTS ---

export const generateDiaryDisplay = (target: string, userCard: CardData | null, charCards: CardData[]) => {
  let data = findCard(target, userCard, charCards);
  if (!data && charCards.length > 0) data = charCards[0];
  if (!data) return "⚠️ NO DATA";

  const entries = data.diary || [];
  const border = repeat('═', WIDTH);
  const line = repeat('─', WIDTH);

  return `╔${border}╗
║ 📔 DIARY: ${pad(data.name.toUpperCase(), WIDTH - 12)} ║
╟${line}╢
${entries.length > 0 ? entries.map(e => 
`║ [${e.date}] ${pad(e.title, WIDTH - 15)} ║
║ ${pad(e.content, WIDTH - 4)} ║
╟${line}╢`).join('\n') : `║ (No entries found)                                                                                               ║`}
╚${border}╝`;
};

export const generateInspectDisplay = (target: string, userCard: CardData | null, charCards: CardData[]) => {
  let data = findCard(target, userCard, charCards);
  // If target is literally 'TARGET' (from generic button click), pick first char or user
  if (target === 'TARGET') {
      data = charCards.length > 0 ? charCards[0] : userCard;
  }
  
  if (!data) return "⚠️ NO TARGET IDENTIFIED";

  const border = repeat('═', WIDTH);
  const line = repeat('─', WIDTH);
  const s = data.status || {};
  
  return `╔${border}╗
║ 👁️ INSPECTION RESULT: ${pad(data.name.toUpperCase(), WIDTH - 24)} ║
╟${line}╢
║ 👤 ROLE: ${pad(data.role || 'Unknown', 40)} | 🎂 AGE: ${pad(String(data.age), 10)} | ⚧ SEX: ${pad(data.gender || '?', 10)} ║
║ 📏 HEIGHT: ${pad(data.height || '?', 20)}                                                                ║
╟${line}╢
║ 📊 VITALS & STATUS                                                                                           ║
║    ❤️ HP:      ${pad(s.hp || '100/100', 30)}                                                     ║
║    🧠 STRESS:  ${pad(s.stress || 'Normal', 30)}                                                     ║
║    🔥 AROUSAL: ${pad(s.arousal || 'None', 30)}                                                     ║
╟${line}╢
║ 📝 TRAITS                                                                                                    ║
║    ${pad((data.traits || []).join(', '), WIDTH - 8)}   ║
╟${line}╢
║ 🤫 SECRET (GM ONLY)                                                                                          ║
║    ${pad(s.secret || 'None detected.', WIDTH - 8)}   ║
╚${border}╝`;
};

export const generateScanDisplay = () => {
  const border = repeat('═', WIDTH);
  return `╔${border}╗
║ 📡 ENVIRONMENTAL SCAN                                                                                        ║
║ 📍 LOCATION: Unknown Sector                                                                                  ║
║ 🌡️ TEMP: 24°C | 💧 HUMIDITY: 45%                                                                            ║
╚${border}╝`;
};

export const generateHelpDisplay = () => {
    const border = repeat('═', WIDTH);
    return `╔${border}╗
║ ❓ HELP & GUIDE                                                                                              ║
║                                                                                                              ║
║ COMMANDS:                                                                                                    ║
║  /phone [name]   - Check phone                                                                               ║
║  /inspect [name] - Check stats                                                                               ║
║  /bank [name]    - Check finances                                                                            ║
║                                                                                                              ║
║ TIPS:                                                                                                        ║
║  - Use 'Brainstorm' to get ideas.                                                                            ║
║  - Upload a .txt file to import characters.                                                                  ║
╚${border}╝`;
};
