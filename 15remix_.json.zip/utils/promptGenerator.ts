import { AppConfig } from "../types";
import * as Lib from "./promptLib";
import { NM_PLUS_1_6_PROMPT, QUASAR_PHRASES } from "../constants";
import { CUSTOM_USER_DIRECTIVES } from "./custom_directives";

export const generateDynamicContext = (config: AppConfig): string => {
  let anchors = "";
  const userName = config.userCard?.name || "User";

  const userOutfit = config.userCard?.outfitDescription;

  let charOutfitsText = "";
  let missingOutfits: string[] = [];

  if (userOutfit) {
    charOutfitsText += `User (${userName}): ${userOutfit}\n`;
  } else if (config.userCard) {
    missingOutfits.push(userName);
  }

  if (config.characterCards && config.characterCards.length > 0) {
    config.characterCards.forEach((char) => {
      if (char.outfitDescription) {
        charOutfitsText += `${char.name}: ${char.outfitDescription}\n`;
      } else {
        missingOutfits.push(char.name);
      }
    });
  }

  if (charOutfitsText) {
    anchors += `
[CURRENT OUTFIT & INVENTORY STATE]
${charOutfitsText}
- OUTFIT & INVENTORY RULES (ABSOLUTE PHYSICAL LAWS):
  1. The characters are wearing exactly what is listed above. DO NOT invent clothing.
  2. STRICT INVENTORY TRACKING: Where is their phone? In pocket? Hand? Where is their bag? Do they have a drink? You MUST track the physical location of every item. A person with full hands cannot easily open a door without shifting items.
  3. SPATIAL MEMORY: If someone puts a glass of water on a table, IT IS STILL ON THE TABLE until moved. Do not forget previously introduced items.
  4. NO TELEPORTATION: If a character is on the couch, they are on the couch until you explicitly describe them walking elsewhere.
  5. CULTURAL & LOGICAL PHYSICS:
     - Shoes MUST be taken off when entering a house/apartment (unless stated otherwise). If they don't, the floor gets dirty.
     - Accessories (watches, phones, bags) MUST be removed before taking a shower or sleeping.
- MANDATORY STATE UPDATE TAGS: If any article of clothing or inventory changes (e.g., putting phone in pocket, taking off jacket), you MUST append this raw tag at the exact end of your response:
<<<UPDATE_OUTFIT: [CharacterName] | [New detailed outfit and inventory state]>>>
IMPORTANT: When updating an outfit, DO NOT summarize it into one sentence. You MUST copy the entire previous verbose list (including Top, Bottom, Underwear, Shoes, Hair, Accessories, Status) and ONLY change the specific item that was altered. If you summarize it, the system will break.
`;
  }

  if (missingOutfits.length > 0) {
    anchors += `
[INITIALIZE MISSING OUTFITS]
The following characters need outfit/inventory state defined: ${missingOutfits.join(", ")}. Please use the <<<UPDATE_OUTFIT...>>> tag in your first response.
`;
  }

  if (config.currentLocation || config.currentTime || config.currentWeather) {
    anchors += `\n[ENVIRONMENT & TIME STATE]\n`;
    if (config.currentTime) anchors += `Current Time: ${config.currentTime}\n`;
    if (config.currentLocation)
      anchors += `Current Location: ${config.currentLocation}\n`;
    if (config.currentWeather)
      anchors += `Weather/Event: ${config.currentWeather}\n`;
    anchors += `(Note: Please advance time naturally as the scene progresses.)
- STRICT TIME SYNC: The "Current Time" is the system reality.
- TIME CHECKS: If a character needs to know the time, they MUST perform a physical action to check it (e.g. looking at a watch or phone).
- MANDATORY SYSTEM UPDATE TAGS: If time, location, or outfit changes, YOU MUST append <<<TIME_UPDATE: ...>>>, <<<LOCATION_UPDATE: ...>>>, or <<<UPDATE_OUTFIT: ...>>> at the very end of your response.
`;
  }

  if (config.autokiuc) {
    anchors += `\n[LONG-TERM MEMORY (PASSIVE KNOWLEDGE)]\nThe following is a summary of past events. Use this as passive background knowledge. Do not arbitrarily bring these events up in dialogue unless it is naturally relevant to the current situation:\n${config.autokiuc}\n`;
  }

  // CORE ESSENTIALS
  anchors += Lib.getUserIdentityBlock(config);
  anchors += Lib.getRelationshipBlock(config);
  anchors += Lib.getLoreBlock(config);
  anchors += Lib.getCharacterRosterBlock(config);
  anchors += Lib.getArchetypeEnforcementBlock();
  anchors += Lib.getAdvancedPatchesBlock();

  // FINAL KILL-SWITCH OVERRIDE
  anchors += `
[CORE LAWS OF THE SIMULATION]
Respect the rules outlined in the PROSE ELEVATION & WRITING QUALITY STANDARDS and the OPEN WORLD & CHARACTER REALISM FRAMEWORK. 
1. SPATIAL REALISM & NO TELEPATHY: Maintain strict physical constraints and object permanence. Characters cannot magically know what happens in another room. No teleportation. Do not drop items/outfits and forget about them.
2. OPEN WORLD & ORGANIC NPCS (NO COCKBLOCKING): The world does not pause for the user. Spawn NPCs dynamically and organically based on the environment, NOT specifically to interrupt intimate moments. NPCs have their own lives. 
3. CONTINUITY AFTER INTERRUPTION: If an NPC or event interrupts a private moment, DO NOT WIPE THE MEMORY of what was happening. If the characters were undressing, they are still undressed. Maintain absolute scene cohesion!
4. Show, Don't Tell: Write calmly and naturally. Never explain character mental intent. Avoid melodrama.
5. OPEN WORLD SIMULATOR: This is a living world. Emphasize the environment heavily: passing weather, specific times of day, the actions of stray animals, shifting daylight, background chatter of people, passing vehicles. The UI depends on you to update locations and time. Describe changing environments vividly! Never focus solely on the characters; the world MUST be a character itself.
`;

  anchors += Lib.getOutputFormatBlock();

  return anchors;
};
