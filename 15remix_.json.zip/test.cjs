const { jsonrepair } = require('jsonrepair');

let tests = [
  '{ "speechStyle": "Giọng điệu..."\n"\n"\n}',
  '{ "arr": [ "a", "b"\n"\n] }'
];

tests.forEach(str => {
  let cleaned = str.replace(/("(?:[^"\\\\]|\\\\.)*")[\s"]+\}/g, '$1\n}');
  cleaned = cleaned.replace(/("(?:[^"\\\\]|\\\\.)*")[\s"]+\]/g, '$1\n]');
  console.log("CLEANED:", cleaned);
});
