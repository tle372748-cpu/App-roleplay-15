import fs from 'fs';
const file = './services/aiService.ts';
let content = fs.readFileSync(file, 'utf8');

// Revert all to flash
content = content.replace(/model: \(\(typeof config !== "undefined" && config\.model\) \? config\.model : "gemini-3\.5-flash"\),/g, 'model: "gemini-3.5-flash",');

// Wait, the user specifically wants `generateScenarioWithAI` to use the chosen model.
// Let's modify generateScenarioWithAI to use config.model.

const scenarioIndex = content.indexOf('export const generateScenarioWithAI');
if (scenarioIndex !== -1) {
    const p1 = content.slice(0, scenarioIndex);
    let p2 = content.slice(scenarioIndex);
    p2 = p2.replace(/model: "gemini-3\.5-flash",/, 'model: config.model || "gemini-3.5-flash",');
    content = p1 + p2;
}

fs.writeFileSync(file, content);
