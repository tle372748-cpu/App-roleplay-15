const text = `-   **Tên đầy đủ:** Lục Cảnh Thần`;
const re = /^[\s\-\*]*(?:name|tên|tên đầy đủ|tên nhân vật|character|char|identity|họ tên|biệt danh|full name)\s*\**\s*[:=\-–]\s*\**\s*(.+)$/im;
console.log(text.match(re));
